/* One offline document is shared by every reader. Font preparation never
   constructs glyph trees or measures layout and yields between small batches. */
let documentTask,documentPages,fontTask;
const preparedFonts=new Set();
export function loadQuranDocument(normalize) {
 if(!documentTask)documentTask=fetch('/assets/quran-document-v386.json',{cache:'force-cache'})
  .then(async response=>{
   if(!response.ok)throw new Error('تعذر تجهيز صفحات القرآن.');
   const payload=await response.json(),pages=payload.pages;
   if(payload.version!==386||!Array.isArray(pages)||pages.length!==604||
      pages.some((page,index)=>page.page!==index+1||!Array.isArray(page.lines)))throw new Error('تعذر تجهيز صفحات القرآن.');
   documentPages=pages.map(normalize);
   return documentPages;
  }).catch(error=>{documentTask=null;documentPages=undefined;throw error});
 return documentTask;
}
export function loadedQuranDocumentPage(number) {
 return documentPages?.[number-1];
}
export function prepareQuranDocumentFonts({normalize,loadFont,getPriority,canWarm,schedule,onPages}) {
 if(fontTask)return fontTask;
 const idle=()=>new Promise(resolve=>schedule(resolve));
 fontTask=(async()=>{
  const pages=await loadQuranDocument(normalize);
  onPages?.(pages);
  const attempted=new Set(preparedFonts);
  let cursor=1;
  while(attempted.size<604) {
   await idle();
   if(!canWarm())continue;
   const anchor=Math.max(1,Math.min(604,Math.trunc(Number(getPriority())||1)));
   const batch=[];
   // The reader's own lookahead starts independently and takes priority over
   // this idle worker. Reprioritize here after every batch, including jumps.
   for(let distance=0;distance<=18&&batch.length<4;distance++)
    for(const number of distance?[anchor+distance,anchor-distance]:[anchor]) {
     if(number<1||number>604||attempted.has(number)||batch.length===4)continue;
     attempted.add(number);batch.push(number);
    }
   while(batch.length<4&&cursor<=604) {
    const number=cursor++;
    if(attempted.has(number))continue;
    attempted.add(number);batch.push(number);
   }
   await Promise.all(batch.map(async number=>{
    try {await loadFont(pages[number-1].font);preparedFonts.add(number)}catch{}
   }));
  }
  return {pages:pages.length,fonts:preparedFonts.size};
 })().finally(()=>{if(preparedFonts.size<604)fontTask=null});
 return fontTask;
}
