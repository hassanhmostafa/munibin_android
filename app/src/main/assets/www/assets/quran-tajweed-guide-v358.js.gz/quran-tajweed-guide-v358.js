// The legend follows the selected renderer's shipped palette. Sources are
// available from the offline guide; opening their websites needs a connection.
export const TAJWEED_SOURCES=[
 {label:'Quran.com — مفتاح ألوان مصحف التجويد',url:'https://quran.com/product-updates/introducing-the-new-tajweed-mushaf'},
 {label:'دار المعرفة — التعريف بمصحف التجويد',url:'https://tajweedquran-store.com/en/about-tajweed-quran/'},
 {label:'وزارة الأوقاف المصرية — المد والقصر',url:'https://awkafonline.gov.eg/content-sections/116/5024/المد-والقصر'},
 {label:'AlQuran Cloud — أحكام بيانات التجويد',url:'https://legacy.alquran.cloud/tajweed-guide'}
];
export function tajweedGuideEntries() {
 const entries=[
  {color:'#a5a5a5',title:'الرمادي · ما لا يُنطق عند الوصل',text:'مثل همزة الوصل واللام الشمسية وبعض الحروف المكتوبة التي لا تُلفظ. يراعى حكم الابتداء والوقف.'},
  {color:'#ce9e00',title:'الذهبي · المد الطبيعي',text:'مدّ حرف المد بمقدار حركتين، دون زيادة.'},
  {color:'#ff7b00',title:'البرتقالي · المد الجائز',text:'منه المنفصل والعارض للسكون. يمد المنفصل أربعًا أو خمسًا من طريق الشاطبية، ويجوز في العارض عند الوقف حركتان أو أربع أو ست.'},
  {color:'#f40000',title:'الأحمر · المد الواجب المتصل',text:'حرف مد بعده همزة في الكلمة نفسها؛ أربع أو خمس حركات في رواية حفص من طريق الشاطبية.'},
  {color:'#b50000',title:'الأحمر الداكن · المد اللازم',text:'حرف مد بعده سكون أصلي؛ يمد ست حركات.'},
  {color:'#09b000',title:'الأخضر · الغنة والإخفاء',text:'صوت يخرج من الخيشوم، ومقداره حركتان في المواضع المعلَّمة؛ ويشمل الإخفاء والإدغام بغنة.'},
  {color:'#2fadff',title:'الأزرق الفاتح · القلقلة',text:'إظهار نبرة الحرف الساكن من حروف «قطب جد» دون إضافة حركة إليه.'}
 ];
 entries.push({color:'#3f48e6',title:'الأزرق البنفسجي · التفخيم',text:'تغليظ صوت الحرف في الموضع المعلَّم، كما في الراء المفخمة.'});
 return entries;
}
