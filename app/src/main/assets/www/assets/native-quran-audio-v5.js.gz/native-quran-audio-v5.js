// Native Quran audio bridge. Downloaded files are read from the same Cache API
// store as the download manager. Online playback stays streaming, while native
// download requests can transparently recover after a device sleep/network pause.
const AUDIO_CACHE = 'munibin-quran-reciter-audio-v1';
let generation = 0;
const playbackUrls = new Set();
const playbackSourceMap = new Map();
try { window.__munibinQuranPlaybackSourceMap = playbackSourceMap; } catch (_) {}

function isIOSNative() {
  return window.__munibinNativePlatform === 'ios' ||
    (!!window.webkit?.messageHandlers?.['munibin-widget'] && !window.MunibinAndroid);
}

function isHusaryPerAyahSource(source) {
  try {
    const url = new URL(source, location.href);
    return url.protocol === 'https:' &&
      url.hostname === 'audio-cdn.tarteel.ai' &&
      /^\/quran\/husary\/\d{6}\.mp3$/.test(url.pathname);
  } catch (_) {
    return false;
  }
}

function abortError() {
  return new DOMException('Aborted', 'AbortError');
}

function throwIfAborted(signal) {
  if (signal?.aborted) throw abortError();
}

function sleep(ms, signal) {
  throwIfAborted(signal);
  return new Promise((resolve, reject) => {
    const timer = window.setTimeout(done, ms);
    const onAbort = () => {
      window.clearTimeout(timer);
      cleanup();
      reject(abortError());
    };
    function cleanup() { signal?.removeEventListener('abort', onAbort); }
    function done() { cleanup(); resolve(); }
    signal?.addEventListener('abort', onAbort, {once:true});
  });
}

export function quranPlaybackGeneration() {
  return generation;
}

export function releaseQuranPlayback() {
  generation += 1;
  for (const url of playbackUrls) URL.revokeObjectURL(url);
  playbackUrls.clear();
  playbackSourceMap.clear();
}

function nativeBackendAudioPath(source) {
  try {
    const url = new URL(source, location.href);
    const isAudioProxy = url.pathname.startsWith('/api/audio/') || url.pathname.startsWith('/manus-storage/');
    if (!isAudioProxy) return null;
    // Uploaded Munibin audio is represented by a same-origin backend path. In the
    // native apps, keep it on the local app server so /api is proxied normally.
    // The synthetic reciter proxy below deliberately accepts HTTPS sources only.
    if (url.origin === location.origin || url.hostname === 'munibin.com' || url.hostname === 'www.munibin.com') {
      return `${url.pathname}${url.search}${url.hash}`;
    }
  } catch (_) {}
  return null;
}

export function quranDownloadUrl(source) {
  const backendPath = nativeBackendAudioPath(source);
  if (backendPath) return backendPath;
  const native = window.__munibinNativeApp || window.MunibinAndroid ||
    window.webkit?.messageHandlers?.['munibin-widget'];
  return native ? `/__quran-reciter-offline-audio?source=${encodeURIComponent(source)}` : source;
}

// Resolve once the web view is actually usable again. A sleeping WKWebView or
// Android WebView can reject an in-flight fetch with "Load failed" even though
// connectivity itself is fine. Native resume events are dispatched by both apps.
export function waitForQuranForeground(signal) {
  throwIfAborted(signal);
  const ready = () => document.visibilityState !== 'hidden' && navigator.onLine !== false && window.__munibinNativeServerRefreshing !== true;
  if (ready()) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const windowEvents = ['pageshow', 'focus', 'online', 'munibin-native-resume', 'munibin-native-server-ready'];
    const cleanup = () => {
      document.removeEventListener('visibilitychange', check, true);
      windowEvents.forEach(name => window.removeEventListener(name, check, true));
      signal?.removeEventListener('abort', onAbort);
    };
    const finish = () => { cleanup(); resolve(); };
    const check = () => { if (ready()) finish(); };
    const onAbort = () => { cleanup(); reject(abortError()); };
    document.addEventListener('visibilitychange', check, true);
    windowEvents.forEach(name => window.addEventListener(name, check, true));
    signal?.addEventListener('abort', onAbort, {once:true});
    check();
  });
}

async function cacheResponseWithProgress(cache, key, response, progressScale, onProgress) {
  const total = Number(response.headers.get('content-length'));
  if (!response.body || !Number.isFinite(total) || total <= 0 || response.type === 'opaque') {
    await cache.put(key, response.clone());
    onProgress?.(Math.max(0, Math.trunc(progressScale || 0)));
    return;
  }

  const [cacheBody, progressBody] = response.body.tee();
  const cachedResponse = new Response(cacheBody, {
    status: response.status,
    statusText: response.statusText,
    headers: response.headers,
  });
  let loaded = 0;
  const progressTask = (async () => {
    const reader = progressBody.getReader();
    try {
      for (;;) {
        const {done, value} = await reader.read();
        if (done) break;
        loaded += value?.byteLength || 0;
        const scaled = Math.floor((loaded / total) * Math.max(0, progressScale || 0));
        onProgress?.(scaled);
      }
    } finally {
      try { reader.releaseLock(); } catch (_) {}
    }
  })();
  await Promise.all([cache.put(key, cachedResponse), progressTask]);
}

function httpError(status) {
  const error = new Error(`تعذر تنزيل ملف صوتي (${status}).`);
  error.quranHttpStatus = status;
  return error;
}

function canRetry(error, signal) {
  if (signal?.aborted) return false;
  const status = Number(error?.quranHttpStatus);
  if (Number.isFinite(status) && status > 0) return status === 408 || status === 425 || status === 429 || status >= 500;
  if (['QuotaExceededError', 'SecurityError', 'NotSupportedError'].includes(error?.name)) return false;
  return true;
}

// Fetch + body consumption + Cache.put are one retryable unit. That detail is
// important on iOS: sleep can interrupt the response after fetch() has already
// resolved, so retrying only fetch() still leaves a permanent "Load failed".
export async function downloadQuranAudioToCache(cache, source, options = {}) {
  const signal = options.signal;
  const progressScale = Math.max(0, Number(options.progressScale) || 0);
  const onProgress = typeof options.onProgress === 'function' ? options.onProgress : null;
  const maxAttempts = Math.max(1, Math.trunc(options.maxAttempts || 7));
  let lastError = null;
  let peakProgress = 0;
  const report = value => {
    peakProgress = Math.max(peakProgress, Math.max(0, Math.trunc(value || 0)));
    onProgress?.(peakProgress);
  };

  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    throwIfAborted(signal);
    if (navigator.onLine === false) await waitForQuranForeground(signal);
    try {
      const response = await fetch(quranDownloadUrl(source), {signal, cache:'no-store'});
      if (!response.ok || response.status === 206) throw httpError(response.status);
      await cacheResponseWithProgress(cache, source, response, progressScale, report);
      report(progressScale);
      return;
    } catch (error) {
      lastError = error;
      if (!canRetry(error, signal) || attempt >= maxAttempts - 1) break;
      // If the app slept, don't burn all retry attempts while the WebView is
      // suspended. Keep the download pending and continue automatically on wake.
      if (document.visibilityState === 'hidden' || navigator.onLine === false) {
        await waitForQuranForeground(signal);
      }
      await sleep(Math.min(5000, 450 * (attempt + 1)), signal);
    }
  }

  if (signal?.aborted) throw abortError();
  const message = String(lastError?.message || '');
  if (/load failed|failed to fetch|network|connection|offline|cancelled|canceled/i.test(message)) {
    throw new Error('انقطع تحميل الملف الصوتي مؤقتاً. أعد المحاولة بعد التأكد من بقاء التطبيق متصلاً بالإنترنت.');
  }
  throw lastError || new Error('تعذر إكمال تنزيل الملف الصوتي.');
}

export async function prepareQuranPlayback(tracks, run = generation) {
  const resolved = new Map();
  const created = [];
  const assertCurrent = () => {
    if (run !== generation) throw new DOMException('Playback cancelled', 'AbortError');
  };
  try {
    let cache;
    try { cache = await caches.open(AUDIO_CACHE); } catch (_) { /* Online playback still works. */ }
    for (const { audioUrl: source } of tracks) {
      assertCurrent();
      if (resolved.has(source)) continue; // A surah recording may cover many verses.
      const cached = cache ? await cache.match(source) : null;
      assertCurrent();
      if (cached?.ok && cached.status !== 206 && cached.type !== 'opaque') {
        let blob = await cached.blob();
        assertCurrent();
        if (blob.size > 0) {
          if (!blob.type || blob.type === 'application/octet-stream') {
            blob = blob.slice(0, blob.size, 'audio/mpeg');
          }
          const url = URL.createObjectURL(blob);
          created.push(url);
          resolved.set(source, url);
          continue;
        }
      }
      if (navigator.onLine === false) {
        throw new Error('ملف التلاوة غير متاح على الجهاز. أعد تنزيل هذا المدى عند توفر الإنترنت.');
      }
      // Hussary is one MP3 per ayah. Direct HTTPS on iOS avoids creating a new
      // localhost -> URLSession -> CDN stream for every manual/natural transition.
      const backendPath = nativeBackendAudioPath(source);
      resolved.set(source, backendPath || (isIOSNative() && isHusaryPerAyahSource(source)
        ? source
        : `/__quran-reciter-offline-audio?source=${encodeURIComponent(source)}`));
    }
    assertCurrent();
    created.forEach(url => playbackUrls.add(url));
    return tracks.map(track => {
      const source = track.quranSourceUrl || track.audioUrl;
      const audioUrl = resolved.get(track.audioUrl);
      if (audioUrl) playbackSourceMap.set(audioUrl, source);
      return { ...track, quranSourceUrl: source, audioUrl };
    });
  } catch (error) {
    created.forEach(url => URL.revokeObjectURL(url));
    throw error;
  }
}

window.addEventListener('pagehide', event => {
  if (!event.persisted) releaseQuranPlayback();
});
