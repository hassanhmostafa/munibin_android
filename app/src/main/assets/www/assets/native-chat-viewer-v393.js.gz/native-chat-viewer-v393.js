// Chat previews stay in the app. Opening a new tab replaces the iOS main WebView.
let activeViewer = null;
let sequence = 0;
const HISTORY_KEY = "__munibinChatAttachmentPreview";

export function chatAttachmentKind(item) {
  const mime = String(item?.mime || "").toLowerCase();
  if (/^image\/(png|jpeg|gif|webp|avif)$/.test(mime)) return "image";
  if (/^video\/(mp4|webm|quicktime)$/.test(mime)) return "video";
  if (mime === "application/pdf") return "pdf";
  if (mime === "text/plain") return "text";
  return "file";
}

export function openChatAttachment(item, event) {
  event?.preventDefault();
  if (!item || typeof item.url !== "string" || !item.url.startsWith("/api/support/attachments?ticket=")) return false;
  if (activeViewer) return false;

  const kind = chatAttachmentKind(item);
  const name = String(item.name || "مرفق");
  const opener = event?.currentTarget || document.activeElement;
  const id = `munibin-chat-preview-${++sequence}`;
  const dialog = document.createElement("div");
  dialog.className = "munibin-chat-viewer";
  dialog.setAttribute("role", "dialog");
  dialog.setAttribute("aria-modal", "true");
  dialog.setAttribute("aria-labelledby", `${id}-title`);
  dialog.tabIndex = -1;
  const toolbar = document.createElement("div");
  toolbar.className = "munibin-chat-viewer-toolbar";
  const closeButton = document.createElement("button");
  closeButton.type = "button";
  closeButton.className = "munibin-chat-viewer-close";
  closeButton.setAttribute("aria-label", "إغلاق المعاينة");
  closeButton.title = "إغلاق المعاينة";
  closeButton.textContent = "×";
  const title = document.createElement("div");
  title.className = "munibin-chat-viewer-title";
  title.id = `${id}-title`;
  title.dir = "auto";
  title.textContent = name;
  const download = document.createElement("a");
  download.className = "munibin-chat-viewer-download";
  download.href = item.url + "&download=1";
  download.setAttribute("download", name);
  download.setAttribute("aria-label", "تنزيل " + name);
  download.title = "تنزيل";
  download.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5M12 15V3"/></svg>';
  toolbar.append(closeButton, title, download);
  const content = document.createElement("div");
  content.className = "munibin-chat-viewer-content";
  const status = document.createElement("p");
  status.className = "munibin-chat-viewer-status";
  status.setAttribute("role", "status");
  status.dir = "rtl";
  status.textContent = kind === "file" ? "يمكنك تنزيل هذا الملف وفتحه في التطبيق المناسب." : "جارٍ فتح المرفق…";
  content.append(status);
  let media = null;
  if (kind === "image") {
    media = document.createElement("img");
    media.alt = name;
  } else if (kind === "video") {
    media = document.createElement("video");
    media.controls = true;
    media.playsInline = true;
    media.preload = "metadata";
    media.setAttribute("aria-label", name);
  } else if (kind === "pdf") {
    media = document.createElement("iframe");
    media.title = name;
    // The preview cannot navigate the parent app or open a new window.
    media.setAttribute("sandbox", "allow-same-origin");
    media.tabIndex = -1;
  } else if (kind === "text") {
    media = document.createElement("pre");
    media.dir = "auto";
  }
  if (media) {
    media.className = `munibin-chat-viewer-media munibin-chat-viewer-${kind}`;
    content.append(media);
  }
  dialog.append(toolbar, content);
  const inertSiblings = Array.from(document.body.children).filter(node => !node.hasAttribute("inert"));
  for (const node of inertSiblings) node.setAttribute("inert", "");
  document.body.append(dialog);
  document.documentElement.classList.add("munibin-chat-viewer-open");
  let pushed = false;
  let closing = false;
  let fallback = 0;
  let abort = null;
  let disposed = false;
  const dispose = () => {
    if (disposed) return;
    disposed = true;
    clearTimeout(fallback);
    abort?.abort();
    if (kind === "video") { media.pause(); media.removeAttribute("src"); media.load(); }
    window.removeEventListener("popstate", onPopState);
    document.removeEventListener("keydown", onKeyDown, true);
    document.removeEventListener("focusin", onFocus, true);
    dialog.remove();
    for (const node of inertSiblings) node.removeAttribute("inert");
    document.documentElement.classList.remove("munibin-chat-viewer-open");
    if (activeViewer?.id === id) activeViewer = null;
    if (opener?.isConnected) { try { opener.focus({preventScroll: true}); } catch (_) { opener.focus?.(); } }
  };
  const releaseHistoryMarker = () => {
    if (window.history.state?.[HISTORY_KEY] === id) {
      const state = {...window.history.state}; delete state[HISTORY_KEY];
      try { window.history.replaceState(state, "", window.location.href); } catch (_) {}
    }
  };
  const close = () => {
    if (closing || disposed) return;
    closing = true;
    if (pushed && window.history.state?.[HISTORY_KEY] === id) {
      try {
        window.history.back();
        // A close button must work even if native history cannot move.
        fallback = setTimeout(() => {
          releaseHistoryMarker();
          dispose();
        }, 200);
        return;
      } catch (_) {}
    }
    releaseHistoryMarker();
    dispose();
  };
  const onPopState = () => { releaseHistoryMarker(); dispose(); };
  const onFocus = event => { if (!dialog.contains(event.target) && !disposed) closeButton.focus({preventScroll: true}); };
  const onKeyDown = event => {
    if (event.key === "Escape") { event.preventDefault(); event.stopPropagation(); close(); }
    else if (event.key === "Tab") {
      const controls = [closeButton, download];
      const current = controls.indexOf(document.activeElement);
      if (current >= 0 || !dialog.contains(document.activeElement)) {
        event.preventDefault(); controls[event.shiftKey ? (current <= 0 ? controls.length - 1 : current - 1) : (current + 1) % controls.length].focus();
      }
    }
  };
  activeViewer = {id, close};
  closeButton.addEventListener("click", close);
  dialog.addEventListener("click", event => { if (event.target === dialog || event.target === content) close(); });
  window.addEventListener("popstate", onPopState);
  document.addEventListener("keydown", onKeyDown, true);
  document.addEventListener("focusin", onFocus, true);
  try {
    const state = window.history.state;
    window.history.pushState({...((state && typeof state === "object") ? state : {}), [HISTORY_KEY]: id}, "", window.location.href);
    pushed = true;
  } catch (_) {}
  closeButton.focus({preventScroll: true});

  const loaded = () => { if (!disposed) status.hidden = true; };
  const failed = () => { if (!disposed) { status.hidden = false; status.textContent = "تعذر عرض المرفق. يمكنك إغلاق المعاينة أو تنزيل الملف."; } };
  if (kind === "text") {
    abort = new AbortController();
    fetch(item.url, {credentials: "same-origin", signal: abort.signal}).then(response => {
      if (!response.ok) throw new Error("attachment unavailable");
      return response.text();
    }).then(text => { if (!disposed) { media.textContent = text; loaded(); } }).catch(error => { if (error.name !== "AbortError") failed(); });
  } else if (media) {
    media.addEventListener(kind === "video" ? "loadedmetadata" : "load", loaded);
    media.addEventListener("error", failed);
    media.src = item.url;
  }
  return true;
}
