/* Munibin production feature layer v220: account-synced Quran wird/bookmarks, Qibla, persistence, iqama. Sleeping adhkar now lives natively in the main Adhkar page. */
(() => {
  'use strict';
  if (window.__munibinFeaturesV185) return;
  window.__munibinFeaturesV185 = true;

  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const clamp = (n,a,b) => Math.max(a,Math.min(b,n));
  const isQuran = () => location.pathname.startsWith('/quran') || !!$('.qcf1441-preview');
  const STORAGE = {
    bookmarks:'munibin:quran-bookmarks:v1', wird:'munibin:quran-wirds:v1', wirdHubTab:'munibin:quran-hub-tab:v1',
    account:'munibin:quran-account:last-user:v1', cloudDirty:'munibin:quran-cloud-dirty:v1', guestImport:'munibin:quran-guest-wird-imported:v1',
    bookmarkReplaceSameColor:'munibin:quran-bookmarks:v1:replace-same-color',
    bookmarkColorNames:'munibin:quran-bookmarks:v1:color-names',
    bookmarkLastColor:'munibin:quran-bookmarks:v1:last-color'
  };
  const COLORS = [
    {name:'ذهبي',value:'#d9901a'},{name:'أخضر',value:'#4b8e50'},{name:'نيلي',value:'#5269b8'},
    {name:'برقوقي',value:'#955182'},{name:'طوبي',value:'#b9564e'}
  ];
  const DEFAULT_BOOKMARK_NAMES={
    '#d9901a':'قراءة','#4b8e50':'مراجعة','#5269b8':'حفظ','#955182':'سماع','#b9564e':'تدبر'
  };
  const LEGACY_BOOKMARK_COLORS=new Map([['#c9892b','#d9901a'],['#2d8b72','#4b8e50'],['#6470b8','#5269b8'],['#8b5d8d','#955182'],['#b86770','#b9564e']]);
  function bookmarkColor(value){const raw=String(value||'').toLowerCase();return LEGACY_BOOKMARK_COLORS.get(raw)||COLORS.find(c=>c.value===raw)?.value||value||COLORS[0].value;}
  function replaceSameBookmarkColorEnabled(){return localStorage.getItem(STORAGE.bookmarkReplaceSameColor)!=='0';}
  function bookmarkColorNames(){try{const x=JSON.parse(localStorage.getItem(STORAGE.bookmarkColorNames)||'{}');return x&&typeof x==='object'&&!Array.isArray(x)?x:{};}catch{return {};}}
  function bookmarkDefaultNameForColor(color){return DEFAULT_BOOKMARK_NAMES[bookmarkColor(color)]||'قراءة';}
  function bookmarkNameForColor(color){const names=bookmarkColorNames(),key=bookmarkColor(color),saved=String(names[key]||'').trim();if(saved)return saved;try{const previous=bookmarks().filter(b=>bookmarkColor(b?.color)===key&&String(b?.name||'').trim()).sort((a,b)=>(Number(b?.updatedAt||b?.createdAt)||0)-(Number(a?.updatedAt||a?.createdAt)||0))[0];const value=String(previous?.name||'').trim();if(value)return value;}catch{}return bookmarkDefaultNameForColor(key);}
  function rememberBookmarkName(color,name){try{const names=bookmarkColorNames(),key=bookmarkColor(color),value=String(name||'').trim()||bookmarkDefaultNameForColor(key);names[key]=value;localStorage.setItem(STORAGE.bookmarkColorNames,JSON.stringify(names));}catch{}}
  function bookmarkLocationText(key){const [s,a]=String(key||'').split(':');const surah=SURAH_NAMES[Number(s)]||`سورة ${s||'—'}`;return `${surah} · آية ${a||'—'}`;}
  const SURAH_NAMES=['','الفاتحة','البقرة','آل عمران','النساء','المائدة','الأنعام','الأعراف','الأنفال','التوبة','يونس','هود','يوسف','الرعد','إبراهيم','الحجر','النحل','الإسراء','الكهف','مريم','طه','الأنبياء','الحج','المؤمنون','النور','الفرقان','الشعراء','النمل','القصص','العنكبوت','الروم','لقمان','السجدة','الأحزاب','سبأ','فاطر','يس','الصافات','ص','الزمر','غافر','فصلت','الشورى','الزخرف','الدخان','الجاثية','الأحقاف','محمد','الفتح','الحجرات','ق','الذاريات','الطور','النجم','القمر','الرحمن','الواقعة','الحديد','المجادلة','الحشر','الممتحنة','الصف','الجمعة','المنافقون','التغابن','الطلاق','التحريم','الملك','القلم','الحاقة','المعارج','نوح','الجن','المزمل','المدثر','القيامة','الإنسان','المرسلات','النبأ','النازعات','عبس','التكوير','الانفطار','المطففين','الانشقاق','البروج','الطارق','الأعلى','الغاشية','الفجر','البلد','الشمس','الليل','الضحى','الشرح','التين','العلق','القدر','البينة','الزلزلة','العاديات','القارعة','التكاثر','العصر','الهمزة','الفيل','قريش','الماعون','الكوثر','الكافرون','النصر','المسد','الإخلاص','الفلق','الناس'];
  let navPromise, lastVerseKey='', featureOverlay=null, audioPanelSeen=null, audioBigPlayIntent=null, expandedWirdId=null;
  let headingStop=null, accountScope=localStorage.getItem(STORAGE.account)||'guest', cloudUserId=accountScope!=='guest'?accountScope:null, cloudSyncTimer=0;

  function scopedKey(key,scope=accountScope){
    if(key===STORAGE.wird||key===STORAGE.bookmarks)return `${key}:account:${scope||'guest'}`;
    return key;
  }
  function cloudDirtyKey(scope=accountScope){return `${STORAGE.cloudDirty}:account:${scope||'guest'}`;}
  function guestImportKey(scope=accountScope){return `${STORAGE.guestImport}:account:${scope||'guest'}`;}
  function guestWirdLinksKey(scope=cloudUserId||accountScope){return `munibin:quran-wird-guest-links:v1:${scope||'guest'}`;}
  function readGuestWirdLinks(scope=cloudUserId||accountScope){try{const x=JSON.parse(localStorage.getItem(guestWirdLinksKey(scope))||'[]');return new Set(Array.isArray(x)?x.filter(Boolean).map(String):[]);}catch{return new Set();}}
  function writeGuestWirdLinks(links,scope=cloudUserId||accountScope){try{localStorage.setItem(guestWirdLinksKey(scope),JSON.stringify([...links]));}catch{}}
  function jsonGetForScope(key,scope,fallback){try{const x=JSON.parse(localStorage.getItem(scopedKey(key,scope))||'null');return x??fallback;}catch{return fallback;}}
  function guestBookmarkLinksKey(scope=cloudUserId||accountScope){return `munibin:quran-bookmark-guest-links:v1:${scope||'guest'}`;}
  function readGuestBookmarkLinks(scope=cloudUserId||accountScope){try{const x=JSON.parse(localStorage.getItem(guestBookmarkLinksKey(scope))||'[]');return new Set(Array.isArray(x)?x.filter(Boolean).map(String):[]);}catch{return new Set();}}
  function writeGuestBookmarkLinks(links,scope=cloudUserId||accountScope){try{localStorage.setItem(guestBookmarkLinksKey(scope),JSON.stringify([...links]));}catch{}}
  function plannerStamp(x){const raw=x?.updatedAt??x?.createdAt??0,n=Number(raw);if(Number.isFinite(n)&&n>0)return n;const d=typeof raw==='string'?Date.parse(raw):NaN;return Number.isFinite(d)?d:0;}
  function wirdKey(w){return w?.id?`id:${w.id}`:`legacy:${JSON.stringify([w?.name||'',w?.ranges||[],w?.selectedPages||[]])}`;}
  function bookmarkKey(b){return b?.id?`id:${b.id}`:`verse:${b?.verseKey||''}`;}
  function mergeWirdPair(a,b){
    if(!a)return b;if(!b)return a;
    const as=plannerStamp(a),bs=plannerStamp(b);
    if(bs>as)return b;
    if(as>bs)return a;
    return b;
  }
  function mergeWirdLists(base,incoming){
    const out=[],index=new Map();
    for(const w of Array.isArray(base)?base:[]){const k=wirdKey(w);if(index.has(k))continue;index.set(k,out.length);out.push(w);}
    for(const w of Array.isArray(incoming)?incoming:[]){const k=wirdKey(w),i=index.get(k);if(i==null){index.set(k,out.length);out.push(w);}else out[i]=mergeWirdPair(out[i],w);}
    return out;
  }
  function mergeWirdProgressForExisting(base,other){const map=new Map((Array.isArray(other)?other:[]).map(w=>[wirdKey(w),w]));return (Array.isArray(base)?base:[]).map(w=>mergeWirdPair(w,map.get(wirdKey(w))));}
  function mergeBookmarkLists(base,incoming){
    const out=[],index=new Map();
    for(const b of Array.isArray(base)?base:[]){const k=bookmarkKey(b);if(index.has(k))continue;index.set(k,out.length);out.push(b);}
    for(const b of Array.isArray(incoming)?incoming:[]){const k=bookmarkKey(b),i=index.get(k);if(i==null){index.set(k,out.length);out.push(b);}else if(plannerStamp(b)>plannerStamp(out[i]))out[i]=b;}
    return out;
  }
  function mergeBookmarkProgressForExisting(base,other){const map=new Map((Array.isArray(other)?other:[]).map(b=>[bookmarkKey(b),b]));return (Array.isArray(base)?base:[]).map(b=>{const x=map.get(bookmarkKey(b));return x&&plannerStamp(x)>plannerStamp(b)?x:b;});}
  function reconcileGuestPlannerFromAccount(accountWirds,accountBookmarks){
    if(!cloudUserId||accountScope==='guest')return;
    try{
      const aw=Array.isArray(accountWirds)?accountWirds:[],ab=Array.isArray(accountBookmarks)?accountBookmarks:[];
      const guestW=jsonGetForScope(STORAGE.wird,'guest',[]),wLinks=readGuestWirdLinks(cloudUserId),wMap=new Map(aw.map(w=>[wirdKey(w),w]));let wc=false;
      for(const key of [...wLinks])if(!wMap.has(key)){const i=guestW.findIndex(w=>wirdKey(w)===key);if(i>=0){guestW.splice(i,1);wc=true;}wLinks.delete(key);}
      for(const w of aw){const key=wirdKey(w),i=guestW.findIndex(x=>wirdKey(x)===key),next=i>=0?mergeWirdPair(w,guestW[i]):w;if(i>=0){if(JSON.stringify(guestW[i])!==JSON.stringify(next)){guestW[i]=next;wc=true;}}else{guestW.push(next);wc=true;}wLinks.add(key);}
      if(wc)localStorage.setItem(scopedKey(STORAGE.wird,'guest'),JSON.stringify(guestW));writeGuestWirdLinks(wLinks,cloudUserId);
      const guestB=jsonGetForScope(STORAGE.bookmarks,'guest',[]),bLinks=readGuestBookmarkLinks(cloudUserId),bMap=new Map(ab.map(b=>[bookmarkKey(b),b]));let bc=false;
      for(const key of [...bLinks])if(!bMap.has(key)){const i=guestB.findIndex(b=>bookmarkKey(b)===key);if(i>=0){guestB.splice(i,1);bc=true;}bLinks.delete(key);}
      for(const b of ab){const key=bookmarkKey(b),i=guestB.findIndex(x=>bookmarkKey(x)===key),next=i>=0&&plannerStamp(guestB[i])>plannerStamp(b)?guestB[i]:b;if(i>=0){if(JSON.stringify(guestB[i])!==JSON.stringify(next)){guestB[i]=next;bc=true;}}else{guestB.push(next);bc=true;}bLinks.add(key);}
      if(bc)localStorage.setItem(scopedKey(STORAGE.bookmarks,'guest'),JSON.stringify(guestB));writeGuestBookmarkLinks(bLinks,cloudUserId);persistCriticalState();
    }catch{}
  }
  function reconcileGuestWirdsFromAccount(accountWirds){reconcileGuestPlannerFromAccount(accountWirds,jsonGetForScope(STORAGE.bookmarks,accountScope,[]));}
  function jsonGet(key, fallback){ return jsonGetForScope(key,accountScope,fallback); }
  function jsonSet(key, value){ try { localStorage.setItem(scopedKey(key), JSON.stringify(value)); if((key===STORAGE.wird||key===STORAGE.bookmarks)&&accountScope!=='guest')reconcileGuestPlannerFromAccount(jsonGetForScope(STORAGE.wird,accountScope,[]),jsonGetForScope(STORAGE.bookmarks,accountScope,[])); if(key===STORAGE.wird||key===STORAGE.bookmarks){localStorage.setItem(cloudDirtyKey(),String(Date.now()));scheduleCloudSync();} persistCriticalState(); } catch {} }
  function guestPlannerSnapshot(){const wirds=jsonGetForScope(STORAGE.wird,'guest',[]),bookmarks=jsonGetForScope(STORAGE.bookmarks,'guest',[]),w=Array.isArray(wirds)?wirds:[],b=Array.isArray(bookmarks)?bookmarks:[];return{wirds:w,bookmarks:b,version:Math.max(0,...w.map(plannerStamp),...b.map(plannerStamp))};}
  function writePlannerLocal(payload){const updatedAt=Number(payload?.updatedAt)||Date.now(),nextWirds=Array.isArray(payload?.wirds)?payload.wirds:[],nextBookmarks=Array.isArray(payload?.bookmarks)?payload.bookmarks:[],prevWirds=jsonGetForScope(STORAGE.wird,accountScope,[]),prevBookmarks=jsonGetForScope(STORAGE.bookmarks,accountScope,[]),contentChanged=JSON.stringify(prevWirds)!==JSON.stringify(nextWirds)||JSON.stringify(prevBookmarks)!==JSON.stringify(nextBookmarks);localStorage.setItem(scopedKey(STORAGE.wird),JSON.stringify(nextWirds));localStorage.setItem(scopedKey(STORAGE.bookmarks),JSON.stringify(nextBookmarks));localStorage.setItem(cloudDirtyKey(),String(updatedAt));if(accountScope!=='guest')reconcileGuestPlannerFromAccount(nextWirds,nextBookmarks);applyBookmarkTints();if(featureOverlay&&contentChanged){const oldBody=featureOverlay.querySelector('.munibin-v185-body'),scrollTop=oldBody?.scrollTop||0,tab=savedWirdHubTab();openWirdHub(tab).then(()=>requestAnimationFrame(()=>{const body=featureOverlay?.querySelector('.munibin-v185-body');if(body)body.scrollTop=scrollTop;}));}}
  function loadNav(){
    if (!navPromise) navPromise = fetch('/api/quran/navigation', {cache:'force-cache'}).then(r => { if(!r.ok) throw new Error('navigation'); return r.json(); });
    return navPromise;
  }
  function b64EncodeUnicode(value){const bytes=new TextEncoder().encode(JSON.stringify(value));let bin='';bytes.forEach(b=>bin+=String.fromCharCode(b));return btoa(bin);}
  function b64DecodeUnicode(value){const bin=atob(value);const bytes=Uint8Array.from(bin,c=>c.charCodeAt(0));return JSON.parse(new TextDecoder().decode(bytes));}
  async function trpcQuery(path,input=null){
    const u=`/api/trpc/${path}?input=${encodeURIComponent(JSON.stringify({json:input}))}`;const r=await fetch(u,{credentials:'include',cache:'no-store'});if(!r.ok)throw new Error(`${path}:${r.status}`);const j=await r.json();return j?.result?.data?.json??j?.result?.data??null;
  }
  async function trpcMutation(path,input){
    const r=await fetch(`/api/trpc/${path}`,{method:'POST',credentials:'include',headers:{'content-type':'application/json'},body:JSON.stringify({json:input})});if(!r.ok)throw new Error(`${path}:${r.status}`);const j=await r.json();return j?.result?.data?.json??j?.result?.data??null;
  }
  function plannerPayload(){return{version:1,updatedAt:Math.max(Number(localStorage.getItem(cloudDirtyKey()))||0,...wirids().map(w=>Number(w.updatedAt)||0),...bookmarks().map(b=>Number(b.updatedAt||b.createdAt)||0)),wirds:wirids(),bookmarks:bookmarks()};}
  function encodePlannerChunks(payload){const b64=b64EncodeUnicode(payload),size=1800;return Array.from({length:Math.ceil(b64.length/size)},(_,i)=>`qpl1:${i}:${b64.slice(i*size,(i+1)*size)}`);}
  function decodePlannerRecord(rec){try{const parts=(rec?.matnIds||[]).filter(x=>typeof x==='string'&&x.startsWith('qpl1:')).sort((a,b)=>Number(a.split(':')[1])-Number(b.split(':')[1])).map(x=>x.split(':').slice(2).join(':')).join('');return parts?b64DecodeUnicode(parts):null;}catch{return null;}}
  function migrateLegacyToScope(scope){
    for(const key of [STORAGE.wird,STORAGE.bookmarks]){const dest=scopedKey(key,scope);if(localStorage.getItem(dest)==null&&localStorage.getItem(key)!=null)localStorage.setItem(dest,localStorage.getItem(key));}
  }
  function migrateLegacySleepToNativeAdhkar(){
    const marker='munibin:adhkar-native-sleep-migrated:v203';if(localStorage.getItem(marker)==='1')return;
    const idMap={kursi:'sleep-kursi',muawwidhat:'sleep-muawwidhat','baqarah-end':'sleep-baqarah-end',tasbeeh:'sleep-tasbeeh',bismika:'sleep-bismika',fitrah:'sleep-fitrah',side:'sleep-side',punishment:'sleep-punishment'};
    const progressPrefix='munibin:sleep-adhkar-progress:v1:';
    const keys=[];for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.startsWith(progressPrefix))keys.push(k);}
    for(const key of keys){try{const raw=JSON.parse(localStorage.getItem(key)||'{}');const m=key.match(/^munibin:sleep-adhkar-progress:v1:(\d{4}-\d{2}-\d{2})(?::account:([^:]+))?$/);if(!m||!raw||typeof raw!=='object')continue;const day=m[1],scope=m[2]||'guest',nativeScope=scope==='guest'?'guest':`account-${scope}`,dest=`motoon-adhkar-progress:${nativeScope}:${day}:sleep`,current=JSON.parse(localStorage.getItem(dest)||'{}');for(const [oldId,value] of Object.entries(raw)){const newId=idMap[oldId];if(newId&&Number.isFinite(Number(value)))current[newId]=Math.max(Number(current[newId])||0,Math.max(0,Math.trunc(Number(value))));}localStorage.setItem(dest,JSON.stringify(current));}catch{}}
    try{const guestGoal=Number(localStorage.getItem('munibin:adhkar-sleep-goal:v1:account:guest')??localStorage.getItem('munibin:adhkar-sleep-goal:v1'));if(Number.isFinite(guestGoal)&&guestGoal>0){const key='motoon-adhkar-goal-streak:guest:v1',state=JSON.parse(localStorage.getItem(key)||'{"goals":null,"metDays":{}}'),goals=state.goals&&typeof state.goals==='object'?state.goals:{morningGoal:0,eveningGoal:0};goals.sleepGoal=Math.min(8,Math.max(0,Math.trunc(guestGoal)));state.goals=goals;state.metDays=state.metDays&&typeof state.metDays==='object'?state.metDays:{};localStorage.setItem(key,JSON.stringify(state));}}catch{}
    localStorage.setItem(marker,'1');
  }
  async function refreshAccountAndCloud(){
    if(!navigator.onLine)return;try{const me=await trpcQuery('auth.me',null);const next=me?.id?String(me.id):'guest';const changed=next!==accountScope;if(changed){accountScope=next;cloudUserId=next==='guest'?null:next;if(cloudUserId)localStorage.setItem(STORAGE.account,next);else localStorage.removeItem(STORAGE.account);migrateLegacyToScope(next);applyBookmarkTints();if(featureOverlay)openWirdHub(savedWirdHubTab());}else cloudUserId=next==='guest'?null:next;if(cloudUserId){await syncPlannerCloud();}}catch{}
  }
  async function mergeAndSyncPlannerRemote(remote,saveRemote){
    const local=plannerPayload(),remotePayload=remote&&typeof remote==='object'?remote:null,remoteNewer=remotePayload&&Number(remotePayload.updatedAt||0)>Number(local.updatedAt||0),membership=remoteNewer?remotePayload:local,older=remoteNewer?local:remotePayload;
    const accountWirds=mergeWirdProgressForExisting(Array.isArray(membership?.wirds)?membership.wirds:[],Array.isArray(older?.wirds)?older.wirds:[]),accountBookmarks=mergeBookmarkProgressForExisting(Array.isArray(membership?.bookmarks)?membership.bookmarks:[],Array.isArray(older?.bookmarks)?older.bookmarks:[]);
    reconcileGuestPlannerFromAccount(accountWirds,accountBookmarks);
    const guest=guestPlannerSnapshot(),mergedWirds=mergeWirdLists(accountWirds,guest.wirds),mergedBookmarks=mergeBookmarkLists(accountBookmarks,guest.bookmarks),content={wirds:mergedWirds,bookmarks:mergedBookmarks};
    const remoteContent={wirds:Array.isArray(remotePayload?.wirds)?remotePayload.wirds:[],bookmarks:Array.isArray(remotePayload?.bookmarks)?remotePayload.bookmarks:[]},needsSave=!remotePayload||JSON.stringify(content)!==JSON.stringify(remoteContent)||Number(local.updatedAt||0)>Number(remotePayload?.updatedAt||0);
    let finalPayload={version:1,updatedAt:Math.max(Number(membership?.updatedAt)||0,Number(local.updatedAt)||0,Number(remotePayload?.updatedAt)||0),...content};
    if(needsSave){finalPayload.updatedAt=Math.max(Date.now(),finalPayload.updatedAt)+1;writePlannerLocal(finalPayload);const result=await saveRemote(finalPayload);if(result&&typeof result==='object'&&(Array.isArray(result.wirds)||Array.isArray(result.bookmarks)))finalPayload={updatedAt:Number(result.updatedAt)||finalPayload.updatedAt,wirds:Array.isArray(result.wirds)?result.wirds:finalPayload.wirds,bookmarks:Array.isArray(result.bookmarks)?result.bookmarks:finalPayload.bookmarks};}
    else if(remoteNewer||JSON.stringify(local.wirds)!==JSON.stringify(finalPayload.wirds)||JSON.stringify(local.bookmarks)!==JSON.stringify(finalPayload.bookmarks))writePlannerLocal(finalPayload);
    reconcileGuestPlannerFromAccount(finalPayload.wirds,finalPayload.bookmarks);localStorage.setItem(guestImportKey(cloudUserId),String(guest.version));persistCriticalState();return finalPayload;
  }
  async function syncPlannerCloud(){
    if(!cloudUserId||!navigator.onLine)return;
    try{const remote=await trpcQuery('quranPlanner.get',null);await mergeAndSyncPlannerRemote(remote,payload=>trpcMutation('quranPlanner.sync',{updatedAt:payload.updatedAt,wirds:payload.wirds,bookmarks:payload.bookmarks}));return;}catch{}
    try{const list=await trpcQuery('wirds.list',null)||[],rec=list.find(x=>x?.id==='quran_planner_v1'||x?.id===`quran_planner_v1_u${cloudUserId}`||x?.name?.startsWith('__QPL__|QURAN|')),remote=decodePlannerRecord(rec);await mergeAndSyncPlannerRemote(remote,async payload=>{await trpcMutation('wirds.save',{id:'quran_planner_v1',name:`__QPL__|QURAN|${payload.updatedAt}`,matnIds:encodePlannerChunks(payload),dailyCount:1,pointers:{},sortOrder:9999,colorKey:null,nextMatnIndex:0});return payload;});}catch{}
  }
  function scheduleCloudSync(){clearTimeout(cloudSyncTimer);cloudSyncTimer=setTimeout(()=>syncPlannerCloud(),650);}
  function currentPage(){
    // The native iOS reader can keep the original ?page= URL while React has already moved
    // to another Mushaf page. Prefer the live reader state/DOM and only use the URL as fallback.
    try{
      const state=window.__munibinQuranWorkingNavigator?.debugState?.();
      const bridgePage=Number(state?.refPage ?? state?.reactPage ?? state?.dataPage);
      if(Number.isInteger(bridgePage)&&bridgePage>0&&bridgePage<=604)return bridgePage;
    }catch{}
    const live = $('.qcf1441-page-number--base,.qcf1441-page-number')?.textContent || $('.qcf1441-page-context span[aria-live], .qcf1441-page-context span')?.textContent || '';
    const m = live.replace(/[٠-٩]/g,d=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))).match(/(?:صفحة\s*)?(\d{1,3})/);
    if(m){const page=Number(m[1]);if(Number.isInteger(page)&&page>0&&page<=604)return page;}
    const url = Number(new URL(location.href).searchParams.get('page'));
    if(Number.isInteger(url)&&url>0&&url<=604)return url;
    return 1;
  }
  function preloadQuranPage(page){
    page=clamp(Number(page)||1,1,604);
    try{return window.__munibinQuranNavigationBridge?.preloadPage?.(page);}catch{return null;}
  }
  async function goPage(page,verseKey=null){
    page=clamp(Number(page)||1,1,604);
    if(verseKey)window.__munibinQuranNavigationHighlight?.request?.(verseKey,page);
    const exact=window.__munibinQuranWorkingNavigator?.goPage;
    if(typeof exact==='function'&&isQuran()){
      closeOverlay();
      try{
        const result=await exact(page);
        if(result===true||result?.ok)return;
      }catch(err){console.warn('[Munibin] working navigator page jump failed',err);}
    }
    const liveReader=$('.qcf1441-preview,[data-loc="client/src/pages/QuranQcfV2Page.tsx:219"]');
    if(liveReader){
      const bridge=window.__munibinQuranNavigationBridge;
      try{
        bridge?.preloadPage?.(page);
        if(typeof bridge?.goPage==='function'){
          closeOverlay();
          if(bridge.goPage(page)!==false)return;
        }
      }catch(err){console.warn('[Munibin] direct Quran page jump failed',err);}
      if(liveReader.matches('[data-loc="client/src/pages/QuranQcfV2Page.tsx:219"]')){
        closeOverlay();
        window.dispatchEvent(new CustomEvent('munibin-quran-go-page',{detail:{page}}));
        return;
      }
    }
    closeOverlay();
    const u=new URL(location.href); u.pathname='/quran'; u.searchParams.set('page',String(page)); if(verseKey)u.searchParams.set('highlightVerse',verseKey);else u.searchParams.delete('highlightVerse'); u.hash='';
    location.assign(u.pathname+u.search);
  }
  async function goWirdDay(day,page){
    const range=day?.ayahRanges?.[0];
    let key=range?`${range.startSurah}:${range.startAyah}`:null;
    if(!key){const nav=await loadNav(),verse=nav.ayahs.find(a=>Number(a.page)===Number(page));if(verse)key=`${verse.surah}:${verse.ayah}`;}
    return goPage(page,key);
  }
  async function pageForVerse(key){ const n=await loadNav(); return n.ayahs.find(a=>`${a.surah}:${a.ayah}`===key)?.page || 1; }
  function closeOverlay(){ if(featureOverlay){ featureOverlay.remove(); featureOverlay=null; } }
  function icon(name){
    if(name==='close') return '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></svg>';
    if(name==='bookmark') return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h12v18l-6-4-6 4Z"/></svg>';
    if(name==='dot') return '<svg class="munibin-filled-dot" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4.4" fill="currentColor" stroke="none"/></svg>';
    if(name==='back') return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg>';
    if(name==='edit') return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>';
    if(name==='calendar') return '<svg viewBox="0 0 24 24"><path d="M5 5h14v15H5zM8 2v6M16 2v6M5 9h14"/></svg>';
    if(name==='mic') return '<svg viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M6 11a6 6 0 0 0 12 0M12 17v4M9 21h6"/></svg>';
    if(name==='qibla') return '<svg class="munibin-qibla-button-kaaba" viewBox="0 0 96 96" aria-hidden="true"><path class="k-roof" d="M16 28 47 16 80 29 49 42Z"/><path class="k-front" d="M16 28 49 42 49 81 16 66Z"/><path class="k-side" d="M49 42 80 29 80 67 49 81Z"/><path class="k-band" d="M18 36 49 49 78 37 78 45 49 57 18 44Z"/><path class="k-door" d="M58 56h9v18h-9z"/></svg>';
    return '';
  }
  function overlayShell(title, body, cls=''){
    closeOverlay();
    const el=document.createElement('div'); el.className=`munibin-v185-overlay ${cls}`; el.dir='rtl';
    el.innerHTML=`<div class="munibin-v185-backdrop"></div><section class="munibin-v185-sheet" role="dialog" aria-modal="true"><header><strong>${esc(title)}</strong><button type="button" data-close aria-label="إغلاق">${icon('close')}</button></header><div class="munibin-v185-body">${body}</div></section>`;
    el.querySelector('[data-close]').onclick=closeOverlay; el.querySelector('.munibin-v185-backdrop').onclick=closeOverlay;
    document.body.append(el); featureOverlay=el; return el;
  }
  function toast(text){
    let t=$('.munibin-v185-toast'); if(!t){t=document.createElement('div');t.className='munibin-v185-toast';document.body.append(t);} t.textContent=text;t.classList.add('show'); clearTimeout(t._h);t._h=setTimeout(()=>t.classList.remove('show'),2200);
  }

  // ---------------- Bookmarks ----------------
  function bookmarks(){ return jsonGet(STORAGE.bookmarks, []); }
  function applyBookmarkTints(){
    const map=new Map(bookmarks().map(b=>[b.verseKey,b])),desired=new Map();
    map.forEach((b,key)=>{const glyphs=$$(`.qcf1441-glyph-word[data-verse-key="${CSS.escape(key)}"]`);const end=glyphs.find(g=>g.dataset.wordType==='end')||glyphs[glyphs.length-1];if(end)desired.set(end,bookmarkColor(b.color));});
    // Keep unchanged marks intact: the 700 ms compatibility tick must not
    // clear/repaint every Quran word while the user is moving a color slider.
    $$('.qcf1441-glyph-word[data-verse-key].munibin-bookmarked-marker, .qcf1441-glyph-word[data-verse-key][style*="--munibin-bookmark-color"]').forEach(g=>{if(!desired.has(g)){if(g.classList.contains('munibin-bookmarked-marker'))g.classList.remove('munibin-bookmarked-marker');if(g.style.getPropertyValue('--munibin-bookmark-color'))g.style.removeProperty('--munibin-bookmark-color');}});
    desired.forEach((color,g)=>{if(!g.classList.contains('munibin-bookmarked-marker'))g.classList.add('munibin-bookmarked-marker');if(g.style.getPropertyValue('--munibin-bookmark-color')!==color)g.style.setProperty('--munibin-bookmark-color',color);});
  }
  function openBookmarkEditor(key,returnToHub=false){
    const all=bookmarks(), old=all.find(b=>b.verseKey===key),oldColor=old?.color?bookmarkColor(old.color):null; const [s,a]=key.split(':');
    const replaceSame=replaceSameBookmarkColorEnabled(),savedLastColor=bookmarkColor(localStorage.getItem(STORAGE.bookmarkLastColor)||COLORS[0].value),initialColor=oldColor||savedLastColor,initialName=old?.name||bookmarkNameForColor(initialColor),locationText=bookmarkLocationText(key);
    const el=overlayShell(old?'تعديل العلامة':'إضافة علامة',`<div class="munibin-v185-form munibin-bookmark-form"><label>اسم العلامة<input data-name maxlength="60" value="${esc(initialName)}"></label><p class="munibin-v185-muted munibin-bookmark-location">${esc(locationText)}</p><fieldset><legend>اللون</legend><div class="munibin-color-row">${COLORS.map(c=>`<button type="button" class="munibin-color ${initialColor===c.value?'selected':''}" data-color="${c.value}" title="${c.name}" aria-label="${c.name}" style="--swatch:${c.value}"></button>`).join('')}</div><label class="munibin-bookmark-replace-option"><input type="checkbox" data-replace-same-color ${replaceSame?'checked':''}><span><strong>استبدال العلامة السابقة من نفس اللون</strong><small>عند إلغاء التحديد يمكن استخدام اللون نفسه لأكثر من علامة.</small></span></label></fieldset><div class="munibin-v185-actions">${old?'<button type="button" data-delete class="danger">حذف العلامة</button>':''}<button type="button" data-save class="primary">حفظ</button></div></div>`);
    const back=el.querySelector('[data-close]');if(back){back.innerHTML=icon('back');back.setAttribute('aria-label','العودة إلى الأوراد والعلامات');back.title='العودة';back.onclick=()=>openWirdHub('bookmarks');}
    const nameInput=el.querySelector('[data-name]');let color=initialColor,nameEdited=!!old;
    nameInput?.addEventListener('input',()=>{nameEdited=true;});
    el.querySelectorAll('[data-color]').forEach(b=>b.onclick=()=>{color=b.dataset.color;localStorage.setItem(STORAGE.bookmarkLastColor,color);persistCriticalState(true);el.querySelectorAll('[data-color]').forEach(x=>x.classList.toggle('selected',x===b));if(!old&&!nameEdited&&nameInput)nameInput.value=bookmarkNameForColor(color);});
    el.querySelector('[data-save]').onclick=()=>{const name=nameInput?.value.trim()||bookmarkNameForColor(color),replace=!!el.querySelector('[data-replace-same-color]')?.checked;localStorage.setItem(STORAGE.bookmarkReplaceSameColor,replace?'1':'0');localStorage.setItem(STORAGE.bookmarkLastColor,color);rememberBookmarkName(color,name);let next=all.filter(b=>b.verseKey!==key);if(replace)next=next.filter(b=>bookmarkColor(b.color)!==color);next.push({id:old?.id||crypto.randomUUID?.()||String(Date.now()),verseKey:key,name,color,createdAt:old?.createdAt||Date.now(),updatedAt:Date.now()});jsonSet(STORAGE.bookmarks,next);persistCriticalState(true);applyBookmarkTints();toast('تم حفظ العلامة');returnToHub?openWirdHub('bookmarks'):closeOverlay();};
    const del=el.querySelector('[data-delete]'); if(del) del.onclick=()=>{jsonSet(STORAGE.bookmarks,all.filter(b=>b.verseKey!==key));applyBookmarkTints();toast('تم حذف العلامة');returnToHub?openWirdHub('bookmarks'):closeOverlay();};
  }
  function injectBookmarkAction(){
    const menu=$('.qcf1441-verse-action-menu'); if(!menu||menu.dataset.munibinBookmark==='1'||!lastVerseKey)return;
    menu.dataset.munibinBookmark='1'; const box=$('.qcf1441-verse-action-buttons',menu); if(!box)return;
    const b=document.createElement('button');b.type='button';b.dataset.action='bookmark';b.innerHTML='<svg class="qcf1441-verse-action-icon qcf1441-verse-action-icon--bookmark" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h12v18l-6-4-6 4Z"/></svg><span>علامة</span>'; b.onclick=(e)=>{e.stopPropagation();$('.qcf1441-verse-action-layer')?.remove();openBookmarkEditor(lastVerseKey);};const copy=box.querySelector('[data-action="copy"]');box.insertBefore(b,copy);
  }

  // ---------------- Wird ----------------
  function wirids(){ return jsonGet(STORAGE.wird, []); }
  function savedWirdHubTab(){return localStorage.getItem(STORAGE.wirdHubTab)==='bookmarks'?'bookmarks':'wirds';}
  function rememberWirdHubTab(tab){const next=tab==='bookmarks'?'bookmarks':'wirds';localStorage.setItem(STORAGE.wirdHubTab,next);persistCriticalState();return next;}
  function dateKey(d){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
  function formatWirdStartDate(key,todayKey=dateKey(new Date())){
    if(key===todayKey)return 'اليوم';
    const d=new Date(`${key}T12:00:00`);if(Number.isNaN(d.getTime()))return key;
    const weekdays=['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
    const asciiDate=`${d.getDate()}-${d.getMonth()+1}-${d.getFullYear()}`;
    return `${weekdays[d.getDay()]} \u2066${asciiDate}\u2069`;
  }
  function syncWirdTodayOptionLabel(select){
    if(!select)return;
    const today=dateKey(new Date());
    const option=[...select.options].find(o=>String(o.value)===today);
    if(option)option.textContent='اليوم';
  }
  function wirdStartDateOptions(selectedKey){
    const today=new Date();today.setHours(12,0,0,0);const todayKey=dateKey(today);
    const min=new Date(today);min.setFullYear(min.getFullYear()-1);
    const max=new Date(today);max.setFullYear(max.getFullYear()+1);
    const selected=String(selectedKey||todayKey),out=[];let found=false;
    for(const d=new Date(min);d<=max;d.setDate(d.getDate()+1)){const key=dateKey(d);if(key===selected)found=true;out.push(`<option value="${key}" ${key===selected?'selected':''}>${esc(formatWirdStartDate(key,todayKey))}</option>`);}
    if(!found&&/^\d{4}-\d{2}-\d{2}$/.test(selected))out.unshift(`<option value="${esc(selected)}" selected>${esc(formatWirdStartDate(selected,todayKey))}</option>`);
    return out.join('');
  }
  function addDays(key,n){const d=new Date(key+'T12:00:00');d.setDate(d.getDate()+n);return dateKey(d);}
  function dayPages(day){
    if(Array.isArray(day?.pages)&&day.pages.length)return day.pages.map(Number).filter(Number.isFinite);
    const pages=[];for(const s of day?.segments||[]){for(let p=Number(s.from)||0;p<=(Number(s.to)||0);p++)if(p>0)pages.push(p);}return pages;
  }
  function deriveDayAyahRanges(nav,w,day){
    const pages=new Set(dayPages(day));if(!pages.size||!Array.isArray(w?.ranges))return[];
    const order=new Map(nav.ayahs.map((a,i)=>[`${a.surah}:${a.ayah}`,i])),out=[];
    for(const r of w.ranges){
      let a=order.get(`${r.startSurah}:${r.startAyah}`),b=order.get(`${r.endSurah}:${r.endAyah}`);if(!Number.isInteger(a)||!Number.isInteger(b))continue;if(a>b)[a,b]=[b,a];
      const selected=nav.ayahs.slice(a,b+1).filter(x=>pages.has(Number(x.page)));if(!selected.length)continue;
      const first=selected[0],last=selected[selected.length-1];out.push({startSurah:first.surah,startAyah:first.ayah,endSurah:last.surah,endAyah:last.ayah});
    }
    return out;
  }
  const WIRD_WEEKDAYS=[
    {value:6,label:'السبت'},{value:0,label:'الأحد'},{value:1,label:'الاثنين'},{value:2,label:'الثلاثاء'},
    {value:3,label:'الأربعاء'},{value:4,label:'الخميس'},{value:5,label:'الجمعة'}
  ];
  function normalizeWirdWeekdays(days){
    const raw=Array.isArray(days)?days.map(Number).filter(n=>Number.isInteger(n)&&n>=0&&n<=6):[];
    return raw.length?Array.from(new Set(raw)):WIRD_WEEKDAYS.map(d=>d.value);
  }
  function scheduledWirdDates(startDate,count,weekdays){
    const allowed=new Set(normalizeWirdWeekdays(weekdays)),out=[],d=new Date(`${startDate}T12:00:00`);
    let guard=0;const maxSteps=Math.max(10000,count*7+7);
    while(out.length<count&&guard<maxSteps){if(allowed.has(d.getDay()))out.push(dateKey(d));d.setDate(d.getDate()+1);guard++;}
    return out;
  }
  function applyWirdScheduleDates(days,startDate,weekdays){
    const dates=scheduledWirdDates(startDate,days.length,weekdays);
    days.forEach((day,i)=>{day.index=i+1;day.date=dates[i]||startDate;});
    return days;
  }
  function wirdDailyUnit(w){return w?.dailyUnit==='ayahs'||w?.dailyUnit==='surahs'?w.dailyUnit:'pages';}
  function wirdDailyAmount(w,unit=wirdDailyUnit(w)){
    const raw=unit===wirdDailyUnit(w)&&w?.dailyCount!=null?w.dailyCount:unit==='ayahs'?w?.ayahsPerDay:unit==='surahs'?w?.surahsPerDay:w?.pagesPerDay;
    const value=Number(raw);return Number.isFinite(value)&&value>=1?Math.min(unit==='ayahs'?6236:unit==='surahs'?114:604,Math.floor(value)):1;
  }
  function syncWirdRangeUnit(el,unit){
    const wholeSurahs=unit==='surahs';
    el.querySelectorAll('.munibin-range-head strong').forEach(label=>{label.textContent=wholeSurahs?'مدى سور':'مدى آيات';});
    el.querySelectorAll('[data-wird-ayah-endpoint]').forEach(label=>{label.hidden=wholeSurahs;const input=label.querySelector('select');if(input)input.disabled=wholeSurahs;});
    const smart=el.querySelector('[data-wird-smart-option]');if(smart){smart.hidden=wholeSurahs;const input=smart.querySelector('input');if(input)input.disabled=wholeSurahs;}
  }
  function quranSurahAyahCounts(nav){return new Map((nav.surahs||[]).map(s=>[Number(s.surah),Number(s.ayahCount)||0]));}
  function pageSpanBetween(nav,startIndex,endIndex){
    const first=nav.ayahs[startIndex],last=nav.ayahs[endIndex];if(!first||!last)return 0;return Math.max(1,Number(last.page)-Number(first.page)+1);
  }
  function exactWirdEndIndex(nav,startIndex,endIndex,per){
    const first=nav.ayahs[startIndex];if(!first)return startIndex;
    const targetPage=Math.min(Number(nav.ayahs[endIndex]?.page)||Number(first.page),Number(first.page)+Math.max(1,per)-1);
    let out=startIndex;for(let i=startIndex;i<=endIndex;i++){const page=Number(nav.ayahs[i]?.page)||0;if(page>targetPage)break;out=i;}return out;
  }
  function exactSurahWirdEndIndex(nav,startIndex,endIndex,per){
    const targetSurah=Math.min(Number(nav.ayahs[endIndex]?.surah)||114,Number(nav.ayahs[startIndex]?.surah)+per-1);
    let out=startIndex;for(let i=startIndex;i<=endIndex;i++){if(Number(nav.ayahs[i]?.surah)>targetSurah)break;out=i;}return out;
  }
  function smartWirdEndIndex(nav,startIndex,endIndex,per,enabled,surahCounts,unit='pages'){
    if(unit==='surahs')return exactSurahWirdEndIndex(nav,startIndex,endIndex,per);
    const first=nav.ayahs[startIndex];if(!first)return startIndex;
    const span=(start,end)=>unit==='ayahs'?end-start+1:pageSpanBetween(nav,start,end);
    const exact=unit==='ayahs'?Math.min(endIndex,startIndex+per-1):exactWirdEndIndex(nav,startIndex,endIndex,per),remainingSpan=span(startIndex,endIndex);
    if(!enabled||remainingSpan<=per||Number(first.ayah)!==1)return exact;
    const minLen=Math.max(1,Math.ceil(per*.8)),maxLen=Math.max(minLen,Math.floor(per*1.2)),candidates=[];
    for(let i=startIndex;i<=endIndex;i++){
      const a=nav.ayahs[i],count=surahCounts.get(Number(a?.surah))||0;if(!a||Number(a.ayah)!==count)continue;
      const length=span(startIndex,i);if(length<minLen||length>maxLen)continue;
      candidates.push({index:i,span:length});
    }
    if(!candidates.length)return exact;
    candidates.sort((a,b)=>Math.abs(a.span-per)-Math.abs(b.span-per)||a.span-b.span);return candidates[0].index;
  }
  async function buildSchedule(ranges,dailyCount,startDate,weekdays=WIRD_WEEKDAYS.map(d=>d.value),smartSurahBoundaries=true,dailyUnit='pages'){
    const nav=await loadNav(); const order=new Map(nav.ayahs.map((a,i)=>[`${a.surah}:${a.ayah}`,i])),surahCounts=quranSurahAyahCounts(nav),unit=dailyUnit==='ayahs'||dailyUnit==='surahs'?dailyUnit:'pages';
    const normalized=ranges.map(r=>{let sk=`${r.startSurah}:${r.startAyah}`,ek=`${r.endSurah}:${r.endAyah}`;if(unit==='surahs'){const first=Math.min(Number(r.startSurah),Number(r.endSurah)),last=Math.max(Number(r.startSurah),Number(r.endSurah));sk=`${first}:1`;ek=`${last}:${surahCounts.get(last)||0}`;} if((order.get(sk)??0)>(order.get(ek)??0))[sk,ek]=[ek,sk];return{startKey:sk,endKey:ek};}).sort((a,b)=>(order.get(a.startKey)||0)-(order.get(b.startKey)||0));
    const normalizedRanges=normalized.map(r=>{const [ss,sa]=r.startKey.split(':').map(Number),[es,ea]=r.endKey.split(':').map(Number);return{startSurah:ss,startAyah:sa,endSurah:es,endAyah:ea};});
    const selected=[],days=[],seen=new Set(),per=unit==='pages'?Math.max(1,Number(dailyCount)||1):Math.min(unit==='surahs'?114:nav.ayahs.length,Math.max(1,Math.floor(Number(dailyCount)||1)));
    normalized.forEach((r,rangeIndex)=>{
      const rangeStart=order.get(r.startKey),rangeEnd=order.get(r.endKey);if(!Number.isInteger(rangeStart)||!Number.isInteger(rangeEnd))return;
      for(let cursor=rangeStart;cursor<=rangeEnd;){
        const endIndex=smartWirdEndIndex(nav,cursor,rangeEnd,per,smartSurahBoundaries!==false,surahCounts,unit),first=nav.ayahs[cursor],last=nav.ayahs[endIndex];if(!first||!last)break;
        const pages=[];for(let p=Number(first.page);p<=Number(last.page);p++){pages.push(p);if(!seen.has(p)){seen.add(p);selected.push(p);}}
        const day={index:days.length+1,rangeIndex,date:startDate,pages,segments:[{from:pages[0],to:pages[pages.length-1]}],done:false,doneAt:null,ayahRanges:[{startSurah:Number(first.surah),startAyah:Number(first.ayah),endSurah:Number(last.surah),endAyah:Number(last.ayah)}]};
        days.push(day);cursor=endIndex+1;
      }
    });
    applyWirdScheduleDates(days,startDate,weekdays);
    return {ranges:normalizedRanges,selectedPages:selected,days,weekdays:normalizeWirdWeekdays(weekdays),smartSurahBoundaries:smartSurahBoundaries!==false};
  }
  function segmentText(day){return (day?.segments||[]).map(s=>s.from===s.to?`ص ${s.from}`:`ص ${s.from}–${s.to}`).join(' · ');}
  function formatAyahRange(r){
    if(!r)return'';const a=SURAH_NAMES[Number(r.startSurah)]||`سورة ${r.startSurah}`,b=SURAH_NAMES[Number(r.endSurah)]||`سورة ${r.endSurah}`;
    return `${a} ${Number(r.startAyah)||1} ← ${b} ${Number(r.endAyah)||1}`;
  }
  function wirdDayAyahRangeText(day){return (day?.ayahRanges||[]).map(formatAyahRange).filter(Boolean).join(' · ');}
  function wirdDayPosition(w,day){const days=w?.days||[],i=Math.max(0,days.indexOf(day));return{day:i+1,total:days.length};}
  function wirdRangeText(w){return (Array.isArray(w?.ranges)?w.ranges:[]).map(formatAyahRange).filter(Boolean).join(' · ');}
  let wirdDayMetadataPromise=null;
  let wirdScheduleUpgradePromise=null;
  async function ensureWirdScheduleV6(){
    if(wirdScheduleUpgradePromise)return wirdScheduleUpgradePromise;
    wirdScheduleUpgradePromise=(async()=>{
      const all=wirids();if(!all.length)return false;let changed=false;
      for(const w of all){if(w?.smartSurahBoundaries===false||Number(w?.scheduleVersion||0)>=6)continue;if((w.days||[]).some(d=>d.done))continue;
        try{const built=await buildSchedule(w.ranges||[],wirdDailyAmount(w),w.cycleStartDate||dateKey(new Date()),w.weekdays,true,wirdDailyUnit(w));w.ranges=built.ranges;w.selectedPages=built.selectedPages;w.days=built.days;w.weekdays=built.weekdays;w.smartSurahBoundaries=true;w.scheduleVersion=7;w.updatedAt=Date.now();changed=true;}catch{}
      }
      if(changed)jsonSet(STORAGE.wird,all);return changed;
    })().finally(()=>{wirdScheduleUpgradePromise=null;});
    return wirdScheduleUpgradePromise;
  }
  async function ensureWirdDayAyahRanges(){
    if(wirdDayMetadataPromise)return wirdDayMetadataPromise;
    wirdDayMetadataPromise=(async()=>{
      const all=wirids();if(!all.length)return false;let nav;try{nav=await loadNav();}catch{return false;}let changed=false;
      for(const w of all){let touched=false;for(const d of w.days||[]){if(Array.isArray(d.ayahRanges)&&d.ayahRanges.length)continue;const derived=deriveDayAyahRanges(nav,w,d);if(derived.length){d.ayahRanges=derived;touched=changed=true;}}if(touched){w.scheduleVersion=Math.max(Number(w.scheduleVersion)||0,4);w.updatedAt=Date.now();}}
      if(changed)jsonSet(STORAGE.wird,all);return changed;
    })().finally(()=>{wirdDayMetadataPromise=null;});
    return wirdDayMetadataPromise;
  }
  async function saveWirdFromForm(el,existing){
    const name=el.querySelector('[data-wird-name]').value.trim(),unit=wirdDailyUnit({dailyUnit:el.querySelector('[data-wird-unit]')?.value}),amount=Number(el.querySelector('[data-wird-pages]').value);
    if(!Number.isFinite(amount)||!Number.isInteger(amount)||amount<1||amount>(unit==='ayahs'?6236:unit==='surahs'?114:604)){toast(unit==='ayahs'?'أدخل عدداً صحيحاً من 1 إلى 6236 آية':unit==='surahs'?'أدخل عدداً صحيحاً من 1 إلى 114 سورة':'أدخل عدداً صحيحاً من 1 إلى 604 صفحة');return;}
    const ranges=$$('.munibin-range-row',el).map(row=>({startSurah:Number(row.querySelector('[data-ss]').value),startAyah:Number(row.querySelector('[data-sa]').value),endSurah:Number(row.querySelector('[data-es]').value),endAyah:Number(row.querySelector('[data-ea]').value)}));
    const weekdays=$$('[data-wird-weekday]:checked',el).map(input=>Number(input.value)),smartSurahBoundaries=!!el.querySelector('[data-wird-smart-surah]')?.checked;
    const startDate=el.querySelector('[data-wird-start-date]')?.value||dateKey(new Date());
    if(!name||!ranges.length){toast('أدخل اسم الورد ومداه');return;}if(!weekdays.length){toast('اختر يوماً واحداً على الأقل للورد');return;}if(!/^\d{4}-\d{2}-\d{2}$/.test(startDate)||Number.isNaN(new Date(`${startDate}T12:00:00`).getTime())){toast('اختر تاريخ بدء صحيحاً');return;}
    const built=await buildSchedule(ranges,amount,startDate,weekdays,smartSurahBoundaries,unit);
    const daySig=d=>(d?.ayahRanges||[]).map(r=>`${r.startSurah}:${r.startAyah}-${r.endSurah}:${r.endAyah}`).join('|')||dayPages(d).join(',');
    const oldDone=new Map((existing?.days||[]).map(d=>[daySig(d),d])); built.days.forEach(d=>{const old=oldDone.get(daySig(d));if(old){d.done=!!old.done;d.doneAt=old.doneAt||null;}});
    const item={id:existing?.id||crypto.randomUUID?.()||String(Date.now()),name,dailyUnit:unit,dailyCount:amount,pagesPerDay:unit==='pages'?amount:wirdDailyAmount(existing,'pages'),ayahsPerDay:unit==='ayahs'?amount:wirdDailyAmount(existing,'ayahs'),surahsPerDay:unit==='surahs'?amount:wirdDailyAmount(existing,'surahs'),ranges:built.ranges,selectedPages:built.selectedPages,days:built.days,weekdays:built.weekdays,smartSurahBoundaries,scheduleVersion:7,cycleStartDate:startDate,cycle:Number(existing?.cycle)||1,createdAt:existing?.createdAt||Date.now(),updatedAt:Date.now()};
    const all=wirids(); const next=all.filter(w=>w.id!==item.id);next.push(item);jsonSet(STORAGE.wird,next);closeOverlay();openWirdHub('wirds');toast(existing?'تم تحديث الورد':'تم إنشاء الورد');
  }
  async function addRangeRow(host,r={startSurah:1,startAyah:1,endSurah:1,endAyah:7}){
    const nav=await loadNav(); const row=document.createElement('div');row.className='munibin-range-row';
    const surOpts=nav.surahs.map(s=>`<option value="${s.surah}">${s.surah}. ${esc(s.nameArabic)}</option>`).join('');
    row.innerHTML=`<div class="munibin-range-head"><strong>مدى آيات</strong><button type="button" data-remove aria-label="حذف المدى">×</button></div><div class="munibin-range-grid"><label>من سورة<select class="munibin-wird-choice-select" data-ss aria-label="من سورة">${surOpts}</select></label><label data-wird-ayah-endpoint>من آية<select class="munibin-wird-choice-select" data-sa aria-label="من آية"></select></label><label>إلى سورة<select class="munibin-wird-choice-select" data-es aria-label="إلى سورة">${surOpts}</select></label><label data-wird-ayah-endpoint>إلى آية<select class="munibin-wird-choice-select" data-ea aria-label="إلى آية"></select></label></div>`;
    const ss=row.querySelector('[data-ss]'),es=row.querySelector('[data-es]'),sa=row.querySelector('[data-sa]'),ea=row.querySelector('[data-ea]');ss.value=String(r.startSurah);es.value=String(r.endSurah);
    const ayahCount=sur=>nav.surahs.find(x=>x.surah===Number(sur.value))?.ayahCount||1;
    const fill=(sur,sel,val)=>{const count=ayahCount(sur);sel.innerHTML=Array.from({length:count},(_,i)=>`<option value="${i+1}">${i+1}</option>`).join('');sel.value=String(clamp(Number(val)||1,1,count));};
    fill(ss,sa,r.startAyah);fill(es,ea,r.endAyah);ss.onchange=()=>fill(ss,sa,1);es.onchange=()=>fill(es,ea,ayahCount(es));row.querySelector('[data-remove]').onclick=()=>{if(host.querySelectorAll('.munibin-range-row').length>1)row.remove();};host.append(row);
  }
  async function openWirdForm(existing=null){
    const dailyUnit=wirdDailyUnit(existing),unitValues={pages:wirdDailyAmount(existing,'pages'),ayahs:wirdDailyAmount(existing,'ayahs'),surahs:wirdDailyAmount(existing,'surahs')};
    const selectedDays=new Set(existing?normalizeWirdWeekdays(existing.weekdays):WIRD_WEEKDAYS.map(d=>d.value));
    const weekdayOptions=WIRD_WEEKDAYS.map(d=>`<label class="munibin-weekday-option"><input type="checkbox" data-wird-weekday value="${d.value}" ${selectedDays.has(d.value)?'checked':''}><span>${d.label}</span></label>`).join('');
    const smartChecked=existing?.smartSurahBoundaries!==false?'checked':'',startDateValue=existing?.cycleStartDate||dateKey(new Date()),startDateOptions=wirdStartDateOptions(startDateValue);
    const el=overlayShell(existing?'تعديل الورد':'ورد جديد',`<div class="munibin-v185-form"><label>اسم الورد<input data-wird-name maxlength="60" placeholder="مثال: حفظ، مراجعة، قراءة" value="${esc(existing?.name||'')}"></label><div class="munibin-wird-amount-field"><label>وحدة الورد<select data-wird-unit class="munibin-wird-choice-select" dir="rtl"><option value="pages" ${dailyUnit==='pages'?'selected':''}>صفحات</option><option value="surahs" ${dailyUnit==='surahs'?'selected':''}>سور</option><option value="ayahs" ${dailyUnit==='ayahs'?'selected':''}>آيات</option></select></label><label><span data-wird-amount-label>المتوسط اليومي (${dailyUnit==='ayahs'?'آيات':dailyUnit==='surahs'?'سور':'صفحات'})</span><input data-wird-pages type="number" inputmode="numeric" min="1" max="${dailyUnit==='ayahs'?6236:dailyUnit==='surahs'?114:604}" step="1" value="${unitValues[dailyUnit]}"></label></div><label>تاريخ بدء الخطة<select data-wird-start-date class="munibin-wird-date-select munibin-wird-choice-select" dir="rtl" aria-label="تاريخ بدء الخطة">${startDateOptions}</select></label><label class="munibin-smart-wird-option" data-wird-smart-option><input type="checkbox" data-wird-smart-surah ${smartChecked}><span><strong>تقسيم ذكي على حدود السور</strong><small>يحاول أن يبدأ اليوم بسورة وينهيه بنهاية سورة ضمن ±20٪ من العدد اليومي، من دون تخطي أي آية.</small></span></label><fieldset class="munibin-weekdays"><legend>أيام الورد</legend><div class="munibin-weekday-grid">${weekdayOptions}</div></fieldset><div class="munibin-ranges" data-ranges></div><button type="button" class="secondary" data-add-range>+ إضافة مدى آخر</button><div class="munibin-v185-actions">${existing?'<button type="button" class="danger" data-delete>حذف الورد</button>':''}<button type="button" class="primary" data-save>${existing?'حفظ التعديلات':'إنشاء الورد'}</button></div></div>`,'munibin-wird-form-overlay');
    const back=el.querySelector('[data-close]');if(back){back.innerHTML=icon('back');back.setAttribute('aria-label','العودة إلى قائمة الأوراد');back.title='العودة';back.onclick=()=>void openWirdHub('wirds');}
    let activeUnit=dailyUnit;
    const amountField=el.querySelector('[data-wird-pages]'),amountLabel=el.querySelector('[data-wird-amount-label]'),unitSelect=el.querySelector('[data-wird-unit]');
    unitSelect.onchange=()=>{
      const next=wirdDailyUnit({dailyUnit:unitSelect.value});if(next===activeUnit)return;
      const value=Number(amountField.value);if(Number.isFinite(value)&&Number.isInteger(value)&&value>=1&&value<=(activeUnit==='ayahs'?6236:activeUnit==='surahs'?114:604))unitValues[activeUnit]=value;
      activeUnit=next;amountField.max=String(next==='ayahs'?6236:next==='surahs'?114:604);amountField.value=String(unitValues[next]);amountLabel.textContent=`المتوسط اليومي (${next==='ayahs'?'آيات':next==='surahs'?'سور':'صفحات'})`;
      syncWirdRangeUnit(el,next);
    };
    syncWirdRangeUnit(el,dailyUnit);
    const startDateSelect=el.querySelector('[data-wird-start-date]');
    syncWirdTodayOptionLabel(startDateSelect);
    startDateSelect?.addEventListener('change',()=>{
      // Keep the semantic "اليوم" label visible after choosing today's date.
      // The stored value remains the real YYYY-MM-DD date used by scheduling.
      syncWirdTodayOptionLabel(startDateSelect);
    });
    const host=el.querySelector('[data-ranges]');for(const r of existing?.ranges?.length?existing.ranges:[{startSurah:1,startAyah:1,endSurah:114,endAyah:6}])await addRangeRow(host,r);el.querySelector('[data-add-range]').onclick=async()=>{await addRangeRow(host,{startSurah:1,startAyah:1,endSurah:1,endAyah:7});syncWirdRangeUnit(el,activeUnit);};syncWirdRangeUnit(el,activeUnit);el.querySelector('[data-save]').onclick=()=>saveWirdFromForm(el,existing);
    const del=el.querySelector('[data-delete]');if(del)del.onclick=()=>{confirm(`حذف ورد "${existing.name}"؟`)&&(jsonSet(STORAGE.wird,wirids().filter(w=>w.id!==existing.id)),closeOverlay(),openWirdHub('wirds'));};
  }
  function currentWirdDay(w){
    const today=dateKey(new Date());return (w.days||[]).find(d=>!d.done&&d.date<=today)||(w.days||[]).find(d=>!d.done)||(w.days||[])[0]||null;
  }
  function previewWirdDay(w){
    const today=dateKey(new Date()),days=w?.days||[];
    // Preview the oldest unfinished scheduled day only when it is actually late.
    // Otherwise always show today's scheduled Wird; never let a day merely checked
    // today replace today's range in the collapsed card.
    const overdue=days.find(d=>!d.done&&d.date&&d.date<today);
    if(overdue)return overdue;
    return days.find(d=>d.date===today)||days.find(d=>!d.done&&d.date&&d.date>today)||days.find(d=>!d.done)||days[0]||null;
  }
  function previewWirdMeta(w){const today=dateKey(new Date()),day=previewWirdDay(w);return{day,label:day?(day.date===today?'اليوم':day.date||''):'',overdue:!!(day&&!day.done&&day.date&&day.date<today)};}
  function doneToday(w){const today=dateKey(new Date()),todayDay=(w.days||[]).find(d=>d.date===today);return !!todayDay?.done||!!(w.lastCycleCompletedAt&&dateKey(new Date(w.lastCycleCompletedAt))===today);}
  function toggleWirdDay(id,idx,{stayOpen=true}={}){
    const all=wirids(),w=all.find(x=>x.id===id);if(!w)return;const d=w.days[idx];if(!d)return;d.done=!d.done;d.doneAt=d.done?new Date().toISOString():null;
    if(w.days.length&&w.days.every(x=>x.done)){
      const tomorrow=dateKey(new Date(Date.now()+86400000));w.lastCycleCompletedAt=new Date().toISOString();w.cycle=(w.cycle||1)+1;w.cycleStartDate=tomorrow;w.days=w.days.map((x,i)=>({...x,index:i+1,done:false,doneAt:null}));applyWirdScheduleDates(w.days,tomorrow,w.weekdays);toast('اكتمل الورد؛ تبدأ الدورة التالية في أول يوم محدد');
    }
    w.updatedAt=Date.now();jsonSet(STORAGE.wird,all);if(stayOpen)openWirdHub('wirds');
  }
  function renderExpandedDays(w){return `<div class="munibin-wird-expanded"><div class="munibin-days">${(w.days||[]).map((d,i)=>`<div class="munibin-day ${d.done?'done':''}"><button type="button" class="munibin-day-open" data-open-day="${i}" data-wird-id="${esc(w.id)}"><b>اليوم ${i+1}</b><span>${esc(wirdDayAyahRangeText(d)||'—')}</span><small>${esc(d.date)}</small></button><button type="button" class="munibin-day-check" data-check-day="${i}" data-wird-id="${esc(w.id)}" aria-pressed="${d.done}" aria-label="${d.done?'إلغاء اكتمال اليوم':'تعليم اليوم كمكتمل'}">${d.done?'✓':'○'}</button></div>`).join('')}</div></div>`;}
  async function openWirdHub(tab=savedWirdHubTab()){
    await ensureWirdScheduleV6();
    await ensureWirdDayAyahRanges();
    const all=wirids(),marks=bookmarks(); const sorted=all.slice().sort((a,b)=>b.updatedAt-a.updatedAt);
    const el=overlayShell('الأوراد والعلامات',`<div class="munibin-tabs"><button data-tab="wirds" class="${tab==='wirds'?'active':''}">${icon('calendar')}<span>الأوراد</span></button><button data-tab="bookmarks" class="${tab==='bookmarks'?'active':''}">${icon('bookmark')}<span>العلامات</span></button></div><div data-panel="wirds" ${tab!=='wirds'?'hidden':''}><button type="button" class="primary munibin-add-wird" data-new>+ ورد جديد</button><div class="munibin-wird-list">${sorted.length?sorted.map(w=>{const todayDone=doneToday(w),expanded=expandedWirdId===w.id,previewMeta=previewWirdMeta(w),current=previewMeta.day,todayRange=wirdDayAyahRangeText(current);return`<article class="munibin-wird-card ${todayDone?'today-done':''} ${expanded?'expanded':''}" data-wird="${esc(w.id)}"><button type="button" class="munibin-wird-edit-icon" data-edit="${esc(w.id)}" aria-label="تعديل الورد" title="تعديل الورد">${icon('edit')}</button><button type="button" class="munibin-wird-main" aria-expanded="${expanded}"><strong>${esc(w.name)}</strong><span class="munibin-wird-range-only">${esc(todayRange||'—')}</span><small class="munibin-wird-preview-date${previewMeta.overdue?' is-overdue':''}">${esc(previewMeta.label||'')}</small></button><button type="button" class="munibin-wird-expand" data-expand-wird="${esc(w.id)}" aria-expanded="${expanded}"><span>${expanded?'إخفاء الأيام':'عرض الأيام'}</span><span class="munibin-wird-chevron" aria-hidden="true">⌄</span></button><div class="munibin-wird-actions"><button type="button" class="munibin-wird-start" data-resume-card="${esc(w.id)}">ابدأ الورد</button><button type="button" class="munibin-wird-finish${todayDone?' done':''}" data-finish-current="${esc(w.id)}" ${todayDone?'disabled':''}>${todayDone?'تم اليوم ✓':'أتممت ورد اليوم'}</button></div>${expanded?renderExpandedDays(w):''}</article>`;}).join(''):'<p class="munibin-empty">لا توجد أوراد بعد.</p>'}</div></div><div data-panel="bookmarks" ${tab!=='bookmarks'?'hidden':''}><div class="munibin-bookmark-list">${marks.length?marks.map(b=>`<article class="munibin-bookmark-card" data-bookmark="${esc(b.verseKey)}"><i style="--swatch:${esc(bookmarkColor(b.color))}"></i><button type="button" class="munibin-bookmark-open"><strong>${esc(b.name)}</strong><span>${esc(bookmarkLocationText(b.verseKey))}</span></button><button type="button" class="munibin-bookmark-edit" aria-label="تعديل العلامة" title="تعديل العلامة">${icon('edit')}</button></article>`).join(''):'<p class="munibin-empty">أضف علامة من قائمة الضغط المطوّل على الآية.</p>'}</div></div>`);
    el.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>openWirdHub(rememberWirdHubTab(b.dataset.tab)));el.querySelector('[data-new]')?.addEventListener('click',()=>openWirdForm());
    const body=el.querySelector('.munibin-v185-body');
    const updateWirdCard=(id,{refreshDays=true}={})=>{
      const w=wirids().find(x=>x.id===id),card=el.querySelector(`[data-wird="${CSS.escape(String(id))}"]`);if(!w||!card)return;
      const todayDone=doneToday(w),previewMeta=previewWirdMeta(w),preview=previewMeta.day,range=card.querySelector('.munibin-wird-range-only'),previewDate=card.querySelector('.munibin-wird-preview-date'),finish=card.querySelector('[data-finish-current]');
      card.classList.toggle('today-done',todayDone);
      if(range)range.textContent=wirdDayAyahRangeText(preview)||'—';
      if(previewDate){previewDate.textContent=previewMeta.label||'';previewDate.classList.toggle('is-overdue',previewMeta.overdue);}
      if(finish){finish.classList.toggle('done',todayDone);finish.disabled=todayDone;finish.textContent=todayDone?'تم اليوم ✓':'أتممت ورد اليوم';}
      if(refreshDays&&expandedWirdId===id){const current=card.querySelector('.munibin-wird-expanded'),html=renderExpandedDays(w);if(current)current.outerHTML=html;else card.insertAdjacentHTML('beforeend',html);}
    };
    const toggleExpanded=(id)=>{
      const next=expandedWirdId===id?null:id;expandedWirdId=next;
      el.querySelectorAll('[data-wird]').forEach(card=>{
        const cardId=card.dataset.wird,isOpen=cardId===next,btn=card.querySelector('[data-expand-wird]'),main=card.querySelector('.munibin-wird-main'),expanded=card.querySelector('.munibin-wird-expanded');
        card.classList.toggle('expanded',isOpen);if(btn){btn.setAttribute('aria-expanded',String(isOpen));const label=btn.querySelector('span');if(label)label.textContent=isOpen?'إخفاء الأيام':'عرض الأيام';}if(main)main.setAttribute('aria-expanded',String(isOpen));
        if(!isOpen&&expanded)expanded.remove();else if(isOpen&&!expanded){const w=wirids().find(x=>x.id===cardId);if(w)card.insertAdjacentHTML('beforeend',renderExpandedDays(w));}
      });
    };
    el.querySelectorAll('[data-resume-card]').forEach(b=>{
      const w=all.find(x=>x.id===b.dataset.resumeCard),resume=currentWirdDay(w),page=resume?.pages?.[0]||w?.selectedPages?.[0]||1;
      preloadQuranPage(page);
      b.addEventListener('pointerdown',()=>preloadQuranPage(page),{passive:true});
      b.onclick=()=>goWirdDay(resume,page);
    });
    el.querySelectorAll('[data-edit]').forEach(b=>b.onclick=e=>{e.stopPropagation();openWirdForm(all.find(x=>x.id===b.dataset.edit));});
    el.addEventListener('pointerdown',e=>{const b=e.target.closest?.('[data-open-day]');if(!b)return;const w=wirids().find(x=>x.id===b.dataset.wirdId),page=w?.days?.[Number(b.dataset.openDay)]?.pages?.[0]||1;preloadQuranPage(page);},{passive:true});
    el.addEventListener('click',e=>{
      const expand=e.target.closest?.('[data-expand-wird]');if(expand){e.stopPropagation();const saved=body?.scrollTop||0;toggleExpanded(expand.dataset.expandWird);if(body)body.scrollTop=saved;return;}
      const main=e.target.closest?.('.munibin-wird-main');if(main){const card=main.closest('[data-wird]'),saved=body?.scrollTop||0;if(card)toggleExpanded(card.dataset.wird);if(body)body.scrollTop=saved;return;}
      const openDay=e.target.closest?.('[data-open-day]');if(openDay){const w=wirids().find(x=>x.id===openDay.dataset.wirdId),day=w?.days?.[Number(openDay.dataset.openDay)],page=day?.pages?.[0]||1;goWirdDay(day,page);return;}
      const check=e.target.closest?.('[data-check-day]');if(check){const id=check.dataset.wirdId,idx=Number(check.dataset.checkDay),before=wirids().find(x=>x.id===id);if(!before?.days?.[idx])return;const saved=body?.scrollTop||0;toggleWirdDay(id,idx,{stayOpen:false});updateWirdCard(id,{refreshDays:true});if(body)body.scrollTop=saved;return;}
      const finish=e.target.closest?.('[data-finish-current]');if(finish){const id=finish.dataset.finishCurrent,w=wirids().find(x=>x.id===id),d=currentWirdDay(w),i=w?.days?.indexOf(d);if(i>=0){const saved=body?.scrollTop||0;toggleWirdDay(id,i,{stayOpen:false});updateWirdCard(id,{refreshDays:true});if(body)body.scrollTop=saved;}return;}
    });
    el.querySelectorAll('[data-bookmark]').forEach(card=>{card.querySelector('.munibin-bookmark-open').onclick=async()=>goPage(await pageForVerse(card.dataset.bookmark),card.dataset.bookmark);card.querySelector('.munibin-bookmark-edit').onclick=()=>openBookmarkEditor(card.dataset.bookmark,true);});
  }
  function ensureWirdButton(){
    if(!isQuran())return;
    const settings=$('.qcf1441-header-actions .munibin-quran-settings-button');if(!settings)return;
    const actions=settings.parentElement;
    let wird=actions.querySelector('.munibin-wird-header-button'),marks=actions.querySelector('.munibin-bookmark-header-button');
    if(wird&&marks)return;
    const button=(existing,kind,label,symbol,tab)=>{
      const el=existing||document.createElement('button');el.type='button';
      el.className='qcf1441-icon-button '+kind;el.setAttribute('aria-label',label);el.title=label;el.innerHTML=icon(symbol);
      el.onclick=()=>{expandedWirdId=null;openWirdHub(rememberWirdHubTab(tab))};return el;
    };
    wird=button(wird,'munibin-wird-header-button','الأوراد','calendar','wirds');
    marks=button(marks,'munibin-bookmark-header-button','العلامات','bookmark','bookmarks');
    // The Quran action row is LTR even when the surrounding reader is RTL.
    actions.insertBefore(marks,settings.nextSibling);actions.insertBefore(wird,marks.nextSibling);
  }

  // ---------------- Audio range preselection ----------------
  function setSelect(select,value){if(!select)return false;const v=String(value);if(select.value===v)return true;const setter=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value')?.set;setter?.call(select,v);select.dispatchEvent(new Event('input',{bubbles:true}));select.dispatchEvent(new Event('change',{bubbles:true}));return select.value===v;}
  async function preselectAudioForBigPlay(panel){
    if(!panel||!audioBigPlayIntent)return;const intent=audioBigPlayIntent;if(Date.now()-intent.at>5000){audioBigPlayIntent=null;return;}const token=`${intent.page}:${intent.at}`;if(audioPanelSeen===token)return;audioPanelSeen=token;const nav=await loadNav();if(audioBigPlayIntent!==intent)return;const pageAyahs=(nav.ayahs||[]).filter(a=>Number(a.page)===intent.page);if(!pageAyahs.length){audioBigPlayIntent=null;return;}const firstSurahStart=pageAyahs.find(a=>Number(a.ayah)===1),representative=firstSurahStart||pageAyahs[0];const target=(nav.surahs||[]).find(s=>Number(s.surah)===Number(representative.surah));if(!target){audioBigPlayIntent=null;return;}const targetCount=Number(target.ayahCount)||Math.max(1,...(nav.ayahs||[]).filter(a=>Number(a.surah)===Number(target.surah)).map(a=>Number(a.ayah)||0));
    const bridge=window.__munibinQuranWorkingNavigator?.selectAudioSurah;
    let tries=0;const verify=()=>{const find=a=>panel.querySelector(`select[aria-label="${a}"]`),ss=find('سورة بداية المدى'),es=find('سورة نهاية المدى'),sa=find('آية بداية المدى'),ea=find('آية نهاية المدى');return!!ss&&!!es&&ss.value===String(target.surah)&&es.value===String(target.surah)&&(!sa||sa.value==='1')&&(!ea||ea.value===String(targetCount));};
    const fallback=()=>{const mode=$$('button',panel).find(b=>(b.textContent||'').includes('مدى السورة والآية'));if(mode&&mode.getAttribute('aria-pressed')!=='true')mode.click();const find=a=>panel.querySelector(`select[aria-label="${a}"]`),ss=find('سورة بداية المدى'),es=find('سورة نهاية المدى'),sa=find('آية بداية المدى'),ea=find('آية نهاية المدى');if(!ss||!es)return false;setSelect(ss,target.surah);setSelect(es,target.surah);if(sa&&ea){setSelect(sa,1);setSelect(ea,targetCount);}return verify();};
    const retry=()=>{if(!document.contains(panel)||audioBigPlayIntent!==intent)return;let accepted=false;try{accepted=typeof bridge==='function'?bridge(target.surah)===true:fallback();}catch{}requestAnimationFrame(()=>{if(audioBigPlayIntent!==intent)return;if(verify()){audioBigPlayIntent=null;return;}if(!accepted&&typeof bridge==='function')fallback();if(++tries<20)setTimeout(retry,90);else audioBigPlayIntent=null;});};
    retry();
  }
  // ---------------- Qibla ----------------
  function calcBearing(lat,lon){const φ1=lat*Math.PI/180,φ2=21.422487*Math.PI/180,dl=(39.826206-lon)*Math.PI/180;return (Math.atan2(Math.sin(dl)*Math.cos(φ2),Math.cos(φ1)*Math.sin(φ2)-Math.sin(φ1)*Math.cos(φ2)*Math.cos(dl))*180/Math.PI+360)%360;}
  function startHeading(onHeading){
    const ios=window.webkit?.messageHandlers?.['munibin-compass']; const handler=e=>onHeading(Number(e.detail?.heading)||0);window.addEventListener('munibin-native-heading',handler);
    if(window.MunibinAndroid?.startCompass)window.MunibinAndroid.startCompass();else if(ios)ios.postMessage({action:'start'});else {const orient=e=>{let h=e.webkitCompassHeading ?? (e.absolute?360-e.alpha:null);if(Number.isFinite(h))onHeading(h);};window.addEventListener('deviceorientationabsolute',orient,true);window.addEventListener('deviceorientation',orient,true);return()=>{window.removeEventListener('deviceorientationabsolute',orient,true);window.removeEventListener('deviceorientation',orient,true);window.removeEventListener('munibin-native-heading',handler);};}
    return()=>{window.MunibinAndroid?.stopCompass?.();ios?.postMessage({action:'stop'});window.removeEventListener('munibin-native-heading',handler);};
  }
  function openQibla(){
    const el=overlayShell('القبلة',`<div class="munibin-qibla"><div class="munibin-qibla-intro"><strong>اتجاه القبلة</strong><span>حرّك الجهاز حتى يتجه السهم إلى الكعبة</span></div><div class="munibin-compass" data-compass><div class="munibin-qibla-target" data-qibla-target aria-hidden="true"><div class="munibin-qibla-kaaba"><svg viewBox="0 0 96 96" aria-hidden="true"><path class="k-roof" d="M16 28 47 16 80 29 49 42Z"/><path class="k-front" d="M16 28 49 42 49 81 16 66Z"/><path class="k-side" d="M49 42 80 29 80 67 49 81Z"/><path class="k-band" d="M18 36 49 49 78 37 78 45 49 57 18 44Z"/><path class="k-door" d="M58 56h9v18h-9z"/></svg></div></div><span class="munibin-cardinal n">ش</span><span class="munibin-cardinal e">ق</span><span class="munibin-cardinal s">ج</span><span class="munibin-cardinal w">غ</span><div class="munibin-qibla-needle" data-arrow aria-hidden="true"><span class="needle-head"></span><span class="needle-shaft"></span><span class="needle-tail"></span></div><span class="munibin-center-pin" aria-hidden="true"></span></div><div class="munibin-qibla-readout"><div><span>اتجاه القبلة</span><strong data-bearing>—</strong></div><div><span>اتجاه الجهاز</span><strong data-heading>—</strong></div></div><div class="munibin-qibla-status" data-qibla-status>يُحدَّد اتجاه القبلة…</div><p class="munibin-qibla-help">ثبّت الهاتف بشكل مستوٍ وابتعد عن الأجسام المعدنية للحصول على قراءة أدق.</p></div>`,'munibin-qibla-overlay');
    const arrow=el.querySelector('[data-arrow]'),target=el.querySelector('[data-qibla-target]'),status=el.querySelector('[data-qibla-status]'),compass=el.querySelector('[data-compass]'),bearingEl=el.querySelector('[data-bearing]'),headingEl=el.querySelector('[data-heading]');let bearing=null,heading=0,targetRel=0,displayRel=0,hasAngle=false,raf=0;
    const paint=()=>{raf=0;if(!hasAngle||!document.contains(compass))return;const delta=targetRel-displayRel;if(Math.abs(delta)>.035){displayRel+=delta*.14;raf=requestAnimationFrame(paint);}else displayRel=targetRel;arrow.style.transform=`rotate(${displayRel}deg)`;const radius=Math.max(0,compass.clientWidth*.43),rad=displayRel*Math.PI/180,x=Math.sin(rad)*radius,y=-Math.cos(rad)*radius;target.style.transform=`translate(-50%,-50%) translate(${x.toFixed(2)}px,${y.toFixed(2)}px)`;};
    const draw=()=>{if(bearing==null)return;const raw=((bearing-heading+540)%360)-180,aligned=Math.abs(raw)<=5;if(!hasAngle){targetRel=displayRel=raw;hasAngle=true;}else{const delta=((raw-targetRel+540)%360)-180;if(Math.abs(delta)>.16)targetRel+=delta*.34;}if(!raf)raf=requestAnimationFrame(paint);compass.classList.toggle('aligned',aligned);bearingEl.textContent=`${Math.round(bearing)}°`;headingEl.textContent=`${Math.round(heading)}°`;status.classList.toggle('aligned',aligned);status.textContent=aligned?'أنت باتجاه القبلة':raw>0?'حرّك الجهاز قليلاً إلى اليمين':'حرّك الجهاز قليلاً إلى اليسار';};
    navigator.geolocation?.getCurrentPosition(pos=>{bearing=calcBearing(pos.coords.latitude,pos.coords.longitude);draw();},()=>{status.textContent='فعّل الموقع لحساب اتجاه القبلة';status.classList.remove('aligned');},{enableHighAccuracy:true,maximumAge:300000,timeout:10000});headingStop=startHeading(h=>{heading=h;draw();});const cleanup=()=>{headingStop?.();if(raf)cancelAnimationFrame(raf);};const oldClose=el.querySelector('[data-close]').onclick;el.querySelector('[data-close]').onclick=()=>{cleanup();oldClose();};el.querySelector('.munibin-v185-backdrop').onclick=()=>{cleanup();closeOverlay();};
  }
  function ensureQiblaButton(){
    const row=$('[data-loc="client/src/pages/PrayerTimesPage.tsx:347"]');
    if(row){if($('.munibin-qibla-button',row))return;const notif=row.querySelector('button[aria-label="إعداد إشعارات كل صلاة"]'),edit=row.querySelector('button[aria-label*="تعديل"]')||$$('button',row).at(-1);if(!notif)return;const b=document.createElement('button');b.type='button';b.className=((edit||notif).className||'')+' munibin-qibla-button';b.style.cssText=(edit||notif).style.cssText;b.setAttribute('aria-label','فتح بوصلة القبلة');b.title='القبلة';b.innerHTML=icon('qibla');b.onclick=openQibla;if(edit?.parentNode===row)row.insertBefore(b,edit);else notif.insertAdjacentElement('afterend',b);return;}
    const inactive=$('[data-loc="client/src/pages/PrayerTimesPage.tsx:327"]');if(!inactive||$('.munibin-qibla-inactive-button',inactive))return;inactive.classList.add('munibin-qibla-inactive-card');const b=document.createElement('button');b.type='button';b.className='munibin-qibla-inactive-button';b.setAttribute('aria-label','فتح بوصلة القبلة');b.title='القبلة';b.innerHTML=`${icon('qibla')}<span>القبلة</span>`;b.onclick=openQibla;inactive.appendChild(b);
  }

  // ---------------- Persistent state + iqama countdown ----------------
  function persistentPayload(){
    const out={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(!k)continue;if(k==='munibin:adhkar-view:v1'||k.startsWith('munibin:hisn-progress:v1:')||/prayer|iqama|notification/i.test(k)||k.startsWith(STORAGE.wird)||k.startsWith(STORAGE.bookmarks)||k.startsWith(STORAGE.guestImport)||k===STORAGE.wirdHubTab||k===STORAGE.account||k.startsWith('motoon-adhkar-progress:')||k==='motoon-adhkar-goal-streak:guest:v1')out[k]=localStorage.getItem(k);}return out;
  }
  function restorePersistentState(){
    let raw=null,count=0;try{raw=window.MunibinAndroid?.getPersistentState?.()||null;}catch{}if(!raw&&window.__munibinNativePersistentState)raw=typeof window.__munibinNativePersistentState==='string'?window.__munibinNativePersistentState:JSON.stringify(window.__munibinNativePersistentState);if(!raw)return 0;try{const obj=JSON.parse(raw);Object.entries(obj).forEach(([k,v])=>{const current=localStorage.getItem(k);if(typeof v==='string'&&current==null){localStorage.setItem(k,v);count++;}});}catch{}return count;
  }
  function writePersistentStateNow(){const raw=JSON.stringify(persistentPayload());try{window.MunibinAndroid?.savePersistentState?.(raw);}catch{}try{window.webkit?.messageHandlers?.['munibin-persistence']?.postMessage(JSON.parse(raw));}catch{}}
  let persistTimer=0;function persistCriticalState(immediate=false){clearTimeout(persistTimer);if(immediate){writePersistentStateNow();return;}persistTimer=setTimeout(writePersistentStateNow,150);}
  function setTextIfNeeded(el,value){if(el&&el.textContent!==value)el.textContent=value;}
  function prayerLabel(key,fallback=''){
    const labels={Fajr:'الفجر',Sunrise:'الشروق',Dhuhr:'الظهر',Asr:'العصر',Maghrib:'المغرب',Isha:'العشاء'};return labels[key]||fallback||key;
  }
  function parseSnapshotAt(t){
    if(window.MunibinAndroid&&/^\d\d?:\d\d$/.test(t?.time||'')){const [h,m]=t.time.split(':').map(Number),d=new Date();d.setHours(h,m,0,0);return d.getTime();}
    let at=t?.at?Date.parse(t.at):NaN;if(Number.isFinite(at))return at;
    if(/^\d\d?:\d\d$/.test(t?.time||'')){const [h,m]=t.time.split(':').map(Number),d=new Date();d.setHours(h,m,0,0);return d.getTime();}
    return NaN;
  }
  function inAppPrayerTarget(now=Date.now()){
    const snap=jsonGet('munibin-prayer-widget-snapshot-v1',null);if(!snap?.timings?.length)return null;
    const offsets=snap.iqamaOffsets||{},timings=snap.timings.map(t=>({...t,_at:parseSnapshotAt(t)})).filter(t=>Number.isFinite(t._at)).sort((a,b)=>a._at-b._at);
    for(const t of timings){const key=String(t.key||'');if(key.toLowerCase()==='sunrise')continue;const mins=Number(offsets[key]??offsets[key[0]?.toUpperCase()+key.slice(1)]??0);if(!Number.isFinite(mins)||mins<=0)continue;const iqamaAt=t._at+mins*60000;if(now>=t._at&&now<iqamaAt)return{kind:'iqama',key:'Iqama',label:`${prayerLabel(key)} إقامة`,at:iqamaAt};}
    const next=timings.find(t=>t._at>now);if(next)return{kind:'prayer',key:String(next.key||''),label:prayerLabel(String(next.key||''),next.label),at:next._at};
    const fallback=snap.nextPrayer;let at=fallback?parseSnapshotAt(fallback):NaN;if(window.MunibinAndroid&&Number.isFinite(at)&&at<=now&&/^\d\d?:\d\d$/.test(fallback?.time||''))at+=86400000;if(Number.isFinite(at)&&at>now)return{kind:'prayer',key:String(fallback.key||''),label:prayerLabel(String(fallback.key||''),fallback.label),at};
    return null;
  }
  function formatCountdown(ms){const s=Math.max(0,Math.floor(ms/1000)),h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;return`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(x).padStart(2,'0')}`;}
  const PRAYER_HEADER_TOGGLE_KEY='mutoon:prayer-header-countdown';
  function prayerHeaderToggleEnabled(){return false;}
  function updateInAppPrayerCountdown(){
    const enabled=prayerHeaderToggleEnabled(),target=inAppPrayerTarget();
    if(!target){$$('.munibin-mutoon-reader-prayer').forEach(header=>header.hidden=true);return;}const remain=formatCountdown(target.at-Date.now());
    $$('.prayer-header-countdown,.public-page-header-countdown').forEach(header=>{if(header.classList.contains('munibin-mutoon-reader-prayer')){if(!enabled){header.hidden=true;return;}header.hidden=false;}const label=header.querySelector('span'),time=header.querySelector('time')||$$('span',header)[1];setTextIfNeeded(label,target.label);setTextIfNeeded(time,remain);header.setAttribute('aria-label',`متبقي على ${target.label}: ${remain}`);header.dataset.munibinPrayerTarget=target.kind;});
    const next=$('[data-loc="client/src/pages/PrayerTimesPage.tsx:342"]');if(next&&next.dataset.munibinPrayerOwnedCountdown!=="true"){const h=next.querySelector('h2');const time=Array.from(next.children).find(x=>x.tagName==='SPAN')||next.querySelector('span');setTextIfNeeded(h,target.label);setTextIfNeeded(time,remain);next.dataset.munibinPrayerTarget=target.kind;}
  }

  function readerPrayerCountdownElement(){
    const b=document.createElement('button');
    b.type='button';
    b.className='prayer-header-countdown munibin-mutoon-reader-prayer';
    b.title='مواقيت الصلاة';
    b.setAttribute('aria-label','مواقيت الصلاة');
    b.innerHTML='<svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="9"></circle><path d="M12 7v5l3 2"></path></svg><span>الصلاة</span><time dir="ltr">--:--:--</time>';
    b.addEventListener('click',()=>{location.href='/prayer-times';});
    return b;
  }
  function ensureMutoonReaderPrayerCountdown(){
    const enabled=prayerHeaderToggleEnabled();
    const syncRow=(row,titleSelector,rowClass,titleClass,keepTitleLayout=false)=>{
      if(!row)return;const title=$(titleSelector,row),prayer=row.querySelector('.munibin-mutoon-reader-prayer');
      if(keepTitleLayout){row.classList.add('munibin-mutoon-reader-header-row',rowClass);title?.classList.add('munibin-mutoon-reader-title',titleClass);}
      if(!enabled){prayer?.remove();if(!keepTitleLayout){row.classList.remove('munibin-mutoon-reader-header-row',rowClass);title?.classList.remove('munibin-mutoon-reader-title',titleClass);}return;}
      row.classList.add('munibin-mutoon-reader-header-row',rowClass);
      title?.classList.add('munibin-mutoon-reader-title',titleClass);
      if(!prayer)row.append(readerPrayerCountdownElement());
    };
    syncRow($('[data-loc="client/src/pages/MatnReader.tsx:1824"]'),'[data-loc="client/src/pages/MatnReader.tsx:1882"]','munibin-matn-reader-header-row','munibin-matn-reader-title');
    syncRow($('[data-loc="client/src/pages/WirdSession.tsx:1213"]'),'[data-loc="client/src/pages/WirdSession.tsx:1231"]','munibin-wird-reader-header-row','munibin-wird-reader-title',true);
  }

  // ---------------- Runtime observer ----------------
  function ensureAudioSelectedScroll(){
    // Existing v184 custom sheets get this class. Center the selected row every time a sheet opens.
    const list=$('.munibin-choice-list');const selected=list?.querySelector('.is-selected');if(selected&&!selected.dataset.munibinCentered){selected.dataset.munibinCentered='1';requestAnimationFrame(()=>selected.scrollIntoView({block:'center'}));}
  }
  function tick(){
    try{
      ensureWirdButton(); applyBookmarkTints(); injectBookmarkAction(); ensureQiblaButton(); ensureAudioSelectedScroll(); ensureMutoonReaderPrayerCountdown(); updateInAppPrayerCountdown(); const panel=$('.qcf1441-reciter-panel[aria-label="الاستماع إلى تلاوة القرآن"]');const visible=!!panel&&panel.getClientRects().length>0&&getComputedStyle(panel).display!=='none'&&panel.getAttribute('aria-hidden')!=='true';if(visible)preselectAudioForBigPlay(panel);else{if(panel)delete panel.dataset.munibinMidpageApplied;audioPanelSeen=null;}
    }catch(err){console.error('[Munibin] feature tick failed',err);}
  }
  const restoredNativeCount=restorePersistentState();migrateLegacySleepToNativeAdhkar();persistCriticalState();
  if(restoredNativeCount>0&&window.MunibinAndroid&&!sessionStorage.getItem('munibin:persistent-restored:v1')){sessionStorage.setItem('munibin:persistent-restored:v1','1');setTimeout(()=>location.reload(),40);}
  document.addEventListener('pointerdown',e=>{const g=e.target.closest?.('.qcf1441-glyph-word[data-verse-key]');if(g)lastVerseKey=g.dataset.verseKey||'';},true);
  document.addEventListener('click',e=>{const t=e.target.closest?.('.qcf1441-audio-footer-launch,.qcf1441-audio-menu-opener');if(!t)return;if(t.classList.contains('qcf1441-audio-footer-launch'))audioBigPlayIntent={page:currentPage(),at:Date.now()};else audioBigPlayIntent=null;},true);
  window.addEventListener('storage',persistCriticalState);['munibin-adhkar-view-change','munibin-hisn-progress-change','munibin-prayer-reminders-change','munibin-prayer-time-format-change','munibin-prayer-iqama-notifications-change'].forEach(name=>window.addEventListener(name,()=>persistCriticalState(true)));window.addEventListener('mutoon:prayer-location-change',()=>persistCriticalState(true));window.addEventListener('mutoon:prayer-times-offline-cache',()=>persistCriticalState(true));window.addEventListener('beforeunload',persistCriticalState);window.addEventListener('online',refreshAccountAndCloud);
  let featureTickQueued=false;
  const queueFeatureTick=()=>{if(featureTickQueued)return;featureTickQueued=true;requestAnimationFrame(()=>{featureTickQueued=false;tick();});};
  window.addEventListener('mutoon:prayer-header-countdown-change',queueFeatureTick);
  // Color controls only repaint their own preview/CSS. Their DOM changes do
  // not require rescanning Quran words, sura geometry, bookmarks or audio.
  function isOutsideQuranColorSettings(record){
    const inside=node=>{const element=node?.nodeType===1?node:node?.parentElement;return !!element?.closest?.('.munibin-quran-color-setting, .munibin-quran-color-backdrop');};
    if(inside(record.target))return false;
    if(record.type==='childList'){
      const nodes=[...record.addedNodes,...record.removedNodes];
      if(nodes.length&&nodes.every(inside))return false;
    }
    return true;
  }
  new MutationObserver(records=>{if(records.some(isOutsideQuranColorSettings))queueFeatureTick();}).observe(document.documentElement,{childList:true,subtree:true,characterData:true});
  migrateLegacyToScope(accountScope);tick();refreshAccountAndCloud();setInterval(()=>{tick();},700);setInterval(updateInAppPrayerCountdown,250);setInterval(()=>{if(navigator.onLine)refreshAccountAndCloud();},15000);

  // Useful deterministic hooks for validation and future migrations.
  window.__munibinFeatureRelease='v220';window.__munibinV185={buildSchedule,openWirdHub,openQibla,syncPlannerCloud,openBookmarkEditor};

  const style=document.createElement('style');style.id='munibin-features-v185-style';style.textContent=`
  .munibin-v185-overlay{position:fixed;inset:0;z-index:100000;font-family:var(--app-font,'Noto Kufi Arabic',sans-serif);color:var(--app-text-primary,#3d1506)}.munibin-v185-backdrop{position:absolute;inset:0;background:rgba(20,10,4,.54);backdrop-filter:blur(2px)}.munibin-v185-sheet{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(94vw,620px);max-height:88dvh;display:flex;flex-direction:column;background:var(--app-card-bg,#fffdf7);border:1px solid var(--app-divider,rgba(120,70,20,.2));border-radius:24px;box-shadow:0 24px 70px rgba(0,0,0,.3);overflow:hidden}.munibin-v185-sheet>header{display:flex;align-items:center;justify-content:space-between;padding:15px 17px;border-bottom:1px solid var(--app-divider,rgba(120,70,20,.18));background:var(--app-header-bg,var(--app-card-bg,#fffdf7))}.munibin-v185-sheet>header strong{font-size:16px}.munibin-v185-sheet>header button{width:34px;height:34px;border:0;border-radius:50%;background:var(--app-input-bg,rgba(150,90,20,.08));color:inherit;display:flex;align-items:center;justify-content:center;padding:0}.munibin-v185-sheet>header button svg{width:16px;height:16px;display:block;margin:0 auto;flex:0 0 auto}.munibin-v185-sheet svg,.munibin-wird-header-button svg,.munibin-bookmark-header-button svg,.munibin-recitation-mic svg,.munibin-qibla-button svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}.munibin-v185-body{padding:15px;overflow:auto;overscroll-behavior:contain}.munibin-v185-form{display:grid;gap:14px}.munibin-wird-amount-field{display:grid;gap:9px}.munibin-wird-form-overlay [data-wird-smart-option][hidden],.munibin-wird-form-overlay [data-wird-ayah-endpoint][hidden]{display:none!important}.munibin-v185-form label{display:grid;gap:6px;font-size:12px;font-weight:700}.munibin-v185-form input,.munibin-v185-form select{width:100%;min-height:44px;border:1px solid var(--app-divider,rgba(120,70,20,.22));border-radius:12px;background:var(--app-input-bg,var(--app-bg,#fff8ee));color:inherit;padding:9px 11px;font:inherit}.munibin-wird-choice-select{-webkit-appearance:none!important;appearance:none!important;background-image:none!important;background-color:color-mix(in srgb,var(--app-bg,#fffaf2) 90%,var(--app-gold,#a85d0a) 10%)!important;border-color:color-mix(in srgb,var(--app-divider,rgba(120,70,20,.22)) 72%,var(--app-gold,#a85d0a) 28%)!important;padding-left:11px!important;cursor:pointer;display:block!important;box-sizing:border-box!important}.munibin-wird-date-select{font-variant-numeric:tabular-nums;white-space:nowrap}.munibin-v185-form fieldset{border:0;padding:0;margin:0}.munibin-v185-form legend{font-size:12px;font-weight:700;margin-bottom:7px}.munibin-color-row{display:flex;gap:11px;flex-wrap:wrap;align-items:center}.munibin-color{width:36px;height:36px;border-radius:50%;border:3px solid transparent;background:var(--swatch)!important;box-shadow:0 0 0 1px color-mix(in srgb,var(--swatch) 68%,#28170d),0 2px 7px color-mix(in srgb,var(--swatch) 25%,transparent)}.munibin-color.selected{border-color:var(--app-card-bg,#fff);box-shadow:0 0 0 3px var(--swatch),0 3px 9px color-mix(in srgb,var(--swatch) 35%,transparent)}.munibin-bookmark-location{margin-top:-8px!important;text-align:right!important}.munibin-bookmark-replace-option{display:flex!important;grid-template-columns:none!important;flex-direction:row!important;align-items:flex-start!important;gap:9px!important;margin-top:12px;padding:10px 11px;border:1px solid var(--app-divider,rgba(120,70,20,.18));border-radius:12px;background:var(--app-input-bg,rgba(160,95,15,.06));font-weight:700!important}.munibin-bookmark-replace-option input{width:18px!important;min-height:18px!important;height:18px!important;flex:0 0 18px;margin:2px 0 0!important;padding:0!important;accent-color:var(--app-gold,#a16207)}.munibin-bookmark-replace-option span{display:grid;gap:2px;line-height:1.55}.munibin-bookmark-replace-option strong{font-size:11px}.munibin-bookmark-replace-option small{font-size:9px;font-weight:500;opacity:.68}.munibin-v185-actions{display:flex;gap:10px;justify-content:flex-end;flex-wrap:wrap;margin-top:4px}.munibin-v185-overlay button{font:inherit;cursor:pointer}.munibin-v185-overlay .primary,.munibin-v185-overlay .secondary,.munibin-v185-overlay .danger{border-radius:12px;padding:10px 14px;font-weight:800;border:1px solid transparent}.munibin-v185-overlay .primary{background:var(--app-gold,#b26a12);color:#fff}.munibin-v185-overlay .secondary{background:var(--app-input-bg,rgba(180,110,20,.1));color:inherit;border-color:var(--app-divider,rgba(120,70,20,.2))}.munibin-v185-overlay .danger{background:rgba(185,28,28,.10);color:#b91c1c;border-color:rgba(185,28,28,.22)}.munibin-v185-muted{font-size:11px;line-height:1.8;opacity:.72;margin:0}.munibin-tabs{display:flex;padding:3px;background:var(--app-input-bg,rgba(130,70,15,.08));border-radius:14px;margin-bottom:13px}.munibin-tabs button{flex:1;border:0;background:none;padding:9px;border-radius:11px;color:inherit;font-weight:700}.munibin-tabs button[data-tab]{display:flex;align-items:center;justify-content:center;gap:.42rem;direction:rtl}.munibin-tabs button.active{background:var(--app-card-bg,#fff);box-shadow:0 2px 8px rgba(0,0,0,.08)}.munibin-add-wird{width:100%;margin-bottom:12px}.munibin-wird-list,.munibin-bookmark-list,.munibin-days{display:grid;gap:10px}.munibin-wird-card,.munibin-bookmark-card,.munibin-day{border:1px solid var(--app-divider,rgba(120,70,20,.18));border-radius:16px;background:var(--app-bg,#fffaf2)}.munibin-wird-main{width:100%;text-align:right;border:0;background:none;color:inherit;padding:13px;display:grid;gap:4px}.munibin-wird-main strong{font-size:14px}.munibin-wird-main span,.munibin-wird-main small{font-size:11px}.munibin-wird-range-only{font-size:12px!important;opacity:1!important;color:inherit!important;font-weight:650;line-height:1.8}.munibin-wird-preview-date{display:block;font-size:10px!important;line-height:1.35;opacity:.68;font-weight:600;font-variant-numeric:tabular-nums}.munibin-wird-preview-date.is-overdue{color:#b91c1c!important;opacity:1;font-weight:800}.munibin-wird-preview-date:empty{display:none}.munibin-wird-expand{width:100%;min-height:36px;border:0;border-top:1px solid var(--app-divider,rgba(120,70,20,.12));background:var(--app-input-bg,rgba(180,110,20,.045));color:var(--app-gold,#a85d0a);display:flex;align-items:center;justify-content:center;gap:7px;font-size:11px;font-weight:800}.munibin-wird-chevron{font-size:18px;line-height:1;transition:transform .18s ease}.munibin-wird-expand[aria-expanded="true"] .munibin-wird-chevron{transform:rotate(180deg)}.munibin-wird-card{position:relative;overflow:hidden;transition:box-shadow .25s,transform .25s,border-color .25s}.munibin-wird-card.today-done{border-color:rgba(39,129,94,.52);box-shadow:0 0 0 2px rgba(39,129,94,.08),0 8px 24px rgba(39,129,94,.12)}.munibin-wird-edit-icon{position:absolute;left:10px;top:9px;z-index:2;width:36px;height:36px;border:1px solid var(--app-divider,rgba(120,70,20,.16));border-radius:12px;background:var(--app-input-bg,rgba(160,95,15,.07));color:var(--app-gold,#a16207);display:flex;align-items:center;justify-content:center;box-shadow:none;transition:transform .16s ease,box-shadow .16s ease}.munibin-wird-edit-icon:active{transform:scale(.94);box-shadow:0 1px 4px rgba(80,35,5,.12)}.munibin-wird-edit-icon svg{width:19px!important;height:19px!important;fill:none!important;stroke:currentColor!important;stroke-width:2.25!important;stroke-linecap:round!important;stroke-linejoin:round!important}.munibin-wird-main{padding-left:52px!important}.munibin-wird-actions{display:flex;border-top:1px solid var(--app-divider,rgba(120,70,20,.14))}.munibin-wird-actions button{flex:1;border:0;background:none;color:var(--app-gold,#a85d0a);padding:11px 9px;font-weight:700}.munibin-wird-actions .munibin-wird-start{margin:8px;border-radius:14px;min-height:46px;background:var(--app-gold,#b26a12);color:#fff;font-weight:900;box-shadow:0 7px 18px color-mix(in srgb,var(--app-gold,#b26a12) 30%,transparent),inset 0 1px 0 rgba(255,255,255,.24);transition:transform .16s ease,box-shadow .16s ease}.munibin-wird-actions .munibin-wird-start:active{transform:scale(.98);box-shadow:0 3px 9px color-mix(in srgb,var(--app-gold,#b26a12) 24%,transparent)}.munibin-wird-actions .munibin-wird-finish{margin:8px;border-radius:14px;min-height:46px;background:linear-gradient(135deg,#73936a,#496d50);color:#fff;font-weight:900;display:flex;align-items:center;justify-content:center;border-right:0!important;box-shadow:0 7px 18px rgba(73,109,80,.20),inset 0 1px 0 rgba(255,255,255,.22);transition:transform .16s ease,box-shadow .16s ease,filter .16s ease}.munibin-wird-actions .munibin-wird-finish:active{transform:scale(.98);box-shadow:0 3px 9px rgba(73,109,80,.18)}.munibin-wird-actions .munibin-wird-finish:disabled,.munibin-wird-actions .munibin-wird-finish.done{color:#fff;opacity:1;filter:saturate(1.05);background:linear-gradient(135deg,#648b60,#3b6547);box-shadow:0 0 0 2px rgba(100,139,96,.13),0 8px 22px rgba(59,101,71,.24),inset 0 1px 0 rgba(255,255,255,.22)}.munibin-wird-actions button+button{border-right:1px solid var(--app-divider,rgba(120,70,20,.14))}.munibin-wird-actions button:disabled{opacity:1}.munibin-wird-expanded{border-top:1px solid var(--app-divider,rgba(120,70,20,.14));padding:10px;background:color-mix(in srgb,var(--app-bg,#fffaf2) 78%,var(--app-card-bg,#fff) 22%)}.munibin-wird-summary{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px}.munibin-wird-summary [data-resume]{grid-column:1/-1}.munibin-day{display:flex;align-items:stretch;overflow:hidden}.munibin-day.done{opacity:.62}.munibin-day-open{flex:1;border:0;background:none;color:inherit;text-align:right;padding:11px;display:grid;grid-template-columns:auto 1fr;gap:2px 10px}.munibin-day-open span{font-size:12px}.munibin-day-open small{grid-column:1/-1;font-size:10px;opacity:.65}.munibin-day-check{width:54px;border:0;border-right:1px solid var(--app-divider,rgba(120,70,20,.16));background:rgba(48,130,85,.07);color:#27815e;font-size:22px}.munibin-weekdays{border:0!important;padding:0!important;margin:0!important}.munibin-weekdays legend{font-size:12px;font-weight:800;margin-bottom:8px}.munibin-weekday-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:7px}.munibin-weekday-option{display:flex!important;align-items:center;justify-content:center;gap:5px;min-height:42px;border:1px solid var(--app-divider,rgba(120,70,20,.18));border-radius:11px;background:var(--app-bg,#fffaf2);padding:7px!important;font-size:11px!important;font-weight:700!important;cursor:pointer}.munibin-weekday-option input{width:16px!important;height:16px!important;min-height:0!important;margin:0!important;padding:0!important;accent-color:var(--app-gold,#a85d0a)}.munibin-weekday-option:has(input:checked){border-color:var(--app-gold,#a85d0a);background:var(--app-input-bg,rgba(180,110,20,.08))}.munibin-smart-wird-option{display:flex!important;grid-template-columns:none!important;align-items:flex-start!important;gap:10px!important;border:1px solid var(--app-divider,rgba(120,70,20,.18));border-radius:13px;padding:10px 11px!important;background:var(--app-bg,#fffaf2);cursor:pointer}.munibin-smart-wird-option input{width:18px!important;height:18px!important;min-height:0!important;margin:2px 0 0!important;padding:0!important;flex:0 0 18px;accent-color:var(--app-gold,#a85d0a)}.munibin-smart-wird-option span{display:grid;gap:3px;line-height:1.55}.munibin-smart-wird-option strong{font-size:12px}.munibin-smart-wird-option small{font-size:10px;font-weight:500;opacity:.68}.munibin-smart-wird-option:has(input:checked){border-color:var(--app-gold,#a85d0a);background:var(--app-input-bg,rgba(180,110,20,.08))}@media(max-width:380px){.munibin-weekday-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}.munibin-ranges{display:grid;gap:12px}.munibin-range-row{border:1.5px solid color-mix(in srgb,var(--app-gold,#a85d0a) 42%,var(--app-divider,rgba(120,70,20,.18)) 58%);border-radius:15px;padding:10px;background:var(--app-bg,#fffaf2);box-shadow:0 1px 0 color-mix(in srgb,var(--app-gold,#a85d0a) 10%,transparent)}.munibin-range-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;font-size:12px}.munibin-range-head button{border:0;background:none;color:#b91c1c;font-size:20px}.munibin-range-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}.munibin-bookmark-card{display:flex;align-items:center;padding:8px 9px;gap:7px}.munibin-bookmark-card>i{width:11px;height:38px;border-radius:999px;background:var(--swatch);margin-left:3px;box-shadow:0 0 0 1px color-mix(in srgb,var(--swatch) 70%,#2c1608)}.munibin-bookmark-open{flex:1;border:0;background:none;text-align:right;color:inherit;display:grid;gap:3px}.munibin-bookmark-open span{font-size:11.5px;line-height:1.5;color:var(--app-text-secondary,#765f50);opacity:.9;font-weight:600}.munibin-bookmark-edit{width:36px;height:36px;flex:0 0 36px;border:1px solid var(--app-divider,rgba(120,70,20,.16));border-radius:11px;background:var(--app-input-bg,rgba(160,95,15,.07));color:var(--app-gold,#a16207);display:flex;align-items:center;justify-content:center;padding:0}.munibin-bookmark-edit svg{width:17px!important;height:17px!important;display:block!important}.munibin-empty{text-align:center;opacity:.65;padding:28px 8px}
  .qcf1441-verse-action-buttons button[data-action="bookmark"]{display:flex!important;align-items:center!important;justify-content:center!important;direction:rtl!important;flex-direction:row!important;gap:.48rem!important}/* v426 bookmark uses the same outline icon as the ayah toolbar. */
.munibin-mutoon-reader-header-row{position:relative!important;min-height:40px!important}
.munibin-mutoon-reader-prayer{position:absolute!important;left:50%!important;top:50%!important;z-index:12!important;transform:translate(-50%,-50%)!important;max-width:138px!important;min-height:31px!important}
.munibin-mutoon-reader-title{position:relative!important;z-index:4!important}
.munibin-wird-reader-header-row .munibin-wird-reader-title{position:absolute!important;right:16px!important;top:50%!important;transform:translateY(-50%)!important;width:calc(50% - 86px)!important;max-width:150px!important;min-width:0!important;flex:none!important;margin:0!important;text-align:right!important;padding:0!important}
.munibin-wird-reader-header-row .munibin-wird-reader-title>div{justify-content:flex-end!important}.munibin-wird-reader-header-row .munibin-wird-reader-title h1,.munibin-wird-reader-header-row .munibin-wird-reader-title p{max-width:100%!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;text-align:right!important}
.munibin-matn-reader-header-row .munibin-matn-reader-title{padding-left:142px!important;text-align:right!important}
@media(max-width:460px){.munibin-mutoon-reader-prayer{max-width:128px!important;font-size:10px!important;padding-inline:5px!important}.munibin-mutoon-reader-prayer span{max-width:39px!important}.munibin-matn-reader-header-row .munibin-matn-reader-title{padding-left:132px!important}.munibin-wird-reader-header-row .munibin-wird-reader-title{right:14px!important;width:calc(50% - 82px)!important;max-width:132px!important}}
@media(max-width:370px){.munibin-mutoon-reader-prayer{max-width:116px!important}.munibin-mutoon-reader-prayer span{max-width:32px!important}.munibin-matn-reader-header-row .munibin-matn-reader-title{padding-left:120px!important}.munibin-wird-reader-header-row .munibin-wird-reader-title{right:12px!important;width:calc(50% - 76px)!important;max-width:112px!important}}
.munibin-bookmarked-marker{position:relative}.munibin-bookmarked-marker::after{content:"";position:absolute;inset:-.08em -.1em -.13em;border-radius:50%;background:color-mix(in srgb,var(--munibin-bookmark-color) 36%,transparent);border:1px solid color-mix(in srgb,var(--munibin-bookmark-color) 54%,transparent);box-shadow:0 0 8px color-mix(in srgb,var(--munibin-bookmark-color) 36%,transparent);transform:translate(.03em,.055em) scale(1.01,.96);transform-origin:center;pointer-events:none;z-index:-1}.qcf1441-line{isolation:isolate!important;overflow:visible!important}.qcf1441-glyph-word{position:relative!important;z-index:auto!important;overflow:visible!important}.qcf1441-glyph.qcf1441-glyph-word--recited{position:relative!important;z-index:auto!important;isolation:auto!important;overflow:visible!important;background:transparent!important}.qcf1441-glyph.qcf1441-glyph-word--recited::before{inset:0!important;z-index:1!important;pointer-events:none!important}.qcf1441-glyph-ink{position:relative!important;z-index:3!important}.qcf1441-glyph-word--recited-end::before{border-radius:0 .32em .32em 0}.munibin-qibla-inactive-card{position:relative!important}.munibin-qibla-inactive-button{position:absolute;top:12px;right:12px;z-index:2;min-width:52px;height:46px;padding:4px 7px;border:1px solid var(--app-divider,rgba(120,70,20,.22));border-radius:13px;background:var(--app-input-bg,rgba(161,98,7,.10));color:var(--app-gold,#a16207);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;font:inherit;font-weight:800;cursor:pointer;box-shadow:0 2px 8px rgba(161,98,7,.10)}.munibin-qibla-inactive-button .munibin-qibla-button-kaaba{width:28px!important;height:28px!important;display:block!important;stroke:none!important}.munibin-qibla-inactive-button span{font-size:9px;line-height:1}.munibin-qibla-inactive-button .k-roof{fill:#17110d!important}.munibin-qibla-inactive-button .k-front{fill:#0e0d0b!important}.munibin-qibla-inactive-button .k-side{fill:#1c1914!important}.munibin-qibla-inactive-button .k-band,.munibin-qibla-inactive-button .k-door{fill:#d8a916!important}.munibin-qibla-button{color:var(--app-gold,#a16207)!important;box-shadow:0 2px 8px rgba(161,98,7,.10)!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;padding:0!important}.munibin-qibla-button .munibin-qibla-button-kaaba{width:36px!important;height:36px!important;display:block!important;stroke:none!important;pointer-events:none}.munibin-qibla-button .k-roof{fill:#17110d!important;stroke:none!important}.munibin-qibla-button .k-front{fill:#0e0d0b!important;stroke:none!important}.munibin-qibla-button .k-side{fill:#1c1914!important;stroke:none!important}.munibin-qibla-button .k-band,.munibin-qibla-button .k-door{fill:#d8a916!important;stroke:none!important}.munibin-qibla-overlay .munibin-v185-backdrop{background:rgba(30,18,8,.62);backdrop-filter:none}.munibin-qibla-overlay .munibin-v185-sheet{width:min(94vw,520px);max-height:min(90dvh,760px);background:#211606!important;color:#fff8e7!important;border:1px solid #5b421f!important;box-shadow:0 24px 72px rgba(0,0,0,.58)}.munibin-qibla-overlay .munibin-v185-sheet>header{background:#2d1e0d!important;border-color:#5b421f!important}.munibin-qibla-overlay .munibin-v185-sheet>header button{background:#3a2916!important;color:#f4c76a!important;display:flex!important;align-items:center!important;justify-content:center!important;padding:0!important}.munibin-qibla-overlay .munibin-v185-sheet>header button svg{display:block!important;margin:0!important}.munibin-qibla-overlay .munibin-v185-body{background:#211606!important;padding:18px 18px 20px}.light .munibin-qibla-overlay .munibin-v185-sheet{background:#fffdf7!important;color:#3d1506!important;border-color:#d9bf8d!important;box-shadow:0 22px 60px rgba(61,21,6,.25)}.light .munibin-qibla-overlay .munibin-v185-sheet>header{background:#fff7e5!important;border-color:#e3cda5!important}.light .munibin-qibla-overlay .munibin-v185-sheet>header button{background:#f5e7ca!important;color:#8a4b08!important}.light .munibin-qibla-overlay .munibin-v185-body{background:#fffdf7!important}.munibin-qibla{text-align:center;padding:0 2px 2px}.munibin-qibla-intro{display:grid;gap:4px;margin:0 auto 21px}.munibin-qibla-intro strong{font-size:18px}.munibin-qibla-intro span{font-size:11px;opacity:.7}.munibin-compass{position:relative;width:min(75vw,350px);aspect-ratio:1;margin:34px auto 20px;border:2px solid #8f682c;border-radius:50%;background:#2d1e0d!important;box-shadow:inset 0 0 0 9px #261a0d,inset 0 0 0 10px #5b421f,0 10px 30px rgba(0,0,0,.2);overflow:visible}.light .munibin-compass{border-color:#c48a32;background:#fff8e9!important;box-shadow:inset 0 0 0 9px #f4e6c7,inset 0 0 0 10px #e0c48c,0 10px 30px rgba(91,54,10,.12)}.munibin-compass::before{content:"";position:absolute;inset:13px;border-radius:50%;background:repeating-conic-gradient(from -1deg,#8f682c 0deg 1deg,transparent 1deg 14deg);opacity:.58;mask:radial-gradient(circle,transparent 0 76%,#000 77% 100%);-webkit-mask:radial-gradient(circle,transparent 0 76%,#000 77% 100%)}.light .munibin-compass::before{background:repeating-conic-gradient(from -1deg,#a16207 0deg 1deg,transparent 1deg 14deg)}.munibin-compass::after{content:"";position:absolute;inset:36px;border-radius:50%;border:1px solid #4d371c;pointer-events:none}.light .munibin-compass::after{border-color:#ead4aa}.munibin-qibla-target{position:absolute;z-index:6;left:50%;top:50%;transform:translate(-50%,-50%);width:58px;height:58px;border-radius:0;display:flex;align-items:center;justify-content:center;background:transparent!important;border:0!important;box-shadow:none!important;pointer-events:none;will-change:transform}.light .munibin-qibla-target{background:transparent!important;border:0!important;box-shadow:none!important}.munibin-qibla-kaaba{width:54px;height:54px;filter:drop-shadow(0 3px 4px rgba(0,0,0,.28))}.munibin-qibla-kaaba svg{width:100%;height:100%;stroke:none!important}.munibin-qibla-kaaba .k-roof{fill:#17110d}.munibin-qibla-kaaba .k-front{fill:#0e0d0b}.munibin-qibla-kaaba .k-side{fill:#1c1914}.munibin-qibla-kaaba .k-band{fill:#d8a916}.munibin-qibla-kaaba .k-door{fill:#d8a916}.munibin-cardinal{position:absolute;z-index:3;font-size:14px;font-weight:900;color:#f4c76a}.light .munibin-cardinal{color:#a16207}.munibin-cardinal.n{top:45px;left:50%;transform:translateX(-50%)}.munibin-cardinal.s{bottom:26px;left:50%;transform:translateX(-50%)}.munibin-cardinal.e{right:29px;top:50%;transform:translateY(-50%)}.munibin-cardinal.w{left:29px;top:50%;transform:translateY(-50%)}.munibin-qibla-needle{position:absolute;z-index:4;left:50%;top:50%;width:34px;height:78%;margin-left:-17px;margin-top:-39%;transform-origin:50% 50%;transition:none;will-change:transform}.munibin-qibla-needle .needle-head{position:absolute;left:3px;right:3px;top:0;height:48%;background:#f4c76a;clip-path:polygon(50% 0,100% 100%,50% 81%,0 100%);filter:drop-shadow(0 3px 4px rgba(0,0,0,.2))}.light .munibin-qibla-needle .needle-head{background:#b35f08}.munibin-qibla-needle .needle-shaft{position:absolute;left:14px;top:37%;width:6px;height:30%;border-radius:999px;background:#f4c76a}.light .munibin-qibla-needle .needle-shaft{background:#b35f08}.munibin-qibla-needle .needle-tail{position:absolute;left:7px;right:7px;bottom:4%;height:29%;background:#f0dfbb;clip-path:polygon(50% 100%,0 0,50% 18%,100% 0)}.light .munibin-qibla-needle .needle-tail{background:#d8c7a7}.munibin-center-pin{position:absolute;z-index:5;left:50%;top:50%;width:18px;height:18px;transform:translate(-50%,-50%);border-radius:50%;background:#f4c76a;border:4px solid #211606;box-shadow:0 0 0 2px #8f682c}.light .munibin-center-pin{background:#b35f08;border-color:#fff8e9;box-shadow:0 0 0 2px #c48a32}.munibin-compass.aligned{border-color:#61a276;box-shadow:inset 0 0 0 9px #261a0d,inset 0 0 0 10px #61a276,0 0 0 5px rgba(97,162,118,.12),0 10px 30px rgba(0,0,0,.2)}.light .munibin-compass.aligned{border-color:#2d7b48;box-shadow:inset 0 0 0 9px #f4e6c7,inset 0 0 0 10px #5f9870,0 0 0 5px rgba(45,123,72,.10),0 10px 30px rgba(91,54,10,.12)}.munibin-qibla-readout{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:0 auto 12px;max-width:350px}.munibin-qibla-readout>div{display:grid;gap:3px;padding:10px 12px;border-radius:15px;background:#2d1e0d!important;border:1px solid #5b421f}.light .munibin-qibla-readout>div{background:#fff7e5!important;border-color:#e3cda5}.munibin-qibla-readout span{font-size:10px;opacity:.65}.munibin-qibla-readout strong{font-size:20px;color:#f4c76a}.light .munibin-qibla-readout strong{color:#a16207}.munibin-qibla-status{max-width:350px;margin:0 auto;padding:11px 14px;border-radius:15px;background:#382714!important;border:1px solid #5b421f;font-weight:800;font-size:13px;color:#f4c76a}.light .munibin-qibla-status{background:#fff4d5!important;border-color:#dfbd7b;color:#8d4f09}.munibin-qibla-status.aligned{background:#203528!important;border-color:#4f8661;color:#a7e1b6}.light .munibin-qibla-status.aligned{background:#e6f2e8!important;border-color:#82ae8f;color:#23633b}.munibin-qibla-help{max-width:340px;margin:10px auto 0;font-size:10px;line-height:1.8;opacity:.62}[data-loc="client/src/pages/AdhkarPage.tsx:236"]>div{border-bottom-left-radius:1.5rem!important;border-bottom-right-radius:1.5rem!important}
.munibin-v185-toast{position:fixed;left:50%;bottom:88px;transform:translate(-50%,20px);z-index:110000;background:#24170d;color:#fff9eb;padding:10px 15px;border-radius:999px;opacity:0;pointer-events:none;transition:.2s}.munibin-v185-toast.show{opacity:1;transform:translate(-50%,0)}
  `;document.head.append(style);
})();


/* v263: feature sheets are fully opaque in every app palette. */
(()=>{
  if(window.__munibinOpaqueFeatureSheetsV263)return;
  window.__munibinOpaqueFeatureSheetsV263=true;
  const style=document.createElement('style');
  style.id='munibin-opaque-feature-sheets-v263';
  style.textContent=`
    .munibin-v185-sheet{
      background:var(--app-bg,#3d1506)!important;
      opacity:1!important;
    }
  `;
  const install=()=>{if(!document.getElementById(style.id))document.head.appendChild(style);};
  if(document.head)install();else document.addEventListener('DOMContentLoaded',install,{once:true});
})();
