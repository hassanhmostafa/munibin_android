// Local prayer reminders. No network or push subscription is used.
import { formatPrayerClock, normalizePrayerTimeFormat } from './prayer-display-v423.js';
export const REMINDER_KEY = 'munibin:prayer-reminders:v1';
export const REMINDER_EVENT = 'munibin-prayer-reminders-change';
export const IQAMA_NOTIFICATION_KEY = 'munibin:prayer-iqama-notifications:v1';
export const IQAMA_NOTIFICATION_EVENT = 'munibin-prayer-iqama-notifications-change';
export const PRAYER_LABELS = { Fajr: 'الفجر', Dhuhr: 'الظهر', Asr: 'العصر', Maghrib: 'المغرب', Isha: 'العشاء' };
const MIN_REMINDER_MINUTES = 5;
const MAX_REMINDER_MINUTES = 60;
const REMINDER_STEP_MINUTES = 5;
function normalizeReminderMinutes(value) {
  if (value == null || value === '') return 10;
  const minutes = Number(value);
  if (!Number.isFinite(minutes)) return 10;
  const stepped = Math.round(minutes / REMINDER_STEP_MINUTES) * REMINDER_STEP_MINUTES;
  return Math.min(MAX_REMINDER_MINUTES, Math.max(MIN_REMINDER_MINUTES, stepped));
}
export function normalizeReminders(value) {
  return Object.fromEntries(Object.keys(PRAYER_LABELS).map(key => {
    const item = value?.[key];
    return [key, { enabled: item?.enabled === true, minutes: normalizeReminderMinutes(item?.minutes) }];
  }));
}
export function readReminders(storage = localStorage) {
  try { return normalizeReminders(JSON.parse(storage.getItem(REMINDER_KEY) || 'null')); }
  catch { return normalizeReminders(null); }
}
export function saveReminders(value, storage = localStorage) {
  const clean = normalizeReminders(value);
  storage.setItem(REMINDER_KEY, JSON.stringify(clean));
  if (typeof window !== 'undefined') window.dispatchEvent(new Event(REMINDER_EVENT));
  return clean;
}
export function hasReminders(value) {
  return Object.values(normalizeReminders(value)).some(item => item.enabled);
}
export function normalizeIqamaNotifications(value) {
  return Object.fromEntries(Object.keys(PRAYER_LABELS).map(key => [key, { enabled: value?.[key]?.enabled === true }]));
}
export function readIqamaNotifications(storage = globalThis.localStorage) {
  try { return normalizeIqamaNotifications(JSON.parse(storage?.getItem(IQAMA_NOTIFICATION_KEY) || 'null')); }
  catch { return normalizeIqamaNotifications(null); }
}
export function saveIqamaNotifications(value, storage = globalThis.localStorage) {
  const clean = normalizeIqamaNotifications(value);
  storage?.setItem(IQAMA_NOTIFICATION_KEY, JSON.stringify(clean));
  if (typeof window !== 'undefined') window.dispatchEvent(new Event(IQAMA_NOTIFICATION_EVENT));
  return clean;
}
export function hasIqamaNotifications(value) {
  return Object.values(normalizeIqamaNotifications(value)).some(item => item.enabled);
}

const iqamaClockFormatters = new Map();
function iqamaClockAt(date, timeZone) {
  if (timeZone) {
    try {
      let formatter = iqamaClockFormatters.get(timeZone);
      if (!formatter) {
        formatter = new Intl.DateTimeFormat('en-US-u-nu-latn', { timeZone, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });
        iqamaClockFormatters.set(timeZone, formatter);
        if (iqamaClockFormatters.size > 16) iqamaClockFormatters.delete(iqamaClockFormatters.keys().next().value);
      }
      const parts = Object.fromEntries(formatter.formatToParts(date).filter(part => part.type === 'hour' || part.type === 'minute').map(part => [part.type, part.value]));
      return `${parts.hour}:${parts.minute}`;
    } catch { return null; }
  }
  return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
}

export function buildPrayerAlertSchedule(calendar, now, offsets, modes, reminders, applyOffsets, dateFor, iqamaOffsets = {}, iqamaSettings = {}, timeFormat = '12h') {
  if (!calendar?.days) return [];
  const settings = normalizeReminders(reminders);
  const iqama = normalizeIqamaNotifications(iqamaSettings);
  const clockFormat = normalizePrayerTimeFormat(timeFormat);
  const cutoff = now.getTime();
  const alerts = [];
  for (const [day, data] of Object.entries(calendar.days)) {
    const timings = applyOffsets(data.timings, offsets);
    const timeZone = data.meta?.timezone || calendar.location?.timeZone || '';
    for (const [key, label] of Object.entries(PRAYER_LABELS)) {
      const prayerDate = dateFor(day, timings[key]);
      if (!prayerDate || !Number.isFinite(prayerDate.getTime())) continue;
      const prayerAt = prayerDate.toISOString();
      const displayTime = formatPrayerClock(timings[key], clockFormat);
      const shared = { key, label, prayerAt, time: timings[key], prayerTime: timings[key], timeZone, displayTime };
      if (modes[key] === 'notification' || modes[key] === 'audio') {
        if (prayerDate.getTime() > cutoff) alerts.push({ ...shared, at: prayerAt, alertMode: modes[key], kind: 'prayer' });
      }
      if (settings[key].enabled) {
        const reminderDate = new Date(prayerDate.getTime() - settings[key].minutes * 60000);
        if (reminderDate.getTime() > cutoff) alerts.push({ ...shared, at: reminderDate.toISOString(), alertMode: 'notification', kind: 'pre-prayer', minutesBefore: settings[key].minutes });
      }
      const minutes = iqamaOffsets[key];
      if (iqama[key].enabled && Number.isInteger(minutes) && minutes > 0) {
        const iqamaDate = new Date(prayerDate.getTime() + minutes * 60000);
        if (Number.isFinite(iqamaDate.getTime()) && iqamaDate.getTime() > cutoff) {
          const time = iqamaClockAt(iqamaDate, timeZone);
          if (time) alerts.push({ ...shared, at: iqamaDate.toISOString(), time, displayTime: formatPrayerClock(time, clockFormat), alertMode: 'notification', kind: 'iqama', type: 'iqama' });
        }
      }
    }
  }
  // One chronological queue prevents later reminders from displacing nearer prayers.
  return alerts.sort((a, b) => Date.parse(a.at) - Date.parse(b.at) || a.key.localeCompare(b.key)).slice(0, 60);
}

let permissionRequest = null;
export function requestReminderPermission() {
  if (permissionRequest) return permissionRequest;
  const ios = window.webkit?.messageHandlers?.['munibin-prayer-permission'];
  const android = window.MunibinAndroid?.requestPrayerReminderPermission;
  if (!ios && !android) return Promise.reject(new Error('حدّث التطبيق لتفعيل التذكير قبل الصلاة.'));
  permissionRequest = new Promise((resolve, reject) => {
    const finish = () => { clearTimeout(timer); window.removeEventListener('munibin-prayer-permission-result', result); };
    const result = event => {
      finish();
      if (event.detail?.granted) resolve();
      else reject(new Error('فعّل إشعارات منيبين من إعدادات الجهاز ثم أعد المحاولة.'));
    };
    const timer = setTimeout(() => { finish(); reject(new Error('لم يكتمل طلب إذن الإشعارات. أعد المحاولة.')); }, 60000);
    window.addEventListener('munibin-prayer-permission-result', result);
    try { if (ios) ios.postMessage({ type: 'request' }); else window.MunibinAndroid.requestPrayerReminderPermission(); }
    catch (error) { finish(); reject(error); }
  }).finally(() => { permissionRequest = null; });
  return permissionRequest;
}

export function createPrayerReminderComponents(React) {
  const h = React.createElement;
  function usePrayerReminders() {
    const [settings, setSettings] = React.useState(() => readReminders());
    React.useEffect(() => {
      const refresh = () => setSettings(readReminders());
      window.addEventListener(REMINDER_EVENT, refresh);
      window.addEventListener('storage', refresh);
      return () => { window.removeEventListener(REMINDER_EVENT, refresh); window.removeEventListener('storage', refresh); };
    }, []);
    return [settings, value => setSettings(saveReminders(value))];
  }
  function useIqamaNotifications() {
    const [settings, setSettings] = React.useState(() => readIqamaNotifications());
    React.useEffect(() => {
      const refresh = () => setSettings(readIqamaNotifications());
      window.addEventListener(IQAMA_NOTIFICATION_EVENT, refresh);
      window.addEventListener('storage', refresh);
      return () => { window.removeEventListener(IQAMA_NOTIFICATION_EVENT, refresh); window.removeEventListener('storage', refresh); };
    }, []);
    return [settings, value => setSettings(saveIqamaNotifications(value))];
  }
  function IqamaNotificationControl({ prayerKey, label, value, onChange, hasLocation, iqamaMinutes, onError = () => {} }) {
    const [busy, setBusy] = React.useState(false);
    const enabled = value?.enabled === true;
    const toggle = async () => {
      onError('');
      if (enabled) { onChange({ enabled: false }); return; }
      if (!hasLocation) { onError('اختر موقعك أولاً ليُحدد وقت الإقامة.'); return; }
      if (!Number.isInteger(iqamaMinutes) || iqamaMinutes <= 0) { onError('حدد مدة إقامة أكبر من صفر لهذه الصلاة أولاً.'); return; }
      setBusy(true);
      try { await requestReminderPermission(); onChange({ enabled: true }); }
      catch (error) { onError(error.message || 'تعذر تفعيل تنبيه الإقامة الآن.'); }
      finally { setBusy(false); }
    };
    return h('div', { className: 'munibin-prayer-reminder munibin-prayer-iqama-control', 'data-prayer': prayerKey },
      h('div', { className: 'munibin-reminder-heading' },
        h('span', { className: 'munibin-reminder-title' }, 'تنبيه وقت الإقامة'),
        h('button', { type: 'button', role: 'switch', 'aria-checked': enabled, 'aria-label': `تنبيه إقامة صلاة ${label}`, disabled: busy, onClick: toggle, className: 'munibin-reminder-switch', 'data-on': enabled }, h('span', { 'aria-hidden': true }, enabled ? '✓' : ''))));
  }
  function IqamaSoundControl({ onError = () => {} }) {
    const android = globalThis.window?.MunibinAndroid;
    const supported = typeof android?.selectIqamaNotificationSound === 'function';
    const readStatus = () => {
      try {
        const raw = android?.getIqamaNotificationSoundStatus?.();
        const status = typeof raw === 'string' ? JSON.parse(raw) : raw;
        return status && typeof status === 'object' ? status : {};
      } catch { return {}; }
    };
    const [status, setStatus] = React.useState(readStatus);
    React.useEffect(() => {
      const refresh = event => setStatus(event.detail && typeof event.detail === 'object' ? event.detail : readStatus());
      window.addEventListener('munibin-iqama-sound-status', refresh);
      return () => window.removeEventListener('munibin-iqama-sound-status', refresh);
    }, []);
    if (!supported || status.selectionSupported === false) return null;
    return h('button', { type: 'button', className: 'munibin-iqama-sound-control', onClick: () => {
      onError('');
      try { android.selectIqamaNotificationSound(); }
      catch { onError('تعذر فتح أصوات الجهاز. حاول مرة أخرى.'); }
    } }, h('span', null, 'صوت تنبيه الإقامة'), status.name && h('small', null, status.name));
  }
  function ReminderControl({ prayerKey, label, value, onChange, hasLocation, onError }) {
    const [busy, setBusy] = React.useState(false);
    const toggle = async () => {
      onError('');
      if (value.enabled) { onChange({ ...value, enabled: false }); return; }
      if (!hasLocation) { onError('اختر موقعك أولاً ليُحدد وقت التذكير.'); return; }
      setBusy(true);
      try { await requestReminderPermission(); onChange({ ...value, enabled: true }); }
      catch (error) { onError(error.message || 'تعذر تفعيل التذكير الآن.'); }
      finally { setBusy(false); }
    };
    const minutes = normalizeReminderMinutes(value.minutes);
    const decrease = () => onChange({ ...value, minutes: Math.max(MIN_REMINDER_MINUTES, minutes - REMINDER_STEP_MINUTES) });
    const increase = () => onChange({ ...value, minutes: Math.min(MAX_REMINDER_MINUTES, minutes + REMINDER_STEP_MINUTES) });
    return h('div', { className: 'munibin-prayer-reminder' },
      h('div', { className: 'munibin-reminder-heading' },
        h('div', null, h('span', { className: 'munibin-reminder-title' }, 'تذكير قبل الصلاة'), h('small', null, 'تنبيه الجهاز فقط')),
        h('button', { type: 'button', role: 'switch', 'aria-checked': value.enabled, 'aria-label': `تذكير قبل صلاة ${label}`, disabled: busy, onClick: toggle, className: 'munibin-reminder-switch', 'data-on': value.enabled }, h('span', { 'aria-hidden': true }, value.enabled ? '✓' : ''))),
      value.enabled && h('div', { className: 'munibin-reminder-minutes' }, h('span', null, 'قبل الصلاة بـ'),
        h('div', { className: 'munibin-reminder-stepper', dir: 'ltr', role: 'group', 'aria-label': `دقائق التذكير قبل صلاة ${label}` },
          h('button', { type: 'button', className: 'munibin-reminder-step', disabled: minutes <= MIN_REMINDER_MINUTES, onClick: decrease, 'aria-label': 'إنقاص 5 دقائق' }, '−'),
          h('span', { className: 'munibin-reminder-value', role: 'status', 'aria-live': 'polite' }, String(minutes)),
          h('button', { type: 'button', className: 'munibin-reminder-step', disabled: minutes >= MAX_REMINDER_MINUTES, onClick: increase, 'aria-label': 'زيادة 5 دقائق' }, '+')),
        h('span', null, 'دقيقة')));
  }
  return { usePrayerReminders, ReminderControl, useIqamaNotifications, IqamaNotificationControl, IqamaSoundControl };
}
