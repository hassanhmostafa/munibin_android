/* The complete document owns the scroll range. Only nearby page ink is mounted;
   fetching or removing ink never inserts/removes a page or changes its height. */
import {documentPageLayout} from './quran-document-geometry-v387.js';
import {loadQuranDocument} from './quran-document-resources-v387.js';

export function pageAtOffset(layouts,offset) {
 let low=0,high=layouts.length-1;
 while(low<high){const middle=(low+high+1)>>1;if(layouts[middle].top<=offset)low=middle;else high=middle-1;}
 return layouts[low]?.page||1;
}
export function createVerticalDocumentPages(React,{normalize,fitBeforePaint,finishMotion,paintKey}) {
 const h=React.createElement;
 const Page=React.memo(function DocumentPage({item,layout,live,render,paint}) {
  return h('article',{'data-scroll-page':item.page,'data-document-live':live?'true':'false',
   className:'munibin-quran-scroll-page',style:{'--munibin-document-page-height':`${layout.articleHeight}px`,
    '--munibin-document-content-height':`${layout.contentHeight}px`,
    '--munibin-document-row-height':`${layout.nativeRowHeight||0}px`}},
   live?render.current(item):null,
   h('div',{className:'munibin-quran-scroll-page-number'},item.page.toLocaleString('ar-EG')));
 },(a,b)=>a.item===b.item&&a.layout===b.layout&&a.live===b.live&&a.render===b.render&&a.paint===b.paint);
 return function VerticalPages({page,data,loadPage,renderPage,revision={},onVisiblePage,onDocumentReady}) {
  const [pages,setPages]=React.useState(()=>data?[data]:[]),[ready,setReady]=React.useState(false),[error,setError]=React.useState(false);
  const [center,setCenter]=React.useState(page),[viewport,setViewport]=React.useState(null);
  const root=React.useRef(null),render=React.useRef(renderPage),load=React.useRef(loadPage),report=React.useRef(onVisiblePage);
  const documentReady=React.useRef(onDocumentReady),items=React.useRef(pages),geometry=React.useRef([]),active=React.useRef(page),reported=React.useRef(page);
  const alive=React.useRef(true),jumping=React.useRef(page),anchor=React.useRef(null),frame=React.useRef(0),reportTimer=React.useRef(0);
  const fonts=React.useRef(new Set()),pendingFonts=React.useRef(new Set()),prepared=React.useRef(false);
  const measuredViewport=React.useRef(null),committedViewport=React.useRef(null);
  render.current=renderPage;load.current=loadPage;report.current=onVisiblePage;documentReady.current=onDocumentReady;items.current=pages;
  const prefs=revision.prefs||{};
  const layouts=React.useMemo(()=>{
   if(!viewport)return [];
   let top=0;
   return pages.map(item=>{const layout={page:item.page,top,...documentPageLayout(item,prefs,viewport)};top+=layout.height;return layout});
  },[pages,viewport,prefs.font,prefs.scale,prefs.tajweed,prefs.spacing,prefs.lineSpacing]);
  const padding=el=>parseFloat(getComputedStyle(el).paddingTop)||0;
  const visible=()=>{
   const el=root.current;if(!el||!geometry.current.length)return active.current;
   const target=Math.min(el.clientHeight-1,Math.max(padding(el)+1,Math.min(el.clientHeight*.22,130)));
   return pageAtOffset(geometry.current,Math.max(0,el.scrollTop+target-padding(el)));
  };
  const captureAnchor=()=>{
   const el=root.current;if(!el||!geometry.current.length||jumping.current!=null)return null;
   const number=pageAtOffset(geometry.current,Math.max(0,el.scrollTop-padding(el)+1));
   const layout=geometry.current.find(layout=>layout.page===number);
   return layout?{page:number,offset:el.scrollTop-layout.top}:null;
  };
  if(layouts!==geometry.current){
   // Zoom/rotation change document geometry, not the selected page. Preserve
   // the within-page offset before replacing the old prefix offsets.
   if(!anchor.current)anchor.current=captureAnchor();
   geometry.current=layouts;
  }
  const flush=()=>{
   const number=visible(),item=items.current.find(item=>item.page===number);if(!item)return null;
   clearTimeout(reportTimer.current);active.current=number;
   if(reported.current!==number){reported.current=number;report.current(number,item)}
   return item;
  };
  const warm=number=>{
   // No data fetching at a range edge: every record is already in Ax. Font
   // activation is independent of scroll extent and prioritizes visible ink.
   const numbers=[number];for(let distance=1;distance<=10;distance++)numbers.push(number+distance,number-distance);
   for(const target of numbers){
    if(target<1||target>604||fonts.current.has(target)||pendingFonts.current.has(target))continue;
    pendingFonts.current.add(target);
    Promise.resolve().then(()=>alive.current?load.current(target):undefined).then(()=>{if(alive.current)fonts.current.add(target)})
     .catch(()=>{}).finally(()=>pendingFonts.current.delete(target));
   }
  };
  const prepare=()=>{
   setError(false);
   loadQuranDocument(normalize).then(all=>{
    if(!alive.current)return;
    const initial=items.current.find(item=>item.page===page);
    const document=initial?all.map(item=>item.page===initial.page?initial:item):all;
    documentReady.current?.(document);
    prepared.current=true;
    // Keep the initial within-page offset while installing the full document.
    if(root.current&&jumping.current==null)anchor.current={page:active.current,offset:root.current.scrollTop};
    setPages(document);setReady(true);
   }).catch(()=>{if(alive.current)setError(true)});
  };
  React.useEffect(()=>{alive.current=true;prepare();return()=>{alive.current=false;cancelAnimationFrame(frame.current);clearTimeout(reportTimer.current)}},[]);
  const measure=preservedAnchor=>{
   const el=root.current;if(!el)return;
   const reader=el.closest('.qcf1441-preview'),style=getComputedStyle(reader||el);
   const native=window.__munibinQcf1441DocumentSizing?.()||{};
   const next={width:el.clientWidth,height:el.clientHeight,
    nativeBaseSize:native.base,nativeIOS:native.ios,nativeTablet:native.tablet,
    contentHeight:parseFloat(style.getPropertyValue('--munibin-reader-content-height'))||el.clientHeight,
    openingContentHeight:parseFloat(style.getPropertyValue('--munibin-opening-content-height'))||undefined,
    // The landscape padding is a max()/safe-area expression. Read its resolved
    // pixels instead of parsing the raw custom-property text as a number.
    inlinePadding:parseFloat(getComputedStyle(el.querySelector('.munibin-quran-document-padding-probe')).paddingLeft)||0,
    fontBase:parseFloat(style.getPropertyValue('--munibin-spread-base-size'))||undefined,
    rootFontSize:parseFloat(getComputedStyle(document.documentElement).fontSize)||16,
    landscape:innerWidth>innerHeight};
   const signature=JSON.stringify(next);
   if(JSON.stringify(measuredViewport.current)!==signature){
    if(!anchor.current&&jumping.current==null)anchor.current=preservedAnchor?.page?preservedAnchor:captureAnchor();
    measuredViewport.current=next;setViewport(next);
   }
   return JSON.stringify(committedViewport.current)!==signature;
  };
  React.useLayoutEffect(()=>{
   const controller={root:root.current,captureAnchor,measure};
   window.__munibinQuranDocumentLayout=controller;
   fitBeforePaint();measure();
   const observer=typeof ResizeObserver==='function'?new ResizeObserver(measure):null;
   const reader=root.current?.closest('.qcf1441-preview');
   const mutation=typeof MutationObserver==='function'?new MutationObserver(measure):null;
   if(reader)mutation?.observe(reader,{attributes:true,attributeFilter:['style','class']});
   observer?.observe(root.current);window.addEventListener('resize',measure,{passive:true});
   return()=>{observer?.disconnect();mutation?.disconnect();window.removeEventListener('resize',measure);
    if(window.__munibinQuranDocumentLayout===controller)delete window.__munibinQuranDocumentLayout;};
  },[]);
  React.useLayoutEffect(()=>{measure()},[prefs.scale,prefs.spacing,prefs.lineSpacing,prefs.tajweed,revision.chrome]);
  React.useLayoutEffect(()=>{
   const el=root.current;if(!el||!layouts.length)return;
   // A measurement requested in this same commit must win before any static
   // alignment reads. React flushes layout-effect state before the next paint.
   if(JSON.stringify(measuredViewport.current)!==JSON.stringify(viewport))return;
   committedViewport.current=viewport;
   const number=jumping.current??anchor.current?.page;
   if(number!=null){
    const layout=layouts.find(item=>item.page===number);
    if(layout){el.scrollTop=layout.top+(anchor.current?.page===number?anchor.current.offset:0);jumping.current=null;anchor.current=null}
   }
   fitBeforePaint(el);
   finishMotion?.(el.closest('.qcf1441-preview'));
  },[layouts,center]);
  const jump=number=>{
   if(!Number.isInteger(number)||number<1||number>604)return;
   clearTimeout(reportTimer.current);cancelAnimationFrame(frame.current);frame.current=0;
   active.current=number;reported.current=number;jumping.current=number;anchor.current=null;
   setCenter(number);if(prepared.current)warm(number);
   const layout=geometry.current.find(item=>item.page===number);
   if(root.current&&layout){root.current.scrollTop=layout.top;jumping.current=null}
  };
  React.useEffect(()=>{if(page!==reported.current)jump(page)},[page]);
  React.useEffect(()=>{
   const navigate=event=>jump(Number(event.detail?.page));
   window.addEventListener('munibin-quran-explicit-jump',navigate);
   window.__munibinQuranFlushVisiblePage=flush;
   return()=>{window.removeEventListener('munibin-quran-explicit-jump',navigate);if(window.__munibinQuranFlushVisiblePage===flush)delete window.__munibinQuranFlushVisiblePage};
  },[]);
  React.useEffect(()=>{if(ready)warm(center)},[ready,center]);
  const scroll=()=>{
   window.__munibinQuranLastInteractionAt=performance.now();
   if(frame.current)return;
   frame.current=requestAnimationFrame(()=>{
    frame.current=0;if(!alive.current||window.__munibinQuranPinching||jumping.current!=null)return;
    const number=visible();active.current=number;setCenter(previous=>previous===number?previous:number);
    if(ready)warm(number);
    clearTimeout(reportTimer.current);
    if(number!==reported.current)reportTimer.current=setTimeout(()=>{if(alive.current&&!window.__munibinQuranPinching&&active.current===number)flush()},100);
   });
  };
  React.useEffect(()=>{
   const el=root.current;if(!el)return;
   const touch=event=>{
    if(event.touches.length>1){
     clearTimeout(reportTimer.current);cancelAnimationFrame(frame.current);frame.current=0;
     // Only pinch handoff may cancel existing native inertia; never an ordinary
     // pan, wheel event, page crossing, font completion or render-window change.
     const top=el.scrollTop,overflow=el.style.overflowY;el.style.overflowY='hidden';el.scrollTop=top;
     el.getBoundingClientRect();el.style.overflowY=overflow;el.scrollTop=top;
    }else flush();
   };
   el.addEventListener('touchstart',touch,{passive:true});
   return()=>el.removeEventListener('touchstart',touch);
  },[]);
  return h('div',{ref:root,className:'munibin-quran-vertical-pages munibin-quran-full-document',onScroll:scroll,
   'data-document-ready':ready?'true':'false','aria-label':'صفحات القرآن بالتمرير العمودي'},
   h('span',{className:'munibin-quran-document-padding-probe','aria-hidden':true}),
   layouts.map((layout,index)=>{const item=pages[index],live=!ready||Math.abs(item.page-center)<=4;
    return h(Page,{key:item.page,item,layout,live,render,paint:live?paintKey(item,revision):''})}),
   !ready&&error&&h('button',{className:'munibin-quran-page-retry',type:'button',onClick:prepare},
    'تعذر تجهيز الصفحات. إعادة المحاولة'));
 };
}
