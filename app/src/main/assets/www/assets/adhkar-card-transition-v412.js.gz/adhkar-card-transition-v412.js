// The completed card stays visible before its position changes. Counter writes
// remain the reader's responsibility and always happen before this controller.
export const ADHKAR_DONE_HOLD_MS = 520;
export const ADHKAR_CARD_OUT_MS = 200;
export const ADHKAR_CARD_IN_MS = 240;

// Keep the page at the reader controls when exchanging cards of different heights.
// If the controls are off screen, preserve the page's ordinary scroll offset.
export function captureAdhkarScroll(card) {
  const controls = card?.nextElementSibling;
  const rect = controls?.matches?.('.munibin-hisn-reader-controls') ? controls.getBoundingClientRect() : null;
  return {
    left: window.scrollX || 0,
    top: window.scrollY || document.documentElement.scrollTop || 0,
    controlsTop: rect && rect.bottom > 0 && rect.top < window.innerHeight ? rect.top : null,
  };
}
export function restoreAdhkarScroll(saved, card) {
  // Every newly arrived dhikr starts at the top, including the final RAF pass.
  window.scrollTo({ left: 0, top: 0, behavior: 'instant' });
  return 0;
}

export function createAdhkarCardTransition(read, clock = window) {
  let timer = null, busy = false, pending = false, origin = null, expectedScope = null;
  let lockedCard = null, previousBusy = null, arrivalScope = null, arrivalIdentity = null;
  const clearTimer = () => { if (timer !== null) clock.clearTimeout(timer); timer = null; };
  const unlockCard = () => {
    if (!lockedCard) return;
    delete lockedCard.dataset.adhkarMotion;
    delete lockedCard.dataset.adhkarBusy;
    lockedCard.style?.removeProperty?.('--adhkar-exit-drag');
    if (previousBusy === null) lockedCard.removeAttribute('aria-busy');
    else lockedCard.setAttribute('aria-busy', previousBusy);
    lockedCard = null;
  };
  const lockCard = card => {
    if (lockedCard === card || !card) return;
    unlockCard(); lockedCard = card;
    previousBusy = card.getAttribute('aria-busy');
    card.dataset.adhkarBusy = 'true'; card.setAttribute('aria-busy', 'true');
  };
  const finish = (notify = true) => {
    clearTimer(); unlockCard(); pending = false; origin = null; expectedScope = null;
    if (busy) { busy = false; if (notify) read().onBusy?.(false); }
  };
  const current = () => {
    const state = read();
    return origin && state.scope === origin.scope && state.identity === origin.identity && state.isCurrent();
  };
  const later = (callback, delay) => { clearTimer(); timer = clock.setTimeout(() => { timer = null; callback(); }, delay); };
  const reduced = () => read().reducedMotion?.() === true;
  let direction = 1;
  return {
    get busy() { return busy; },
    cancel: () => finish(),
    dispose: () => finish(false),
    move(commit, delta = 1, options = {}) {
      if (busy || !read().isCurrent()) return false;
      const state = read();
      origin = { scope: state.scope, identity: state.identity };
      expectedScope = options.scope ?? state.scope;
      direction = delta < 0 ? -1 : 1;
      busy = true; state.onBusy?.(true); lockCard(state.card());
      const switchCard = () => {
        if (!current()) { finish(); return; }
        pending = true;
        // A failed/obsolete navigation must not leave the card locked.
        if (commit() === false) { finish(); return; }
        if (pending) later(finish, 800);
      };
      const leave = () => {
        if (!current()) { finish(); return; }
        if (reduced()) { switchCard(); return; }
        if (lockedCard) lockedCard.dataset.adhkarMotion = direction > 0 ? 'out-next' : 'out-previous';
        later(switchCard, ADHKAR_CARD_OUT_MS);
      };
      // Even with reduced motion, preserve a moment to see the green completion.
      if (options.done) later(leave, ADHKAR_DONE_HOLD_MS);
      else leave();
      return true;
    },
    arrived(scope, identity) {
      const changed = arrivalScope !== scope || arrivalIdentity !== identity;
      arrivalScope = scope; arrivalIdentity = identity;
      if (!changed) return;
      if (!pending || scope !== expectedScope || !read().isCurrent()) { finish(); return; }
      clearTimer(); pending = false;
      lockCard(read().card());
      if (reduced()) { finish(); return; }
      if (lockedCard) lockedCard.dataset.adhkarMotion = direction > 0 ? 'in-next' : 'in-previous';
      later(finish, ADHKAR_CARD_IN_MS);
    },
  };
}

export function useAdhkarCardTransition(React, options) {
  const [busy, setBusy] = React.useState(false);
  const live = React.useRef(null), controller = React.useRef(null);
  live.current = {
    ...options, card: () => options.cardRef.current, onBusy: setBusy,
    reducedMotion: () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches === true,
  };
  if (!controller.current) controller.current = createAdhkarCardTransition(() => live.current);
  React.useLayoutEffect(() => {
    controller.current.arrived(options.scope, options.identity);
  }, [options.scope, options.identity]);
  React.useEffect(() => {
    const cancel = () => controller.current.cancel();
    const hidden = () => { if (document.visibilityState === 'hidden') cancel(); };
    window.addEventListener('pagehide', cancel);
    document.addEventListener('visibilitychange', hidden);
    return () => {
      window.removeEventListener('pagehide', cancel);
      document.removeEventListener('visibilitychange', hidden);
      controller.current.dispose();
    };
  }, []);
  return { get busy() { return controller.current.busy; }, animating: busy, move: (...args) => controller.current.move(...args), cancel: () => controller.current.cancel() };
}

const ADHKAR_INTERACTIVE = 'button,a,input,textarea,select,summary,[role="button"],[role="slider"],[contenteditable="true"],[data-adhkar-no-swipe]';
const ADHKAR_GHOST_CLICK_MS = 750;

// Pointer movement writes only card styles. Reader state changes once, on release.
// The suppression session is shared by successive card bindings so a delayed
// native touch click cannot count the card that has just arrived.
export function createAdhkarSwipeController(read, clock = window, session = { suppressUntil: 0 }) {
  let gesture = null, snapTimer = null;
  const pointers = new Set();
  const now = () => clock.now?.() ?? clock.performance?.now?.() ?? Date.now();
  const card = () => read().card();
  const direction = () => read().direction === 'ltr' ? 'ltr' : 'rtl';
  const blocked = () => read().isBlocked?.() === true || read().isCurrent?.() === false;
  const interactive = target => !!target?.closest?.(ADHKAR_INTERACTIVE);
  const valueControl = target => !!target?.closest?.('input,textarea,select,[role="slider"],[contenteditable="true"]');
  const clearSnap = () => { if (snapTimer !== null) clock.clearTimeout(snapTimer); snapTimer = null; };
  const suppress = () => { session.suppressUntil = now() + ADHKAR_GHOST_CLICK_MS; };
  const actionForDrag = dx => (direction() === 'rtl' ? dx > 0 : dx < 0) ? 'next' : 'previous';
  const available = action => read()[action === 'next' ? 'canNext' : 'canPrevious']?.() !== false;
  const reduced = () => read().reducedMotion?.() === true;
  const forgetDrag = target => {
    if (!target) return;
    delete target.dataset.adhkarDragging; delete target.dataset.adhkarSnap;
    target.style.removeProperty('--adhkar-drag-x');
    target.style.removeProperty('--adhkar-drag-fade');
    target.style.removeProperty('--adhkar-exit-drag');
  };
  const releaseCapture = old => {
    if (!old?.captured) return;
    try { old.card.releasePointerCapture?.(old.id); } catch {}
  };
  const snap = old => {
    clearSnap();
    if (!old?.card) return;
    const target = old.card;
    delete target.dataset.adhkarDragging;
    if (!old.drag || reduced()) { forgetDrag(target); return; }
    target.style.setProperty('--adhkar-exit-drag', `${old.drag}px`);
    target.dataset.adhkarSnap = 'true';
    snapTimer = clock.setTimeout(() => { snapTimer = null; forgetDrag(target); }, 180);
  };
  const cancel = (withSnap = true) => {
    const old = gesture; gesture = null;
    if (old) suppress();
    releaseCapture(old);
    if (withSnap) snap(old); else { clearSnap(); forgetDrag(old?.card || card()); }
  };
  const move = event => {
    const current = gesture;
    if (!current || event.pointerId !== current.id) return;
    if (blocked()) { cancel(); return; }
    current.dx = event.clientX - current.x; current.dy = event.clientY - current.y;
    const x = Math.abs(current.dx), y = Math.abs(current.dy);
    if (current.axis === 'pending') {
      if (y >= 10 && y > x * 1.1) current.axis = 'vertical';
      else if (x >= 10 && x > y * 1.2) current.axis = 'horizontal';
    }
    if (current.axis !== 'horizontal') return;
    if (event.cancelable) event.preventDefault();
    if (!current.captured) {
      try { current.card.setPointerCapture?.(current.id); current.captured = true; } catch {}
    }
    const width = Math.max(180, current.card.getBoundingClientRect?.().width || 360);
    const limit = Math.min(100, width * .25);
    const resistance = available(actionForDrag(current.dx)) ? .68 : .2;
    current.drag = Math.max(-limit, Math.min(limit, current.dx * resistance));
    if (reduced()) return;
    current.card.style.setProperty('--adhkar-drag-x', `${current.drag}px`);
    current.card.style.setProperty('--adhkar-drag-fade', String(Math.min(.12, Math.abs(current.drag) / width * .35)));
    current.card.dataset.adhkarDragging = 'true';
  };
  const handlers = {
    pointerdown(event) {
      if (event.pointerType === 'mouse' && event.button !== 0) return;
      pointers.add(event.pointerId);
      if (pointers.size > 1 || event.isPrimary === false) { cancel(); return; }
      // A fresh intentional touch must not inherit a previous gesture's ghost guard.
      session.suppressUntil = 0;
      if (blocked() || valueControl(event.target)) return;
      clearSnap(); forgetDrag(card());
      gesture = { id: event.pointerId, card: card(), x: event.clientX, y: event.clientY, dx: 0, dy: 0, drag: 0, started: now(), axis: interactive(event.target) ? 'interactive' : 'pending', captured: false };
    },
    pointermove: move,
    pointerup(event) {
      pointers.delete(event.pointerId);
      const old = gesture;
      if (!old || event.pointerId !== old.id) return;
      move(event);
      if (!gesture) return;
      gesture = null; releaseCapture(old);
      const x = Math.abs(old.dx), y = Math.abs(old.dy);
      const traveled = old.axis === 'horizontal' || old.axis === 'vertical' || Math.max(x, y) >= 8;
      if (traveled) suppress();
      if (old.axis !== 'horizontal' || blocked()) { snap(old); return; }
      const width = Math.max(180, old.card.getBoundingClientRect?.().width || 360);
      const threshold = Math.max(38, Math.min(72, width * .16));
      const speed = x / Math.max(1, now() - old.started);
      const action = actionForDrag(old.dx);
      if (x <= y * 1.2 || (x < threshold && !(x >= 28 && speed >= .5)) || !available(action)) { snap(old); return; }
      old.card.style.setProperty('--adhkar-exit-drag', `${reduced() ? 0 : old.drag}px`);
      delete old.card.dataset.adhkarDragging;
      // Returning false means the reader declined navigation (for example midnight).
      if (read()[action]?.() === false) snap(old);
    },
    pointercancel(event) { pointers.delete(event.pointerId); if (gesture?.id === event.pointerId) cancel(); },
    lostpointercapture(event) { if (gesture?.id === event.pointerId) cancel(); },
    click(event) {
      if (session.suppressUntil > now() && event.detail !== 0) {
        event.preventDefault(); event.stopPropagation(); event.stopImmediatePropagation?.();
      }
    },
    keydown(event) {
      if (event.defaultPrevented || event.isComposing || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey || interactive(event.target) || blocked()) return;
      const key = event.key;
      if (key !== 'ArrowLeft' && key !== 'ArrowRight') return;
      const action = (direction() === 'rtl' ? key === 'ArrowLeft' : key === 'ArrowRight') ? 'next' : 'previous';
      event.preventDefault();
      if (available(action)) read()[action]?.();
    },
  };
  return {
    handlers,
    cancel() { cancel(false); pointers.clear(); },
    dispose() { cancel(false); pointers.clear(); },
  };
}

export function useAdhkarSwipe(React, options) {
  const live = React.useRef(options), session = React.useRef({ suppressUntil: 0 });
  live.current = options;
  React.useLayoutEffect(() => {
    const target = live.current.cardRef.current;
    if (!target) return;
    const explicitDirection = live.current.direction;
    const inheritedDirection = target.closest?.('[dir]')?.getAttribute?.('dir');
    const direction = explicitDirection === 'rtl' ? 'rtl' : explicitDirection === 'ltr' || inheritedDirection === 'ltr' ? 'ltr' : 'rtl';
    const controller = createAdhkarSwipeController(() => ({
      ...live.current, card: () => target, direction,
      reducedMotion: () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches === true,
    }), window, session.current);
    target.dataset.adhkarSwipe = direction;
    const listeners = Object.entries(controller.handlers);
    for (const [name, handler] of listeners) target.addEventListener(name, handler, { capture: true, passive: false });
    const hidden = () => { if (document.visibilityState === 'hidden') controller.cancel(); };
    const cancel = () => controller.cancel();
    document.addEventListener('visibilitychange', hidden); window.addEventListener('pagehide', cancel);
    return () => {
      for (const [name, handler] of listeners) target.removeEventListener(name, handler, { capture: true });
      document.removeEventListener('visibilitychange', hidden); window.removeEventListener('pagehide', cancel);
      controller.dispose(); delete target.dataset.adhkarSwipe;
    };
  }, [options.identity]);
}

// Only a newly completed dhikr celebrates; persisted completed cards and ordinary
// navigation retain static success colors without replaying the effect.
export function useAdhkarRewardEffect(React, { cardRef, identity, complete, reward }) {
  const previous = React.useRef({ identity, complete: !!complete });
  React.useLayoutEffect(() => {
    const before = previous.current;
    previous.current = { identity, complete: !!complete };
    const target = cardRef.current;
    if (!target || before.identity !== identity || before.complete || !complete || !reward) return;
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches === true;
    target.dataset.adhkarReward = reduced ? 'complete' : 'celebrate';
    const timer = window.setTimeout(() => { delete target.dataset.adhkarReward; }, ADHKAR_DONE_HOLD_MS + ADHKAR_CARD_OUT_MS);
    return () => { window.clearTimeout(timer); delete target.dataset.adhkarReward; };
  }, [identity, !!complete, reward]);
}
