/* Persistent RTL panes. One frame-driven horizontal gesture owns movement and
   settlement, so WebKit snapping cannot lock a fresh touch and Android native
   momentum cannot fight corrective scroll writes. Vertical pans stay native. */
export function horizontalPageWidth(el) {
  // Android density can produce fractional CSS widths. clientWidth rounds to
  // an integer; multiplying it by 581 slots can land on the preceding page.
  return el?.children?.[0]?.getBoundingClientRect?.().width||el?.clientWidth||0;
}
export function horizontalPageIndex(scrollLeft,width,count) {
  return width>0&&count>0?Math.max(0,Math.min(count-1,Math.round(-scrollLeft/width))):0;
}
export function horizontalSwipeOffset(scrollLeft,width,origin,count=604) {
  if(!(width>0)||!Number.isInteger(origin))return scrollLeft;
  const first=Math.max(1,origin-1),last=Math.min(count,origin+1);
  return Math.max(-(last-1)*width,Math.min(-(first-1)*width,scrollLeft));
}
export function horizontalSwipeTarget(origin,distance,width,velocity=0,count=604) {
  const committed=Math.abs(distance)>=width*.18||Math.abs(distance)>=10&&Math.abs(velocity)>=.2;
  return Math.max(1,Math.min(count,origin+(committed?Math.sign(distance):0)));
}
export function horizontalInstantScroll(el,left) {
  if(!el)return;
  try{el.scrollTo({left,behavior:'instant'});return}catch{}
  // Older WebKit validates the behavior enum and rejects "instant". Disable
  // CSS smoothing for the fallback without changing the vertical scroll offset.
  const previous=el.style?.scrollBehavior;
  if(el.style)el.style.scrollBehavior='auto';
  try{if(typeof el.scrollTo==='function')el.scrollTo({left,behavior:'auto'});else el.scrollLeft=left}
  catch{el.scrollLeft=left}
  finally{if(el.style)el.style.scrollBehavior=previous||''}
}
export function horizontalPageNumbers(page,radius=6) {
  const start=Math.max(1,page-radius),end=Math.min(604,page+radius);
  return Array.from({length:end-start+1},(_,index)=>start+index);
}
export function horizontalMovingWindow(current,page) {
  // Every slot keeps its width. Extending the ink window cannot recenter a
  // fling, and old nearby trees survive a reversed swipe. Cap live ink trees
  // during an unusually long continuous gesture; prune the rest after settling.
  const wanted=new Set([...current,...horizontalPageNumbers(page)]);
  return [...wanted].filter(number=>Math.abs(number-page)<=12).sort((a,b)=>a-b);
}
export function createHorizontalPages(React,fitPage) {
  const h=React.createElement;
  const PageInk=React.memo(function PageInk({item,revision,render}) {return render.current.renderPage(item)});
  // Fixed-width slots keep native scroll offsets stable, but the 591 distant
  // slots do not need skeleton trees or a new render when controls open. React
  // only visits the memoized panes whose ink/reveal/selection props changed.
  const PageSlot=React.memo(function PageSlot({number,item,retained,selected,revision,visibilityRevision,render,events,error}) {
    return h('article',{'data-horizontal-page':number,className:'munibin-quran-horizontal-page'+(number<=2?' munibin-quran-opening-slot':'')+(selected?' is-active':''),
      'aria-hidden':!selected,inert:!selected?'':undefined,'data-horizontal-ink-ready':String(!!item)},
      h('div',{className:'qcf1441-page-layer qcf1441-page-layer--base munibin-quran-horizontal-page-scroll',onScroll:events.verticalScroll,style:{visibility:item?'visible':'hidden'}},
        item?h(PageInk,{item,visibilityRevision,revision,render}):null),
      retained&&!item&&error?h('div',{className:'munibin-quran-page-loading',role:'status','aria-label':'تعذر تحميل الصفحة'},
        h('button',{onClick:()=>events.retry(number)},'تعذر تحميل الصفحة. اضغط لإعادة المحاولة.')):null);
  });
  return function HorizontalPages({page,data,loadPage,renderPage,onPageSelected,onVisiblePage,onTap,onCancelPress,revision,geometryKey}) {
    const [numbers,setNumbers]=React.useState(()=>horizontalPageNumbers(page));
    const [ready,setReady]=React.useState(()=>new Map(data?[[data.page,data]]:[]));
    const [error,setError]=React.useState(null);
    // Every retained page switches between Mushaf rows and wrapped rows together.
    const contentRevision=React.useMemo(()=>`${revision?.prefs?.font}|${revision?.prefs?.tajweed}|${revision?.prefs?.scale===1}|${revision?.paint}`,
      [revision?.prefs?.font,revision?.prefs?.tajweed,revision?.prefs?.scale===1,revision?.paint]);
    // Eye/reveal state applies to every retained page, including pages being
    // dragged into view before a settled-page callback. Audio ticks need only
    // refresh the active tree; hiding the Quran and waking its ink refresh all.
    const visibilityRevision=React.useMemo(()=>({counts:revision?.counts,start:revision?.start,hidden:revision?.hidden,paint:revision?.paint,mic:revision?.mic}),
      [revision?.counts,revision?.start,revision?.hidden,revision?.paint,revision?.mic]);
    const root=React.useRef(null),range=React.useRef(numbers),cache=React.useRef(new Map(ready));
    const active=React.useRef(page),reported=React.useRef(page),published=React.useRef(data?.page||null),anchor=React.useRef(page);
    const pending=React.useRef(new Set()),queue=React.useRef(new Map()),demand=React.useRef(new Set()),failures=React.useRef(new Set()),generation=React.useRef(0);
    const frame=React.useRef(0),timer=React.useRef(0),gesture=React.useRef(null),moving=React.useRef(false);
    const settleFrame=React.useRef(0),lastScroll=React.useRef(-Infinity),panScroller=React.useRef(null);
    const settleVersion=React.useRef(0),destination=React.useRef(page);
    const motion=React.useRef(null),motionFrame=React.useRef(0),dragFrame=React.useRef(0),dragLeft=React.useRef(null);
    const liveGeometry=React.useRef(geometryKey),mountedInk=React.useRef(new Set());liveGeometry.current=geometryKey;
    const fitted=React.useRef(new Map()),pinchOrigin=React.useRef(null);
    const inkTimer=React.useRef(0),inkIdle=React.useRef(0),alive=React.useRef(true);
    const readyRef=React.useRef(ready);readyRef.current=ready;
    const viewportPending=React.useRef(false),viewportQueue=React.useRef([]),viewportTimer=React.useRef(0),viewportStamp=React.useRef(''),viewportFrame=React.useRef(0);
    const callbacks=React.useRef({loadPage,renderPage,onPageSelected,onVisiblePage,onTap,onCancelPress});
    const dispatch=React.useRef(null);
    const events=React.useMemo(()=>({
      scroll:event=>dispatch.current.scroll(event),verticalScroll:event=>dispatch.current.scroll(event,true),
      down:event=>dispatch.current.down(event),move:event=>dispatch.current.move(event),
      up:event=>dispatch.current.up(event),cancel:event=>dispatch.current.up(event,true),
      retry:number=>dispatch.current.retry(number)
    }),[]);
    range.current=numbers;callbacks.current={loadPage,renderPage,onPageSelected,onVisiblePage,onTap,onCancelPress};
    const inkBusy=()=>moving.current||gesture.current||window.__munibinQuranPinching||window.__munibinQuranInteracting;
    // Page/font promises only fill this cache. Promoting one local page into
    // React is separate idle work, so a late font never stalls the next swipe.
    const scheduleInk=()=>{
      if(!alive.current||inkTimer.current||inkIdle.current)return;
      const work=()=>{
        inkIdle.current=0;
        if(!alive.current)return;
        if(inkBusy()){inkTimer.current=setTimeout(()=>{inkTimer.current=0;scheduleInk()},70);return}
        const wanted=range.current.filter(number=>queue.current.has(number)&&readyRef.current.get(number)!==queue.current.get(number));
        wanted.sort((a,b)=>Math.abs(a-active.current)-Math.abs(b-active.current));
        const number=wanted[0];
        if(number!=null){
          const item=queue.current.get(number);queue.current.delete(number);
          setReady(previous=>new Map(previous).set(number,item));setError(null);
        }
        if(failures.current.has(active.current))setError(active.current);
        if(pending.current.size<2){
          const requests=[...demand.current].sort((a,b)=>Math.abs(a-active.current)-Math.abs(b-active.current));
          const requested=requests[0];
          if(requested!=null){demand.current.delete(requested);void loadNow(requested)}
        }
        if(wanted.length>1||demand.current.size)inkTimer.current=setTimeout(()=>{inkTimer.current=0;scheduleInk()},24);
      };
      inkTimer.current=setTimeout(()=>{
        inkTimer.current=0;
        if(typeof window.requestIdleCallback==='function')inkIdle.current=window.requestIdleCallback(work,{timeout:120});
        else work();
      },24);
    };
    const layoutKey=()=>{
      const el=root.current,reader=el?.closest?.('.qcf1441-preview');
      const lines=el?.children[active.current-1]?.querySelector('.qcf1441-lines');
      const computed=lines&&typeof getComputedStyle==='function'?getComputedStyle(lines):null;
      const padding=computed?`${computed.paddingLeft}|${computed.paddingRight}`:reader?.style.getPropertyValue('--munibin-reader-inline-padding')||'';
      return `${liveGeometry.current}|${el?.clientWidth||0}x${el?.clientHeight||0}|${reader?.style.getPropertyValue('--munibin-reader-content-height')||''}|${padding}`;
    };
    const showInk=(pane,visible)=>{
      if(!pane)return;
      // A page can have its font/data cached while its local geometry is still
      // queued. Keep that cold ink blank until its one-page fitter finishes.
      pane.dataset.horizontalInkReady=String(visible);
      const scroll=pane.querySelector('.munibin-quran-horizontal-page-scroll'),loader=pane.querySelector('.munibin-quran-page-loading');
      if(scroll?.style)scroll.style.visibility=visible?'visible':'hidden';
      if(loader)loader.hidden=visible;
    };
    const primeInk=(pane,key)=>{
      const primed=window.__munibinPrimeQuranReadingPage?.(pane)||window.__munibinPrimeQcf1441Page?.(pane);
      if(primed){fitted.current.set(Number(pane.dataset.horizontalPage),key);showInk(pane,true)}
      return !!primed;
    };
    const prepareAdjacentInk=()=>{
      const el=root.current;
      if(!el||document.documentElement.classList.contains('munibin-quran-mode-spread')||moving.current||gesture.current||window.__munibinQuranPinching||window.__munibinQuranInteracting)return;
      const key=layoutKey();
      // A native page's scoped fitter cannot recurse into this global hook.
      // Two loaded neighboring trees are bounded work before chrome moves.
      for(const number of [active.current-1,active.current+1]) {
        if(number<1||number>604||!readyRef.current.has(number)||fitted.current.get(number)===key)continue;
        const pane=el.children[number-1];if(!pane)continue;
        fitPage(pane);fitted.current.set(number,layoutKey());showInk(pane,true);
      }
    };
    const prepareViewportNeighbors=()=>{
      const el=root.current;if(!el)return;
      if(moving.current||gesture.current||window.__munibinQuranPinching||window.__munibinQuranInteracting){viewportPending.current=true;return}
      viewportPending.current=false;clearTimeout(viewportTimer.current);viewportQueue.current=[];
      const key=layoutKey();viewportStamp.current=key;
      for(const number of range.current) {
        if(!readyRef.current.has(number))continue;
        const pane=el.children[number-1];
        if(number===active.current){
          if(fitted.current.get(number)!==key){fitPage(pane);fitted.current.set(number,layoutKey())}
          showInk(pane,true);continue;
        }
        if(fitted.current.get(number)===key)continue;
        showInk(pane,false);viewportQueue.current.push(number);
      }
      viewportQueue.current.sort((a,b)=>Math.abs(a-active.current)-Math.abs(b-active.current));
      const next=()=>{
        if(moving.current||gesture.current||window.__munibinQuranPinching||window.__munibinQuranInteracting){viewportTimer.current=setTimeout(next,70);return}
        const number=viewportQueue.current.shift();if(number==null)return;
        if(range.current.includes(number)&&readyRef.current.has(number)) {
          const pane=el.children[number-1];
          if(!primeInk(pane,layoutKey())){fitPage(pane);fitted.current.set(number,layoutKey());showInk(pane,true)}
        }
        viewportTimer.current=setTimeout(next,16);
      };
      if(viewportQueue.current.length)viewportTimer.current=setTimeout(next,16);
    };
    const currentNumber=()=>{
      const el=root.current;
      return el?horizontalPageIndex(el.scrollLeft,horizontalPageWidth(el),604)+1:active.current;
    };
    const mark=number=>{
      const el=root.current;if(!el)return;
      for(const pane of new Set([el.children[active.current-1],el.children[number-1]])) {
        if(!pane)continue;
        const selected=Number(pane.dataset.horizontalPage)===number;
        pane.classList.toggle('is-active',selected);
        pane.setAttribute('aria-hidden',String(!selected));
        pane.inert=!selected;
        if(selected&&number!==active.current&&number!==reported.current)pane.querySelector('.munibin-quran-horizontal-page-scroll').scrollTop=0;
      }
      active.current=number;
    };
    const publish=()=>{
      const number=currentNumber(),item=readyRef.current.get(number);mark(number);
      if(reported.current!==number) {
        reported.current=number;
        callbacks.current.onPageSelected?.(number);
      }
      if(item&&published.current!==number) {
        published.current=number;
        callbacks.current.onVisiblePage?.(number,item);
      }
      return item||null;
    };
    const warmPageColor=number=>{
      const ensure=window.__munibinQuranReading?.ensureTajweedPage;
      // Plain navigation never waits for color. Warm the retained pages' local
      // faces so a later color choice can promote cached ink without fallback.
      if(ensure)void ensure(number).catch(()=>{});
    };
    const loadNow=async number=>{
      if(number<1||number>604||cache.current.has(number)||queue.current.has(number)||pending.current.has(number))return;
      const token=generation.current;pending.current.add(number);
      try {
        const item=await callbacks.current.loadPage(number);
        if(token!==generation.current)return;
        warmPageColor(number);
        cache.current.set(number,item);queue.current.set(number,item);
        scheduleInk();
      } catch {if(token===generation.current){failures.current.add(number);scheduleInk()}}
      finally {if(token===generation.current){pending.current.delete(number);scheduleInk()}}
    };
    const load=React.useCallback(number=>{
      if(number<1||number>604||cache.current.has(number)||queue.current.has(number)||pending.current.has(number)||failures.current.has(number))return;
      demand.current.add(number);scheduleInk();
    },[]);
    const extend=number=>{
      const current=range.current;
      if(number-current[0]>3&&current.at(-1)-number>3)return;
      const wanted=horizontalMovingWindow(current,number);
      if(current.join(',')!==wanted.join(',')) {
        range.current=wanted;
        for(const value of wanted)if(cache.current.has(value)&&!readyRef.current.has(value))queue.current.set(value,cache.current.get(value));
        setNumbers(wanted);
      }
      horizontalPageNumbers(number,9).sort((a,b)=>Math.abs(a-number)-Math.abs(b-number)).forEach(value=>void load(value));
    };
    const finishScroll=()=>{
      if(gesture.current||window.__munibinQuranPinching)return;
      const el=root.current,number=currentNumber(),target=-(number-1)*horizontalPageWidth(el);
      if(el&&Math.abs(el.scrollLeft-target)>.5){animateTo(number);return}
      clearTimeout(timer.current);moving.current=false;window.__munibinQuranInteracting=false;
      publish();
      const wanted=horizontalPageNumbers(number);destination.current=number;
      if(range.current.join(',')!==wanted.join(',')){range.current=wanted;setNumbers(wanted)}
      setReady(previous=>[...previous.keys()].every(value=>wanted.includes(value))?previous:new Map([...previous].filter(([value])=>wanted.includes(value))));
      for(const value of wanted)if(cache.current.has(value)&&!readyRef.current.has(value))queue.current.set(value,cache.current.get(value));
      scheduleInk();
      panScroller.current=null;
      // Chrome/rotation work may have been coalesced while native inertia or
      // a pinch held the shared guard. Release exactly that dirty work; an
      // ordinary already-prepared page settlement schedules nothing.
      clearTimeout(viewportTimer.current);viewportTimer.current=setTimeout(()=>{
        if(inkBusy()){viewportPending.current=true;return}
        window.__munibinQuranReading?.flushPendingQuranReaderFit?.();prepareViewportNeighbors();
      },24);
    };
    const stopMotion=()=>{
      motion.current=null;cancelAnimationFrame(motionFrame.current);motionFrame.current=0;
      cancelAnimationFrame(dragFrame.current);dragFrame.current=0;dragLeft.current=null;
      clearTimeout(timer.current);cancelAnimationFrame(settleFrame.current);settleFrame.current=0;settleVersion.current++;
    };
    const flushDrag=()=>{
      cancelAnimationFrame(dragFrame.current);dragFrame.current=0;
      if(dragLeft.current!=null&&root.current)root.current.scrollLeft=dragLeft.current;
      dragLeft.current=null;
    };
    const animateTo=number=>{
      const el=root.current;if(!el)return;
      stopMotion();destination.current=number;
      moving.current=true;window.__munibinQuranInteracting=true;extend(number);
      const from=el.scrollLeft,to=-(number-1)*horizontalPageWidth(el),start=performance.now();
      const reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
      const duration=reduced?0:Math.min(260,180+Math.abs(to-from)/Math.max(1,horizontalPageWidth(el))*35);
      const animation={number};motion.current=animation;
      const step=now=>{
        if(motion.current!==animation)return;
        if(window.__munibinQuranPinching){stopMotion();scheduleEnd();return}
        const progress=duration?Math.min(1,(now-start)/duration):1;
        el.scrollLeft=from+(to-from)*(1-Math.pow(1-progress,3));
        mark(currentNumber());lastScroll.current=now;
        if(progress<1)motionFrame.current=requestAnimationFrame(step);
        else {motion.current=null;motionFrame.current=0;el.scrollLeft=to;finishScroll()}
      };
      motionFrame.current=requestAnimationFrame(step);
    };
    const scheduleEnd=(nativeEnd=false)=>{
      clearTimeout(timer.current);cancelAnimationFrame(settleFrame.current);settleFrame.current=0;
      const version=++settleVersion.current;
      if(gesture.current||motion.current)return;
      // A pointer cancellation starts native panning; it does not end it. A
      // quiet event gap is also not a settled snap. Confirm two unchanged
      // compositor frames before fitting, and wait longer on older WebViews
      // that lack scrollend. Each page's vertical inertia uses the same guard.
      const delay=nativeEnd?32:160;
      const check=()=>{
        if(version!==settleVersion.current)return;
        if(gesture.current||motion.current)return;
        if(window.__munibinQuranPinching){timer.current=setTimeout(check,70);return}
        const quiet=performance.now()-lastScroll.current;
        if(quiet<delay){timer.current=setTimeout(check,delay-quiet);return}
        const el=root.current;if(!el)return;
        const left=el.scrollLeft,scroller=panScroller.current,top=scroller?.scrollTop;
        settleFrame.current=requestAnimationFrame(()=>{
          if(version!==settleVersion.current)return;
          settleFrame.current=requestAnimationFrame(()=>{
            settleFrame.current=0;
            if(version!==settleVersion.current)return;
            if(gesture.current||motion.current)return;
            if(window.__munibinQuranPinching){scheduleEnd(nativeEnd);return}
            if(el.scrollLeft!==left||scroller?.scrollTop!==top||performance.now()-lastScroll.current<delay){scheduleEnd(nativeEnd);return}
            finishScroll();
          });
        });
      };
      timer.current=setTimeout(check,delay);
    };
    const endScroll=event=>{
      if(event?.target&&event.target!==root.current&&event.target!==panScroller.current)return;
      scheduleEnd(true);
    };
    const scroll=(event,vertical=false)=>{
      if(!vertical&&event.target!==root.current)return;
      if(window.__munibinQuranPinching)return;
      // The last animation write can dispatch scroll after finishScroll. It
      // must not restart an interaction or suppress the following tap.
      if(!vertical&&!gesture.current&&!motion.current&&Math.abs(root.current.scrollLeft+(destination.current-1)*horizontalPageWidth(root.current))<.5)return;
      moving.current=true;window.__munibinQuranInteracting=true;lastScroll.current=performance.now();
      if(vertical)panScroller.current=event.target;
      callbacks.current.onCancelPress?.();scheduleEnd();
      if(vertical||frame.current)return;
      frame.current=requestAnimationFrame(()=>{frame.current=0;const number=currentNumber();mark(number);extend(number)});
    };
    const jump=number=>{
      if(!Number.isInteger(number)||number<1||number>604)return;
      generation.current++;pending.current.clear();queue.current.clear();demand.current.clear();failures.current.clear();stopMotion();destination.current=number;
      gesture.current=null;moving.current=false;window.__munibinQuranInteracting=false;
      active.current=number;reported.current=number;published.current=null;anchor.current=number;
      const wanted=horizontalPageNumbers(number);range.current=wanted;setNumbers(wanted);
      setReady(previous=>new Map([...previous].filter(([value])=>wanted.includes(value))));
      for(const value of wanted)if(cache.current.has(value)&&!readyRef.current.has(value))queue.current.set(value,cache.current.get(value));
      callbacks.current.onPageSelected?.(number);scheduleInk();
      void load(number);
      window.__munibinQuranReading?.flushPendingQuranReaderFit?.();
    };
    React.useLayoutEffect(()=>{
      document.documentElement.classList.add('munibin-quran-native-horizontal');
      return ()=>document.documentElement.classList.remove('munibin-quran-native-horizontal');
    },[]);
    React.useLayoutEffect(()=>{
      const el=root.current;if(!el)return;
      if(anchor.current!=null) {
        el.scrollLeft=-(anchor.current-1)*horizontalPageWidth(el);
        mark(anchor.current);anchor.current=null;
      }
      const mounted=new Set(numbers.filter(number=>ready.has(number)));
      const fresh=new Set([...mounted].filter(number=>!mountedInk.current.has(number)));
      for(const number of mounted)if(!mountedInk.current.has(number))fitted.current.delete(number);
      for(const number of mountedInk.current)if(!mounted.has(number))fitted.current.delete(number);
      mountedInk.current=mounted;
      const busy=inkBusy();
      if(busy){
        // Keep the active ink through live reflow. Geometry is intentionally
        // pending while fingers move; hiding an already-painted page here
        // leaves a blank viewport with no React change on finger release.
        for(const number of mounted)if(number!==active.current&&!fitted.current.get(number)?.startsWith(`${liveGeometry.current}|`))showInk(el.children[number-1],false);
        if(ready.has(active.current))showInk(el.children[active.current-1],true);
        viewportPending.current=true;return;
      }
      const key=layoutKey();
      if(!busy)viewportStamp.current=key;
      for(const number of numbers) {
        if(!ready.has(number))continue;
        const pane=el.children[number-1],selected=number===active.current;
        if(fitted.current.get(number)===key){showInk(pane,true);continue}
        // New current ink is fitted before its first idle paint; neighbors
        // prepare one at a time without adding work to a swipe callback.
        if(selected) {
          fitPage(pane);fitted.current.set(number,layoutKey());showInk(pane,true);
        } else if(fresh.has(number)&&primeInk(pane,key)) {
          // The idle worker promotes one fresh tree per commit. Prime that
          // single tree before paint so its first appearance has current zoom.
        } else {showInk(pane,false);viewportPending.current=true}
      }
      if(viewportPending.current){clearTimeout(viewportTimer.current);viewportTimer.current=setTimeout(prepareViewportNeighbors,24)}
    },[numbers,ready,geometryKey,contentRevision]);
    React.useEffect(()=>{
      // Nearest pages first, ahead of distant fonts or full-Quran background work.
      const center=active.current;
      [...numbers].sort((a,b)=>Math.abs(a-center)-Math.abs(b-center)).forEach(number=>void load(number));
      horizontalPageNumbers(center,9).sort((a,b)=>Math.abs(a-center)-Math.abs(b-center)).forEach(number=>void load(number));
      if(!moving.current&&ready.has(center)&&published.current!==center)publish();
    },[numbers,ready,load]);
    React.useEffect(()=>{if(data) {
      cache.current.set(data.page,data);
      if(readyRef.current.get(data.page)!==data){queue.current.set(data.page,data);scheduleInk()}
    }},[data]);
    React.useEffect(()=>{if(page!==reported.current)jump(page)},[page]);
    React.useEffect(()=>{
      alive.current=true;
      const el=root.current;
      const flush=()=>publish();
      window.__munibinQuranFlushVisiblePage=flush;
      const navigate=event=>jump(Number(event.detail?.page));
      const turn=number=>{
        if(!Number.isInteger(number)||number<1||number>604)return false;
        void load(number);
        const pane=el.children[number-1],scroller=pane?.querySelector('.munibin-quran-horizontal-page-scroll');if(scroller)scroller.scrollTop=0;
        gesture.current=null;animateTo(number);return true;
      };
      window.__munibinQuranHorizontalTurn=turn;
      window.__munibinQuranHorizontalPrepareAdjacent=prepareAdjacentInk;
      const resize=()=>{
        if(moving.current||gesture.current||window.__munibinQuranPinching||window.__munibinQuranInteracting){viewportPending.current=true;return}
        el.scrollLeft=-(active.current-1)*horizontalPageWidth(el);fitPage(el.children[active.current-1]);prepareViewportNeighbors();
      };
      // Chrome reserves and safe-area padding can change without changing the
      // outer pager size. Refresh cached neighbors for those changes too; the
      // settled active page is already fitted by the reader's layout pass.
      const reader=el.closest?.('.qcf1441-preview');
      const observer=reader&&typeof MutationObserver==='function'?new MutationObserver(()=>{
        if(viewportStamp.current===layoutKey()||viewportFrame.current)return;
        viewportFrame.current=requestAnimationFrame(()=>{
          viewportFrame.current=0;if(viewportStamp.current===layoutKey())return;
          if(moving.current||gesture.current||window.__munibinQuranPinching||window.__munibinQuranInteracting){viewportPending.current=true;return}
          const schedule=window.__munibinQuranReading?.scheduleQuranReaderFit;
          if(schedule)schedule();else fitPage(el.children[active.current-1]);
          prepareViewportNeighbors();
        });
      }):null;
      observer?.observe(reader,{attributes:true,attributeFilter:['class','style']});
      const point=(event,touch)=>({pointerId:touch.identifier,kind:'touch',clientX:touch.clientX,clientY:touch.clientY,
        preventDefault:()=>event.preventDefault(),stopPropagation:()=>event.stopPropagation()});
      const touchStart=event=>{if(event.touches.length===1)dispatch.current.down(point(event,event.touches[0]))};
      const touchMove=event=>{const touch=Array.from(event.touches).find(value=>value.identifier===gesture.current?.id);if(touch)dispatch.current.move(point(event,touch))};
      const touchEnd=(event,cancelled=false)=>{const touch=Array.from(event.changedTouches).find(value=>value.identifier===gesture.current?.id);if(touch)dispatch.current.up(point(event,touch),cancelled)};
      const touchCancel=event=>touchEnd(event,true);
      const pinch=event=>{if(event.touches.length>1&&el.contains(event.target)){
        // A pinch takes ownership from horizontal dragging/momentum. Keep
        // exactly the grabbed page and cancel all delayed settlement writes.
        const number=pinchOrigin.current??currentNumber();pinchOrigin.current=number;
        stopMotion();gesture.current=null;moving.current=false;panScroller.current=null;
        window.__munibinQuranInteracting=false;destination.current=number;
        horizontalInstantScroll(el,-(number-1)*horizontalPageWidth(el));mark(number);
        viewportPending.current=true;
      }};
      const pinchEnd=()=>{
        if(pinchOrigin.current==null||!alive.current)return;
        const number=pinchOrigin.current;pinchOrigin.current=null;
        stopMotion();gesture.current=null;moving.current=false;window.__munibinQuranInteracting=false;
        destination.current=number;horizontalInstantScroll(el,-(number-1)*horizontalPageWidth(el));mark(number);
        publish();prepareViewportNeighbors();scheduleInk();
        window.__munibinQuranReading?.flushPendingQuranReaderFit?.();
      };
      // A fresh touch is delivered even while WebKit would suppress pointer
      // events during its native snap. Only horizontal drags prevent default.
      el.addEventListener('touchstart',touchStart,{passive:true});
      el.addEventListener('touchmove',touchMove,{passive:false});
      el.addEventListener('touchend',touchEnd,{passive:true});
      el.addEventListener('touchcancel',touchCancel,{passive:true});
      document.addEventListener('touchstart',pinch,true);
      window.addEventListener('munibin-quran-pinch-end',pinchEnd);
      el.addEventListener('scrollend',endScroll,true);
      window.addEventListener('resize',resize,{passive:true});
      window.addEventListener('munibin-quran-explicit-jump',navigate);
      return ()=>{
        alive.current=false;clearTimeout(inkTimer.current);window.cancelIdleCallback?.(inkIdle.current);
        settleVersion.current++;
        generation.current++;stopMotion();cancelAnimationFrame(frame.current);
        clearTimeout(viewportTimer.current);cancelAnimationFrame(viewportFrame.current);observer?.disconnect();
        el.removeEventListener('scrollend',endScroll,true);window.removeEventListener('resize',resize);
        el.removeEventListener('touchstart',touchStart);el.removeEventListener('touchmove',touchMove);
        el.removeEventListener('touchend',touchEnd);el.removeEventListener('touchcancel',touchCancel);document.removeEventListener('touchstart',pinch,true);
        window.removeEventListener('munibin-quran-pinch-end',pinchEnd);
        window.removeEventListener('munibin-quran-explicit-jump',navigate);
        if(window.__munibinQuranFlushVisiblePage===flush)delete window.__munibinQuranFlushVisiblePage;
        if(window.__munibinQuranHorizontalTurn===turn)delete window.__munibinQuranHorizontalTurn;
        if(window.__munibinQuranHorizontalPrepareAdjacent===prepareAdjacentInk)delete window.__munibinQuranHorizontalPrepareAdjacent;
        window.__munibinQuranInteracting=false;
      };
    },[]);
    const down=event=>{
      event.stopPropagation();
      if(event.pointerType==='touch')return;
      if(window.__munibinQuranPinching||event.isPrimary===false)return;
      const continuing=moving.current,origin=motion.current?destination.current:currentNumber();
      stopMotion();const el=root.current;
      moving.current=true;window.__munibinQuranInteracting=true;
      gesture.current={id:event.pointerId,kind:event.kind||'pointer',x:event.clientX,y:event.clientY,lastX:event.clientX,lastTime:performance.now(),velocity:0,
        left:el.scrollLeft,origin,time:performance.now(),moved:false,axis:null,continuing};
    };
    const move=event=>{
      if(event.pointerType==='touch'){event.stopPropagation();return}
      event.stopPropagation();const g=gesture.current;if(!g||g.id!==event.pointerId)return;
      const dx=event.clientX-g.x,dy=event.clientY-g.y,now=performance.now();
      if(Math.hypot(dx,dy)>7){g.moved=true;callbacks.current.onCancelPress?.()}
      if(!g.axis&&g.moved){if(Math.abs(dx)>Math.abs(dy)*1.05)g.axis='horizontal';else if(Math.abs(dy)>Math.abs(dx)*1.05)g.axis='vertical'}
      if(g.axis==='horizontal') {
        event.preventDefault?.();
        if(!g.parentCancelled){window.__munibinQuranNavigationBridge?.cancelGesture?.();g.parentCancelled=true}
        if(g.kind==='pointer')root.current.setPointerCapture?.(g.id);
        g.velocity=(event.clientX-g.lastX)/Math.max(1,now-g.lastTime);
        const width=horizontalPageWidth(root.current),distance=Math.max(-width,Math.min(width,dx));
        // A very quick next swipe can start before its preceding destination
        // reaches the screen. Bound the drag relative to the grabbed position
        // so taking over never jumps to a logical-page boundary.
        dragLeft.current=Math.max(-603*width,Math.min(0,g.left-distance));
        if(!dragFrame.current)dragFrame.current=requestAnimationFrame(()=>{if(gesture.current!==g)return;dragFrame.current=0;flushDrag();mark(currentNumber())});
      }
      g.lastX=event.clientX;g.lastTime=now;
    };
    const up=(event,cancelled=false)=>{
      if(event.pointerType==='touch'){event.stopPropagation();return}
      event.stopPropagation();const g=gesture.current;
      if(!g||event.pointerId!==g.id)return;
      flushDrag();gesture.current=null;
      if(window.__munibinQuranPinching){stopMotion();scheduleEnd();return}
      const tap=!cancelled&&!g.moved&&!g.continuing&&!window.__munibinQuranPinching&&performance.now()-g.time<450;
      if(tap){moving.current=false;window.__munibinQuranInteracting=false;callbacks.current.onTap?.();window.__munibinQuranReading?.flushPendingQuranReaderFit?.()}
      else if(g.axis==='horizontal'||g.continuing) {
        const dx=event.clientX-g.x,velocity=performance.now()-g.lastTime<100?g.velocity:0;
        animateTo(cancelled||g.axis!=='horizontal'?g.origin:horizontalSwipeTarget(g.origin,dx,horizontalPageWidth(root.current),velocity));
      } else scheduleEnd();
    };
    dispatch.current={scroll,down,move,up,retry:number=>{setError(null);failures.current.delete(number);void load(number)}};
    // Chrome/menu state changes update callbacks.current, not the 604 slot
    // element list. Selection/reveal/settings still invalidate the exact panes
    // that consume them; PageInk remains independently memoized.
    const slots=React.useMemo(()=>{
      const retained=new Set(numbers);
      return Array.from({length:604},(_,index)=>index+1).map(number=>h(PageSlot,{key:number,number,
        retained:retained.has(number),item:retained.has(number)?ready.get(number)||null:null,selected:number===active.current,
        visibilityRevision:retained.has(number)?visibilityRevision:null,
        revision:retained.has(number)?number===active.current?revision:contentRevision:null,
        render:callbacks,events,error:error===number}));
    },[numbers,ready,error,contentRevision,visibilityRevision,revision,active.current]);
    return h('div',{ref:root,className:'qcf1441-page-stage munibin-quran-horizontal-pages',dir:'rtl',onScroll:events.scroll,
      onPointerDown:events.down,onPointerMove:events.move,onPointerUp:events.up,onPointerCancel:events.cancel,
      'aria-label':'صفحات القرآن. اسحب يمينًا ويسارًا بين الصفحات.'},
      slots);
  };
}
