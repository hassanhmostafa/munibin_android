// Row highlighting follows the same adhan/iqama boundaries as the native widgets.
const PRAYER_KEYS = ['Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];

function prayerClock(time, now, dayOffset) {
  if (typeof time !== 'string') return null;
  const parts = /^(\d{1,2}):(\d{2})$/.exec(time.trim());
  if (!parts) return null;
  const hour = Number(parts[1]), minute = Number(parts[2]);
  if (hour > 23 || minute > 59) return null;
  const date = new Date(now);
  // Calendar dates preserve the displayed local clock across daylight-saving days.
  date.setDate(date.getDate() + dayOffset);
  date.setHours(hour, minute, 0, 0);
  return date.getTime();
}

export function prayerHighlightedKey(timings, iqamaOffsets, now = new Date()) {
  const current = new Date(now).getTime();
  if (!timings || !Number.isFinite(current)) return null;
  let activeKey = null, activeStart = Infinity, nextKey = null, nextAt = Infinity;
  for (const key of PRAYER_KEYS) {
    const offset = key === 'Sunrise' ? 0 : iqamaOffsets?.[key];
    const minutes = Number.isInteger(offset) && offset > 0 ? offset : 0;
    // Yesterday keeps an Isha iqama active when its deadline falls after midnight.
    for (const dayOffset of [-1, 0, 1]) {
      const start = prayerClock(timings[key], current, dayOffset);
      if (start === null) continue;
      if (minutes > 0 && current >= start && current < start + minutes * 60000 && start < activeStart) {
        activeStart = start;
        activeKey = key;
      }
      if (start > current && start < nextAt) {
        nextAt = start;
        nextKey = key;
      }
    }
  }
  return activeKey ?? nextKey;
}
