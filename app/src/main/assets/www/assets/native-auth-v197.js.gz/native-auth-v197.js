/* Munibin native authentication bridge v261: social login + password autofill auto-submit. */
(() => {
  'use strict';
  if (window.__munibinNativeAuthV197) return;
  window.__munibinNativeAuthV197 = true;

  const isNative = !!window.__munibinNativeApp || /MunibinNative\/(Android|iOS)/i.test(navigator.userAgent);
  const platform = window.__munibinNativePlatform || (/iPhone|iPad|iPod/i.test(navigator.userAgent) ? 'ios' : /Android/i.test(navigator.userAgent) ? 'android' : 'web');
  if (!isNative && platform === 'web') return;

  function trpcData(json) { return json?.result?.data?.json ?? json?.result?.data ?? null; }
  async function trpcQuery(path, input = null) {
    const url = `/api/trpc/${path}?input=${encodeURIComponent(JSON.stringify({json: input}))}`;
    const res = await fetch(url, { credentials: 'include', cache: 'no-store' });
    if (!res.ok) throw new Error(`${path}:${res.status}`);
    return trpcData(await res.json());
  }
  async function trpcMutation(path, input) {
    const res = await fetch(`/api/trpc/${path}`, {
      method: 'POST', credentials: 'include',
      headers: {'content-type': 'application/json'},
      body: JSON.stringify({json: input}),
    });
    if (!res.ok) {
      let message = '';
      try { message = (await res.json())?.error?.json?.message || ''; } catch (_) {}
      throw new Error(message || `${path}:${res.status}`);
    }
    return trpcData(await res.json());
  }

  function dispatchToast(message) {
    try {
      const toast = document.createElement('div');
      toast.textContent = message;
      toast.dir = 'rtl';
      Object.assign(toast.style, {
        position:'fixed', left:'50%', bottom:'30px', transform:'translateX(-50%)', zIndex:'2147483647',
        maxWidth:'88vw', padding:'10px 14px', borderRadius:'12px', background:'rgba(45,30,13,.96)', color:'#fff8e7',
        fontFamily:'var(--app-font, sans-serif)', fontSize:'13px', boxShadow:'0 8px 30px rgba(0,0,0,.28)', textAlign:'center'
      });
      document.body.appendChild(toast); setTimeout(() => toast.remove(), 3200);
    } catch (_) {}
  }

  function startSocial(provider) {
    try {
      if (platform === 'ios' && window.webkit?.messageHandlers?.['munibin-social-auth']) {
        window.webkit.messageHandlers['munibin-social-auth'].postMessage({provider});
        return;
      }
      if (platform === 'android' && typeof window.MunibinAndroid?.startSocialAuth === 'function') {
        window.MunibinAndroid.startSocialAuth(provider);
        return;
      }
    } catch (_) {}
    location.href = `https://munibin.com/api/auth/${provider}?native=1`;
  }

  let socialBusy = false;
  window.addEventListener('munibin-native-social-auth', async event => {
    if (socialBusy) return;
    const detail = event?.detail || {};
    if (detail.error) { dispatchToast(String(detail.error)); return; }
    if (!detail.code) return;
    socialBusy = true;
    try {
      await trpcMutation('auth.exchangeSocialHandoff', {code: String(detail.code)});
      try { localStorage.removeItem('manus-runtime-user-info'); } catch (_) {}
      location.assign('/');
    } catch (error) {
      dispatchToast(error?.message || 'تعذر إكمال تسجيل الدخول.');
    } finally { socialBusy = false; }
  });

  let providers = {google:false, apple:false};
  fetch('/api/auth/social/providers', {credentials:'include', cache:'no-store'})
    .then(r => r.ok ? r.json() : null).then(data => { if (data) { providers = data; enhanceAuthPage(); } }).catch(() => {});

  function button(provider, label) {
    const b = document.createElement('button');
    b.type = 'button'; b.dataset.provider = provider; b.className = 'munibin-native-social-button';
    b.innerHTML = provider === 'apple'
      ? `<span class="munibin-social-mark munibin-apple-mark"></span><span>${label}</span>`
      : `<span class="munibin-social-mark munibin-google-mark">G</span><span>${label}</span>`;
    b.addEventListener('click', () => startSocial(provider));
    return b;
  }

  function ensureStyles() {
    if (document.getElementById('munibin-native-auth-v197-style')) return;
    const style = document.createElement('style'); style.id = 'munibin-native-auth-v197-style';
    style.textContent = `
      .munibin-native-social-wrap{margin-top:16px;display:grid;gap:10px;font-family:var(--app-font,sans-serif)}
      .munibin-native-social-divider{display:flex;align-items:center;gap:10px;color:var(--app-text-muted,rgba(61,21,6,.48));font-size:11px}
      .munibin-native-social-divider:before,.munibin-native-social-divider:after{content:"";height:1px;flex:1;background:var(--app-divider,rgba(120,70,20,.18))}
      .munibin-native-social-buttons{display:grid;grid-template-columns:1fr 1fr;gap:8px}
      .munibin-native-social-button{min-height:44px;border-radius:12px;border:1px solid var(--app-input-border,var(--app-divider,rgba(120,70,20,.22)));background:var(--app-input-bg,var(--app-card-bg,#fff));color:var(--app-text-primary,#3d1506);display:flex;align-items:center;justify-content:center;gap:8px;font:700 12px var(--app-font,sans-serif);cursor:pointer}
      .munibin-native-social-button:active{transform:scale(.985)}
      .munibin-social-mark{width:20px;height:20px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;font-weight:800;font-size:14px}
      .munibin-google-mark{background:#fff;color:#4285f4;border:1px solid rgba(0,0,0,.12)}
      .munibin-apple-mark{font-size:20px;line-height:1;color:currentColor}
      .munibin-ios-password-access{display:flex;justify-content:flex-start;margin-top:7px}
      .munibin-ios-password-button{border:0;background:transparent;color:var(--app-link-color,#a24d0b);font:700 12px var(--app-font,sans-serif);padding:3px 2px;display:inline-flex;align-items:center;gap:5px;cursor:pointer}
      .munibin-ios-password-button:active{opacity:.62}
      .munibin-ios-password-key{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;font-size:13px;line-height:1}
      @keyframes munibin-credential-autofill{from{opacity:.9999}to{opacity:1}}
      #login-identifier:-webkit-autofill,#current-password:-webkit-autofill{animation-name:munibin-credential-autofill;animation-duration:.01s;animation-iteration-count:1}
      @media(max-width:340px){.munibin-native-social-buttons{grid-template-columns:1fr}}
    `;
    document.head.appendChild(style);
  }

  let passwordAutofillRequested = false;
  let passwordAutofillExplicit = false;

  function requestPasswordAutofill(explicit = false) {
    if (platform !== 'ios' || !location.pathname.startsWith('/auth')) return;
    const bridge = window.webkit?.messageHandlers?.['munibin-password-autofill'];
    if (!bridge) return;
    if (!explicit && passwordAutofillRequested) return;
    passwordAutofillRequested = true;
    passwordAutofillExplicit = !!explicit;
    try { bridge.postMessage({domain:'munibin.com', explicit:!!explicit}); }
    catch (_) { if (explicit) dispatchToast('تعذر فتح كلمات السر.'); }
  }

  function setControlledInputValue(input, value) {
    if (!(input instanceof HTMLInputElement)) return;
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
    try { setter ? setter.call(input, value) : (input.value = value); }
    catch (_) { input.value = value; }
    input.dispatchEvent(new Event('input', {bubbles:true}));
    input.dispatchEvent(new Event('change', {bubbles:true}));
  }

  let autofillLoginTimer = 0;
  let autofillLoginBusy = false;
  let lastAutofillSignature = '';
  let lastAutofillSubmitAt = 0;

  function isAutofilled(input) {
    if (!(input instanceof HTMLInputElement)) return false;
    try { if (input.matches(':-webkit-autofill')) return true; } catch (_) {}
    try { if (input.matches(':autofill')) return true; } catch (_) {}
    return false;
  }

  function submitAutofilledLogin(source = 'browser') {
    if (!location.pathname.startsWith('/auth')) return;
    const loginId = document.getElementById('login-identifier');
    const currentPassword = document.getElementById('current-password');
    const form = currentPassword?.closest('form') || loginId?.closest('form');
    if (!(form instanceof HTMLFormElement) || !(loginId instanceof HTMLInputElement) || !(currentPassword instanceof HTMLInputElement)) return;
    const account = loginId.value.trim();
    const password = currentPassword.value;
    if (!account || !password) return;
    if (source === 'browser' && !isAutofilled(loginId) && !isAutofilled(currentPassword)) return;

    const signature = `${account}\u0000${password}`;
    const now = Date.now();
    if (autofillLoginBusy || (signature === lastAutofillSignature && now - lastAutofillSubmitAt < 2500)) return;
    lastAutofillSignature = signature;
    lastAutofillSubmitAt = now;
    autofillLoginBusy = true;

    // Keep React's controlled state in sync with values inserted by Passwords / Autofill.
    setControlledInputValue(loginId, account);
    setControlledInputValue(currentPassword, password);

    requestAnimationFrame(() => requestAnimationFrame(() => {
      if (!form.isConnected || loginId.value.trim() !== account || currentPassword.value !== password) {
        autofillLoginBusy = false;
        return;
      }
      try {
        if (typeof form.requestSubmit === 'function') form.requestSubmit();
        else {
          const submit = form.querySelector('button[type="submit"],input[type="submit"]');
          if (submit instanceof HTMLElement) submit.click();
        }
      } finally {
        window.setTimeout(() => { autofillLoginBusy = false; }, 1800);
      }
    }));
  }

  function scheduleAutofilledLogin(source = 'browser', delay = 70) {
    clearTimeout(autofillLoginTimer);
    autofillLoginTimer = window.setTimeout(() => submitAutofilledLogin(source), delay);
  }

  function bindAutofillAutoSubmit(input) {
    if (!(input instanceof HTMLInputElement) || input.dataset.munibinAutoSubmitBound) return;
    input.dataset.munibinAutoSubmitBound = '1';
    input.addEventListener('animationstart', event => {
      if (event.animationName === 'munibin-credential-autofill') scheduleAutofilledLogin('browser', 35);
    });
    input.addEventListener('input', event => {
      const inputType = typeof event.inputType === 'string' ? event.inputType : '';
      if (isAutofilled(input)) {
        scheduleAutofilledLogin('browser', 55);
        return;
      }
      // Password-manager / biometric fills commonly arrive as one replacement
      // event instead of ordinary per-character insertText keyboard events.
      const loginId = document.getElementById('login-identifier');
      const currentPassword = document.getElementById('current-password');
      const ready = loginId instanceof HTMLInputElement && currentPassword instanceof HTMLInputElement
        && !!loginId.value.trim() && currentPassword.value.length >= 4;
      if (ready && (inputType === 'insertReplacementText' || (!inputType && event.isTrusted && event.data == null))) {
        scheduleAutofilledLogin('credential', 70);
      }
    }, true);
    input.addEventListener('change', () => {
      if (isAutofilled(input)) scheduleAutofilledLogin('browser', 45);
    }, true);
  }

  window.addEventListener('munibin-native-password-autofill', event => {
    const detail = event?.detail || {};
    if (detail.error) {
      if (passwordAutofillExplicit && detail.error !== 'canceled') dispatchToast(String(detail.error));
      passwordAutofillExplicit = false;
      return;
    }
    const account = typeof detail.account === 'string' ? detail.account : '';
    const password = typeof detail.password === 'string' ? detail.password : '';
    if (!account || !password || !location.pathname.startsWith('/auth')) return;
    const loginId = document.getElementById('login-identifier');
    const currentPassword = document.getElementById('current-password');
    if (!(loginId instanceof HTMLInputElement) || !(currentPassword instanceof HTMLInputElement)) return;
    setControlledInputValue(loginId, account);
    setControlledInputValue(currentPassword, password);
    passwordAutofillExplicit = false;
    scheduleAutofilledLogin('native', 40);
  });

  function enhanceAuthPage() {
    if (!location.pathname.startsWith('/auth')) return;
    ensureStyles();
    const form = document.querySelector('form');
    if (!form) return;
    form.setAttribute('autocomplete','on');
    const loginId = document.getElementById('login-identifier');
    const registerEmail = document.getElementById('register-email');
    const currentPassword = document.getElementById('current-password');
    const newPassword = document.getElementById('new-password');
    const confirmPassword = document.getElementById('confirm-password');
    if (loginId) { loginId.setAttribute('autocomplete','username'); loginId.setAttribute('autocapitalize','none'); loginId.setAttribute('spellcheck','false'); }
    if (registerEmail) registerEmail.setAttribute('autocomplete','email');
    if (currentPassword) currentPassword.setAttribute('autocomplete','current-password');
    if (newPassword) newPassword.setAttribute('autocomplete','new-password');
    if (confirmPassword) confirmPassword.setAttribute('autocomplete','new-password');
    if (loginId && currentPassword) {
      bindAutofillAutoSubmit(loginId);
      bindAutofillAutoSubmit(currentPassword);
      if (loginId.value && currentPassword.value && (isAutofilled(loginId) || isAutofilled(currentPassword))) {
        scheduleAutofilledLogin('browser', 90);
      }
    }

    if (platform === 'ios' && currentPassword) {
      currentPassword.setAttribute('data-munibin-password-domain','munibin.com');
      loginId?.setAttribute('data-munibin-password-domain','munibin.com');
      const passwordFieldWrap = currentPassword.parentElement;
      if (passwordFieldWrap && !passwordFieldWrap.querySelector('.munibin-ios-password-access')) {
        const access = document.createElement('div'); access.className = 'munibin-ios-password-access';
        const passwords = document.createElement('button'); passwords.type = 'button'; passwords.className = 'munibin-ios-password-button';
        passwords.innerHTML = '<span class="munibin-ios-password-key" aria-hidden="true">⌨︎</span><span>كلمات السر</span>';
        passwords.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); requestPasswordAutofill(true); });
        access.appendChild(passwords); passwordFieldWrap.appendChild(access);
      }
      if (!currentPassword.dataset.munibinAutofillFocusBound) {
        currentPassword.dataset.munibinAutofillFocusBound = '1';
        currentPassword.addEventListener('focus', () => requestPasswordAutofill(false), {passive:true});
      }
      if (loginId && !loginId.dataset.munibinAutofillFocusBound) {
        loginId.dataset.munibinAutofillFocusBound = '1';
        loginId.addEventListener('focus', () => requestPasswordAutofill(false), {passive:true});
      }
      if (!passwordAutofillRequested && !loginId?.value && !currentPassword.value) {
        window.setTimeout(() => requestPasswordAutofill(false), 420);
      }
    } else {
      document.querySelectorAll('.munibin-ios-password-access').forEach(node => node.remove());
    }

    const existing = document.querySelector('.munibin-native-social-wrap');
    const authMode = currentPassword ? 'login' : newPassword ? 'register' : 'other';
    if (authMode === 'other') { existing?.remove(); return; }
    if (existing) return;

    const wrap = document.createElement('div'); wrap.className = 'munibin-native-social-wrap';
    const divider = document.createElement('div'); divider.className = 'munibin-native-social-divider'; divider.textContent = 'أو';
    const buttons = document.createElement('div'); buttons.className = 'munibin-native-social-buttons';
    if (providers.google !== false) buttons.append(button('google','المتابعة عبر Google'));
    if (providers.apple !== false) buttons.append(button('apple','المتابعة عبر Apple'));
    if (!buttons.childElementCount) return;
    wrap.append(divider, buttons);
    form.insertAdjacentElement('afterend', wrap);
  }

  let pendingPassword = null;
  let passwordCheckTimer = 0;
  async function confirmAndOfferPassword() {
    if (platform !== 'ios' || !pendingPassword) return;
    try {
      const me = await trpcQuery('auth.me', null);
      if (!me?.id) return;
      const credential = pendingPassword; pendingPassword = null;
      const account = (me.email || credential.account || '').trim();
      if (!account || !credential.password) return;
      window.webkit?.messageHandlers?.['munibin-password']?.postMessage({account,password:credential.password});
    } catch (_) {}
  }
  function schedulePasswordChecks() {
    clearTimeout(passwordCheckTimer);
    let attempt = 0;
    const run = async () => {
      attempt += 1; await confirmAndOfferPassword();
      if (pendingPassword && attempt < 8) passwordCheckTimer = setTimeout(run, 450 + attempt * 130);
    };
    passwordCheckTimer = setTimeout(run, 350);
  }

  document.addEventListener('submit', event => {
    if (platform !== 'ios' || !location.pathname.startsWith('/auth')) return;
    const form = event.target;
    if (!(form instanceof HTMLFormElement)) return;
    const password = form.querySelector('#current-password,#new-password');
    if (!(password instanceof HTMLInputElement) || !password.value) return;
    const accountInput = form.querySelector('#login-identifier,#register-email');
    const account = accountInput instanceof HTMLInputElement ? accountInput.value : '';
    pendingPassword = {account, password:password.value};
    schedulePasswordChecks();
  }, true);

  const observer = new MutationObserver(() => enhanceAuthPage());
  observer.observe(document.documentElement, {childList:true, subtree:true});
  window.addEventListener('popstate', enhanceAuthPage);
  setInterval(enhanceAuthPage, 800);
  enhanceAuthPage();
})();
