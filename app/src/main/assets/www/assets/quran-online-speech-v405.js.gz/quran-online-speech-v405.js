import {tokenizeRecitation} from './recitation-matcher-v401.js';

const RATE=16000, FRAME_BYTES=8000, MAX_SECONDS=26, REQUEST_INTERVAL=750, PAUSE_SECONDS=1;
const same=(a,b)=>a?.normalized===b?.normalized;
function common(a,b){let n=0;while(n<a.length&&n<b.length&&same(a[n],b[n]))n++;return n;}
export function encodeQuranWav(pcm) {
  const bytes=new Uint8Array(44+pcm.length), view=new DataView(bytes.buffer);
  const tag=(at,value)=>{for(let i=0;i<value.length;i++)bytes[at+i]=value.charCodeAt(i);};
  tag(0,'RIFF');view.setUint32(4,bytes.length-8,true);tag(8,'WAVE');tag(12,'fmt ');
  view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,1,true);
  view.setUint32(24,RATE,true);view.setUint32(28,RATE*2,true);view.setUint16(32,2,true);view.setUint16(34,16,true);
  tag(36,'data');view.setUint32(40,pcm.length,true);bytes.set(pcm,44);return bytes;
}
function joined(chunks){const bytes=new Uint8Array(chunks.reduce((n,c)=>n+c.length,0));let at=0;for(const c of chunks){bytes.set(c,at);at+=c.length;}return bytes;}
function voiced(bytes,threshold){const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let sum=0;for(let i=0;i<bytes.length;i+=2){const x=view.getInt16(i,true)/32768;sum+=x*x;}return Math.sqrt(sum/(bytes.length/2))>=threshold;}
function hypothesis(result){
  const tokens=tokenizeRecitation(result.text), timed=[];
  for(const word of result.words||[])for(const token of tokenizeRecitation(word.text))timed.push({...token,start:word.start,end:word.end,probability:word.probability});
  return timed.length===tokens.length&&timed.every((t,i)=>same(t,tokens[i]))?timed:tokens;
}

/** Audio is sent only to Munibin's backend. Its private model-service URL/token
 * never enter the native apps. Expected Quran text is never used as an ASR prompt.
 * Completed acoustic words can update the strict matcher on the first result.
 * Hypotheses remain revisable across breath pauses; stable overlapping audio is
 * retained when rolling the window. No word is supplied from the expected text.
 */
export class OnlineQuranSpeechAdapter {
  constructor({target=window,fetcher=(...args)=>fetch(...args),now=()=>Date.now(),setTimer=(...args)=>globalThis.setTimeout(...args),clearTimer=(...args)=>globalThis.clearTimeout(...args)}={}) {
    this.target=target;this.fetcher=fetcher;this.now=now;this.setTimer=setTimer;this.clearTimer=clearTimer;
    this.generation=0;this.requestId='';this.phrases=[];this.current=null;this.preRoll=[];this.busy=false;this.timer=0;
    this.sequence=0;this.frameSequence=0;this.abort=null;this.ready=false;
    this.native=typeof target.MunibinAndroid?.startQuranAudioRecognition==='function'?{
      start:id=>target.MunibinAndroid.startQuranAudioRecognition(id),
      stop:()=>target.MunibinAndroid.stopQuranAudioRecognition()
    }:target.webkit?.messageHandlers?.['munibin-speech']?.postMessage?{
      start:id=>target.webkit.messageHandlers['munibin-speech'].postMessage({action:'startAudio',requestId:id}),
      stop:()=>target.webkit.messageHandlers['munibin-speech'].postMessage({action:'stopAudio'})
    }:null;
  }
  emit(detail){if(this.requestId)this.target.dispatchEvent(new this.target.CustomEvent('munibin-native-speech',{detail:{requestId:this.requestId,...detail}}));}
  async prepare(){
    this.ready=false;
    if(!this.native)throw Object.assign(new Error('native-audio-unavailable'),{code:'unavailable'});
    const abort=new AbortController(),timer=this.setTimer(()=>abort.abort(),10000);this.prepareAbort=abort;
    try{
      const response=await this.fetcher('/api/quran-recitation/config',{credentials:'include',cache:'no-store',signal:abort.signal});
      if(!response.ok)throw Object.assign(new Error('service-not-configured'),{code:response.status===404?'service-not-configured':'network'});
      if(!/application\/json/i.test(response.headers.get('content-type')||''))throw Object.assign(new Error('service-not-configured'),{code:'service-not-configured'});
      let config;
      try{config=await response.json();}
      catch(error){throw Object.assign(new Error('invalid-service-config'),{code:error?.name==='AbortError'?'service-timeout':'service-protocol'});}
      if(!config||typeof config!=='object'||Array.isArray(config))throw Object.assign(new Error('invalid-service-config'),{code:'service-protocol'});
      if(config.enabled!==true||config.model!=='tarteel-ai/whisper-base-ar-quran'||config.sampleRate!==RATE)throw Object.assign(new Error('service-not-configured'),{code:'service-not-configured'});
      this.ready=true;
    }catch(error){
      if(typeof error?.code==='string')throw error;
      throw Object.assign(new Error('service-config-request-failed'),{code:error?.name==='AbortError'?'service-timeout':'network'});
    }finally{this.clearTimer(timer);if(this.prepareAbort===abort)this.prepareAbort=null;}
  }
  start(id){
    if(!this.ready)throw Object.assign(new Error('service-not-configured'),{code:'service-not-configured'});
    this.stop();this.requestId=id;this.frameSequence=0;this.sequence=0;this.nextUtterance=0;this.phrases=[];this.preRoll=[];
    this.receive=event=>this.onAudio(event.detail);this.target.addEventListener('munibin-native-quran-audio',this.receive);
    try{this.native.start(id);}
    catch(error){this.stop();throw Object.assign(new Error('native-audio-start-failed'),{code:'audio-capture'});}
  }
  stop(){
    const listening=!!this.requestId;
    this.generation++;this.requestId='';this.prepareAbort?.abort();this.abort?.abort();this.abort=null;
    if(this.receive)this.target.removeEventListener('munibin-native-quran-audio',this.receive);
    this.receive=null;this.clearTimer(this.timer);this.timer=0;this.busy=false;this.current=null;this.phrases=[];this.preRoll=[];
    if(listening)this.native?.stop();
  }
  fail(code){this.emit({state:'error',error:code,isFinal:true});this.stop();}
  onAudio(detail){
    if(!this.requestId||detail?.requestId!==this.requestId)return;
    if(detail.error){this.fail(detail.error);return;}
    if(detail.state==='stopped'){this.emit({state:'stopped',isFinal:true});this.stop();return;}
    if(detail.state){this.emit({state:detail.state});return;}
    if(detail.sampleRate!==RATE||!Number.isInteger(detail.sequence)||detail.sequence!==this.frameSequence+1){this.fail('audio-gap');return;}
    this.frameSequence=detail.sequence;
    let bytes;
    try{const raw=this.target.atob(detail.pcmBase64);bytes=Uint8Array.from(raw,c=>c.charCodeAt(0));}catch{this.fail('audio-format');return;}
    if(bytes.length!==FRAME_BYTES){this.fail('audio-format');return;}
    // Hysteresis retains quieter sustained recitation after its louder onset.
    const isVoice=voiced(bytes,this.current?0.0015:0.003);
    if(!this.current){
      if(!isVoice){this.preRoll.push(bytes);this.preRoll=this.preRoll.slice(-2);return;}
      this.current={id:++this.nextUtterance,chunks:this.preRoll,bytes:this.preRoll.reduce((n,c)=>n+c.length,0),silence:0,paused:false,prefix:[],context:[],previous:[],stable:[],lastRequest:-Infinity,revision:0,lastRevision:-1,alignment:null};
      this.preRoll=[];this.phrases=[this.current];
    }
    const phrase=this.current;
    // A breath pause ends a recognition segment, not the revisable transcript.
    // Avoid filling the window with idle silence or repeatedly decoding it.
    if(phrase.paused&&!isVoice){this.preRoll.push(bytes);this.preRoll=this.preRoll.slice(-2);return;}
    if(phrase.paused){for(const frame of this.preRoll){phrase.chunks.push(frame);phrase.bytes+=frame.length;}this.preRoll=[];}
    phrase.chunks.push(bytes);phrase.bytes+=bytes.length;phrase.revision++;
    phrase.silence=isVoice?0:phrase.silence+0.25;phrase.paused=phrase.silence>=PAUSE_SECONDS;
    if(phrase.bytes>MAX_SECONDS*RATE*2){
      // Never silently cut an unrecognized elongated word or skip its gate.
      this.fail('audio-window-full');return;
    }
    this.schedule();
  }
  setAlignment({utteranceId,tokenLimit}){
    const phrase=this.current;
    if(phrase?.id===utteranceId&&Number.isInteger(tokenLimit)&&tokenLimit>=0)phrase.alignment=tokenLimit;
  }
  schedule(){
    if(this.busy||this.timer||!this.requestId)return;
    const phrase=this.current;
    if(!phrase||phrase.revision===phrase.lastRevision||phrase.bytes<0.75*RATE*2)return;
    const delay=Math.max(25,REQUEST_INTERVAL-(this.now()-phrase.lastRequest));
    this.timer=this.setTimer(()=>{this.timer=0;void this.pump();},delay);
  }
  async pump(){
    if(this.busy||!this.requestId)return;
    const phrase=this.current;if(!phrase||phrase.revision===phrase.lastRevision)return;
    const time=this.now();
    if(phrase.bytes<0.75*RATE*2||time-phrase.lastRequest<REQUEST_INTERVAL){
      this.schedule();return;
    }
    this.busy=true;phrase.lastRequest=time;phrase.lastRevision=phrase.revision;
    const generation=this.generation,requestId=this.requestId,pcm=joined(phrase.chunks),duration=pcm.length/(RATE*2),segmentEnded=phrase.paused;
    const sequence=++this.sequence,abort=new AbortController();this.abort=abort;
    const timeout=this.setTimer(()=>abort.abort(),22000);
    this.emit({state:'processing'});
    try{
      const response=await this.fetcher('/api/quran-recitation/transcribe',{
        method:'POST',credentials:'include',cache:'no-store',signal:abort.signal,
        headers:{'Content-Type':'audio/wav','X-Quran-Request-Id':requestId,'X-Quran-Sequence':String(sequence)},body:encodeQuranWav(pcm)
      });
      if(generation!==this.generation||requestId!==this.requestId)return;
      if(!response.ok){let code='network';try{const payload=await response.json();if((payload.code||payload.error)==='QURAN_ASR_NOT_CONFIGURED')code='service-not-configured';else if(response.status===429||response.status===503)code='service-busy';}catch{}if(generation!==this.generation||requestId!==this.requestId)return;this.fail(code);return;}
      const result=await response.json();
      if(generation!==this.generation||requestId!==this.requestId)return;
      if(result.model!=='tarteel-ai/whisper-base-ar-quran'||result.requestId!==requestId||result.requestSequence!==sequence){this.fail('service-protocol');return;}
      const local=hypothesis(result);
      if(phrase.context.length&&common(local,phrase.context)!==phrase.context.length){
        // A changed overlap is uncertain recognition, not a recitation mistake.
        // Keep its audio so the next cumulative hypothesis can repair it.
        this.emit({state:'listening',error:'recognition-uncertain',recoverable:true});
      }else{
        const full=[...phrase.prefix,...local],agreement=common(phrase.previous,full);
        let count=local.length;
        if(!segmentEnded){
          count=0;
          for(let i=0;i<local.length;i++){
            const token=local[i];
            if(Number.isFinite(token.end)){
              if(token.end>duration-0.25||(Number.isFinite(token.probability)&&token.probability<0.2))break;
            }else if(i===local.length-1&&phrase.prefix.length+i>=agreement)break;
            count++;
          }
        }
        const published=[...phrase.prefix,...local.slice(0,count)];
        phrase.previous=full;
        // Only agreement across growing audio permits irreversible window trim.
        phrase.stable=full.slice(0,Math.min(agreement,published.length));
        this.emit({utteranceId:phrase.id,text:published.map(t=>t.text).join(' '),isFinal:false,segmentEnded,evidenceSequence:sequence,uncertain:result.uncertain===true,state:'listening',confidence:result.confidence});
        this.trim(phrase,local,full,phrase.stable.length,duration);
      }
    }catch(error){if(generation===this.generation&&requestId===this.requestId)this.fail(error?.name==='AbortError'?'service-timeout':'network');}
    finally{
      this.clearTimer(timeout);if(this.abort===abort)this.abort=null;
      if(generation===this.generation&&requestId===this.requestId){
        this.busy=false;this.schedule();
      }
    }
  }
  trim(phrase,local,full,stableCount,duration){
    // Preserve two already-heard words as acoustic context. The next result must
    // actually repeat that context before it can supply any new words.
    if(phrase.alignment==null)return;
    stableCount=Math.min(stableCount,phrase.alignment);
    if(duration<6||stableCount<phrase.prefix.length+4)return;
    const keep=stableCount-2,index=keep-phrase.prefix.length;
    const seconds=local[index]?.start;
    if(!Number.isFinite(seconds)||seconds<1)return;
    const skip=Math.max(0,Math.floor((seconds-0.06)*RATE)*2);
    const audio=joined(phrase.chunks).slice(skip);
    phrase.chunks=[audio];phrase.bytes=audio.length;
    phrase.prefix=full.slice(0,keep);phrase.context=full.slice(keep,stableCount);
  }
}

export function onlineQuranSpeechAdapter(target=window){
  const adapter=new OnlineQuranSpeechAdapter({target});return adapter.native?adapter:null;
}
