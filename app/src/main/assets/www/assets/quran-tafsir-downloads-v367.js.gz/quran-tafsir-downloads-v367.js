import {inflateTafsirSurah} from './tafsir-gzip-v362.js';
import {trustedTafsirPackageRows} from './tafsir-package-index-v362.js';

export const TAFSIR_DOWNLOAD_EVENT='munibin-tafsir-download-change';
export const BUNDLED_TAFSIR_IDS=new Set([30003,30001]);
export const OPTIONAL_TAFSIR_CATALOG=[
 {id:30004,revision:'7f5d2e24b57358078a3b13ea812bb20d0f6634458191e785da1e74c90f381d4e',bytes:1799248,rawBytes:7026971,surahs:114},
 {id:30005,revision:'73c504b31756d944af4e2290638fa8bdde8f4e68ba9e7befb15c4ad526d3bb71',bytes:5505466,rawBytes:26042471,surahs:114},
 {id:30006,revision:'b24325be58f661496fec22223921938844f697990a861ae9ad99e4f8c9bf5096',bytes:7580979,rawBytes:32835561,surahs:114},
 {id:30007,revision:'3f6a1a6e04be4ed7b9527c526a1938c8fa1190894472b880895577f226a8d665',bytes:8458360,rawBytes:39346205,surahs:114}
];
const optionalIds=new Set(OPTIONAL_TAFSIR_CATALOG.map(book=>book.id));
const downloaded=new Map(),jobs=new Map(),generations=new Map();
let databasePromise,readyPromise;
const announce=(id,kind)=>window.dispatchEvent(new CustomEvent(TAFSIR_DOWNLOAD_EVENT,{detail:{id,kind}}));
const generation=id=>generations.get(id)||0;
const nextGeneration=id=>generations.set(id,generation(id)+1);
const requiredError=()=>Object.assign(new Error('حمّل هذا التفسير من القائمة لقراءته دون اتصال.'),{code:'DOWNLOAD_REQUIRED'});
function requestValue(request){return new Promise((resolve,reject)=>{request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error)})}
function transactionDone(transaction){return new Promise((resolve,reject)=>{transaction.oncomplete=resolve;transaction.onabort=transaction.onerror=()=>reject(transaction.error||new Error('تعذر حفظ التفسير على الجهاز.'))})}
function database(){
 if(!databasePromise)databasePromise=new Promise((resolve,reject)=>{
  if(typeof indexedDB==='undefined'){reject(new Error('تعذر فتح مساحة التنزيلات على الجهاز.'));return}
  const request=indexedDB.open('munibin-quran-tafsir-downloads-v1',1);
  request.onupgradeneeded=()=>{const db=request.result;db.createObjectStore('books',{keyPath:'id'});db.createObjectStore('surahs',{keyPath:'key'})};
  request.onsuccess=()=>{const db=request.result;db.onversionchange=()=>{db.close();databasePromise=null;readyPromise=null};resolve(db)};
  request.onerror=()=>{databasePromise=null;reject(request.error)};
  request.onblocked=()=>{databasePromise=null;reject(new Error('أغلق نسخة التطبيق الأخرى ثم أعد المحاولة.'))};
 });
 return databasePromise;
}
export function initializeTafsirDownloads(){
 if(!readyPromise)readyPromise=(async()=>{
  const db=await database(),tx=db.transaction('books','readonly');
  const rows=await requestValue(tx.objectStore('books').getAll());
  for(const row of rows)if(optionalIds.has(row.id)&&row.surahs===114)downloaded.set(row.id,row);
  announce(null,'ready');
 })().catch(error=>{readyPromise=null;throw error});
 return readyPromise;
}
export function tafsirDownloadStatus(id){
 if(BUNDLED_TAFSIR_IDS.has(id))return {state:'bundled'};
 const job=jobs.get(id);if(job)return {state:'downloading',progress:job.progress,phase:job.phase};
 return downloaded.has(id)?{state:'downloaded',...downloaded.get(id)}:{state:'missing'};
}
export async function isTafsirDownloaded(id){await initializeTafsirDownloads();return downloaded.has(id)}
export async function sha256Hex(bytes){
 const hash=await crypto.subtle.digest('SHA-256',bytes);
 return Array.from(new Uint8Array(hash),byte=>byte.toString(16).padStart(2,'0')).join('');
}
const utf8=new TextDecoder('utf-8',{fatal:true});
export async function unpackTafsirPackage(input,resource){
 const bytes=input instanceof Uint8Array?input:new Uint8Array(input);
 if(bytes.length!==resource.bytes||await sha256Hex(bytes)!==resource.revision)throw new Error('لم يكتمل التنزيل أو تعذر التحقق من سلامته. أعد المحاولة.');
 if(bytes.length<12||utf8.decode(bytes.subarray(0,8))!=='MNBTFS01')throw new Error('ملف التفسير غير صالح.');
 const manifestLength=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength).getUint32(8,true),payloadStart=12+manifestLength;
 if(manifestLength>256*1024||payloadStart>=bytes.length)throw new Error('فهرس التفسير غير صالح.');
 const manifest=JSON.parse(utf8.decode(bytes.subarray(12,payloadStart)));
 const trusted=trustedTafsirPackageRows(resource);
 if(trusted){
  // Known packages are authenticated above. Keep a tiny length/hash index,
  // never the optional books themselves, and verify each unchanged gzip chunk.
  const records=[],remaining=trusted.slice(),view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let cursor=payloadStart,rawTotal=0;
  while(remaining.length){
   // Recognize an authenticated chunk by its length, gzip footer and digest.
   // This also accepts the same package data in any manifest/surah order.
   let row,chunk,index=-1;
   if(bytes[cursor]!==31||bytes[cursor+1]!==139)throw new Error('بيانات سورة التفسير غير مكتملة.');
   for(let candidate=0;candidate<remaining.length;candidate++){
    const entry=remaining[candidate],end=cursor+entry.bytes;
    if(end>bytes.length||view.getUint32(end-4,true)!==entry.rawBytes)continue;
    const value=bytes.slice(cursor,end);
    if(await sha256Hex(value)===entry.sha256){row=entry;chunk=value;index=candidate;break}
   }
   if(index<0)throw new Error('بيانات سورة التفسير غير مكتملة.');
   remaining.splice(index,1);cursor+=row.bytes;rawTotal+=row.rawBytes;
   records.push({key:`${resource.id}:${row.surah}`,id:resource.id,surah:row.surah,bytes:chunk.buffer,rawBytes:row.rawBytes,sha256:row.sha256,hashKind:'gzip'});
  }
  if(cursor!==bytes.length||rawTotal!==resource.rawBytes)throw new Error('حجم التفسير لا يطابق الفهرس.');
  return records;
 }
 const manifestId=manifest.resource??manifest.resourceId??manifest.id??manifest.bookId;
 if(manifestId!=null&&Number(manifestId)!==resource.id||manifest.version!==1)throw new Error('التفسير المطلوب لا يطابق الملف.');
 const rows=manifest.surahs;
 if(!Array.isArray(rows)||rows.length!==114)throw new Error('التفسير لا يشمل جميع السور.');
 const seen=new Set(),result=[];
 let cursor=payloadStart,rawTotal=0;
 const absolute=Number(rows[0]?.offset)===payloadStart;
 for(const row of rows){
  const surah=Number(row.surah??row.number),offset=Number(row.offset)+(absolute?0:payloadStart);
  const length=Number(row.bytes??row.gzipBytes??row.compressedBytes??row.size);
  const rawBytes=Number(row.rawBytes??row.uncompressedBytes??row.rawSize);
  if(!Number.isInteger(surah)||surah<1||surah>114||seen.has(surah)||offset!==cursor||!Number.isSafeInteger(length)||length<18||cursor+length>bytes.length||!Number.isSafeInteger(rawBytes)||rawBytes<1||rawBytes>64*1024*1024||!/^[a-f0-9]{64}$/.test(row.sha256))throw new Error('فهرس سور التفسير غير مكتمل.');
  seen.add(surah);const chunk=bytes.slice(cursor,cursor+length);cursor+=length;rawTotal+=rawBytes;
  const view=new DataView(chunk.buffer,chunk.byteOffset,chunk.byteLength);
  if(chunk[0]!==31||chunk[1]!==139||view.getUint32(chunk.length-4,true)!==rawBytes)throw new Error('بيانات سورة التفسير غير مكتملة.');
  const gzipHash=await sha256Hex(chunk);
  result.push({key:`${resource.id}:${surah}`,id:resource.id,surah,bytes:chunk.buffer,rawBytes,sha256:row.sha256,hashKind:gzipHash===row.sha256?'gzip':'raw'});
 }
 if(cursor!==bytes.length||rawTotal!==resource.rawBytes)throw new Error('حجم التفسير لا يطابق الفهرس.');
 return result;
}
async function fetchPackage(resource,job){
 const response=await fetch(`/api/quran/tafsir/downloads/${resource.id}/${resource.revision}.bin`,{cache:'no-store',signal:job.controller.signal});
 if(!response.ok)throw new Error('تعذر تنزيل التفسير الآن. تحقق من الاتصال ثم أعد المحاولة.');
 const length=Number(response.headers.get('content-length'));
 if(length&&length!==resource.bytes)throw new Error('حجم ملف التنزيل غير صحيح.');
 if(!response.body?.getReader)return new Uint8Array(await response.arrayBuffer());
 const reader=response.body.getReader(),chunks=[];let received=0,lastProgress=-1;
 try{
  for(;;){
   const {done,value}=await reader.read();if(done)break;
   received+=value.byteLength;if(received>resource.bytes)throw new Error('حجم ملف التنزيل غير صحيح.');
   chunks.push(value);job.progress=Math.min(99,Math.floor(received/resource.bytes*100));
   if(job.progress!==lastProgress){lastProgress=job.progress;announce(resource.id,'progress')}
  }
 }catch(error){await reader.cancel().catch(()=>{});throw error}finally{reader.releaseLock()}
 const bytes=new Uint8Array(received);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length}
 return bytes;
}
export async function downloadTafsir(id){
 if(!optionalIds.has(id))return;
 if(jobs.has(id))return jobs.get(id).promise;
 const token=generation(id),job={controller:new AbortController(),progress:0,phase:'download',promise:null};
 const checkCurrent=()=>{if(job.controller.signal.aborted||token!==generation(id))throw new DOMException('Cancelled','AbortError')};
 const task=(async()=>{
  await initializeTafsirDownloads();checkCurrent();
  const catalogResponse=await fetch('/api/quran/tafsir/downloads',{cache:'no-store',signal:job.controller.signal});
  if(!catalogResponse.ok)throw new Error('تعذر الوصول إلى تنزيلات التفسير. أعد المحاولة لاحقًا.');
  const catalog=await catalogResponse.json(),resource=catalog.resources?.find(book=>book.id===id);checkCurrent();
  if(!resource||!/^[a-f0-9]{64}$/.test(resource.revision)||!Number.isSafeInteger(resource.bytes)||resource.bytes<1||resource.bytes>32*1024*1024||!Number.isSafeInteger(resource.rawBytes)||resource.rawBytes<1||resource.rawBytes>128*1024*1024||resource.surahs!==114)throw new Error('ملف التفسير غير متاح حاليًا.');
  const bytes=await fetchPackage(resource,job);job.phase='verify';job.progress=100;announce(id,'progress');
  const records=await unpackTafsirPackage(bytes,resource);
  checkCurrent();
  const db=await database();checkCurrent();
  const tx=db.transaction(['books','surahs'],'readwrite'),done=transactionDone(tx);
  const abort=()=>{try{tx.abort()}catch{}};job.controller.signal.addEventListener('abort',abort,{once:true});
  const book={id,revision:resource.revision,bytes:resource.bytes,rawBytes:resource.rawBytes,surahs:114,downloadedAt:Date.now()};
  tx.objectStore('books').put(book);for(const record of records)tx.objectStore('surahs').put(record);
  try{await done}finally{job.controller.signal.removeEventListener('abort',abort)}
  if(job.controller.signal.aborted||token!==generation(id)){await removeStoredTafsir(id);checkCurrent()}
  downloaded.set(id,book);
  try{navigator.storage?.persist?.().catch(()=>{})}catch{}
  return book;
 })();
 job.promise=task;jobs.set(id,job);announce(id,'progress');
 try{const book=await task;if(job.controller.signal.aborted||token!==generation(id)){await removeStoredTafsir(id);downloaded.delete(id);checkCurrent()}if(jobs.get(id)===job){jobs.delete(id);announce(id,'installed')}return book}
 catch(error){if(jobs.get(id)===job){jobs.delete(id);announce(id,'failed')}throw error}
}
export function cancelTafsirDownload(id){nextGeneration(id);jobs.get(id)?.controller.abort()}
async function removeStoredTafsir(id){
 const db=await database(),tx=db.transaction(['books','surahs'],'readwrite'),done=transactionDone(tx);
 tx.objectStore('books').delete(id);
 const cursor=tx.objectStore('surahs').openCursor(IDBKeyRange.bound(`${id}:`,`${id}:\uffff`));
 cursor.onsuccess=()=>{const row=cursor.result;if(row){row.delete();row.continue()}};
 await done;
}
export async function deleteTafsir(id){
 if(!optionalIds.has(id))return;
 nextGeneration(id);const pending=jobs.get(id);pending?.controller.abort();if(pending)await pending.promise.catch(()=>{});
 await initializeTafsirDownloads();
 await removeStoredTafsir(id);downloaded.delete(id);announce(id,'removed');
}
export async function loadDownloadedTafsirSurah(id,surah){
 await initializeTafsirDownloads();if(!downloaded.has(id))throw requiredError();
 const token=generation(id),db=await database(),tx=db.transaction('surahs','readonly');
 const record=await requestValue(tx.objectStore('surahs').get(`${id}:${surah}`));
 if(!record)throw requiredError();
 const raw=await inflateTafsirSurah(record.bytes,record.rawBytes);
 if(record.hashKind==='raw'&&await sha256Hex(raw)!==record.sha256)throw new Error('تعذر التحقق من التفسير المحمّل. احذفه ثم أعد تحميله.');
 if(token!==generation(id)||!downloaded.has(id))throw requiredError();
 const data=JSON.parse(utf8.decode(raw));
 if(!data||typeof data!=='object'||Array.isArray(data))throw new Error('ملف التفسير غير صالح.');
 return {data,bytes:record.rawBytes};
}
// Reading an optional book online never installs a book or writes IndexedDB.
// Explicit download/delete remains the only way to manage offline copies.
async function loadOnlinePackageSurah(id,surah,signal){
 // Older deployed backends expose only the versioned package route. Keep
 // online reading functional during rollout without installing that package.
 const resource=OPTIONAL_TAFSIR_CATALOG.find(book=>book.id===id);
 const response=await fetch(`/api/quran/tafsir/downloads/${id}/${resource.revision}.bin`,{cache:'no-store',signal});
 if(!response.ok)throw new Error('تعذر فتح التفسير عبر الإنترنت. تحقق من الاتصال ثم أعد المحاولة.');
 const bytes=new Uint8Array(await response.arrayBuffer());
 if(bytes.length!==resource.bytes||await sha256Hex(bytes)!==resource.revision||utf8.decode(bytes.subarray(0,8))!=='MNBTFS01')throw new Error('تعذر التحقق من التفسير عبر الإنترنت.');
 const length=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength).getUint32(8,true),start=12+length;
 if(length>256*1024||start>=bytes.length)throw new Error('ملف التفسير غير صالح.');
 const manifest=JSON.parse(utf8.decode(bytes.subarray(12,start)));
 const row=manifest.files?.find(item=>item.surah===surah),trusted=trustedTafsirPackageRows(resource)?.find(item=>item.surah===surah);
 if(manifest.resource!==id||manifest.version!==1||!row||!trusted||row.bytes!==trusted.bytes||row.rawBytes!==trusted.rawBytes||row.sha256!==trusted.sha256||!Number.isSafeInteger(row.offset)||row.offset<0||start+row.offset+row.bytes>bytes.length)throw new Error('فهرس التفسير غير صالح.');
 const chunk=bytes.slice(start+row.offset,start+row.offset+row.bytes);
 if(await sha256Hex(chunk)!==trusted.sha256)throw new Error('تعذر التحقق من سورة التفسير.');
 const raw=await inflateTafsirSurah(chunk,trusted.rawBytes);
 return {data:JSON.parse(utf8.decode(raw)),bytes:raw.byteLength};
}
export async function loadTafsirSurah(id,surah){
 id=Number(id);surah=Number(surah);
 if(!optionalIds.has(id)||!Number.isInteger(surah)||surah<1||surah>114)throw new Error('التفسير المطلوب غير متاح.');
 try{if(await isTafsirDownloaded(id))return await loadDownloadedTafsirSurah(id,surah)}catch(error){if(downloaded.has(id))throw error}
 if(typeof navigator!=='undefined'&&navigator.onLine===false)throw requiredError();
 const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),20000);
 try{
  const response=await fetch(`/api/quran/tafsir/online/${id}/${surah}.json`,{cache:'no-store',signal:controller.signal});
  if(response.status===404||response.headers?.get?.('content-type')?.includes('text/html'))return await loadOnlinePackageSurah(id,surah,controller.signal);
  if(!response.ok)throw new Error('تعذر فتح التفسير عبر الإنترنت. تحقق من الاتصال ثم أعد المحاولة، أو حمّله للقراءة دون اتصال.');
  const raw=await response.text(),data=JSON.parse(raw);
  if(!data||typeof data!=='object'||Array.isArray(data)||!Object.keys(data).some(key=>key.startsWith(`${surah}:`)))throw new Error('ملف التفسير غير صالح.');
  return {data,bytes:new TextEncoder().encode(raw).byteLength};
 }catch(error){if(error?.name==='AbortError')throw new Error('استغرق فتح التفسير وقتًا طويلًا. تحقق من الاتصال ثم أعد المحاولة.');throw error}
 finally{clearTimeout(timeout)}
}
export function tafsirDownloadError(error){
 if(error?.name==='AbortError')return 'أُلغي التنزيل.';
 if(error?.name==='QuotaExceededError')return 'لا توجد مساحة كافية. حرّر بعض المساحة ثم أعد المحاولة.';
 return /[\u0600-\u06ff]/.test(error?.message||'')?error.message:'تعذر تنزيل التفسير. تحقق من الاتصال والمساحة ثم أعد المحاولة.';
}

export function createTafsirDownloadSelector(React,portal){
 const h=React.createElement;
 return function TafsirDownloadSelector({books,value,onSelect}){
  const [open,setOpen]=React.useState(false),[,refresh]=React.useState(0),[error,setError]=React.useState('');
  const root=React.useRef(null),trigger=React.useRef(null),menu=React.useRef(null),mounted=React.useRef(true),dropdownId=React.useId();
  React.useLayoutEffect(()=>{
   if(!open)return;
   const position=event=>{
    if(event?.type==='scroll'&&menu.current?.contains(event.target))return;
    const rect=trigger.current?.getBoundingClientRect(),panel=menu.current;if(!rect||!panel)return;
    const inherited=getComputedStyle(trigger.current);
    for(const variable of ['--qcf1441-bg','--qcf1441-text','--qcf1441-border','--qcf1441-subtle','--qcf1441-secondary','--qcf1441-gold']){const value=inherited.getPropertyValue(variable);if(value)panel.style.setProperty(variable,value)}
    const width=Math.min(320,window.innerWidth-24),below=window.innerHeight-rect.bottom-20,above=rect.top-20;
    const desired=Math.min(420,window.innerHeight*.52,panel.scrollHeight+2),up=below<desired&&above>below;
    const height=Math.max(90,Math.min(desired,up?above:below));
    Object.assign(panel.style,{position:'fixed',insetInlineStart:'auto',left:`${Math.max(12,Math.min(window.innerWidth-width-12,rect.right-width))}px`,width:`${width}px`,maxHeight:`${height}px`,top:`${up?Math.max(12,rect.top-8-height):rect.bottom+8}px`});
   };
   position();window.addEventListener('resize',position);document.addEventListener('scroll',position,true);
   window.visualViewport?.addEventListener('resize',position);
   return()=>{window.removeEventListener('resize',position);document.removeEventListener('scroll',position,true);window.visualViewport?.removeEventListener('resize',position)};
  },[open]);
  React.useEffect(()=>{
   mounted.current=true;const change=()=>refresh(number=>number+1);
   window.addEventListener(TAFSIR_DOWNLOAD_EVENT,change);
   initializeTafsirDownloads().catch(problem=>{if(mounted.current)setError(tafsirDownloadError(problem))});
   return()=>{mounted.current=false;window.removeEventListener(TAFSIR_DOWNLOAD_EVENT,change)};
  },[]);
  React.useEffect(()=>{
   if(!open)return;
   const outside=event=>{if(!root.current?.contains(event.target)&&!menu.current?.contains(event.target))setOpen(false)};
   const escape=event=>{if(event.key==='Escape'){event.stopPropagation();setOpen(false);trigger.current?.focus()}};
   document.addEventListener('pointerdown',outside,true);document.addEventListener('keydown',escape,true);
   return()=>{document.removeEventListener('pointerdown',outside,true);document.removeEventListener('keydown',escape,true)};
  },[open]);
  const act=async(book,operation)=>{setError('');try{await operation(book.id)}catch(problem){if(mounted.current)setError(tafsirDownloadError(problem))}};
  const selected=books.find(book=>book.id===value)||books[0];
  const dropdown=()=>h('div',{ref:menu,id:dropdownId,className:'munibin-tafsir-dropdown',role:'dialog','aria-label':'التفاسير المتاحة'},
    books.map(book=>{
     const status=tafsirDownloadStatus(book.id);
     const bundled=status.state==='bundled',busy=status.state==='downloading';
     const bytes=OPTIONAL_TAFSIR_CATALOG.find(item=>item.id===book.id)?.bytes||0;
     const note=bundled?'متاح دون اتصال':status.state==='downloaded'?'تم التحميل':busy?(status.phase==='verify'?'يجري الحفظ…':`يجري التحميل ${status.progress}٪`):`متاح عبر الإنترنت · ${(bytes/1000000).toLocaleString('ar-EG',{maximumFractionDigits:1})} م.ب للتحميل`;
     return h('div',{key:book.id,className:`munibin-tafsir-option${book.id===value?' is-selected':''}`},
      h('button',{type:'button',className:'munibin-tafsir-name','aria-pressed':book.id===value,onClick:()=>{
       onSelect(book.id);setOpen(false);trigger.current?.focus();
      }},h('span',null,book.title),h('small',{'aria-live':busy?'polite':undefined,'aria-atomic':true},note)),
      bundled?h('span',{className:'munibin-tafsir-bundled','aria-label':'متاح دائمًا دون اتصال'},'✓'):
      h('button',{type:'button',className:`munibin-tafsir-action${status.state==='downloaded'?' is-delete':''}`,
       'aria-label':busy?`إلغاء تحميل ${book.title}`:status.state==='downloaded'?`حذف ${book.title} من الجهاز`:`تحميل ${book.title}`,
       title:busy?'إلغاء التنزيل':status.state==='downloaded'?'حذف من الجهاز':'تحميل للاستخدام دون اتصال',
       onClick:()=>busy?cancelTafsirDownload(book.id):act(book,status.state==='downloaded'?deleteTafsir:downloadTafsir)},
       busy?h('span',{className:'munibin-tafsir-progress'},`${status.progress}٪`,h('small',null,'إلغاء')):status.state==='downloaded'?'−':
       h('svg',{width:20,height:20,viewBox:'0 0 24 24',fill:'none',stroke:'currentColor',strokeWidth:1.8,'aria-hidden':true},h('path',{d:'M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5'}))));
    }),error&&h('div',{className:'munibin-tafsir-download-error',role:'status'},error));
  return h('div',{ref:root,className:'munibin-tafsir-selector'},
   h('button',{ref:trigger,type:'button',className:'qcf1441-tafsir-resource-select',onClick:()=>setOpen(!open),'aria-expanded':open,'aria-controls':dropdownId,'aria-haspopup':'dialog','aria-label':`${selected?.title||'اختيار التفسير'} · اختيار التفسير وإدارة التنزيلات`},h('span',null,selected?.title||'اختيار التفسير'),h('svg',{className:'munibin-tafsir-chevron',width:14,height:14,viewBox:'0 0 24 24',fill:'none',stroke:'currentColor',strokeWidth:2,strokeLinecap:'round',strokeLinejoin:'round','aria-hidden':true},h('path',{d:'m6 9 6 6 6-6'}))),
   open&&(portal?portal(dropdown(),document.body):dropdown()),
   !open&&error&&h('small',{className:'munibin-tafsir-download-error',role:'status'},error));
 };
}

// Remove only legacy auto-cached Quran fonts/books. Reading preferences,
// bookmarks, recitations and explicit v362 downloads use separate storage.
export async function pruneLegacyQuranAssets(){
 if(typeof caches==='undefined')return;
 try{
  for(const name of await caches.keys()){
   const cache=await caches.open(name);
   for(const request of await cache.keys()){
    const path=new URL(request.url).pathname;
    if(path.startsWith('/api/quran/qcf4/font/')||path.startsWith('/assets/tajweed/')||/^\/assets\/tafsir\/3000[4-7]\//.test(path)||path.startsWith('/api/quran/tafsir/'))await cache.delete(request);
   }
  }
 }catch{}
}
