/* Munibin native UI patch v183: subtle Adhkar card-count affordance + existing native UI fixes */
(() => {
  'use strict';
  const SURAH = [{"surah":1,"name":"الفاتحة","ayahCount":7,"page":1},{"surah":2,"name":"البقرة","ayahCount":286,"page":2},{"surah":3,"name":"آل عمران","ayahCount":200,"page":50},{"surah":4,"name":"النساء","ayahCount":176,"page":77},{"surah":5,"name":"المائدة","ayahCount":120,"page":106},{"surah":6,"name":"الأنعام","ayahCount":165,"page":128},{"surah":7,"name":"الأعراف","ayahCount":206,"page":151},{"surah":8,"name":"الأنفال","ayahCount":75,"page":177},{"surah":9,"name":"التوبة","ayahCount":129,"page":187},{"surah":10,"name":"يونس","ayahCount":109,"page":208},{"surah":11,"name":"هود","ayahCount":123,"page":221},{"surah":12,"name":"يوسف","ayahCount":111,"page":235},{"surah":13,"name":"الرعد","ayahCount":43,"page":249},{"surah":14,"name":"ابراهيم","ayahCount":52,"page":255},{"surah":15,"name":"الحجر","ayahCount":99,"page":262},{"surah":16,"name":"النحل","ayahCount":128,"page":267},{"surah":17,"name":"الإسراء","ayahCount":111,"page":282},{"surah":18,"name":"الكهف","ayahCount":110,"page":293},{"surah":19,"name":"مريم","ayahCount":98,"page":305},{"surah":20,"name":"طه","ayahCount":135,"page":312},{"surah":21,"name":"الأنبياء","ayahCount":112,"page":322},{"surah":22,"name":"الحج","ayahCount":78,"page":332},{"surah":23,"name":"المؤمنون","ayahCount":118,"page":342},{"surah":24,"name":"النور","ayahCount":64,"page":350},{"surah":25,"name":"الفرقان","ayahCount":77,"page":359},{"surah":26,"name":"الشعراء","ayahCount":227,"page":367},{"surah":27,"name":"النمل","ayahCount":93,"page":377},{"surah":28,"name":"القصص","ayahCount":88,"page":385},{"surah":29,"name":"العنكبوت","ayahCount":69,"page":396},{"surah":30,"name":"الروم","ayahCount":60,"page":404},{"surah":31,"name":"لقمان","ayahCount":34,"page":411},{"surah":32,"name":"السجدة","ayahCount":30,"page":415},{"surah":33,"name":"الأحزاب","ayahCount":73,"page":418},{"surah":34,"name":"سبإ","ayahCount":54,"page":428},{"surah":35,"name":"فاطر","ayahCount":45,"page":434},{"surah":36,"name":"يس","ayahCount":83,"page":440},{"surah":37,"name":"الصافات","ayahCount":182,"page":446},{"surah":38,"name":"ص","ayahCount":88,"page":453},{"surah":39,"name":"الزمر","ayahCount":75,"page":458},{"surah":40,"name":"غافر","ayahCount":85,"page":467},{"surah":41,"name":"فصلت","ayahCount":54,"page":477},{"surah":42,"name":"الشورى","ayahCount":53,"page":483},{"surah":43,"name":"الزخرف","ayahCount":89,"page":489},{"surah":44,"name":"الدخان","ayahCount":59,"page":496},{"surah":45,"name":"الجاثية","ayahCount":37,"page":499},{"surah":46,"name":"الأحقاف","ayahCount":35,"page":502},{"surah":47,"name":"محمد","ayahCount":38,"page":507},{"surah":48,"name":"الفتح","ayahCount":29,"page":511},{"surah":49,"name":"الحجرات","ayahCount":18,"page":515},{"surah":50,"name":"ق","ayahCount":45,"page":518},{"surah":51,"name":"الذاريات","ayahCount":60,"page":520},{"surah":52,"name":"الطور","ayahCount":49,"page":523},{"surah":53,"name":"النجم","ayahCount":62,"page":526},{"surah":54,"name":"القمر","ayahCount":55,"page":528},{"surah":55,"name":"الرحمن","ayahCount":78,"page":531},{"surah":56,"name":"الواقعة","ayahCount":96,"page":534},{"surah":57,"name":"الحديد","ayahCount":29,"page":537},{"surah":58,"name":"المجادلة","ayahCount":22,"page":542},{"surah":59,"name":"الحشر","ayahCount":24,"page":545},{"surah":60,"name":"الممتحنة","ayahCount":13,"page":549},{"surah":61,"name":"الصف","ayahCount":14,"page":551},{"surah":62,"name":"الجمعة","ayahCount":11,"page":553},{"surah":63,"name":"المنافقون","ayahCount":11,"page":554},{"surah":64,"name":"التغابن","ayahCount":18,"page":556},{"surah":65,"name":"الطلاق","ayahCount":12,"page":558},{"surah":66,"name":"التحريم","ayahCount":12,"page":560},{"surah":67,"name":"الملك","ayahCount":30,"page":562},{"surah":68,"name":"القلم","ayahCount":52,"page":564},{"surah":69,"name":"الحاقة","ayahCount":52,"page":566},{"surah":70,"name":"المعارج","ayahCount":44,"page":568},{"surah":71,"name":"نوح","ayahCount":28,"page":570},{"surah":72,"name":"الجن","ayahCount":28,"page":572},{"surah":73,"name":"المزمل","ayahCount":20,"page":574},{"surah":74,"name":"المدثر","ayahCount":56,"page":575},{"surah":75,"name":"القيامة","ayahCount":40,"page":577},{"surah":76,"name":"الانسان","ayahCount":31,"page":578},{"surah":77,"name":"المرسلات","ayahCount":50,"page":580},{"surah":78,"name":"النبإ","ayahCount":40,"page":582},{"surah":79,"name":"النازعات","ayahCount":46,"page":583},{"surah":80,"name":"عبس","ayahCount":42,"page":585},{"surah":81,"name":"التكوير","ayahCount":29,"page":586},{"surah":82,"name":"الإنفطار","ayahCount":19,"page":587},{"surah":83,"name":"المطففين","ayahCount":36,"page":587},{"surah":84,"name":"الإنشقاق","ayahCount":25,"page":589},{"surah":85,"name":"البروج","ayahCount":22,"page":590},{"surah":86,"name":"الطارق","ayahCount":17,"page":591},{"surah":87,"name":"الأعلى","ayahCount":19,"page":591},{"surah":88,"name":"الغاشية","ayahCount":26,"page":592},{"surah":89,"name":"الفجر","ayahCount":30,"page":593},{"surah":90,"name":"البلد","ayahCount":20,"page":594},{"surah":91,"name":"الشمس","ayahCount":15,"page":595},{"surah":92,"name":"الليل","ayahCount":21,"page":595},{"surah":93,"name":"الضحى","ayahCount":11,"page":596},{"surah":94,"name":"الشرح","ayahCount":8,"page":596},{"surah":95,"name":"التين","ayahCount":8,"page":597},{"surah":96,"name":"العلق","ayahCount":19,"page":597},{"surah":97,"name":"القدر","ayahCount":5,"page":598},{"surah":98,"name":"البينة","ayahCount":8,"page":598},{"surah":99,"name":"الزلزلة","ayahCount":8,"page":599},{"surah":100,"name":"العاديات","ayahCount":11,"page":599},{"surah":101,"name":"القارعة","ayahCount":11,"page":600},{"surah":102,"name":"التكاثر","ayahCount":8,"page":600},{"surah":103,"name":"العصر","ayahCount":3,"page":601},{"surah":104,"name":"الهمزة","ayahCount":9,"page":601},{"surah":105,"name":"الفيل","ayahCount":5,"page":601},{"surah":106,"name":"قريش","ayahCount":4,"page":602},{"surah":107,"name":"الماعون","ayahCount":7,"page":602},{"surah":108,"name":"الكوثر","ayahCount":3,"page":602},{"surah":109,"name":"الكافرون","ayahCount":6,"page":603},{"surah":110,"name":"النصر","ayahCount":3,"page":603},{"surah":111,"name":"المسد","ayahCount":5,"page":603},{"surah":112,"name":"الإخلاص","ayahCount":4,"page":604},{"surah":113,"name":"الفلق","ayahCount":5,"page":604},{"surah":114,"name":"الناس","ayahCount":6,"page":604}];
  const JUZ = [{"juz":1,"page":1,"surah":1,"ayah":1},{"juz":2,"page":22,"surah":2,"ayah":142},{"juz":3,"page":42,"surah":2,"ayah":253},{"juz":4,"page":62,"surah":3,"ayah":93},{"juz":5,"page":82,"surah":4,"ayah":24},{"juz":6,"page":102,"surah":4,"ayah":148},{"juz":7,"page":121,"surah":5,"ayah":82},{"juz":8,"page":142,"surah":6,"ayah":111},{"juz":9,"page":162,"surah":7,"ayah":88},{"juz":10,"page":182,"surah":8,"ayah":41},{"juz":11,"page":201,"surah":9,"ayah":93},{"juz":12,"page":222,"surah":11,"ayah":6},{"juz":13,"page":242,"surah":12,"ayah":53},{"juz":14,"page":262,"surah":15,"ayah":1},{"juz":15,"page":282,"surah":17,"ayah":1},{"juz":16,"page":302,"surah":18,"ayah":75},{"juz":17,"page":322,"surah":21,"ayah":1},{"juz":18,"page":342,"surah":23,"ayah":1},{"juz":19,"page":362,"surah":25,"ayah":21},{"juz":20,"page":382,"surah":27,"ayah":56},{"juz":21,"page":402,"surah":29,"ayah":46},{"juz":22,"page":422,"surah":33,"ayah":31},{"juz":23,"page":442,"surah":36,"ayah":28},{"juz":24,"page":462,"surah":39,"ayah":32},{"juz":25,"page":482,"surah":41,"ayah":47},{"juz":26,"page":502,"surah":46,"ayah":1},{"juz":27,"page":522,"surah":51,"ayah":31},{"juz":28,"page":542,"surah":58,"ayah":1},{"juz":29,"page":562,"surah":67,"ayah":1},{"juz":30,"page":582,"surah":78,"ayah":1}];
  const state = { choiceOverlay: null, surahOverlay: null };

  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (m) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const q = (sel, root=document) => root.querySelector(sel);
  const qa = (sel, root=document) => [...root.querySelectorAll(sel)];
  const arabicDigits = (n) => String(n).replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[Number(d)]);
  const latinDigits = (s) => String(s ?? '').replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));

  const twoFrames = () => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));

  function closeChoice(immediate=false){
    const overlay = state.choiceOverlay;
    if (!overlay) return;
    if (immediate) {
      if (state.choiceOverlay === overlay) state.choiceOverlay = null;
      overlay.remove();
      return;
    }
    if (overlay.dataset.munibinClosing === '1') return;
    overlay.dataset.munibinClosing = '1';
    const sheet = q('.munibin-choice-sheet', overlay);
    overlay.classList.remove('is-open');
    overlay.style.pointerEvents = 'none';
    overlay.style.transition = 'opacity .20s ease';
    overlay.style.opacity = '0';
    if (sheet) {
      sheet.style.transition = 'transform .20s cubic-bezier(.22,.61,.36,1)';
      sheet.style.transform = 'translate3d(0,110%,0)';
    }
    window.setTimeout(() => {
      if (state.choiceOverlay === overlay) state.choiceOverlay = null;
      overlay.remove();
    }, 205);
  }
  function closeSurah(){
    if (state.surahOverlay) state.surahOverlay.remove();
    state.surahOverlay = null;
  }
  function dismissSurahAfterJump(){
    const overlay = state.surahOverlay;
    if (!overlay) return;
    // Hide the large 114-surah/30-juz sheet immediately, but defer physically
    // removing all of its DOM nodes until after the reader has painted the new
    // page. Removing the full list synchronously was the source of the visible
    // selector-only hitch even though the Quran data itself was already local.
    state.surahOverlay = null;
    overlay.style.transition = 'none';
    overlay.style.opacity = '0';
    overlay.style.visibility = 'hidden';
    overlay.style.pointerEvents = 'none';
    const remove = () => overlay.remove();
    if ('requestIdleCallback' in window) window.requestIdleCallback(remove, {timeout:260});
    else window.setTimeout(remove, 220);
  }

  function iconChevron(){
    return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m7 10 5 5 5-5"/></svg>';
  }
  function iconCheck(){
    return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4 4L19 6"/></svg>';
  }
  function iconSearch(){
    return '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>';
  }
  function iconClose(){
    return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>';
  }

  function ensureTafsirCaret(select){
    if (select.tagName !== 'SELECT') return;
    if (!select.classList.contains('qcf1441-tafsir-resource-select')) return;
    const host = select.parentElement;
    if (!host) return;
    let caret = host.querySelector('.munibin-tafsir-visible-caret');
    if (!caret) {
      caret = document.createElement('i');
      caret.className = 'munibin-tafsir-visible-caret';
      caret.setAttribute('aria-hidden', 'true');
      caret.innerHTML = iconChevron();
      host.appendChild(caret);
    }
    const position = () => {
      if (!select.isConnected || !caret.isConnected) return;
      const sr = select.getBoundingClientRect();
      const hr = host.getBoundingClientRect();
      const size = 17;
      caret.style.left = `${Math.max(6, sr.left - hr.left + 11)}px`;
      caret.style.top = `${Math.max(3, sr.top - hr.top + (sr.height - size) / 2)}px`;
    };
    position();
    requestAnimationFrame(position);
  }

  function applyQuranThemeVars(target){
    const source = q('.qcf1441-preview');
    if (!source || !target) return;
    const styles = getComputedStyle(source);
    [
      '--qcf1441-bg','--qcf1441-text','--qcf1441-header','--qcf1441-border',
      '--qcf1441-input-bg','--qcf1441-input-border','--qcf1441-input-text',
      '--qcf1441-subtle','--qcf1441-secondary','--qcf1441-gold','--qcf1441-verse-highlight'
    ].forEach((name) => {
      const value = styles.getPropertyValue(name).trim();
      if (value) target.style.setProperty(name, value);
    });
  }

  function selectedLabel(select){
    const opt = select.options[select.selectedIndex] || [...select.options].find(o => o.value === select.value);
    return (opt?.textContent || select.getAttribute('aria-label') || 'اختيار').trim();
  }

  function getPageContextInfo(){
    const el = q('.qcf1441-page-context > span[aria-live], .qcf1441-page-context > span');
    const raw = (el?.textContent || '').replace(/\s+/g, ' ').trim();
    const parts = raw.split(/[·•]/).map(part => part.trim()).filter(Boolean);
    const findNumber = (label) => {
      const part = parts.find(p => p.includes(label)) || '';
      const match = part.match(/([0-9٠-٩]+)/);
      return match ? Number(latinDigits(match[1])) : null;
    };
    const urlPage = Number(new URL(window.location.href).searchParams.get('page'));
    const visiblePageText = q('.qcf1441-page-number--base, .qcf1441-page-number')?.textContent || '';
    const visiblePageMatch = visiblePageText.match(/([0-9٠-٩]+)/);
    const visiblePage = visiblePageMatch ? Number(latinDigits(visiblePageMatch[1])) : null;
    const page = findNumber('صفحة') || (Number.isFinite(urlPage) && urlPage > 0 ? urlPage : null) || visiblePage;
    const juzFromText = findNumber('الجزء');
    const hizbFromText = findNumber('الحزب');
    const juzFromPage = page ? [...JUZ].reverse().find(j => page >= j.page)?.juz || null : null;
    return {
      element: el,
      raw,
      parts,
      page,
      juz: juzFromText || juzFromPage,
      hizb: hizbFromText,
    };
  }

  function normalizePageContext(){
    const info = getPageContextInfo();
    if (info.element) info.element.title = info.raw;
    return info;
  }

  function surahForPage(page){
    if (!page) return null;
    let match = SURAH[0];
    for (const surah of SURAH) {
      if (surah.page > page) break;
      match = surah;
    }
    return match || null;
  }

  function reactSurahName(){
    const strong = q('.qcf1441-page-context-title > strong');
    if (!strong) return '';
    const raw = (strong.textContent || '').replace(/\s+/g, ' ').trim();
    return SURAH.some(s => s.name === raw) ? raw : '';
  }

  const CHOICE_SELECT_SELECTOR = '.qcf1441-reciter-panel select, select.qcf1441-tafsir-resource-select, .qcf1441-navigator[aria-label="بحث وانتقال في المصحف"] select, .munibin-wird-form-overlay select';
  const choiceCache = new WeakMap();
  let guardedPointer = null;
  let lastGuardedOpenAt = 0;
  const isAndroidNative = !!window.MunibinAndroid || /Android/i.test(navigator.userAgent || '');

  let androidTouch = null;

  function isAndroidChoiceFallback(select){
    return !!(isAndroidNative && select?.matches?.(CHOICE_SELECT_SELECTOR));
  }

  function hardenSearchAgainstOpeningTap(search, overlay){
    if (!search || !overlay) return;
    // iOS can retarget the synthetic click that follows pointerup onto the newly
    // inserted search field. Keep it temporarily readonly and swallow that one
    // opening click so the keyboard appears only after a deliberate search tap.
    const unlockAt = Date.now() + 360;
    search.readOnly = true;
    const swallowOpeningClick = (event) => {
      if (Date.now() > unlockAt) return;
      if (event.target === search || event.target?.closest?.('.munibin-choice-search')) {
        event.preventDefault();
        event.stopImmediatePropagation();
        search.blur?.();
      }
    };
    overlay.addEventListener('click', swallowOpeningClick, true);
    window.setTimeout(() => {
      search.blur?.();
      search.readOnly = false;
      overlay.removeEventListener('click', swallowOpeningClick, true);
    }, 380);
  }

  function choiceItems(select, force=false){
    const optionCount = select.options.length;
    const first = optionCount ? select.options[0] : null;
    const last = optionCount ? select.options[optionCount - 1] : null;
    const signature = `${optionCount}|${first?.value ?? ''}|${first?.textContent ?? ''}|${last?.value ?? ''}|${last?.textContent ?? ''}`;
    const cached = choiceCache.get(select);
    if (!force && cached?.signature === signature) return cached.items;
    const items = [...select.options]
      .filter(o => !o.disabled && !o.hidden)
      .map(o => ({
        value: String(o.value),
        label: (o.textContent || '').trim(),
        search: (o.textContent || '').trim().toLocaleLowerCase('ar')
      }));
    choiceCache.set(select, {signature, items});
    return items;
  }

  function prewarmChoice(select){
    const warm = () => { try { choiceItems(select, true); } catch {} };
    if ('requestIdleCallback' in window) window.requestIdleCallback(warm, {timeout:180});
    else window.setTimeout(warm, 0);
  }

  function openChoice(select){
    closeChoice(true);
    closeSurah();
    // The range lists are already local. Build from a prewarmed snapshot instead
    // of attaching hundreds of individual listeners on every tap.
    const options = choiceItems(select);
    const overlay = document.createElement('div');
    overlay.className = 'munibin-choice-overlay';
    if (select.matches('.qcf1441-reciter-panel select')) overlay.classList.add('munibin-choice-overlay--audio');
    if (select.closest('.munibin-wird-form-overlay')) overlay.classList.add('munibin-choice-overlay--feature');
    overlay.dir = 'rtl';
    const rawTitle = select.getAttribute('aria-label') || 'اختيار';
    // In the Quran search/jump menu, keep the underlying aria-label used by the
    // reader bridge, but present the simpler Munibin sheet title requested by UI.
    const title = select.closest('.qcf1441-navigator[aria-label="بحث وانتقال في المصحف"]') && rawTitle === 'سورة الآية'
      ? 'السورة'
      : rawTitle;
    const searchable = options.length > 12;
    overlay.innerHTML = `
      <div class="munibin-choice-backdrop"></div>
      <section class="munibin-choice-sheet" role="dialog" aria-modal="true" aria-label="${esc(title)}">
        <header class="munibin-choice-head">
          <button type="button" class="munibin-choice-close" aria-label="إغلاق">${iconClose()}</button>
          <strong>${esc(title)}</strong>
        </header>
        ${searchable ? `<label class="munibin-choice-search">${iconSearch()}<input type="search" inputmode="search" placeholder="بحث…" aria-label="بحث في الخيارات" autocomplete="off" enterkeyhint="search"></label>` : ''}
        <div class="munibin-choice-list"></div>
      </section>`;
    applyQuranThemeVars(overlay);
    document.body.appendChild(overlay);
    state.choiceOverlay = overlay;
    const list = q('.munibin-choice-list', overlay);
    const search = q('.munibin-choice-search input', overlay);
    hardenSearchAgainstOpeningTap(search, overlay);
    let renderRaf = 0;
    const render = () => {
      renderRaf = 0;
      const needle = (search?.value || '').trim().toLocaleLowerCase('ar');
      const matches = options.filter(o => !needle || o.search.includes(needle));
      const selectedValue = String(select.value);
      if (!matches.length) {
        list.innerHTML = '<div class="munibin-choice-empty">لا توجد نتائج</div>';
        return;
      }
      // One HTML parse + one delegated click handler is markedly faster on iOS
      // than creating 604 buttons and 604 listeners synchronously.
      list.innerHTML = matches.map((opt) => {
        const selected = opt.value === selectedValue;
        return `<button type="button" class="munibin-choice-option${selected ? ' is-selected' : ''}" data-value="${esc(opt.value)}"><span>${esc(opt.label)}</span><span class="munibin-choice-check">${selected ? iconCheck() : ''}</span></button>`;
      }).join('');
    };
    render();
    list.addEventListener('click', (event) => {
      const button = event.target?.closest?.('.munibin-choice-option');
      if (!button || !list.contains(button)) return;
      select.value = button.dataset.value ?? '';
      select.dispatchEvent(new Event('input', {bubbles:true}));
      select.dispatchEvent(new Event('change', {bubbles:true}));
      closeChoice();
    });
    search?.addEventListener('input', () => {
      if (renderRaf) cancelAnimationFrame(renderRaf);
      renderRaf = requestAnimationFrame(render);
    });
    const backdrop = q('.munibin-choice-backdrop', overlay);
    const sheet = q('.munibin-choice-sheet', overlay);
    const head = q('.munibin-choice-head', overlay);
    backdrop.addEventListener('click', closeChoice);
    q('.munibin-choice-close', overlay).addEventListener('click', closeChoice);

    // Match the surah navigator's drag interaction: the sheet follows the finger
    // continuously, then either settles back or glides down to dismiss. The header
    // owns the gesture so scrolling/searching the choices themselves stays normal.
    let choiceSwipe = null;
    let choiceSettleTimer = 0;
    const clearChoiceSettle = () => {
      if (choiceSettleTimer) window.clearTimeout(choiceSettleTimer);
      choiceSettleTimer = 0;
    };
    const clearChoiceInlineMotion = () => {
      if (!sheet) return;
      clearChoiceSettle();
      sheet.style.removeProperty('transition');
      sheet.style.removeProperty('transform');
      overlay.style.removeProperty('transition');
      overlay.style.removeProperty('opacity');
    };
    const settleChoiceBack = () => {
      if (!sheet) return;
      clearChoiceSettle();
      sheet.style.transition = 'transform .22s cubic-bezier(.22,.61,.36,1)';
      sheet.style.transform = 'translateY(0)';
      overlay.style.transition = 'opacity .22s ease';
      overlay.style.opacity = '1';
      choiceSettleTimer = window.setTimeout(clearChoiceInlineMotion, 230);
    };
    head?.addEventListener('pointerdown', (event) => {
      if (event.pointerType === 'mouse' && event.button !== 0) return;
      if (event.target.closest('button,input')) return;
      clearChoiceSettle();
      choiceSwipe = {id:event.pointerId, y:event.clientY, t:performance.now(), dy:0};
      try { head.setPointerCapture(event.pointerId); } catch {}
      if (sheet) sheet.style.transition = 'none';
      overlay.style.transition = 'none';
    }, {passive:true});
    head?.addEventListener('pointermove', (event) => {
      if (!choiceSwipe || event.pointerId !== choiceSwipe.id || !sheet) return;
      const dy = Math.max(0, event.clientY - choiceSwipe.y);
      choiceSwipe.dy = dy;
      sheet.style.transform = `translateY(${dy}px)`;
      overlay.style.opacity = String(Math.max(.35, 1 - dy / 320));
    }, {passive:true});
    const finishChoiceSwipe = (event) => {
      if (!choiceSwipe || event.pointerId !== choiceSwipe.id) return;
      const dy = choiceSwipe.dy;
      const dt = Math.max(1, performance.now() - choiceSwipe.t);
      const velocity = dy / dt;
      choiceSwipe = null;
      try { head.releasePointerCapture(event.pointerId); } catch {}
      if (dy >= 72 || velocity > .65) {
        if (sheet) {
          sheet.style.transition = 'transform .22s cubic-bezier(.22,.61,.36,1)';
          sheet.style.transform = 'translateY(110%)';
        }
        overlay.style.transition = 'opacity .22s ease';
        overlay.style.opacity = '0';
        window.setTimeout(() => closeChoice(true), 220);
      } else {
        settleChoiceBack();
      }
    };
    head?.addEventListener('pointerup', finishChoiceSwipe, {passive:true});
    head?.addEventListener('pointercancel', finishChoiceSwipe, {passive:true});

    requestAnimationFrame(() => overlay.classList.add('is-open'));
    // Intentionally do NOT focus the search field here. The keyboard should only
    // appear after the user explicitly taps search.
  }

  function eventChoiceSelect(event){
    const path = typeof event.composedPath === 'function' ? event.composedPath() : [];
    for (const node of path) {
      if (!(node instanceof Element)) continue;
      if (node.matches?.(CHOICE_SELECT_SELECTOR)) return node;
      const nested = node.closest?.(CHOICE_SELECT_SELECTOR);
      if (nested) return nested;
    }
    const target = event.target;
    if (!(target instanceof Element)) return null;
    const direct = target.closest(CHOICE_SELECT_SELECTOR);
    if (direct) return direct;

    // The Wird form uses native <select> elements as invisible state holders for
    // the Munibin sheet. On iOS/WebKit a tap on the rendered text half of a wide
    // RTL select can occasionally retarget to its <label> instead of the <select>.
    // Resolve any tap that is physically inside the select rectangle back to that
    // select so the *entire visible field* opens the Munibin dropdown.
    const wirdLabel = target.closest('.munibin-wird-form-overlay label');
    const wirdSelect = wirdLabel?.querySelector?.('select');
    if (wirdSelect?.matches?.(CHOICE_SELECT_SELECTOR)) {
      const point = event.changedTouches?.[0] || event.touches?.[0] || event;
      const x = Number(point?.clientX), y = Number(point?.clientY);
      const rect = wirdSelect.getBoundingClientRect();
      if (Number.isFinite(x) && Number.isFinite(y) && x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom) return wirdSelect;
    }

    // Only explicit selector controls may open a dropdown. In particular, do not
    // treat the entire Tafsir header as the Tafsir selector: its close button and
    // source/meta area must retain their own actions.
    const label = target.closest('.qcf1441-reciter-panel label, .qcf1441-navigator label');
    const select = label?.querySelector?.('select');
    return select?.matches?.(CHOICE_SELECT_SELECTOR) ? select : null;
  }

  function installChoiceGuard(){
    if (document.documentElement.dataset.munibinChoiceGuard === '181') return;
    document.documentElement.dataset.munibinChoiceGuard = '181';

    // iOS: intercept pointerdown before the native <select> default action.
    // Android WebView is intentionally handled with touchend/click below;
    // canceling Android pointerdown was suppressing the matching pointerup on a
    // fresh launch and made the controls appear dead until a later rerender.
    document.addEventListener('pointerdown', (event) => {
      if (isAndroidNative) return;
      const select = eventChoiceSelect(event);
      if (!select) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      guardedPointer = {select, id:event.pointerId, x:event.clientX, y:event.clientY, moved:false};
    }, {capture:true, passive:false});

    document.addEventListener('pointermove', (event) => {
      if (isAndroidNative || !guardedPointer || event.pointerId !== guardedPointer.id) return;
      if (Math.hypot(event.clientX - guardedPointer.x, event.clientY - guardedPointer.y) > 10) guardedPointer.moved = true;
    }, {capture:true, passive:true});

    document.addEventListener('pointerup', (event) => {
      if (isAndroidNative || !guardedPointer || event.pointerId !== guardedPointer.id) return;
      const pending = guardedPointer;
      guardedPointer = null;
      event.preventDefault();
      event.stopImmediatePropagation();
      if (pending.moved) return;
      pending.select.blur?.();
      lastGuardedOpenAt = Date.now();
      openChoice(pending.select);
    }, {capture:true, passive:false});

    document.addEventListener('pointercancel', () => { guardedPointer = null; }, {capture:true});

    // Android: track a real tap without preventing touchstart. This covers every
    // select in the audio panel (reciter, surah, ayah, page and repeat counts)
    // plus the tafsir selector from the very first app launch.
    document.addEventListener('touchstart', (event) => {
      if (!isAndroidNative) return;
      const select = eventChoiceSelect(event);
      if (!isAndroidChoiceFallback(select)) { androidTouch = null; return; }
      const touch = event.changedTouches?.[0];
      androidTouch = {
        select, id:touch?.identifier ?? null,
        x:touch?.clientX ?? 0, y:touch?.clientY ?? 0, moved:false
      };
    }, {capture:true, passive:true});

    document.addEventListener('touchmove', (event) => {
      if (!isAndroidNative || !androidTouch) return;
      const touches = [...(event.changedTouches || [])];
      const touch = touches.find(t => androidTouch.id == null || t.identifier === androidTouch.id) || touches[0];
      if (!touch) return;
      if (Math.hypot(touch.clientX - androidTouch.x, touch.clientY - androidTouch.y) > 10) androidTouch.moved = true;
    }, {capture:true, passive:true});

    document.addEventListener('touchend', (event) => {
      if (!isAndroidNative) return;
      const select = androidTouch?.select || eventChoiceSelect(event);
      const moved = !!androidTouch?.moved;
      androidTouch = null;
      if (!isAndroidChoiceFallback(select) || moved) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      guardedPointer = null;
      select.blur?.();
      if (Date.now() - lastGuardedOpenAt < 220) return;
      lastGuardedOpenAt = Date.now();
      openChoice(select);
    }, {capture:true, passive:false});

    document.addEventListener('touchcancel', () => { androidTouch = null; }, {capture:true});

    // Click is also kept as a mouse/stylus/emulator fallback. preventDefault here
    // blocks the device-themed native picker before its default action runs.
    document.addEventListener('click', (event) => {
      const select = eventChoiceSelect(event);
      if (!select) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      if (Date.now() - lastGuardedOpenAt < 260) return;
      select.blur?.();
      lastGuardedOpenAt = Date.now();
      openChoice(select);
    }, true);

    document.addEventListener('keydown', (event) => {
      const select = eventChoiceSelect(event);
      if (!select || !['Enter',' ','ArrowDown','ArrowUp'].includes(event.key)) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      lastGuardedOpenAt = Date.now();
      openChoice(select);
    }, true);
  }

  function enhanceSelect(select){
    if (select.tagName !== 'SELECT') return;
    ensureTafsirCaret(select);
    if (select.dataset.munibinEnhanced === '1') return;
    select.dataset.munibinEnhanced = '1';
    select.classList.add('munibin-enhanced-select');
    select.setAttribute('aria-haspopup', 'dialog');
    select.title = selectedLabel(select);
    select.addEventListener('change', () => {
      select.title = selectedLabel(select);
      // The option set can change after another range control changes.
      choiceCache.delete(select);
      prewarmChoice(select);
    });
    prewarmChoice(select);
  }

  function enhanceTargetSelects(){
    qa('.qcf1441-reciter-panel select, select.qcf1441-tafsir-resource-select, .qcf1441-navigator[aria-label="بحث وانتقال في المصحف"] select, .munibin-wird-form-overlay select').forEach(enhanceSelect);
  }

  // A selector choice wins until its destination page has been left.
  // Keep it pending while the previous page is still loading, and do not
  // expire it when scrolling vertically within the same Quran page.
  function selectedSurahForPage(page){
    const selected = window.__munibinSurahNavigatorOverride;
    if (!selected) return null;
    const number = Number(page);
    if (number === Number(selected.page)) selected.active = true;
    else if (selected.active && Number.isInteger(number) && number >= 1 && number <= 604) {
      window.__munibinSurahNavigatorOverride = null;
      return null;
    }
    return selected;
  }

  function currentSurahName(){
    const selected = selectedSurahForPage(currentPage());
    if (selected?.name) return selected.name;
    const custom = (q('.munibin-quran-context-name')?.textContent || '').trim();
    if (custom && SURAH.some(s => s.name === custom)) return custom;
    const reactName = reactSurahName();
    if (reactName) return reactName;
    return surahForPage(currentPage())?.name || 'السورة';
  }
  function currentPage(){
    return normalizePageContext().page;
  }
  function currentSurahNumber(){
    const name = currentSurahName();
    return SURAH.find(s => s.name === name)?.surah || surahForPage(currentPage())?.surah || null;
  }
  function useReaderJump(method, value){
    const bridge = window.__munibinQuranNavigationBridge;
    const fn = bridge && bridge[method];
    if (typeof fn !== 'function') return false;
    try { return fn(value) !== false; } catch { return false; }
  }

  function dispatchChange(el){
    if (!el) return false;
    el.dispatchEvent(new Event('input', {bubbles:true}));
    el.dispatchEvent(new Event('change', {bubbles:true}));
    return true;
  }

  function jumpViaBuiltins(kind, value){
    try {
      if (kind === 'page') {
        const select = q('.qcf1441-navigator-page-jump select[aria-label="الانتقال برقم الصفحة"]');
        if (!select) return false;
        select.value = String(value);
        return dispatchChange(select);
      }
      if (kind === 'juz') {
        const select = q('.qcf1441-navigator-selects select[aria-label="الانتقال إلى جزء"]');
        if (!select) return false;
        select.value = String(value);
        return dispatchChange(select);
      }
      if (kind === 'surah') {
        const wrap = q('.qcf1441-navigator-ayah-jump');
        const surahSelect = q('select[aria-label="سورة الآية"]', wrap || document);
        const ayahSelect = q('select[aria-label="رقم الآية"]', wrap || document);
        const goButton = qa('button', wrap || document).find(btn => /اذهب/.test((btn.textContent || '').trim()));
        if (!surahSelect || !ayahSelect || !goButton) return false;
        surahSelect.value = String(value);
        dispatchChange(surahSelect);
        const setFirstAyah = () => {
          ayahSelect.value = '1';
          dispatchChange(ayahSelect);
          goButton.click();
        };
        requestAnimationFrame(() => requestAnimationFrame(setFirstAyah));
        return true;
      }
    } catch {}
    return false;
  }

  function goPage(page){
    closeSurah();
    const current = currentPage();
    if (current === page) return;
    if (jumpViaBuiltins('page', page)) return;
    // Use the exact same in-memory React state path as the built-in Search/Jump
    // panel. This avoids history/router churn and therefore avoids the online
    // loading pause/stutter that the custom sura/juz sheet used to trigger.
    if (useReaderJump('goPage', page)) return;
    const url = new URL(window.location.href);
    url.searchParams.set('page', String(page));
    const nextUrl = url.toString();
    const nextStateUrl = `${url.pathname}${url.search}${url.hash}`;
    let fellBack = false;
    const fallback = () => {
      if (fellBack) return;
      fellBack = true;
      window.location.assign(nextUrl);
    };
    try {
      window.history.pushState({}, '', nextStateUrl);
      window.dispatchEvent(new PopStateEvent('popstate'));
      window.dispatchEvent(new Event('locationchange'));
      document.dispatchEvent(new CustomEvent('munibin:quran-page-jump', { detail: { page } }));
      let tries = 0;
      const poll = () => {
        if (currentPage() === page) return;
        tries += 1;
        if (tries > 16) return fallback();
        requestAnimationFrame(poll);
      };
      requestAnimationFrame(poll);
    } catch {
      fallback();
    }
  }

  function setReactControlValue(control, value){
    if (!control) return false;
    const proto = control instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
    if (descriptor?.set) descriptor.set.call(control, String(value));
    else control.value = String(value);
    control.dispatchEvent(new Event('input', {bubbles:true}));
    control.dispatchEvent(new Event('change', {bubbles:true}));
    return true;
  }

  async function waitForElement(getter, timeout=1200){
    const started = performance.now();
    for (;;) {
      const found = typeof getter === 'function' ? getter() : q(getter);
      if (found) return found;
      if (performance.now() - started >= timeout) return null;
      await new Promise(resolve => requestAnimationFrame(resolve));
    }
  }

  async function goPageThroughWorkingUI(page){
    const bridge = window.__munibinQuranNavigationBridge;
    if (typeof bridge?.goPage !== 'function') return {ok:false, stage:'reader-not-ready'};
    const ok = await bridge.goPage(Number(page));
    return {ok:ok !== false, stage:'direct-reader-jump'};
  }

  async function goSurah(surah, page){
    const selected = SURAH.find(item => item.surah === Number(surah));
    if (!selected) return;
    const destination = Number(page) || selected.page;
    const label = {surah:selected.surah, page:destination, name:selected.name, active:false};
    window.__munibinSurahNavigatorOverride = label;
    window.__munibinQuranNavigationHighlight?.request?.(`${selected.surah}:1`, destination);
    dismissSurahAfterJump();
    // The same page may contain several surahs. Update its selector even when
    // the direct jump leaves React's page/data values unchanged.
    ensureSurahHeader();
    const clearFailedChoice = () => {
      if (window.__munibinSurahNavigatorOverride !== label) return;
      window.__munibinSurahNavigatorOverride = null;
      window.__munibinQuranNavigationHighlight?.clear?.();
      ensureSurahHeader();
    };
    try {
      // Keep the existing direct navigation path and audio range unchanged.
      const result = await goPageThroughWorkingUI(destination);
      if (result.ok === false) clearFailedChoice();
    } catch (error) {
      clearFailedChoice();
      console.warn('[Munibin] Sura navigation failed', error);
    }
  }

  async function goJuz(juz, page){
    dismissSurahAfterJump();
    try {
      await goPageThroughWorkingUI(page);
    } catch (error) {
      console.warn('[Munibin] Juz navigation failed', error);
    }
  }

  function openSurahNavigator(){
    closeChoice();
    closeSurah();
    const overlay = document.createElement('div');
    overlay.className = 'munibin-surah-overlay munibin-quran-reader-menu';
    overlay.dir = 'rtl';
    overlay.innerHTML = `
      <div class="munibin-surah-backdrop"></div>
      <section class="munibin-surah-sheet" role="dialog" aria-modal="true" aria-label="السور والأجزاء">
        <header class="munibin-surah-head">
          <div class="munibin-surah-grip" aria-hidden="true"><span></span></div>
          <button type="button" class="munibin-surah-close munibin-quran-menu-close" aria-label="إغلاق">×</button>
          <div><strong>السور والأجزاء</strong><span>انتقل مباشرة في المصحف</span></div>
        </header>
        <label class="munibin-surah-search">${iconSearch()}<input type="search" placeholder="ابحث باسم سورة أو كلمات من القرآن" aria-label="البحث باسم سورة أو كلمات من القرآن" autocomplete="off" enterkeyhint="search"></label>
        <div class="munibin-surah-list"></div>
      </section>`;
    applyQuranThemeVars(overlay);
    overlay.dataset.munibinRelease = '157';
    document.body.appendChild(overlay);
    state.surahOverlay = overlay;
    const list = q('.munibin-surah-list', overlay);
    const search = q('.munibin-surah-search input', overlay);
    hardenSearchAgainstOpeningTap(search, overlay);
    const activeSurah = currentSurahNumber();
    const activePage = currentPage();
    const events = [
      ...SURAH.map(x => ({type:'surah', page:x.page, data:x, rank:1})),
      ...JUZ.map(x => ({type:'juz', page:x.page, data:x, rank:0})),
    ].sort((a,b) => a.page-b.page || a.rank-b.rank || (a.data.surah||0)-(b.data.surah||0));
    const render = () => {
      const needle = (search.value || '').trim().toLocaleLowerCase('ar');
      list.replaceChildren();
      if (needle) {
        const results = window.__munibinQuranNavigationBridge?.searchQuran?.(needle);
        const heading = title => {
          const h=document.createElement('h3');h.className='munibin-surah-search-heading';h.textContent=title;list.appendChild(h);
        };
        if (results?.surahs?.length) {
          heading('نتائج السور');
          for (const s of results.surahs) list.appendChild(makeSurah(s, activeSurah));
        }
        if (results?.verses?.length) {
          heading('نتائج كلمات القرآن');
          for (const verse of results.verses) {
            const button=document.createElement('button');
            button.type='button';button.className='munibin-quran-text-result';
            button.innerHTML=`<span>${esc(verse.text)}</span><small>${esc(verse.surahName)} · الآية ${arabicDigits(verse.ayah)}</small>`;
            button.addEventListener('pointerdown',()=>{window.__munibinQuranNavigationBridge?.preloadPage?.(verse.page);},{passive:true});
            button.addEventListener('click',()=>{
              dismissSurahAfterJump();
              void window.__munibinQuranNavigationBridge?.goVerse?.(verse);
            });
            list.appendChild(button);
          }
        }
        if (!results?.surahs?.length && !results?.verses?.length) {
          const e=document.createElement('div');e.className='munibin-choice-empty';e.textContent=results?.ready?'لا توجد نتائج':'يُجهَّز فهرس البحث محلياً داخل التطبيق.';list.appendChild(e);
        }
        return;
      }
      for (const ev of events) list.appendChild(ev.type==='juz' ? makeJuz(ev.data, activePage) : makeSurah(ev.data, activeSurah));
      requestAnimationFrame(() => (list.querySelector('.munibin-surah-row.is-current') || list.querySelector('.munibin-juz-row.is-current') || list.querySelector('.is-current'))?.scrollIntoView({block:'center'}));
    };
    function makeJuz(j, activePageValue){
      const b=document.createElement('button');
      b.type='button';
      b.className='munibin-juz-row';
      if (activePageValue && activePageValue >= j.page && (j.juz===30 || activePageValue < JUZ[j.juz]?.page)) b.classList.add('is-current');
      const surahName=SURAH.find(s=>s.surah===j.surah)?.name || `سورة ${j.surah}`;
      b.innerHTML=`<span class="munibin-juz-copy"><strong>الجزء ${j.juz}</strong><small>${esc(surahName)} · الآية ${j.ayah}</small></span>`;
      b.addEventListener('pointerdown',()=>{ try { window.__munibinQuranNavigationBridge?.preloadPage?.(j.page); } catch {} }, {passive:true});
      b.addEventListener('click',()=>void goJuz(j.juz,j.page));
      return b;
    }
    function makeSurah(s, active){
      const b=document.createElement('button');
      b.type='button';
      b.className='munibin-surah-row';
      if(s.surah===active) b.classList.add('is-current');
      b.innerHTML=`<span class="munibin-surah-number">${s.surah}</span><span class="munibin-surah-name"><strong>${esc(s.name)}</strong><small>${s.ayahCount} آية · صفحة ${s.page}</small></span>`;
      b.addEventListener('pointerdown',()=>{ try { window.__munibinQuranNavigationBridge?.preloadPage?.(s.page); } catch {} }, {passive:true});
      b.addEventListener('click',()=>void goSurah(s.surah,s.page));
      return b;
    }
    render();
    let searchTimer=0;
    search.addEventListener('input',()=>{
      clearTimeout(searchTimer);
      searchTimer=setTimeout(()=>{if(overlay.isConnected){list.scrollTop=0;render();}},120);
    });
    q('.munibin-surah-backdrop',overlay).addEventListener('click',closeSurah);
    q('.munibin-surah-close',overlay).addEventListener('click',closeSurah);
    const sheet=q('.munibin-surah-sheet',overlay),head=q('.munibin-surah-head',overlay);
    let swipe=null;
    const resetSwipe=()=>{if(!sheet)return;sheet.style.removeProperty('transition');sheet.style.removeProperty('transform');overlay.style.removeProperty('opacity');};
    head?.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'&&e.button!==0)return;if(e.target.closest('button,input'))return;swipe={id:e.pointerId,y:e.clientY,t:performance.now(),dy:0};try{head.setPointerCapture(e.pointerId);}catch{}if(sheet)sheet.style.transition='none';},{passive:true});
    head?.addEventListener('pointermove',e=>{if(!swipe||e.pointerId!==swipe.id||!sheet)return;const dy=Math.max(0,e.clientY-swipe.y);swipe.dy=dy;if(dy>0){sheet.style.transform=`translateY(${dy}px)`;overlay.style.opacity=String(Math.max(.35,1-dy/320));}},{passive:true});
    const endSwipe=e=>{if(!swipe||e.pointerId!==swipe.id)return;const dy=swipe.dy,dt=Math.max(1,performance.now()-swipe.t),velocity=dy/dt;swipe=null;try{head.releasePointerCapture(e.pointerId);}catch{}if(dy>=72||velocity>.65){if(sheet){sheet.style.transition='transform .18s ease';sheet.style.transform='translateY(110%)';}overlay.style.transition='opacity .18s ease';overlay.style.opacity='0';setTimeout(closeSurah,180);}else resetSwipe();};
    head?.addEventListener('pointerup',endSwipe,{passive:true});head?.addEventListener('pointercancel',endSwipe,{passive:true});
    requestAnimationFrame(()=>overlay.classList.add('is-open'));
  }

  function ensureVerseActionIcons(){
    // React owns the children of these buttons. Never insert or delete child nodes here.
    qa('.qcf1441-verse-action-buttons button').forEach((button) => {
      const label = (button.textContent || '').replace(/\s+/g, ' ').trim();
      // The verse menu owns all four actions. Preserve them across status-label
      // changes so the icon CSS and bookmark insertion still identify Copy.
      const owned = button.dataset.action;
      const action = ['listen','tafsir','bookmark','copy'].includes(owned) ? owned :
        (/استماع/.test(label) ? 'listen' : (/تفسير/.test(label) ? 'tafsir' :
        (/نسخ/.test(label) ? 'copy' : (/علامة/.test(label) ? 'bookmark' : ''))));
      if (action) button.dataset.action = action;
    });
  }

  function openBigAudioMenu(){
    const launch = q('.qcf1441-audio-footer-launch');
    if (launch) { launch.click(); return true; }
    const bridge = window.__munibinQuranNavigationBridge;
    if (typeof bridge?.openAudio === 'function') {
      try { bridge.openAudio(); return true; } catch {}
    }
    return false;
  }

  function syncAudioProgress(){
    qa('.qcf1441-background-player').forEach((player) => {
      const range = q('input[type="range"]', player);
      if (!range) {
        player.style.setProperty('--munibin-audio-progress','0%');
        return;
      }
      const min = Number(range.min || 0);
      const max = Number(range.max || 100);
      const value = Number(range.value || min);
      const pct = max > min ? Math.max(0, Math.min(100, ((value - min) / (max - min)) * 100)) : 0;
      player.style.setProperty('--munibin-audio-progress', `${pct}%`);
    });
  }

  function enhanceAudioFooter(){
    const panel = q('.qcf1441-reciter-panel[aria-label="الاستماع إلى تلاوة القرآن"]');
    const downloads = q('.qcf1441-reciter-download-manager-panel[aria-label="تنزيلات تلاوات القرآن"]');

    // v173: Start Listening is React-owned and rendered in its own fixed band
    // between the audio sheet and the physical Quran footer. Remove any legacy
    // injected footer elements from older cached UI generations if present.
    qa('.munibin-audio-footer-start,.munibin-audio-sheet-footer').forEach((node) => node.remove());

    qa('.qcf1441-background-player').forEach((player) => {
      q('.munibin-audio-footer-open-zone', player)?.remove();
      const active = !!q('input[type="range"]', player);
      player.classList.toggle('munibin-audio-active', active);
      player.classList.toggle('munibin-audio-menu-open', !!panel);
      player.classList.toggle('munibin-download-menu-open', !!downloads);
      player.dataset.munibinFooterEnhanced = '176';

      const idleLaunch = q('.qcf1441-audio-footer-launch', player);
      if (idleLaunch) idleLaunch.classList.add('munibin-audio-footer-launch-play-only');

      q('.munibin-audio-menu-opener-proxy', player)?.remove();
    });
    syncAudioProgress();
  }

  function selectedReciterName(){
    const select = q('.qcf1441-reciter-panel select') || q('select[aria-label*="قارئ"], select[aria-label*="القارئ"]');
    if (select?.options?.length) {
      const option = select.options[select.selectedIndex] || [...select.options].find((opt) => opt.value === select.value);
      const label = (option?.textContent || '').replace(/\s+/g, ' ').trim();
      if (label) return label;
    }
    const fallback = qa('button,span,div').map((el) => (el.textContent || '').replace(/\s+/g, ' ').trim()).find((txt) => /^(القارئ|الشيخ)\s+/.test(txt));
    return fallback || 'تلاوة القرآن الكريم';
  }

  function publishNativeNowPlaying(payload){
    try {
      const ios = window.webkit?.messageHandlers?.['munibin-now-playing'];
      if (ios) ios.postMessage(payload);
    } catch {}
    try {
      if (window.MunibinAndroid?.publishNowPlaying) window.MunibinAndroid.publishNowPlaying(JSON.stringify(payload));
    } catch {}
  }

  function syncMediaSession(){
    try {
      const audio = window.__munibinQuranPlaylistBridge?.getState?.();
      const track = audio?.track;
      if (!track?.matnId?.startsWith?.('quran-reciter-')) {
        publishNativeNowPlaying({state:'stopped'});
        return;
      }
      const verseKey = audio.activeParaId || track.paraId || window.__munibinPlaylistVerseKey || '';
      const surahNumber = Number(String(verseKey).split(':')[0]);
      const title = SURAH.find(s => s.surah === surahNumber)?.name || 'القرآن الكريم';
      const artist = String(track.matnTitle || selectedReciterName() || 'القارئ').trim() || 'القارئ';
      const state = (audio.playing || audio.loading) ? 'playing' : (audio.paused ? 'paused' : 'stopped');
      const payload = { title, artist, album:'القرآن الكريم', state, verseKey };
      publishNativeNowPlaying(payload);
      if (!('mediaSession' in navigator) || typeof MediaMetadata === 'undefined') return;
      const key = `${title}__${artist}__${verseKey}`;
      if (document.body.dataset.munibinMediaSessionKey !== key) {
        document.body.dataset.munibinMediaSessionKey = key;
        navigator.mediaSession.metadata = new MediaMetadata({
          title, artist, album:'القرآن الكريم',
          artwork:[
            { src:'/icon-192.png', sizes:'192x192', type:'image/png' },
            { src:'/icon-512.png', sizes:'512x512', type:'image/png' }
          ]
        });
      }
      try { navigator.mediaSession.playbackState = state === 'playing' ? 'playing' : (state === 'paused' ? 'paused' : 'none'); } catch {}
    } catch {}
  }

  function fitSurahContextName(button){
    const name=q('.munibin-quran-context-name',button);if(!name||name.dataset.munibinFitScheduled==='1')return;name.dataset.munibinFitScheduled='1';
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      if(!name.isConnected){delete name.dataset.munibinFitScheduled;return;}
      const width=Math.round(button.getBoundingClientRect().width||0),key=`${name.textContent||''}:${width}`;
      if(name.dataset.munibinFitKey!==key){name.style.removeProperty('font-size');name.style.removeProperty('max-width');name.dataset.munibinFitKey=key;}
      const buttonStyle=getComputedStyle(button),padL=parseFloat(buttonStyle.paddingLeft)||0,padR=parseFloat(buttonStyle.paddingRight)||0,gap=parseFloat(buttonStyle.columnGap||buttonStyle.gap)||0;
      const siblings=[...button.children].filter(el=>el!==name),reserved=siblings.reduce((sum,el)=>sum+(el.getBoundingClientRect().width||0),0)+gap*Math.max(0,button.children.length-1);
      const available=Math.max(26,Math.floor(button.clientWidth-padL-padR-reserved));
      name.style.setProperty('max-width',`${available}px`,'important');
      name.style.removeProperty('font-size');
      const base=parseFloat(getComputedStyle(name).fontSize)||17,natural=Math.max(name.scrollWidth,1);
      if(natural>available+1){
        let size=Math.max(7.25,Math.min(base,base*(available/natural)*.97));
        name.style.setProperty('font-size',`${size.toFixed(2)}px`,'important');
        while(size>7.25&&name.scrollWidth>name.clientWidth+1){size=Math.max(7.25,size-.35);name.style.setProperty('font-size',`${size.toFixed(2)}px`,'important');}
      }
      delete name.dataset.munibinFitScheduled;
    }));
    if(document.fonts?.ready&&!name.dataset.munibinFontRefit){name.dataset.munibinFontRefit='1';document.fonts.ready.then(()=>{if(name.isConnected){name.dataset.munibinFitKey='';fitSurahContextName(button);}}).catch(()=>{});}
  }
  function ensureSurahHeader(){
    const header = q('.qcf1441-preview-header');
    if (!header) return;
    const info = normalizePageContext();
    const reactName = reactSurahName();
    const pageSurah = surahForPage(info.page);
    const selected = selectedSurahForPage(info.page);
    const cleanName = selected?.name || reactName || pageSurah?.name || 'السورة';
    let button = q('.munibin-quran-context-button', header);
    if (!button) {
      button = document.createElement('button');
      button.type = 'button';
      button.className = 'munibin-quran-context-button';
      button.setAttribute('aria-label', 'اختيار سورة أو جزء');
      button.addEventListener('click', openSurahNavigator);
      header.appendChild(button);
    }
    const pageText = info.page ? `ص ${info.page}` : '';
    const juzText = info.juz ? `ج ${info.juz}` : '';
    const hizbText = info.hizb ? `ح ${info.hizb}` : '';
    const renderKey = `${cleanName}__${pageText}__${juzText}__${hizbText}`;
    if (button.dataset.munibinRenderKey !== renderKey) {
      button.dataset.munibinRenderKey = renderKey;
      button.innerHTML = `
        <span class="munibin-quran-context-name">${esc(cleanName)}</span>
        ${pageText ? `<span class="munibin-quran-context-stat is-page">${pageText}</span>` : ''}
        ${juzText ? `<span class="munibin-quran-context-stat">${juzText}</span>` : ''}
        ${hizbText ? `<span class="munibin-quran-context-stat">${hizbText}</span>` : ''}
        <span class="munibin-quran-context-caret" aria-hidden="true">${iconChevron()}</span>`;
    }
    fitSurahContextName(button);
  }



  function installAdhkarCountHintStyle(){
    const styleId = 'munibin-adhkar-count-hint-v183';
    if (document.getElementById(styleId)) return;
    const style = document.createElement('style');
    style.id = styleId;
    style.textContent = `
      [data-loc="client/src/pages/AdhkarPage.tsx:262"] > span:last-child {
        color: inherit !important;
        font-size: 11px !important;
        font-weight: 500 !important;
        line-height: 1.2 !important;
        opacity: 0.78 !important;
        white-space: nowrap;
      }
      [data-loc="client/src/pages/AdhkarPage.tsx:262"] > span:last-child::after {
        content: "←";
        display: inline-block;
        margin-right: 0.22rem;
        font-size: 11px;
        font-weight: 600;
        line-height: 1;
        vertical-align: 0;
      }
    `;
    document.head.appendChild(style);
  }

  function refresh(){
    enhanceTargetSelects();
    ensureVerseActionIcons();
    enhanceAudioFooter();
    ensureSurahHeader();
    syncMediaSession();
  }

  // Color controls only repaint their own preview/CSS. Their DOM changes do
  // not require rescanning Quran words, sura geometry, bookmarks or audio.
  function isOutsideQuranColorSettings(record){
    const inside=node=>{const element=node?.nodeType===1?node:node?.parentElement;return !!element?.closest?.('.munibin-quran-color-setting, .munibin-quran-color-backdrop');};
    if(inside(record.target))return false;
    if(record.type==='childList'){
      const nodes=[...record.addedNodes,...record.removedNodes];
      if(nodes.length&&nodes.every(inside))return false;
    }
    return true;
  }
  const observer = new MutationObserver(records => {if(records.some(isOutsideQuranColorSettings))refresh();});
  function start(){
    window.__munibinUiPatchVersion = 'v183';
    document.documentElement.dataset.munibinUiPatch = 'v183';
    installChoiceGuard();
    installAdhkarCountHintStyle();
    window.__munibinQuranWorkingNavigator = { goPage: goPageThroughWorkingUI, debugState: () => window.__munibinQuranNavigationBridge?.debugState?.() };
    refresh();
    observer.observe(document.body,{childList:true,subtree:true,characterData:true});
    window.setInterval(syncMediaSession, 1200);
    window.addEventListener('munibin-quran-audio-state', syncMediaSession);
    window.setInterval(syncAudioProgress, 120);
    document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeChoice();closeSurah();}});
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start,{once:true}); else start();
})();

/* v264: smooth Quran exits using a background-only shell. */
(()=>{
  if(window.__munibinQuranSheetExitV264)return;
  window.__munibinQuranSheetExitV264=true;

  const SELECTOR='.qcf1441-navigator';
  const snapshots=new WeakMap();
  let gesture=null;

  const remember=(node)=>{
    if(!(node instanceof HTMLElement)||!node.matches(SELECTOR)||node.dataset.munibinExitShell==='1')return;
    const r=node.getBoundingClientRect();
    if(r.width<20||r.height<20)return;

    // Only animate the panel shell. Never clone fields, labels, selects or
    // buttons: WKWebView/browser-native controls can otherwise outlive the
    // detached snapshot for a frame and appear to hang in the air.
    const cs=getComputedStyle(node);
    const shell=document.createElement('div');
    shell.dataset.munibinExitShell='1';
    shell.setAttribute('aria-hidden','true');
    Object.assign(shell.style,{
      background:cs.background,
      backgroundColor:cs.backgroundColor,
      backgroundImage:cs.backgroundImage,
      backgroundPosition:cs.backgroundPosition,
      backgroundSize:cs.backgroundSize,
      backgroundRepeat:cs.backgroundRepeat,
      border:cs.border,
      borderRadius:cs.borderRadius,
      boxShadow:cs.boxShadow,
      outline:cs.outline,
      overflow:'hidden'
    });
    snapshots.set(node,{rect:{left:r.left,top:r.top,width:r.width,height:r.height},shell});
  };

  const rememberVisible=()=>document.querySelectorAll(SELECTOR).forEach(remember);

  const animateRemoved=(node)=>{
    if(!(node instanceof HTMLElement)||node.dataset.munibinExitShell==='1')return;
    const snap=snapshots.get(node);
    if(!snap)return;
    if(gesture?.dragging&&gesture?.inside===node)return;
    const {rect,shell}=snap;
    Object.assign(shell.style,{
      position:'fixed',left:rect.left+'px',top:rect.top+'px',width:rect.width+'px',height:rect.height+'px',
      margin:'0',boxSizing:'border-box',zIndex:'2147483000',pointerEvents:'none',
      transform:'translate3d(0,0,0)',opacity:'1',willChange:'transform,opacity',
      transition:'transform 155ms cubic-bezier(.32,.72,0,1), opacity 145ms ease-out'
    });
    document.body.appendChild(shell);
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      shell.style.transform='translate3d(0,26px,0)';
      shell.style.opacity='0';
    }));
    setTimeout(()=>shell.remove(),195);
  };

  document.addEventListener('pointerdown',e=>{
    rememberVisible();
    const panel=e.target instanceof Element?e.target.closest(SELECTOR):null;
    gesture={y:e.clientY,inside:panel instanceof HTMLElement?panel:null,dragging:false};
  },true);
  document.addEventListener('pointermove',e=>{
    if(!gesture||!gesture.inside)return;
    if(Math.abs(e.clientY-gesture.y)>14)gesture.dragging=true;
  },true);
  const clearGesture=()=>setTimeout(()=>{gesture=null},220);
  document.addEventListener('pointerup',clearGesture,true);
  document.addEventListener('pointercancel',clearGesture,true);
  document.addEventListener('keydown',e=>{if(e.key==='Escape')rememberVisible()},true);

  const observer=new MutationObserver(records=>{
    for(const rec of records){
      for(const node of rec.addedNodes){
        if(!(node instanceof HTMLElement))continue;
        if(node.matches?.(SELECTOR))requestAnimationFrame(()=>remember(node));
        node.querySelectorAll?.(SELECTOR).forEach(el=>requestAnimationFrame(()=>remember(el)));
      }
      for(const node of rec.removedNodes){
        if(!(node instanceof HTMLElement))continue;
        if(node.matches?.(SELECTOR))animateRemoved(node);
        node.querySelectorAll?.(SELECTOR).forEach(animateRemoved);
      }
    }
  });

  const start=()=>{
    rememberVisible();
    observer.observe(document.documentElement,{childList:true,subtree:true});
  };
  if(document.documentElement)start();else document.addEventListener('DOMContentLoaded',start,{once:true});
})();
