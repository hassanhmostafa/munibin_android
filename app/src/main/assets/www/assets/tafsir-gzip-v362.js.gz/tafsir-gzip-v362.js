/* A small bounded gzip reader for WebViews without DecompressionStream. */
const LENGTH_BASE=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258];
const LENGTH_EXTRA=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0];
const DIST_BASE=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577];
const DIST_EXTRA=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];
// RFC 1951 code-length order, written explicitly to avoid index assumptions.
const CODE_LENGTH_ORDER=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];
const crcTable=Uint32Array.from({length:256},(_,n)=>{for(let i=0;i<8;i++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0});
export function gzipCrc32(bytes){let crc=0xffffffff;for(const byte of bytes)crc=crcTable[(crc^byte)&255]^(crc>>>8);return (crc^0xffffffff)>>>0}
function huffman(lengths){
 const maximum=Math.max(...lengths);
 if(maximum>15)throw new Error('Invalid Huffman table');
 if(maximum===0)return {table:new Uint32Array(1),maximum:1};
 const counts=new Uint16Array(maximum+1),next=new Uint16Array(maximum+1);
 for(const length of lengths)if(length)counts[length]++;
 let code=0,remaining=1;
 for(let bits=1;bits<=maximum;bits++){
  remaining=(remaining<<1)-counts[bits];if(remaining<0)throw new Error('Oversubscribed Huffman table');
  code=(code+(counts[bits-1]||0))<<1;next[bits]=code;
 }
 const table=new Uint32Array(1<<maximum);
 for(let symbol=0;symbol<lengths.length;symbol++){
  const length=lengths[symbol];if(!length)continue;
  let value=next[length]++,reversed=0;
  for(let bit=0;bit<length;bit++){reversed=(reversed<<1)|(value&1);value>>>=1}
  for(let slot=reversed;slot<table.length;slot+=1<<length)table[slot]=(length<<16)|(symbol+1);
 }
 return {table,maximum};
}
let fixed;
function fixedTables(){
 if(!fixed){const lengths=Array.from({length:288},(_,n)=>n<144?8:n<256?9:n<280?7:8);fixed=[huffman(lengths),huffman(Array(32).fill(5))]}
 return fixed;
}
export function inflateGzipFallback(input,limit=64*1024*1024){
 const bytes=input instanceof Uint8Array?input:new Uint8Array(input);
 if(bytes.length<18||bytes[0]!==31||bytes[1]!==139||bytes[2]!==8||bytes[3]&224)throw new Error('Invalid gzip header');
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),end=bytes.length-8;
 const size=view.getUint32(bytes.length-4,true);
 if(size>limit)throw new Error('Gzip output exceeds limit');
 let position=10;
 if(bytes[3]&4){if(position+2>end)throw new Error('Truncated gzip header');const extra=view.getUint16(position,true);position+=2+extra}
 for(const flag of [8,16])if(bytes[3]&flag){while(position<end&&bytes[position++]!==0){} }
 if(bytes[3]&2)position+=2;
 if(position>end)throw new Error('Truncated gzip header');
 const output=new Uint8Array(size);let count=0,buffer=0,bits=0;
 const fill=n=>{while(bits<n&&position<end){buffer|=bytes[position++]<<bits;bits+=8}};
 const read=n=>{if(!n)return 0;fill(n);if(bits<n)throw new Error('Truncated deflate stream');const value=buffer&((1<<n)-1);buffer>>>=n;bits-=n;return value};
 const symbol=tree=>{fill(tree.maximum);const entry=tree.table[buffer&((1<<tree.maximum)-1)];const length=entry>>>16;if(!entry||length>bits)throw new Error('Invalid deflate symbol');buffer>>>=length;bits-=length;return (entry&65535)-1};
 let final=0;
 do{
  final=read(1);const type=read(2);
  if(type===0){
   const discard=bits%8;buffer>>>=discard;bits-=discard;
   const length=read(16),inverse=read(16);
   if((length^65535)!==inverse||count+length>size)throw new Error('Invalid stored block');
   for(let i=0;i<length;i++)output[count++]=read(8);
   continue;
  }
  if(type===3)throw new Error('Invalid deflate block');
  let literals,distances;
  if(type===1)[literals,distances]=fixedTables();
  else{
   const literalCount=read(5)+257,distanceCount=read(5)+1,codeCount=read(4)+4;
   const codeLengths=Array(19).fill(0);
   for(let i=0;i<codeCount;i++)codeLengths[CODE_LENGTH_ORDER[i]]=read(3);
   const codes=huffman(codeLengths),lengths=[];
   while(lengths.length<literalCount+distanceCount){
    const value=symbol(codes);
    if(value<16)lengths.push(value);
    else{
     if(value===16&&!lengths.length)throw new Error('Invalid code repetition');
     const repeat=value===16?read(2)+3:value===17?read(3)+3:read(7)+11;
     const length=value===16?lengths[lengths.length-1]:0;
     if(lengths.length+repeat>literalCount+distanceCount)throw new Error('Invalid code count');
     for(let i=0;i<repeat;i++)lengths.push(length);
    }
   }
   if(!lengths[256])throw new Error('Missing end code');
   literals=huffman(lengths.slice(0,literalCount));distances=huffman(lengths.slice(literalCount));
  }
  for(;;){
   const value=symbol(literals);
   if(value===256)break;
   if(value<256){if(count>=size)throw new Error('Gzip output exceeds size');output[count++]=value;continue}
   const index=value-257;if(index<0||index>=LENGTH_BASE.length)throw new Error('Invalid deflate length');
   const length=LENGTH_BASE[index]+read(LENGTH_EXTRA[index]),distanceCode=symbol(distances);
   if(distanceCode>=DIST_BASE.length)throw new Error('Invalid deflate distance');
   const distance=DIST_BASE[distanceCode]+read(DIST_EXTRA[distanceCode]);
   if(distance>count||count+length>size)throw new Error('Invalid deflate copy');
   for(let i=0;i<length;i++){output[count]=output[count-distance];count++}
  }
 }while(!final);
 if(position-Math.floor(bits/8)!==end||count!==size||gzipCrc32(output)!==view.getUint32(bytes.length-8,true))throw new Error('Gzip integrity check failed');
 return output;
}
export async function inflateTafsirSurah(input,expectedSize){
 const bytes=input instanceof Uint8Array?input:new Uint8Array(input);
 if(!Number.isSafeInteger(expectedSize)||expectedSize<0||expectedSize>64*1024*1024)throw new Error('Invalid surah size');
 if(bytes.length<18||new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength).getUint32(bytes.length-4,true)!==expectedSize)throw new Error('Surah size mismatch');
 let raw;
 if(typeof DecompressionStream==='function'){
  const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
  const reader=stream.getReader(),chunks=[];let total=0;
  try{for(;;){const {done,value}=await reader.read();if(done)break;total+=value.byteLength;if(total>expectedSize)throw new Error('Surah exceeds expected size');chunks.push(value)}}
  catch(error){await reader.cancel().catch(()=>{});throw error}finally{reader.releaseLock()}
  raw=new Uint8Array(total);let offset=0;for(const chunk of chunks){raw.set(chunk,offset);offset+=chunk.length}
 }else raw=inflateGzipFallback(bytes,expectedSize);
 if(raw.byteLength!==expectedSize)throw new Error('Incomplete surah');
 return raw;
}
