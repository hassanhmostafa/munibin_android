/* Ayah reading uses the existing QCF glyphs and exact bundled font advances.
 * A complete verse owns one toolbar and one stable document slot. Page-based
 * audio, navigation, bookmarks and memorization retain their source identities.
 * Only the nearby ink is mounted; scrolling never fetches or inserts verses. */
import {QCF_READING_METRICS} from './quran-reading-metrics-v361.js';
import {loadQuranDocument} from './quran-document-resources-v387.js';

const readable=word=>!!word.verse_key&&(word.type==='word'||word.type==='end');
export const normalizeReadingDirection=value=>value==='vertical'||value==='ayah'?value:'horizontal';

export function buildQuranAyahs(pages) {
 const ayahs=[],byVerse=new Map(),pageIndex=new Map();let pending=[];
 for(const page of pages) {
  let glyphIndex=0,memIndex=-1;
  const widths=QCF_READING_METRICS[page.page]?.[0]?.[2]||[];
  for(const line of page.lines)for(const source of line.words) {
   if(readable(source))memIndex++;
   const word={...source,font:source.font||page.font,munibinSourcePage:page,munibinOriginalWord:source,
    munibinMemIndex:readable(source)?memIndex:null,munibinAdvance:Math.max(.01,Number(widths[glyphIndex++])||.01)};
   if(word.type==='surah_header'||word.type==='bismillah'){pending.push(word);continue}
   if(!word.verse_key){pending.push(word);continue}
   let item=byVerse.get(word.verse_key);
   if(!item){item={verse:word.verse_key,page:page.page,font:page.font,words:[],headings:pending,pages:[],surahs:page.surahs};pending=[];byVerse.set(item.verse,item);ayahs.push(item)}
   if(pending.length){item.words.push(...pending);pending=[]}
   item.words.push(word);
   if(!item.pages.includes(page.page))item.pages.push(page.page);
   if(!pageIndex.has(page.page))pageIndex.set(page.page,ayahs.length-1);
  }
 }
 return {ayahs,byVerse,pageIndex};
}

export function layoutQuranAyah(item,width,scale=1,top=0) {
 const available=Math.max(1,Number(width)||390)-24;
 const base=Math.min(36.5,Math.max(23.2,(Number(width)||390)*.065));
 const size=base*Math.max(1,Math.min(2.4,Number(scale)||1)),gap=size*.16;

  const lines=[];let row=[],advance=0,leading=0;
  const finish=()=>{if(!row.length)return;lines.push({line:lines.length+1,words:row,munibinAyahGap:gap,munibinAyahHeight:Math.ceil(leading*100)/100});row=[];advance=0;leading=0};
  for(const source of item.headings){finish();const word={...source,munibinAyahSize:Math.min(size,38,Math.max(1,available-36)/source.munibinAdvance)};
   const height=source.type==='surah_header'?Math.max(44,size*1.65):Math.ceil(word.munibinAyahSize*2.35);
   lines.push({line:lines.length+1,words:[word],munibinAyahHeight:height});
  }
  for(const source of item.words){
   const wordSize=Math.min(size,Math.max(1,available-6)/source.munibinAdvance);
   const wordAdvance=source.munibinAdvance*wordSize;
   if(row.length&&advance+gap+wordAdvance>available-.5)finish();
   const word={...source,munibinAyahSize:wordSize};
   advance+=(row.length?gap:0)+wordAdvance;row.push(word);
   leading=Math.max(leading,wordSize*((QCF_READING_METRICS[source.munibinSourcePage.page]?.[0]?.[0]||2.3)+.12));
  }
  finish();
  const height=lines.reduce((sum,line)=>sum+line.munibinAyahHeight,0)+70;
  const result={item,top,height,ink:{page:item.page,font:item.font,surahs:item.surahs,
   munibinAyahPages:item.pages,munibinAyahVerse:item.verse,lines}};
  return result;
}

export function layoutQuranAyahs(document,width,scale=1) {
 let top=0;return document.ayahs.map(item=>{const layout=layoutQuranAyah(item,width,scale,top);top+=layout.height;return layout});
}

export function ayahAtOffset(layouts,offset) {
 let low=0,high=layouts.length-1;
 while(low<high){const mid=(low+high+1)>>1;if(layouts[mid].top<=offset)low=mid;else high=mid-1}
 return Math.max(0,low);
}

export async function copyQuranVerse(text) {
 if(typeof text!=='string'||!text.trim())throw new Error('تعذر نسخ الآية. حاول مرة أخرى.');
 if(navigator.clipboard?.writeText)try{await navigator.clipboard.writeText(text);return true}catch{}
 const focus=document.activeElement,field=document.createElement('textarea');field.value=text;
 Object.assign(field.style,{position:'fixed',left:'-10000px',top:'0',opacity:'0'});
 field.setAttribute('readonly','');document.body.append(field);
 try{field.focus({preventScroll:true});field.select();if(!document.execCommand('copy'))throw new Error('تعذر نسخ الآية. حاول مرة أخرى.');return true}
 finally{field.remove();focus?.focus?.({preventScroll:true})}
}

// One short, interruptible animation per verse transition. Word ticks never
// restart it; a real reading gesture cancels only the current transition.
export function createAyahScrollMotion({root,layouts,onPosition,onEnd,
 raf=requestAnimationFrame,caf=cancelAnimationFrame,now=()=>performance.now(),
 reducedMotion=()=>window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches}) {
 let frame=0,generation=0,moving=false;
 const cancel=()=>{generation++;if(frame)caf(frame);frame=0;moving=false};
 const move=(index,animate=true)=>{
  const el=root(),items=layouts(),item=items[index];if(!el||!item)return false;
  cancel();const token=generation,from=Number(el.scrollTop)||0;
  const extent=Number(el.scrollHeight)-Number(el.clientHeight);
  const to=Math.max(0,Math.min(item.top,Number.isFinite(extent)?Math.max(0,extent):item.top));
  const finish=()=>{if(token!==generation)return;frame=0;moving=false;el.scrollTop=to;onPosition?.(index);onEnd?.()};
  if(!animate||reducedMotion()||Math.abs(to-from)<1){finish();return true}
  const viewport=Math.max(1,Number(el.clientHeight)||844),distance=Math.abs(to-from);
  const duration=Math.min(420,Math.max(260,260+Math.min(1,distance/viewport)*160));let start=null;
  moving=true;
  const step=time=>{if(token!==generation)return;
   if(start===null)start=time;
   const progress=Math.min(1,Math.max(0,(time-start)/duration));
   const eased=1-Math.pow(1-progress,3);el.scrollTop=from+(to-from)*eased;
   onPosition?.(ayahAtOffset(layouts(),Math.max(0,el.scrollTop)));
   if(progress<1)frame=raf(step);else finish();
  };frame=raf(step);return true;
 };
 return {move,cancel,get moving(){return moving}};
}

export function createAyahDocumentPages(React,{normalize,finishMotion,syncHighlights}) {
 const h=React.createElement;
 const ICONS={copy:['M9 9h11v11H9z','M15 5V3H3v12h2'],listen:['m8 5 11 7-11 7z'],tafsir:['M3 4c4-1 6 0 9 2v15c-3-2-5-3-9-2z','M21 4c-4-1-6 0-9 2v15c3-2 5-3 9-2z'],bookmark:['M6 3h12v18l-6-4-6 4z']};
 const LABELS={copy:'نسخ الآية',listen:'الاستماع إلى الآية',tafsir:'تفسير الآية',bookmark:'إضافة علامة للآية'};
 function Toolbar({verse,onAction}) {
  const [status,setStatus]=React.useState(''),timer=React.useRef(0),alive=React.useRef(true);
  React.useEffect(()=>()=>{alive.current=false;clearTimeout(timer.current)},[]);
  const act=async action=>{try{await onAction(verse,action==='listen'?'listen-single':action);if(action==='copy'&&alive.current){setStatus('تم نسخ الآية');clearTimeout(timer.current);timer.current=setTimeout(()=>setStatus(''),1800)}}catch(error){if(alive.current)setStatus(error?.message||'تعذر تنفيذ الخيار')}};
  const actionPointer=event=>{window.__munibinQuranNavigationBridge?.cancelGesture?.();event.stopPropagation()};
  return h('div',{className:'munibin-quran-ayah-toolbar',role:'group','aria-label':`خيارات الآية ${verse}`},
   ...['copy','listen','tafsir','bookmark'].map(action=>h('button',{key:action,type:'button','data-action':action,
    'aria-label':`${LABELS[action]} ${verse}`,title:LABELS[action],onPointerDown:actionPointer,onPointerUp:actionPointer,
    onClick:event=>{event.stopPropagation();void act(action)}},
    h('svg',{viewBox:'0 0 24 24',fill:action==='listen'?'currentColor':'none',stroke:'currentColor',strokeWidth:1.7,strokeLinecap:'round',strokeLinejoin:'round','aria-hidden':true},...ICONS[action].map(d=>h('path',{key:d,d}))))),
   h('span',{className:'munibin-quran-ayah-status',role:'status','aria-live':'polite'},status));
 }
 const Ayah=React.memo(function Ayah({layout,live,ready,render,actions,paint}){
  return h('article',{className:'munibin-quran-ayah','data-ayah-key':layout.item.verse,
   'data-scroll-page':layout.item.page,style:{height:`${layout.height}px`}},live?h(React.Fragment,null,
    h(Toolbar,{verse:layout.item.verse,onAction:actions.current}),ready?render.current(layout.ink):h('div',{className:'munibin-quran-ayah-loading',role:'status'},'يجري تجهيز الآية…')):null);
 },(a,b)=>a.layout.item===b.layout.item&&a.layout.height===b.layout.height&&a.layout.ink===b.layout.ink&&a.live===b.live&&a.ready===b.ready&&a.render===b.render&&a.actions===b.actions&&a.paint===b.paint);
 return function AyahPages({page,data,loadPage,renderPage,revision={},onVisiblePage,onDocumentReady,onVerseAction}) {
  const [document,setDocument]=React.useState(null),[error,setError]=React.useState(false),[width,setWidth]=React.useState(0),[center,setCenter]=React.useState(0),[fontRevision,setFontRevision]=React.useState(0),[preview,setPreview]=React.useState(null),[motionVersion,setMotionVersion]=React.useState(0);
  const root=React.useRef(null),pageProp=React.useRef(page),publishedPage=React.useRef(null),alive=React.useRef(true),render=React.useRef(renderPage),load=React.useRef(loadPage),report=React.useRef(onVisiblePage),onReady=React.useRef(onDocumentReady),actions=React.useRef(onVerseAction);
  const pages=React.useRef([]),geometry=React.useRef([]),reported=React.useRef(page),pending=React.useRef((()=>{const reading=window.__munibinQuranPendingAyahAnchor;if(reading?.word){delete window.__munibinQuranPendingAyahAnchor;return {page:Number(reading.page)||page,verse:reading.word.split(':').slice(0,2).join(':'),reading}}const target=window.__munibinQuranNavigationHighlight?.target?.();return target?.page===page?{page,verse:target.verseKey}:{page}})()),anchor=React.useRef(null),frame=React.useRef(0),fontTasks=React.useRef(new Map()),fontSet=React.useRef(new Set()),fontFailures=React.useRef(new Set()),navTimer=React.useRef(0),scrollMotion=React.useRef(null),motionWindow=React.useRef(null),pendingMotion=React.useRef(null),motionGeneration=React.useRef(0),followedVerse=React.useRef(null),preciseAnchor=React.useRef(null),pinchRange=React.useRef(null),liveRange=React.useRef({low:0,high:0});
  pageProp.current=page;render.current=renderPage;load.current=loadPage;report.current=onVisiblePage;onReady.current=onDocumentReady;actions.current=onVerseAction;
  const prefs=revision.prefs||{};
  const committed=React.useMemo(()=>document&&width?layoutQuranAyahs(document,width,prefs.scale):[],[document,width,prefs.scale]);
  // Rewrap only retained ink while fingers move. Distant slots keep their
  // committed height; shallow prefix offsets cost no font or glyph work.
  const draft=preview&&preview.baseScale===(Number(prefs.scale)||1)?preview:null;
  const layouts=React.useMemo(()=>{if(!draft)return committed;let top=0;return committed.map((layout,index)=>{
   const next=index>=draft.low&&index<=draft.high?layoutQuranAyah(layout.item,width,draft.scale,top):layout;
   const placed=next.top===top?next:{...next,top};top+=placed.height;return placed;
  })},[committed,width,draft]);
  if(geometry.current!==layouts&&root.current&&geometry.current.length&&!pending.current&&!anchor.current){
   const exact=preciseAnchor.current;
   if(exact?.word)anchor.current={verse:exact.word.split(':').slice(0,2).join(':'),offset:0};
   else {const previous=geometry.current[ayahAtOffset(geometry.current,Math.max(0,root.current.scrollTop))];if(previous)anchor.current={verse:previous.item.verse,offset:root.current.scrollTop-previous.top}}
  }
  geometry.current=layouts;
  const measuredWidth=React.useRef(0);measuredWidth.current=width;
  const padding=()=>parseFloat(getComputedStyle(root.current).paddingTop)||0;
  const position=()=>{const el=root.current;return !el||!geometry.current.length?0:ayahAtOffset(geometry.current,Math.max(0,el.scrollTop))};
  const capture=()=>{const el=root.current,index=position(),layout=geometry.current[index];return el&&layout?{verse:layout.item.verse,offset:el.scrollTop-layout.top}:null};
  const visiblePage=()=>{const el=root.current;if(!el||!geometry.current.length)return page;
   const bounds=el.getBoundingClientRect(),target=bounds.top+padding()+Math.min(80,el.clientHeight*.12);
   const words=Array.from(el.querySelectorAll('[data-reading-word]'));
   const word=words.find(node=>node.getBoundingClientRect().bottom>target);
   return Number(word?.dataset.sourcePage)||geometry.current[position()]?.item.page||page;
  };
  const flush=()=>{const number=visiblePage(),item=pages.current[number-1];if(item&&(number!==reported.current||(number!==pageProp.current&&number!==publishedPage.current))){reported.current=number;publishedPage.current=number;report.current?.(number,item)}return item||null};
  const measure=()=>{const el=root.current;if(!el)return;if(el.clientWidth!==measuredWidth.current){if(!anchor.current)anchor.current=capture();setWidth(el.clientWidth)}};
  const prepare=()=>{setError(false);loadQuranDocument(normalize).then(all=>{if(!alive.current)return;pages.current=all;onReady.current?.(all);setDocument(buildQuranAyahs(all))}).catch(()=>{if(alive.current)setError(true)})};
  React.useEffect(()=>{alive.current=true;prepare();return()=>{alive.current=false;cancelAnimationFrame(frame.current);clearTimeout(navTimer.current);scrollMotion.current?.cancel()}},[]);
  React.useLayoutEffect(()=>{measure();const observer=typeof ResizeObserver==='function'?new ResizeObserver(measure):null;observer?.observe(root.current);return()=>observer?.disconnect()},[]);
  React.useLayoutEffect(()=>{const el=root.current;if(!el||!layouts.length)return;
   scrollMotion.current?.cancel();motionWindow.current=null;pendingMotion.current=null;motionGeneration.current++;
   const target=pending.current,old=anchor.current;let index=0;
   if(target?.verse)index=layouts.findIndex(layout=>layout.item.verse===target.verse);
   else if(target?.page)index=document.pageIndex.get(target.page)??0;
   else if(old)index=layouts.findIndex(layout=>layout.item.verse===old.verse);
   else return;
   index=Math.max(0,index);if(target)reported.current=Number(target.page)||layouts[index].item.page;if(target?.reading)preciseAnchor.current=target.reading;el.scrollTop=layouts[index].top+(old&&!target?Math.min(Math.max(0,old.offset),Math.max(0,layouts[index].height-1)):0);setCenter(index);pending.current=null;anchor.current=null;
   finishMotion?.(el.closest('.qcf1441-preview'));
  },[layouts]);
  if(!scrollMotion.current)scrollMotion.current=createAyahScrollMotion({root:()=>root.current,layouts:()=>geometry.current,onEnd:()=>{
   motionWindow.current=null;if(alive.current){setCenter(position());flush()}
  }});
  const cancelMotion=()=>{motionGeneration.current++;pendingMotion.current=null;motionWindow.current=null;scrollMotion.current?.cancel()};
  const prepareMotionWindow=index=>{
   const el=root.current,items=geometry.current,viewport=el?.clientHeight||844;
   const range=offset=>({low:ayahAtOffset(items,Math.max(0,offset-viewport*1.5)),high:ayahAtOffset(items,offset+viewport*2.5)});
   const from=range(el?.scrollTop||0),to=range(items[index].top);
   const adjacent=Math.abs(index-position())<=1||Math.abs(items[index].item.page-items[position()].item.page)<=1;
   motionWindow.current=adjacent||from.low<=to.high+5&&to.low<=from.high+5?[{low:Math.min(from.low,to.low),high:Math.max(from.high,to.high)}]:[from,to];
   pendingMotion.current={index,generation:motionGeneration.current};setMotionVersion(value=>value+1);
  };
  const audioVerse=()=>revision.playing?revision.verse||revision.playlist:null;
  const jump=(number,verse,animate=false)=>{if(!document)return;if(!Number.isInteger(number)||number<1||number>604)return;
   if(!layouts.length||!root.current){pending.current={page:number,verse};return false}
   const index=verse?layouts.findIndex(layout=>layout.item.verse===verse):document.pageIndex.get(number)??0;
   if(index<0)return false;pending.current=null;anchor.current=null;preciseAnchor.current=null;reported.current=number;publishedPage.current=null;clearTimeout(navTimer.current);
   cancelMotion();if(animate){prepareMotionWindow(index);return true}
   return scrollMotion.current.move(index,false);
  };
  const jumpRef=React.useRef(jump);jumpRef.current=jump;
  React.useEffect(()=>{if(page!==reported.current){if(!document){const previous=pending.current,latest=window.__munibinQuranNavigationHighlight?.target?.();pending.current={page,verse:(previous?.page===page?previous.verse:undefined)||(latest?.page===page?latest.verseKey:undefined),reading:previous?.page===page?previous.reading:undefined}}else {
   const verse=audioVerse(),item=verse&&document.byVerse.get(verse);
   if(item&&item.page===page){if(jumpRef.current(page,verse,true))followedVerse.current=verse}
   else jumpRef.current(page);
  }}},[page,document]);
  React.useEffect(()=>{const verse=audioVerse();if(!verse){followedVerse.current=null;return}
   if(!document){pending.current={page,verse};return}
   if(verse===followedVerse.current)return;
   const item=document.byVerse.get(verse);if(item&&jumpRef.current(item.page,verse,true))followedVerse.current=verse;
  },[document,revision.verse,revision.playing,revision.playlist]);
  React.useLayoutEffect(()=>{const controller={root:root.current,captureAnchor:capture,measure,
   goPage(number){return jumpRef.current(Number(number),null,true)},
   beginPreview(){cancelMotion();
    const el=root.current,items=geometry.current,offset=el?.scrollTop||0,viewport=el?.clientHeight||844;
    pinchRange.current={low:ayahAtOffset(items,Math.max(0,offset-viewport*1.5)),high:ayahAtOffset(items,offset+viewport*2.5)};
   },
   previewScale(scale,reading){
    if(!geometry.current.length)return;
    const range=pinchRange.current||liveRange.current;
    if(reading?.word)preciseAnchor.current=reading;
    setPreview({scale,baseScale:Number(prefs.scale)||1,low:Math.max(0,range.low-2),high:Math.min(geometry.current.length-1,range.high+2)});
   },
   finishPreview(reading){if(reading?.word)preciseAnchor.current=reading;},
  };window.__munibinQuranAyahLayout=controller;
   const end=()=>{pinchRange.current=null;setPreview(null);setCenter(position());flush();};
   window.addEventListener('munibin-quran-pinch-end',end);
   return()=>{window.removeEventListener('munibin-quran-pinch-end',end);if(window.__munibinQuranAyahLayout===controller)delete window.__munibinQuranAyahLayout}},[document,width,prefs.scale]);
  React.useEffect(()=>{const navigate=event=>{const number=Number(event.detail?.page);if(!document){const previous=pending.current,latest=window.__munibinQuranNavigationHighlight?.target?.();pending.current={page:number,verse:event.detail?.verse||(previous?.page===number?previous.verse:undefined)||(latest?.page===number?latest.verseKey:undefined)}}else jumpRef.current(number,event.detail?.verse)};
   const highlight=event=>{const verse=event.detail?.verseKey||event.detail?.verse;if(!verse)return;if(!document){pending.current={page:Number(event.detail?.page)||page,verse};return}clearTimeout(navTimer.current);navTimer.current=setTimeout(()=>{const item=document?.byVerse.get(verse);if(item)jumpRef.current(item.page,verse)},0)};
   window.addEventListener('munibin-quran-explicit-jump',navigate);window.addEventListener('munibin-quran-navigation-target',highlight);
   window.__munibinQuranFlushVisiblePage=flush;
   return()=>{window.removeEventListener('munibin-quran-explicit-jump',navigate);window.removeEventListener('munibin-quran-navigation-target',highlight);if(window.__munibinQuranFlushVisiblePage===flush)delete window.__munibinQuranFlushVisiblePage};
  },[document]);
  // Choose the future viewport before React mounts ink. A scale/width change
  // can move a far-away verse by hundreds of thousands of pixels; the old
  // scrollTop must never choose the final mounted window.
  let offset=root.current?.scrollTop||0;
  const future=pending.current||anchor.current;
  if(future&&layouts.length){const index=future.verse?layouts.findIndex(layout=>layout.item.verse===future.verse):document?.pageIndex.get(future.page)??0;if(index>=0)offset=layouts[index].top+Math.min(Math.max(0,future.offset||0),Math.max(0,layouts[index].height-1));}
  const viewport=root.current?.clientHeight||844;
  const frozen=window.__munibinQuranPinching&&pinchRange.current;
  const low=frozen?frozen.low:layouts.length?ayahAtOffset(layouts,Math.max(0,offset-viewport*1.5)):0;
  const high=frozen?frozen.high:layouts.length?ayahAtOffset(layouts,offset+viewport*2.5):0;
  liveRange.current={low,high};
  // Keep both endpoints ready before moving. The scroll animation itself never
  // reconciles the complete Mushaf or fetches every page it passes on a long jump.
  const retained=motionWindow.current||[{low,high}],rangeKey=retained.map(range=>range.low+':'+range.high).join('|');
  const shells=React.useMemo(()=>layouts.map(layout=>h(Ayah,{key:layout.item.verse,layout,live:false,ready:false,render,actions,paint:null})),[layouts]);
  React.useEffect(()=>{const numbers=new Set(retained.flatMap(range=>layouts.slice(Math.max(0,range.low-2),range.high+3).flatMap(layout=>layout.item.pages)));
   for(const number of numbers){if(fontSet.current.has(number)||fontTasks.current.has(number))continue;
    const task=load.current(number).then(()=>{fontSet.current.add(number);fontFailures.current.delete(number);if(alive.current)setFontRevision(value=>value+1)}).catch(()=>{fontFailures.current.add(number);if(alive.current)setFontRevision(value=>value+1)}).finally(()=>fontTasks.current.delete(number));fontTasks.current.set(number,task)}
  },[layouts,rangeKey]);
  React.useLayoutEffect(()=>{const el=root.current,exact=preciseAnchor.current;if(el&&exact){const word=el.querySelector(`[data-reading-word="${exact.word}"]`);if(word){el.scrollTop+=word.getBoundingClientRect().top-el.getBoundingClientRect().top-exact.offset;preciseAnchor.current=null}}if(el)syncHighlights?.(el)},[layouts,rangeKey,revision,fontRevision]);
  React.useLayoutEffect(()=>{
   const request=pendingMotion.current;if(!request||request.generation!==motionGeneration.current)return;
   const ready=retained.every(range=>layouts.slice(Math.max(0,range.low-2),range.high+3).every(layout=>layout.item.pages.every(number=>fontSet.current.has(number)||fontFailures.current.has(number)||revision.fonts?.has?.(`QuranTajweed${number}`))));
   if(!ready)return;pendingMotion.current=null;scrollMotion.current.move(request.index,true);
  },[layouts,rangeKey,motionVersion,fontRevision,revision.fonts]);
  const scroll=()=>{if(scrollMotion.current?.moving||pendingMotion.current)return;window.__munibinQuranLastInteractionAt=performance.now();if(frame.current)return;frame.current=requestAnimationFrame(()=>{frame.current=0;if(!alive.current||scrollMotion.current?.moving||pendingMotion.current)return;setCenter(position());if(!window.__munibinQuranPinching)flush()})};
  const paint=JSON.stringify([revision.paint,revision.counts,revision.start,revision.hidden,Array.from(revision.mic||[]),prefs.font,prefs.tajweed]);
  const children=React.useMemo(()=>{
   const result=shells.slice();
   for(const range of retained)for(let index=Math.max(0,range.low-2);index<=Math.min(layouts.length-1,range.high+2);index++){
    const layout=layouts[index],active=!!(revision.playing&&revision.verse===layout.item.verse||revision.playlist===layout.item.verse);
    result[index]=h(Ayah,{key:layout.item.verse,layout,live:true,ready:layout.item.pages.every(number=>fontSet.current.has(number)||revision.fonts?.has?.(`QuranTajweed${number}`)),render,actions,paint:paint+'|'+Number(active)});
   }
   return result;
  },[shells,rangeKey,paint,revision.verse,revision.playing,revision.playlist,revision.fonts,fontRevision]);
  return h('div',{ref:root,className:'munibin-quran-vertical-pages munibin-quran-ayah-pages',style:{scrollBehavior:'auto'},onScroll:scroll,onPointerDown:cancelMotion,onWheel:cancelMotion,'aria-label':'القرآن بالتمرير آية بآية','data-document-ready':document?'true':'false'},
   children,
   !document&&h('div',{role:'status',className:'munibin-quran-ayah-loading'},'يجري تجهيز الآيات…'),
   error&&h('button',{className:'munibin-quran-page-retry',type:'button',onClick:prepare},'تعذر تجهيز الآيات. إعادة المحاولة'));
 };
}
