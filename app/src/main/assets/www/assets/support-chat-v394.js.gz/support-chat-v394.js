import {chatAttachmentKind,openChatAttachment} from "./native-chat-viewer-v393.js";
// Split plain chat text into HTTP links without interpreting any message as HTML.
export function supportMessageLinkParts(value) {
 const text=String(value??""),parts=[];
 const matches=/https?:\/\/[^\s<>"'`\u201c\u201d\u00ab\u00bb\u202a-\u202e\u2066-\u2069]+/gi;
 let previous=0,match;
 while((match=matches.exec(text))){
  const start=match.index;
  if(start>0&&/[A-Za-z0-9_]/.test(text[start-1]))continue;
  let candidate=match[0];
  while(candidate){
   const last=candidate[candidate.length-1];
   if(/[.,;:!?\u060c\u061b\u06d4\u3002]/.test(last)){candidate=candidate.slice(0,-1);continue;}
   const opener={")":"(","]":"[","}":"{"}[last];
   if(opener&&Array.from(candidate).filter(character=>character===last).length>Array.from(candidate).filter(character=>character===opener).length){candidate=candidate.slice(0,-1);continue;}
   break;
  }
  let url;
  try{url=new URL(candidate);}catch{continue;}
  if(!["http:","https:"].includes(url.protocol)||!url.hostname)continue;
  if(start>previous)parts.push({type:"text",text:text.slice(previous,start)});
  parts.push({type:"link",text:candidate,href:url.href});
  previous=start+candidate.length;
 }
 if(previous<text.length)parts.push({type:"text",text:text.slice(previous)});
 return parts.length?parts:[{type:"text",text}];
}
export function renderSupportMessageText(jsx,value){
 return supportMessageLinkParts(value).map((part,index)=>part.type==="link"?jsx.jsx("a",{href:part.href,rel:"noopener noreferrer",dir:"ltr",className:"munibin-support-message-link",children:part.text},`support-link-${index}`):part.text);
}
// Live CSS variables keep an open conversation in the selected app palette.
// No captured light/dark colors or observers are needed when the root changes.
export function supportThemeColors(){
 return {
  bg:"var(--app-bg)",headerBg:"var(--app-header-bg)",headerBorder:"var(--app-card-border)",
  title:"var(--app-text-primary)",muted:"var(--app-text-secondary)",
  card:"var(--app-card-bg)",border:"var(--app-card-border)",input:"var(--app-input-bg)",
  accent:"var(--app-gold)",accentText:"var(--munibin-support-accent-text)",
  mine:"var(--app-ai-user-bg)",mineText:"var(--app-text-primary)",mineBorder:"var(--app-badge-border)",
  theirs:"var(--app-surface-subtle)",danger:"var(--munibin-support-danger)",
  subtle:"var(--app-surface-subtle)",selected:"var(--app-badge-bg)"
 };
}
export const FILE_LIMIT=20*1024*1024,FILE_COUNT=5;
export function readSupportViewport(win=window){
 const view=win.visualViewport;
 return {height:Math.max(1,Math.min(win.innerHeight,view?.height||win.innerHeight)),top:Math.max(0,view?.offsetTop||0)};
}
export function useSupportViewport(React){
 const [viewport,setViewport]=React.useState(()=>readSupportViewport());
 React.useEffect(()=>{
  let frame=0;
  const update=()=>{if(frame)return;frame=requestAnimationFrame(()=>{frame=0;const next=readSupportViewport();setViewport(old=>old.height===next.height&&old.top===next.top?old:next)})};
  const view=window.visualViewport;
  document.documentElement.classList.add("munibin-support-active");
  window.addEventListener("resize",update);view?.addEventListener("resize",update);view?.addEventListener("scroll",update);update();
  return()=>{cancelAnimationFrame(frame);window.removeEventListener("resize",update);view?.removeEventListener("resize",update);view?.removeEventListener("scroll",update);document.documentElement.classList.remove("munibin-support-active")};
 },[]);
 return {position:"fixed",top:viewport.top,left:0,right:0,height:viewport.height,minHeight:0,display:"flex",flexDirection:"column",overflow:"hidden",boxSizing:"border-box","--support-conversation-display":viewport.height<280?"none":"block"};
}
export function readSupportFile(file){
 return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(",",2)[1]);reader.onerror=()=>reject(new Error("تعذر قراءة الملف. أعد اختياره."));reader.onabort=()=>reject(new Error("أُلغيت قراءة الملف."));reader.readAsDataURL(file)});
}
export function useSupportAttachments(React,upload,channel){
 const [drafts,setDrafts]=React.useState({}),[busy,setBusy]=React.useState(false),[error,setError]=React.useState("");
 const lock=React.useRef(false),allFiles=React.useRef(new Set()),mounted=React.useRef(true),sequence=React.useRef(0);
 const files=drafts[channel]||[];
 React.useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;for(const file of allFiles.current)if(file.preview)URL.revokeObjectURL(file.preview);allFiles.current.clear()}},[]);
 React.useEffect(()=>{setError("")},[channel]);
 const selectFiles=list=>{
  if(lock.current)return;
  const chosen=Array.from(list||[]);let added=[];
  for(const file of chosen){
   if(file.size<1||file.size>FILE_LIMIT){setError("الحد الأقصى لكل ملف 20 ميغابايت. لم يُضَف الملف: "+file.name);continue}
   const fingerprint=`${file.name}:${file.size}:${file.lastModified}`;
   if(files.concat(added).some(item=>item.fingerprint===fingerprint))continue;
   if(files.length+added.length>=FILE_COUNT){setError("يمكن إرسال خمسة مرفقات كحد أقصى.");break}
   const item={id:`support-file-${++sequence.current}`,file,fingerprint,preview:/^(image|video)\//.test(file.type)?URL.createObjectURL(file):null,uploaded:null};
   allFiles.current.add(item);added.push(item);
  }
  if(added.length)setDrafts(old=>({...old,[channel]:(old[channel]||[]).concat(added)}));
 };
 const remove=id=>{if(lock.current)return;const item=files.find(file=>file.id===id);if(item){if(item.preview)URL.revokeObjectURL(item.preview);allFiles.current.delete(item)}setDrafts(old=>({...old,[channel]:(old[channel]||[]).filter(file=>file.id!==id)}))};
 const submit=async action=>{
  if(lock.current)return false;
  lock.current=true;setBusy(true);setError("");
  try{
   const tokens=[];
   for(const item of files){
    if(!item.uploaded||item.uploaded.expiresAt<=Date.now()){
     const base64=await readSupportFile(item.file);
     const result=await upload({filename:item.file.name.slice(0,180)||"مرفق",base64});
     if(!result?.uploadToken)throw new Error("تعذر رفع المرفق.");
     item.uploaded=result;
    }
    tokens.push(item.uploaded.uploadToken);
   }
   await action(tokens);
   for(const item of files){if(item.preview)URL.revokeObjectURL(item.preview);allFiles.current.delete(item)}
   if(mounted.current)setDrafts(old=>({...old,[channel]:[]}));
   return true;
  }catch(err){if(mounted.current)setError(/[\u0600-\u06ff]/.test(err?.message||"")?err.message:"تعذر رفع أو إرسال المرفق. حاول مرة أخرى.");return false}
  finally{lock.current=false;if(mounted.current)setBusy(false)}
 };
 return {files,busy,error,selectFiles,remove,submit};
}
function fileSize(size){return size>=1048576?`${(size/1048576).toFixed(1)} MB`:`${Math.max(1,Math.ceil(size/1024))} KB`}
function clipIcon(v){return v.jsx("svg",{width:22,height:22,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:1.8,"aria-hidden":true,children:v.jsx("path",{d:"M21 11.5l-8.5 8.5a6 6 0 0 1-8.5-8.5l9-9a4 4 0 0 1 5.7 5.7l-9 9a2 2 0 0 1-2.8-2.8l8.5-8.5"})})}
export function SupportFilePicker({React,jsx:v,attachments,colors}){
 const file=React.useRef(null);
 return v.jsxs("div",{className:"munibin-support-picker",children:[
  v.jsx("button",{type:"button",disabled:attachments.busy,onClick:()=>file.current?.click(),"aria-label":"إرفاق صورة أو فيديو أو ملف",title:"إرفاق",className:"munibin-support-attach",style:{color:colors.accent,borderColor:colors.border},children:clipIcon(v)}),
  v.jsx("input",{type:"file",multiple:true,ref:file,tabIndex:-1,"aria-hidden":true,style:{display:"none"},onChange:event=>{attachments.selectFiles(event.target.files);event.target.value=""}})
 ]});
}
export function supportDraftPreview(v,attachments,colors){
 return attachments.files.length?v.jsx("div",{className:"munibin-support-drafts",children:attachments.files.map(item=>v.jsxs("div",{className:"munibin-support-draft",style:{borderColor:colors.border,color:colors.title},children:[item.preview&&item.file.type.startsWith("image/")&&v.jsx("img",{src:item.preview,alt:"",className:"munibin-support-thumbnail"}),v.jsxs("div",{className:"munibin-support-file-label",children:[v.jsx("span",{children:item.file.name}),v.jsx("small",{children:fileSize(item.file.size)})]}),v.jsx("button",{type:"button",disabled:attachments.busy,onClick:()=>attachments.remove(item.id),"aria-label":"إزالة "+item.file.name,children:"×"})]},item.id))}):null;
}
export function renderSupportAttachments(v,items){
 if(!Array.isArray(items))return [];
 return items.filter(item=>typeof item?.url==="string"&&item.url.startsWith("/api/support/attachments?ticket=")).slice(0,FILE_COUNT).map((item,index)=>{
  const kind=chatAttachmentKind(item);
  return v.jsxs("div",{className:"munibin-support-attachment",children:[
   kind==="image"&&v.jsx("button",{type:"button",className:"munibin-support-image-open",onClick:event=>openChatAttachment(item,event),"aria-label":"فتح "+item.name,children:v.jsx("img",{src:item.url,alt:item.name,loading:"lazy"})}),
   kind==="video"&&v.jsxs("button",{type:"button",className:"munibin-support-video-open",onClick:event=>openChatAttachment(item,event),"aria-label":"فتح الفيديو "+item.name,children:[v.jsx("video",{src:item.url,muted:true,playsInline:true,preload:"metadata",tabIndex:-1,"aria-hidden":true}),v.jsx("span",{className:"munibin-support-video-play","aria-hidden":true,children:v.jsx("svg",{width:28,height:28,viewBox:"0 0 24 24",fill:"currentColor",focusable:"false",children:v.jsx("path",{d:"M8 5v14l11-7z"})})})]}),
   kind!=="image"&&kind!=="video"&&v.jsx("div",{className:"munibin-support-file-link",children:v.jsxs("button",{type:"button",className:"munibin-support-file-open",onClick:event=>openChatAttachment(item,event),"aria-label":"فتح "+item.name,children:[v.jsx("span",{children:item.name}),v.jsx("small",{dir:"ltr",children:fileSize(item.size)})]})})
  ]},index);
 });
}
export function SupportComposer({React,jsx:v,attachments,colors,value,onChange,onSubmit,pending,placeholder,fontFamily}){
 const disabled=pending||attachments.busy;
 return v.jsxs("form",{onSubmit:event=>{event.preventDefault();if(!disabled&&(value.trim()||attachments.files.length))onSubmit()},className:"munibin-support-composer",style:{background:colors.card,borderColor:colors.border},children:[
  supportDraftPreview(v,attachments,colors),
  v.jsxs("div",{className:"munibin-support-composer-row",children:[
   v.jsx(SupportFilePicker,{React,jsx:v,attachments,colors}),
   v.jsx("textarea",{value,onChange:event=>onChange(event.target.value),disabled,rows:2,maxLength:2000,placeholder,"aria-label":placeholder,style:{background:colors.input,color:colors.title,borderColor:colors.border,fontFamily}}),
   v.jsx("button",{type:"submit",disabled:disabled||(!value.trim()&&!attachments.files.length),className:"munibin-support-send",style:{background:colors.accent,color:colors.accentText},children:disabled?"جارٍ الإرسال…":"إرسال"})
  ]}),
  attachments.error&&v.jsx("p",{role:"alert",className:"munibin-support-error",style:{color:colors.danger},children:attachments.error})
 ]});
}
