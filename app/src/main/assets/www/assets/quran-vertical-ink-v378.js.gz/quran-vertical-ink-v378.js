/* Each continuous page owns its rendered ink independently of the small shared
   page-element cache. Paint keys describe only values consumed by this page;
   live CSS applies zoom and spacing to all mounted pages without rebuilding
   their glyph trees on unrelated parent commits. No page is removed/reordered. */
const metadata=new WeakMap();

function pageMetadata(page) {
 let value=metadata.get(page);
 if(value)return value;
 const verses=new Set();let total=0;
 for(const line of page.lines||[])for(const word of line.words||[]) {
  if(!word.verse_key||(word.type!=='word'&&word.type!=='end'))continue;
  total++;verses.add(word.verse_key);
 }
 value={total,verses};metadata.set(page,value);return value;
}

export function verticalPagePaintKey(page,revision={}) {
 const prefs=revision.prefs||{},hidden=!!revision.hidden;
 const {total,verses}=pageMetadata(page);
 const count=revision.counts?.[page.page]??(page.page<revision.start?total:0);
 const revealed=hidden?Math.max(0,Math.min(total,count)):0;
 return JSON.stringify([
  prefs.font||'qcf1441',prefs.tajweed===true,(prefs.scale??1)===1,
  revision.paint??0,revision.mic?.get?.(page.page)??0,hidden,revealed,
  revision.playing&&verses.has(revision.verse)?revision.verse:null,
  verses.has(revision.playlist)?revision.playlist:null,
  revision.fonts?.has?.(`QuranTajweed${page.page}`)===true,
 ]);
}

export function sameVerticalPageInk(previous,next) {
 return previous.item===next.item&&previous.render===next.render&&previous.paintKey===next.paintKey;
}

export function createVerticalPageInk(React) {
 const h=React.createElement;
 return React.memo(function VerticalPageInk({item,render,paintKey}) {
  return h('article',{'data-scroll-page':item.page,className:'munibin-quran-scroll-page'},
   render.current(item),
   h('div',{className:'munibin-quran-scroll-page-number'},item.page.toLocaleString('ar-EG')));
 },sameVerticalPageInk);
}
