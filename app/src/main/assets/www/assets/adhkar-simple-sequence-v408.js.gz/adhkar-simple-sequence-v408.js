import { useAdhkarCardTransition, captureAdhkarScroll, restoreAdhkarScroll } from './adhkar-card-transition-v412.js';

const SEQUENCE_KEY = 'munibin:adhkar-simple-sequence:v408:';
const GROUPS = ['morning', 'evening', 'sleep'];
const COMPLETION_ID = '__complete__';

function readMemory(scope, day) {
  try {
    const saved = JSON.parse(localStorage.getItem(SEQUENCE_KEY + scope) || 'null');
    if (saved?.day === day && saved.positions && typeof saved.positions === 'object') {
      return { scope, day, positions: Object.fromEntries(GROUPS.flatMap(group =>
        typeof saved.positions[group] === 'string' ? [[group, saved.positions[group]]] : [])) };
    }
  } catch {}
  return { scope, day, positions: {} };
}
function writeMemory(memory) {
  try { localStorage.setItem(SEQUENCE_KEY + memory.scope, JSON.stringify({ day: memory.day, positions: memory.positions })); } catch {}
}
function complete(items, counts) { return items.length > 0 && items.every(item => (counts[item.id] || 0) >= item.count); }
function firstUnfinished(items, counts) {
  const index = items.findIndex(item => (counts[item.id] || 0) < item.count);
  return index < 0 ? 0 : index;
}
function selectedIndex(items, counts, saved) {
  if (saved === COMPLETION_ID && complete(items, counts)) return items.length;
  const index = items.findIndex(item => item.id === saved);
  return index < 0 ? firstUnfinished(items, counts) : index;
}

export function useSimpleAdhkarSequence(React, options) {
  const { scope, day, mode, items, counterState, counterKey, readCounts, readDay } = options;
  const initialMemory = React.useMemo(() => readMemory(scope, day), [scope, day]);
  const [memory, setMemory] = React.useState(initialMemory);
  const activeMemory = memory.scope === scope && memory.day === day ? memory : initialMemory;
  const key = counterKey(day, mode, scope);
  const counts = counterState.key === key ? counterState.values : readCounts(key);
  const index = selectedIndex(items, counts, activeMemory.positions[mode]);
  const cardRef = React.useRef(null);
  const pendingScroll = React.useRef(null);
  const live = React.useRef(null);
  const previous = live.current;
  live.current = {
    ...options, memory: activeMemory, index,
    // Keep the synchronous event snapshot until React commits the queued counter state.
    counts: previous?.key === key && previous.observed === counterState ? previous.counts : counts,
    key, observed: counterState,
  };
  const readerScope = `${scope}:${day}:${mode}`;
  const transition = useAdhkarCardTransition(React, {
    scope: readerScope, identity: items[index]?.id || COMPLETION_ID, cardRef,
    isCurrent: () => live.current.readDay() === live.current.day,
  });

  const storePosition = (state, itemIndex) => {
    const item = state.items[itemIndex];
    const identity = item?.id || (itemIndex === state.items.length && complete(state.items, state.counts) ? COMPLETION_ID : null);
    if (!identity) return;
    const nextMemory = { ...state.memory, positions: { ...state.memory.positions, [state.mode]: identity } };
    state.memory = nextMemory; state.index = itemIndex;
    writeMemory(nextMemory); setMemory(nextMemory);
  };
  const refreshDay = () => {
    const state = live.current, fresh = state.readDay();
    if (fresh === state.day) return false;
    transition.cancel();
    state.day = fresh; state.key = state.counterKey(fresh, state.mode, state.scope);
    state.counts = state.readCounts(state.key);
    state.memory = readMemory(state.scope, fresh);
    state.index = selectedIndex(state.items, state.counts, state.memory.positions[state.mode]);
    writeMemory(state.memory); setMemory(state.memory);
    state.setDay(fresh); state.setCounters({ key: state.key, values: state.counts });
    return true;
  };
  const writeCounters = (state, values) => {
    state.counts = values;
    // Persist before switching cards/groups, so rapid navigation sees the latest count.
    try { localStorage.setItem(state.key, JSON.stringify(values)); } catch {}
    state.setCounters({ key: state.key, values });
  };
  const moveToIndex = (itemIndex, done = false) => {
    const state = live.current;
    if (itemIndex === state.index || itemIndex < 0 || itemIndex > state.items.length || (itemIndex === state.items.length && !complete(state.items, state.counts))) return;
    const previousIndex = state.index, originScope = `${state.scope}:${state.day}:${state.mode}`;
    transition.move(() => {
      if (refreshDay()) return false;
      const current = live.current;
      if (`${current.scope}:${current.day}:${current.mode}` !== originScope || current.index !== previousIndex) return false;
      pendingScroll.current = { scope: originScope, identity: current.items[itemIndex]?.id || COMPLETION_ID, saved: captureAdhkarScroll(cardRef.current) };
      storePosition(current, itemIndex);
      return true;
    }, done || itemIndex > previousIndex ? 1 : -1, { done });
  };

  React.useLayoutEffect(() => {
    cardRef.current?.scrollTo?.({ top: 0, behavior: 'instant' });
    const pending = pendingScroll.current;
    pendingScroll.current = null;
    if (!pending || pending.scope !== readerScope || pending.identity !== (items[index]?.id || COMPLETION_ID)) return;
    restoreAdhkarScroll(pending.saved, cardRef.current);
    const frame = window.requestAnimationFrame(() => restoreAdhkarScroll(pending.saved, cardRef.current));
    return () => window.cancelAnimationFrame(frame);
  }, [scope, day, mode, items[index]?.id || COMPLETION_ID]);
  React.useEffect(() => {
    const state = live.current;
    // Remember the initial unfinished card as well as explicit navigation.
    storePosition(state, state.index);
  }, [scope, day, mode]);
  React.useEffect(() => {
    let timer = null;
    const schedule = () => {
      if (timer !== null) window.clearTimeout(timer);
      const now = new Date(), midnight = new Date(now);
      midnight.setDate(now.getDate() + 1); midnight.setHours(0, 0, 0, 0);
      timer = window.setTimeout(wake, Math.max(1, midnight.getTime() - now.getTime()) + 5);
    };
    const wake = () => { refreshDay(); schedule(); };
    const visible = () => { if (document.visibilityState !== 'hidden') wake(); };
    schedule();
    window.addEventListener('focus', wake); window.addEventListener('pageshow', wake);
    document.addEventListener('visibilitychange', visible);
    return () => {
      if (timer !== null) window.clearTimeout(timer);
      window.removeEventListener('focus', wake); window.removeEventListener('pageshow', wake);
      document.removeEventListener('visibilitychange', visible);
    };
  }, []);

  return {
    index, cardRef, animating: transition.animating, complete: complete(items, counts), showingCompletion: index === items.length && complete(items, counts),
    selectGroup(nextMode) { transition.cancel(); refreshDay(); if (GROUPS.includes(nextMode)) { live.current.changeGroup(nextMode); restoreAdhkarScroll(null, cardRef.current); } },
    previous() { if (refreshDay() || transition.busy) return; moveToIndex(Math.max(0, live.current.index - 1)); },
    next() { if (refreshDay() || transition.busy) return; moveToIndex(Math.min(live.current.items.length, live.current.index + 1)); },
    review() { if (refreshDay() || transition.busy) return; moveToIndex(0); },
    increment(id, required) {
      const changedDay = refreshDay(), state = live.current;
      if (transition.busy) return;
      // Reset an old non-first card before accepting another tap, so no unseen dhikr is credited.
      const itemIndex = state.items.findIndex(item => item.id === id), item = state.items[itemIndex];
      if (!item || item.count !== required || itemIndex !== state.index) return;
      const before = Math.min(required, Math.max(0, Math.trunc(state.counts[id] || 0)));
      if (before >= required) return;
      const values = { ...state.counts, [id]: before + 1 };
      writeCounters(state, values);
      if (before + 1 === required) {
        // Continue forward, then return to skipped unfinished cards before declaring completion.
        let nextIndex = state.items.findIndex((candidate, i) => i > itemIndex && (values[candidate.id] || 0) < candidate.count);
        if (nextIndex < 0) nextIndex = state.items.findIndex(candidate => (values[candidate.id] || 0) < candidate.count);
        if (nextIndex >= 0) moveToIndex(nextIndex, true);
        else moveToIndex(state.items.length, true);
      } else if (changedDay) storePosition(state, itemIndex);
    },
    reset(id) {
      const changedDay = refreshDay(), state = live.current;
      if (transition.busy) return;
      if (state.items[state.index]?.id !== id) return;
      writeCounters(state, { ...state.counts, [id]: 0 });
    },
    nextGroup() {
      refreshDay(); const state = live.current;
      if (transition.busy || !complete(state.items, state.counts)) return;
      const nextMode = GROUPS[(GROUPS.indexOf(state.mode) + 1) % GROUPS.length];
      transition.move(() => {
        if (refreshDay()) return false;
        live.current.changeGroup(nextMode);
        restoreAdhkarScroll(null, cardRef.current);
        return true;
      }, 1, { scope: `${state.scope}:${state.day}:${nextMode}` });
    },
    nextGroupLabel: mode === 'morning' ? 'الانتقال إلى أذكار المساء' : mode === 'evening' ? 'الانتقال إلى أذكار النوم' : 'العودة إلى أذكار الصباح',
  };
}
