/** Strict spelling-level Quran recitation tracking. This checks recognized words,
 * not pronunciation, vowel accuracy, or tajweed. Supply cumulative transcripts
 * under one utteranceId; every recognizer restart/final result needs a new ID.
 */
const ARABIC_MARKS = /[\u0610-\u061a\u064b-\u065f\u0670\u06d6-\u06ed\u08d3-\u08ff]/gu;
const FORMATTING = /[\u061c\u0640\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff]/gu;
const DAGGER_EXCEPTIONS = /^(?:[وفبلك]?الله|[وفبلك]?الرحمن|[وفبلك]?هذا|[وفبلك]?هذه|[وفبلك]?ذلك|[وفبلك]?لكن|[وفبلك]?اولئك|اله(?:ا|كم|نا|ه|هم)?|لله)$/u;
const MUQATTAAT_BY_ID = new Map([
  ['2:1:1', 'الم'], ['3:1:1', 'الم'], ['7:1:1', 'المص'],
  ['10:1:1', 'الر'], ['11:1:1', 'الر'], ['12:1:1', 'الر'], ['13:1:1', 'المر'],
  ['14:1:1', 'الر'], ['15:1:1', 'الر'], ['19:1:1', 'كهيعص'], ['20:1:1', 'طه'],
  ['26:1:1', 'طسم'], ['27:1:1', 'طس'], ['28:1:1', 'طسم'], ['29:1:1', 'الم'],
  ['30:1:1', 'الم'], ['31:1:1', 'الم'], ['32:1:1', 'الم'], ['36:1:1', 'يس'],
  ['38:1:1', 'ص'], ['40:1:1', 'حم'], ['41:1:1', 'حم'], ['42:1:1', 'حم'],
  ['42:2:1', 'عسق'], ['43:1:1', 'حم'], ['44:1:1', 'حم'], ['45:1:1', 'حم'],
  ['46:1:1', 'حم'], ['50:1:1', 'ق'], ['68:1:1', 'ن'],
]);
const LETTER_NAMES = {
  // أليف is a bounded recognizer spelling of the letter name, accepted only
  // at the 30 canonical muqattaat positions. اَلِف/ألف share normalization.
  ا: ['ألف', 'أليف'], ل: ['لام'], م: ['ميم'], ص: ['صاد'], ر: ['راء', 'را'],
  ك: ['كاف'], ه: ['هاء', 'ها'], ي: ['ياء', 'يا'], ع: ['عين'],
  ط: ['طاء', 'طا'], س: ['سين'], ح: ['حاء', 'حا'], ق: ['قاف'], ن: ['نون'],
};
const ISTIADHA = 'أعوذ بالله من الشيطان الرجيم';
const BASMALA = 'بسم الله الرحمن الرحيم';

export function decodeQuranEntities(value) {
  return String(value ?? '').replace(/&#(x[0-9a-f]+|[0-9]+);/giu, (all, code) => {
    const number = /^x/iu.test(code) ? Number.parseInt(code.slice(1), 16) : Number(code);
    return number > 0 && number <= 0x10ffff && !(number >= 0xd800 && number <= 0xdfff)
      ? String.fromCodePoint(number) : all;
  });
}

export function isNonspokenQuranUnit(source) {
  const text = decodeQuranEntities(source?.text).trim();
  return source?.type === 'end' || text === '#1969' || text === '\u06e9';
}

export function normalizeArabicWord(value) {
  let text = decodeQuranEntities(value).normalize('NFKC').replace(FORMATTING, '');
  // Two consecutive hamzas are not the single long-alif spelling ءا. Preserve
  // their count before the later seating/long-alif normalization loses that
  // distinction (ءَأَنذرتهم must match أأنذرتهم, never أنذرتهم).
  text = text.replace(/ء(?=[\u064b-\u065f]*[أإ])/gu, '\ue000');
  // Dagger alif is a pronounced long vowel, not ordinary removable tashkeel.
  // Standard imlaei intentionally omits it in this small established word set.
  const skeleton = text.replace(ARABIC_MARKS, '').replace(/[أإآٱ]/gu, 'ا');
  if (DAGGER_EXCEPTIONS.test(skeleton)) text = text.replace(/\u0670/gu, '');
  else text = text.replace(/([اى])\u0670/gu, '$1').replace(/\u0670/gu, 'ا');
  text = text.replace(ARABIC_MARKS, '').replace(/[أإآٱ]/gu, 'ا')
    .replace(/[ؤئ]/gu, 'ء').replace(/ى/gu, 'ا');
  // The document uses Quranic ءا/ئَا for long-alif hamza in بآيات/الآن/يا آدم.
  text = text.replace(/ءا/gu, 'ا').replace(/سءل/gu, 'سال');
  text = text.replace(/\ue000/gu, 'ا');
  return text.toLowerCase();
}

export function tokenizeRecitation(value) {
  return decodeQuranEntities(value).normalize('NFKC')
    .split(/[\s\p{P}\p{S}]+/u).filter(Boolean)
    .map(text => ({ text, normalized: normalizeArabicWord(text) }))
    .filter(token => token.normalized.length > 0);
}

function muqattaatAliases(id, text) {
  const letters = MUQATTAAT_BY_ID.get(id);
  if (!letters || normalizeArabicWord(text) !== normalizeArabicWord(letters)) return [];
  let phrases = [''];
  for (const letter of letters) phrases = phrases.flatMap(prefix =>
    LETTER_NAMES[letter].map(name => `${prefix}${name}`));
  return [...new Set(phrases.map(normalizeArabicWord))];
}

function muqattaatLetterNames(id, text) {
  const letters = MUQATTAAT_BY_ID.get(id);
  if (!letters || normalizeArabicWord(text) !== normalizeArabicWord(letters)) return [];
  return [...letters].map(letter => [...new Set(LETTER_NAMES[letter].map(normalizeArabicWord))]);
}

function wordVariants(words) {
  let variants = [''];
  for (const word of words) variants = variants.flatMap(prefix =>
    (word.spellingAliases ?? [word.normalized]).map(spelling => prefix + spelling));
  return [...new Set(variants)];
}

function letterProbe(tokens, offset, end, names, letterIndex, isFinal) {
  let unfinished = false, variants = [''];
  const prefixes = [];
  for (let index = letterIndex; index < names.length; index++) {
    variants = variants.flatMap(prefix => names[index].map(name => prefix + name));
    prefixes.push({count: index - letterIndex + 1, variants});
  }
  for (let spokenCount = 1; spokenCount <= 7 && offset + spokenCount <= end; spokenCount++) {
    const spoken = tokens.slice(offset, offset + spokenCount).map(token => token.normalized).join('');
    for (const prefix of prefixes) {
      if (prefix.variants.includes(spoken)) return {spokenCount, letters: prefix.count, unfinished: false};
      if (!isFinal && offset + spokenCount === end && prefix.variants.some(value => value.startsWith(spoken))) unfinished = true;
    }
  }
  return {spokenCount: 0, letters: 0, unfinished};
}

function exactPhraseProbe(tokens, offset, end, normalizedPhrases, isFinal) {
  let unfinished = false;
  // A preamble or disconnected-letter group may occupy up to seven ASR tokens.
  // Concatenation is exact; a missing, extra, or wrong letter never matches.
  for (let count = 1; count <= 7 && offset + count <= end; count += 1) {
    const spoken = normalizeArabicWord(tokens.slice(offset, offset + count).map(t => t.text).join(''));
    if (normalizedPhrases.includes(spoken)) return { count, unfinished: false };
    if (!isFinal && offset + count === end && normalizedPhrases.some(p => p.startsWith(spoken))) unfinished = true;
  }
  return { count: 0, unfinished };
}

export function buildQuranRecitationIndex(document, { aliases = {} } = {}) {
  const canonicalAliases = aliases?.entries ?? aliases;
  const words = [], byId = new Map(), verseStarts = new Map(), pages = new Map();
  const sourcePages = Array.isArray(document) ? document : document?.pages;
  if (!Array.isArray(sourcePages)) throw new TypeError('Quran document pages are required');
  for (const sourcePage of sourcePages) {
    const page = Number(sourcePage.page), pageWords = [];
    let visualIndex = 0, precedingWord = null;
    for (const line of sourcePage.lines ?? []) {
      for (const source of line.words ?? []) {
        if (source.type !== 'word' && source.type !== 'end') continue;
        if (isNonspokenQuranUnit(source)) {
          // Aya and sajda markers are visual units, never spoken words.
          if (precedingWord?.verseKey === source.verse_key) precedingWord.revealUnits += 1;
          visualIndex += 1;
          continue;
        }
        const verseKey = String(source.verse_key), position = Number(source.position);
        const item = {
          index: words.length, page, line: Number(line.line), verseKey,
          verse_key: verseKey, position, text: String(source.text ?? ''),
          normalized: normalizeArabicWord(source.text),
          id: `${verseKey}:${position}`, pageWordIndex: visualIndex, revealUnits: 1,
        };
        item.spokenAliases = muqattaatAliases(item.id, item.text);
        item.letterNames = muqattaatLetterNames(item.id, item.text);
        const spellings = canonicalAliases?.[item.id] ?? [];
        if (!Array.isArray(spellings)) throw new TypeError(`Invalid aliases for Quran word ${item.id}`);
        item.spellingAliases = [...new Set([item.normalized,
          ...spellings.map(text => normalizeArabicWord(String(text).replace(/\s+/gu, '')))])];
        if (!item.normalized) throw new Error(`Empty spoken Quran word ${item.id}`);
        if (byId.has(item.id)) throw new Error(`Duplicate spoken Quran word ${item.id}`);
        if (!verseStarts.has(verseKey)) verseStarts.set(verseKey, item.index);
        words.push(item); pageWords.push(item); byId.set(item.id, item);
        precedingWord = item; visualIndex += 1;
      }
    }
    pages.set(page, { page, words: pageWords, visualWordCount: visualIndex });
  }
  return { words, byId, verseStarts, pages };
}

function commonPrefix(left, right) {
  let length = 0;
  while (length < left.length && length < right.length &&
    left[length].normalized === right[length].normalized) length += 1;
  return length;
}

/** One matcher per recitation session. A mismatch gates all remaining words in
 * that result. A later appended result may retry from its first newly appended
 * token; we never search the wrong suffix for a later matching Quran word.
 */
export class QuranRecitationMatcher {
  constructor(index, start = {}) {
    if (!Array.isArray(index?.words)) throw new TypeError('A Quran recitation index is required');
    this.index = index;
    this.start(start);
  }

  start(selection = {}) {
    let cursor;
    if (Number.isInteger(selection.index)) cursor = selection.index;
    else if (selection.verseKey || selection.verse_key) {
      const verseKey = selection.verseKey || selection.verse_key;
      const requested = this.index.byId.get(`${verseKey}:${selection.position ?? 1}`);
      cursor = requested?.index;
      if (cursor === undefined) throw new RangeError(`Unknown Quran word ${verseKey}:${selection.position ?? 1}`);
    } else cursor = 0;
    if (cursor < 0 || cursor > this.index.words.length) throw new RangeError('Invalid recitation start index');
    this.startCursor = cursor;
    this.cursor = cursor;
    this.committedCursor = cursor;
    this.active = null;
    this.closedIds = new Set();
    this.error = null;
    this.allowPreamble = selection.allowPreamble ?? this.allowPreamble ?? false;
    const first = this.index.words[cursor];
    const surah = Number(first?.verseKey.split(':')[0]);
    this.allowBasmala = this.allowPreamble && first?.position === 1 &&
      first?.verseKey.split(':')[1] === '1' && surah !== 1 && surah !== 9;
    this.currentPreamble = { istiadha: false, basmala: false };
    this.committedPreamble = { ...this.currentPreamble };
    this.partialWord = null;
    this.committedPartialWord = null;
    return this.getState();
  }

  _parse(tokens, startCursor, boundaries, isFinal, basePreamble, basePartialWord) {
    let cursor = startCursor, error = null;
    const preamble = { ...basePreamble };
    let partialWord = basePartialWord ? {...basePartialWord} : null;
    const cuts = [0, ...boundaries.filter(n => n > 0 && n < tokens.length), tokens.length];
    for (let segment = 0; segment + 1 < cuts.length; segment += 1) {
      let offset = cuts[segment];
      const end = cuts[segment + 1];
      error = null;
      while (offset < end && cursor < this.index.words.length) {
        const expected = this.index.words[cursor];
        let match = null, unfinished = false;
        if (this.allowPreamble && cursor === this.startCursor) {
          const candidates = [];
          if (!preamble.istiadha && !preamble.basmala) candidates.push(['istiadha', ISTIADHA]);
          if (this.allowBasmala && !preamble.basmala) candidates.push(['basmala', BASMALA]);
          let completed = false;
          for (const [kind, phrase] of candidates) {
            // An actual selected Quran word takes precedence over an optional
            // formula beginning with that same word (e.g. selected أعوذ).
            if (expected.normalized === normalizeArabicWord(phrase.split(' ')[0])) continue;
            const probe = exactPhraseProbe(tokens, offset, end,
              [normalizeArabicWord(phrase.replace(/ /gu, ''))], isFinal);
            if (probe.count) {
              preamble[kind] = true; offset += probe.count; completed = true; break;
            }
            unfinished ||= probe.unfinished;
          }
          if (completed) continue;
          if (unfinished) break;
        }
        if (expected.letterNames?.length) {
          let letterIndex = partialWord?.id === expected.id ? partialWord.letterIndex : 0;
          let probe = letterProbe(tokens, offset, end, expected.letterNames, letterIndex, isFinal);
          // The user may repeat the whole disconnected-letter group after a
          // mistake. Restart only from its exact first letter name; never scan
          // ahead through an incorrect letter for a later matching one.
          if (!probe.spokenCount && letterIndex > 0) {
            const restart = letterProbe(tokens, offset, end, expected.letterNames, 0, isFinal);
            if (restart.spokenCount) { letterIndex = 0; probe = restart; }
            else unfinished ||= restart.unfinished;
          }
          if (probe.spokenCount) {
            offset += probe.spokenCount;
            letterIndex += probe.letters;
            if (letterIndex === expected.letterNames.length) { cursor++; partialWord = null; }
            else partialWord = {id: expected.id, letterIndex, totalLetters: expected.letterNames.length};
            continue;
          }
          unfinished ||= probe.unfinished;
        }
        // Exact concatenation permits tokenization-only changes: 'و اياك',
        // 'يا آدم', or one ASR token covering several adjacent Quran words.
        // Shortest exact match takes precedence, preserving genuine repetitions.
        for (let spokenCount = 1; !match && spokenCount <= 4 && offset + spokenCount <= end; spokenCount += 1) {
          const spoken = tokens.slice(offset, offset + spokenCount).map(t => t.normalized).join('');
          for (let wordCount = 1; wordCount <= 3 && cursor + wordCount <= this.index.words.length; wordCount += 1) {
            const candidates = this.index.words.slice(cursor, cursor + wordCount);
            const wanted = wordVariants(candidates);
            if (wanted.includes(spoken)) { match = { spokenCount, wordCount }; break; }
            if (!isFinal && offset + spokenCount === end && wanted.some(value => value.startsWith(spoken))) unfinished = true;
          }
          if (match) break;
        }
        if (match) {
          offset += match.spokenCount;
          cursor += match.wordCount;
          partialWord = null;
          continue;
        }
        // Incomplete final ASR token waits for completion instead of falsely
        // flagging a consonant prefix as a recitation mistake.
        error = unfinished ? null : {
          type: 'unexpected-word', expected, heard: tokens[offset].text,
          heardNormalized: tokens[offset].normalized, tokenIndex: offset,
        };
        break;
      }
    }
    return { cursor, error, preamble, partialWord };
  }

  ingest({ utteranceId, text = '', isFinal = false, emptyFinalRetracts = false } = {}) {
    if (utteranceId === undefined || utteranceId === null || utteranceId === '') {
      throw new TypeError('Every recognition utterance needs a stable nonempty utteranceId');
    }
    const id = String(utteranceId);
    if (this.closedIds.has(id)) return this._state([], [], true);
    const oldCursor = this.cursor;
    if (this.active?.id !== id) {
      if (this.active) {
        // Starting a new recognizer result commits the last result already shown.
        // Older delayed events cannot mutate the new utterance's progress.
        this.closedIds.add(this.active.id);
        this.committedCursor = this.cursor;
        this.committedPreamble = { ...this.currentPreamble };
        this.committedPartialWord = this.partialWord ? {...this.partialWord} : null;
      }
      this.active = { id, baseCursor: this.committedCursor,
        basePreamble: { ...this.committedPreamble },
        basePartialWord: this.committedPartialWord ? {...this.committedPartialWord} : null,
        tokens: [], boundaries: [], gated: false };
    }
    const active = this.active;
    let tokens = tokenizeRecitation(text);
    // Some native recognizers emit an empty final/no-match event merely to close
    // the stream. It is not a revision retracting the preceding spoken partial.
    if (isFinal && !emptyFinalRetracts && tokens.length === 0 && active.tokens.length > 0) tokens = active.tokens;
    const prefix = commonPrefix(active.tokens, tokens);
    const pureAppend = prefix === active.tokens.length && tokens.length > active.tokens.length;
    if (pureAppend && active.gated && active.tokens.length > 0) active.boundaries.push(active.tokens.length);
    if (!pureAppend && prefix < active.tokens.length) {
      // Discard retry checkpoints whose spoken prefix the recognizer has revised.
      active.boundaries = active.boundaries.filter(boundary => boundary <= prefix);
    }
    const result = this._parse(tokens, active.baseCursor, active.boundaries, !!isFinal, active.basePreamble, active.basePartialWord);
    this.cursor = result.cursor;
    this.error = result.error;
    this.currentPreamble = result.preamble;
    this.partialWord = result.partialWord;
    active.tokens = tokens;
    active.gated = !!result.error;
    const accepted = this.cursor > oldCursor ? this.index.words.slice(oldCursor, this.cursor) : [];
    const rolledBack = this.cursor < oldCursor ? this.index.words.slice(this.cursor, oldCursor) : [];
    if (isFinal) {
      this.committedCursor = this.cursor;
      this.committedPreamble = { ...this.currentPreamble };
      this.committedPartialWord = this.partialWord ? {...this.partialWord} : null;
      this.closedIds.add(id);
      this.active = null;
    }
    return this._state(accepted, rolledBack, false);
  }

  _state(accepted, rolledBack, ignored) {
    const acceptedWords = this.index.words.slice(this.startCursor, this.cursor);
    const revealCounts = {}, revealByVerse = {};
    for (const item of acceptedWords) {
      revealCounts[item.page] = (revealCounts[item.page] || 0) + item.revealUnits;
      revealByVerse[item.verseKey] = item.position;
    }
    return {
      start: this.startCursor, cursor: this.cursor, accepted, rolledBack,
      nextWord: this.index.words[this.cursor] ?? null,
      lastAccepted: this.cursor > this.startCursor ? this.index.words[this.cursor - 1] : null,
      waiting: !!this.error, error: this.error,
      complete: this.cursor >= this.index.words.length,
      acceptedCount: acceptedWords.length, acceptedWords, revealCounts, revealByVerse,
      ignored,
      preamble: { ...this.currentPreamble },
      partialWord: this.partialWord ? {...this.partialWord} : null,
    };
  }

  getState() { return this._state([], [], false); }

  /** Evaluate a real recognizer hypothesis without committing its cursor,
   * letter-name checkpoint, retry boundary, or closed utterance ID. */
  preview(event) {
    const trial = Object.create(Object.getPrototypeOf(this));
    Object.assign(trial, this, {
      closedIds: new Set(this.closedIds),
      currentPreamble: {...this.currentPreamble},
      committedPreamble: {...this.committedPreamble},
      partialWord: this.partialWord ? {...this.partialWord} : null,
      committedPartialWord: this.committedPartialWord ? {...this.committedPartialWord} : null,
      active: this.active ? {...this.active, tokens:[...this.active.tokens], boundaries:[...this.active.boundaries],
        basePreamble:{...this.active.basePreamble},
        basePartialWord:this.active.basePartialWord ? {...this.active.basePartialWord} : null} : null,
    });
    return trial.ingest(event);
  }
}
