import {buildQuranRecitationIndex, QuranRecitationMatcher, tokenizeRecitation} from './recitation-matcher-v401.js';

import canonicalAliases from './quran-recitation-aliases-v401.js';
import {onlineQuranSpeechAdapter} from './quran-online-speech-v405.js';

// Temporarily hide the footer control without removing the recitation engine.
const SHOW_QURAN_RECITATION_MIC = false;

/* Native capture supplies PCM audio to a Quran-trained server recognizer.
   Returned words are aligned strictly; no expected-text hints or fuzzy forward
   search can reveal a skipped word. This is not an acoustic tajweed assessment. */
let indexPromise;
export function resetRecitationIndexCacheForTests() { indexPromise = undefined; }
export function loadRecitationIndex(loadDocument) {
  if (!indexPromise) indexPromise = Promise.resolve().then(loadDocument).then(document=>buildQuranRecitationIndex(document,{aliases:canonicalAliases})).catch(error => { indexPromise = undefined; throw error; });
  return indexPromise;
}
export function nativeSpeechAdapter(target = window) { return onlineQuranSpeechAdapter(target); }
const ERROR_MESSAGES = {
  'service-not-configured':'لم تُفعّل خدمة التسميع القرآني بعد. حاول لاحقاً.',
  'service-busy':'خدمة التسميع مشغولة الآن. حاول مجدداً بعد قليل.',
  'service-timeout':'استغرقت خدمة التسميع وقتاً طويلاً. تحقق من الإنترنت وحاول مجدداً.',
  'service-protocol':'تعذر قراءة نتيجة التسميع. حاول مجدداً.',
  'quran-data':'تعذر تحميل كلمات القرآن للتسميع. أعد فتح صفحة القرآن وحاول مجدداً.',
  'missing-page':'لم تتجهز صفحة القرآن للتسميع بعد. انتظر ظهور الآيات ثم حاول مجدداً.',
  'startup-error':'تعذر تجهيز التسميع. أعد فتح صفحة القرآن وحاول مجدداً.',
  'audio-gap':'انقطع الصوت أثناء التسجيل. اضغط الميكروفون للاستئناف.',
  'audio-format':'تعذر تجهيز الصوت للتسميع. حاول مجدداً.',
  'audio-window-full':'خذ وقفة قصيرة، ثم اضغط الميكروفون لاستئناف التسميع.',
  'recognition-uncertain':'لم تتضح الكلمات الأخيرة. أعد المقطع الأخير لمتابعة التسميع.',
  'low-confidence':'لم تتضح الكلمات الأخيرة. أعد المقطع الأخير لمتابعة التسميع.',
  'permission-denied':'اسمح باستخدام الميكروفون من إعدادات الجهاز.',
  'unavailable':'التسجيل الصوتي غير متاح. حدّث التطبيق وحاول مجدداً.',
  'network':'تعذر الاتصال بخدمة التعرف على الكلام. تحقق من الإنترنت وحاول مجدداً.',
  'language-not-supported':'خدمة التعرف على الكلام لا تدعم العربية على هذا الجهاز.',
  'language-unavailable':'نزّل دعم اللغة العربية في خدمة التعرف على الكلام ثم حاول مجدداً.',
  'audio-error':'تعذر استخدام الميكروفون. أغلق التطبيقات التي تستخدمه وحاول مجدداً.',
  'audio-capture':'تعذر استخدام الميكروفون. حاول مجدداً.',
  'background':'توقف التسميع عند مغادرة التطبيق.',
  'interrupted':'توقف التسميع بسبب مقاطعة الصوت. اضغط الميكروفون للاستئناف.'
};
export function speechErrorMessage(code) { return ERROR_MESSAGES[code] || 'تعذر إكمال التعرف على الكلام. اضغط الميكروفون لإعادة المحاولة.'; }
export function contiguousRecitationCounts(index, baseCounts, startPage, acceptedWords) {
  const result = {...baseCounts};
  for (const word of acceptedWords) {
    const count = result[word.page] ?? (word.page < startPage ? Infinity : 0);
    if (word.pageWordIndex === count) result[word.page] = count + (word.revealUnits || 1);
  }
  return result;
}
function revealIds(state) {
  const result = new Set();
  for (const word of state?.acceptedWords || []) {
    result.add(word.id);
    for (let step=1;step<(word.revealUnits || 1);step++) result.add(`${word.verseKey}:${word.position+step}`);
  }
  return result;
}

export class QuranRecitationController {
  constructor({loadDocument, getContext, onChange, adapter, now = () => Date.now()}) {
    this.loadDocument=loadDocument; this.getContext=getContext; this.onChange=onChange; this.adapter=adapter; this.now=now;
    this.generation=0; this.revision=0; this.active=false; this.phase='idle'; this.requestId=''; this.error=''; this.errorCode=''; this.errorStage='';
    this.matcher=null; this.index=null; this.match=null; this.revealed=new Set(); this.followPage=null; this.autoPages=new Set();
    this.baseCounts={}; this.baseStart=1; this.baseRevealed=new Set(); this.pendingStart=false; this.disposed=false;
    this.finalMismatch=false; this.mismatchCandidate=null; this.completionCandidate=null;
    this.paintKeys=new Map(); this.dirtyPages=new Set(); this.lastPainted=null;
  }
  snapshot() {
    const word=this.match?.partialWord ? this.index?.byId.get(this.match.partialWord.id) : this.match?.waiting ? this.match.nextWord : this.match?.lastAccepted;
    return {active:this.active, phase:this.phase, error:this.error, errorCode:this.errorCode, errorStage:this.errorStage, waiting:!!this.match?.waiting && this.finalMismatch,
      verseKey:this.active ? word?.verseKey || this.match?.nextWord?.verseKey || null : null,
      wordId:this.active ? word?.id || null : null, revision:this.revision, revealed:this.revealed,
      match:this.match,paintKeys:this.paintKeys};
  }
  publish() {
    this.revision++;
    const state=this.snapshot(),old=this.lastPainted;
    if (!old || old.verseKey!==state.verseKey || old.wordId!==state.wordId || old.waiting!==state.waiting) {
      for(const verseKey of [old?.verseKey,state.verseKey]) {
        let index=this.index?.verseStarts.get(verseKey);
        if(index==null)continue;
        while(this.index.words[index]?.verseKey===verseKey)this.dirtyPages.add(this.index.words[index++].page);
      }
    }
    if(this.dirtyPages.size) {
      this.paintKeys=new Map(this.paintKeys);
      for(const page of this.dirtyPages)this.paintKeys.set(page,this.revision);
      this.dirtyPages.clear();
    }
    this.lastPainted=state;
    if (!this.disposed) this.onChange(this.snapshot());
  }
  wordHidden(word, defaultHidden) { return defaultHidden && !this.revealed.has(`${word.verse_key}:${word.position}`); }
  async start() {
    if (this.disposed || this.active || this.pendingStart) return false;
    if (!this.adapter) { this.errorCode='unavailable'; this.errorStage='microphone'; this.error=speechErrorMessage('unavailable'); this.phase='error'; this.publish(); return false; }
    const generation=++this.generation;
    this.pendingStart=true; this.phase='loading'; this.error=''; this.errorCode=''; this.errorStage=''; this.publish();
    let stage='service';
    try {
      await this.adapter.prepare?.();
      if(this.disposed || generation!==this.generation)return false;
      stage='quran-data';
      const index=await loadRecitationIndex(this.loadDocument);
      if (this.disposed || generation!==this.generation) return false;
      stage='page';
      const context=this.getContext();
      const page=context.getVisiblePage?.() || context.data;
      if (!page || !Number.isInteger(page.page) || !index.pages.has(page.page) || !index.words.length) throw Object.assign(new Error('missing-page'),{code:'missing-page'});
      const pageWords=index.words.filter(word=>word.page===page.page);
      let first;
      // Continue a stopped session only when its next word still belongs to the
      // current page. A navigation/reset always clears the old checkpoint.
      if (this.match?.nextWord?.page===page.page) first=this.match.nextWord;
      const navigationVerse=context.navigationVerse?.();
      if (!first && navigationVerse) first=pageWords.find(word=>word.verseKey===navigationVerse);
      if (!first && context.hidden) {
        const count=context.counts?.[page.page] ?? (page.page<context.startPage ? Infinity : 0);
        first=pageWords.find(word=>word.pageWordIndex>=count && !this.revealed.has(word.id));
      }
      if (!first && !context.hidden) {
        const visibleId=context.firstVisibleWord?.(page.page);
        first=index.byId.get(visibleId) || pageWords[0];
      }
      if (!first) { this.pendingStart=false; this.phase='idle'; this.error='لا توجد كلمات مخفية متبقية في هذه الصفحة.'; this.publish(); return false; }
      this.index=index; this.matcher=new QuranRecitationMatcher(index,{index:first.index,allowPreamble:true});
      this.match=this.matcher.getState(); this.finalMismatch=false; this.mismatchCandidate=null; this.completionCandidate=null;
      this.baseCounts={...(context.counts || {})}; this.baseStart=context.startPage || page.page;
      this.baseRevealed=new Set(this.revealed);
      this.active=true; this.pendingStart=false; this.phase='starting';
      this.requestId=`quran-${this.now()}-${generation}`; this.followPage=page.page;
      this.publish(); stage='microphone'; this.adapter.start(this.requestId); return this.active;
    } catch (error) {
      if (generation!==this.generation || this.disposed) return false;
      this.pendingStart=false; this.active=false; this.requestId=''; this.phase='error';
      this.errorStage=stage;
      this.errorCode=typeof error?.code==='string' && Object.prototype.hasOwnProperty.call(ERROR_MESSAGES,error.code) ? error.code : (stage==='service'?'network':stage==='quran-data'?'quran-data':stage==='page'?'missing-page':stage==='microphone'?'audio-capture':'startup-error');
      this.error=speechErrorMessage(this.errorCode);
      try{this.adapter.stop();}catch(_){}
      this.publish(); return false;
    }
  }
  stop({clearReveal=false, error=''} = {}) {
    const wasListening=this.active || this.pendingStart;
    this.generation++; this.pendingStart=false; this.active=false; this.requestId=''; this.phase=error?'error':'idle'; this.error=error;
    if(!error){this.errorCode='';this.errorStage='';}
    this.autoPages.clear();this.finalMismatch=false;this.mismatchCandidate=null;this.completionCandidate=null;
    if (clearReveal) {
      for(const id of this.revealed){const word=this.index?.byId.get(id);if(word)this.dirtyPages.add(word.page);}
      this.revealed=new Set(); this.baseRevealed=new Set(); this.match=null; this.matcher=null; this.followPage=null;
    }
    if (wasListening) { try { this.adapter?.stop(); } catch (_) {} }
    this.publish();
  }
  receive(detail) {
    if (!this.active || detail?.requestId!==this.requestId) return;
    if (detail.state==='stopped') { this.stop(); return; }
    const uncertain=detail.uncertain===true;
    if(uncertain){this.finalMismatch=false;this.mismatchCandidate=null;this.completionCandidate=null;}
    if (detail.error && detail.error!=='no-match') {
      if (detail.recoverable===true || detail.state==='restarting' || detail.error==='recognition-uncertain' || detail.error==='low-confidence') {
        const recognitionUncertain=['recognition-uncertain','low-confidence'].includes(detail.error);
        if(recognitionUncertain){this.finalMismatch=false;this.mismatchCandidate=null;this.completionCandidate=null;}
        this.phase=detail.state==='listening'?'listening':'restarting';this.error=recognitionUncertain?speechErrorMessage(detail.error):'';this.publish();return;
      }
      this.errorCode=detail.error; this.errorStage='recording'; this.stop({error:speechErrorMessage(detail.error)}); return;
    }
    if (detail.state) this.phase=detail.state;
    if (!Object.prototype.hasOwnProperty.call(detail,'text') && !detail.isFinal) { this.publish(); return; }
    const isFinal=!!detail.isFinal && !uncertain;
    const next=this.matcher.ingest({utteranceId:detail.utteranceId ?? 1, text:detail.text || '', isFinal, emptyFinalRetracts:true});
    if (next.ignored) return;
    const tokens=tokenizeRecitation(detail.text || '');
    // A pause ends an acoustic window, not the cumulative transcript. Keep its
    // exact matcher checkpoint revisable while later audio clarifies the tail.
    this.adapter.setAlignment?.({utteranceId:detail.utteranceId ?? 1,
      // Retry boundaries can move error.tokenIndex beyond an earlier unresolved
      // word. Preserve its actual audio until the gate or letter group clears.
      tokenLimit:next.waiting || next.partialWord ? 0 : tokens.length});
    const evidence=Number.isSafeInteger(detail.evidenceSequence) && detail.evidenceSequence>0 ? detail.evidenceSequence : null;
    if (next.waiting && !uncertain) {
      const key=JSON.stringify([String(detail.utteranceId ?? 1),next.error.expected.id,
        next.error.tokenIndex,next.error.heardNormalized]);
      if(this.mismatchCandidate?.key!==key)this.mismatchCandidate={key,evidence:new Set()};
      if(evidence!==null && this.mismatchCandidate.evidence.size<2)this.mismatchCandidate.evidence.add(evidence);
      // One interrupted or uncertain recognition result must not be presented
      // as a confirmed recitation mistake. Distinct audio responses must agree.
      this.finalMismatch=isFinal || (!!detail.segmentEnded && this.mismatchCandidate.evidence.size>=2);
    } else {
      this.mismatchCandidate=null;this.finalMismatch=false;
    }
    let completionConfirmed=!uncertain && (isFinal || !!detail.segmentEnded);
    if(next.complete && !uncertain) {
      const key=JSON.stringify([String(detail.utteranceId ?? 1),tokens.map(token=>token.normalized)]);
      if(this.completionCandidate?.key!==key)this.completionCandidate={key,evidence:new Set()};
      if(evidence!==null && this.completionCandidate.evidence.size<2)this.completionCandidate.evidence.add(evidence);
      completionConfirmed ||= this.completionCandidate.evidence.size>=2;
    } else this.completionCandidate=null;
    for(const word of [...next.accepted,...next.rolledBack])this.dirtyPages.add(word.page);
    this.match=next; this.error=''; this.revealed=new Set([...this.baseRevealed,...revealIds(next)]);
    const context=this.getContext();
    if (context.hidden) context.setCounts?.(contiguousRecitationCounts(this.index,this.baseCounts,this.baseStart,next.acceptedWords));
    this.publish();
    if (next.complete && completionConfirmed) { this.stop(); return; }
    const page=next.nextWord?.page;
    if (page && page!==this.followPage) {
      this.followPage=page;
      this.autoPages.add(page);
      const generation=this.generation;
      Promise.resolve(context.navigatePage?.(page)).then(ok=>{
        this.autoPages.delete(page);
        if (generation===this.generation && page===this.followPage && this.active && ok===false) this.stop({error:'تعذر الانتقال للصفحة التالية. اضغط الميكروفون لإعادة المحاولة.'});
      }).catch(()=>{this.autoPages.delete(page);if(generation===this.generation && page===this.followPage && this.active)this.stop({error:'تعذر الانتقال للصفحة التالية.'});});
    }
  }
  dispose() { this.disposed=true; this.stop({clearReveal:true}); }
}

export function firstVisibleReadingWord(pageNumber, root=document) {
  const reader=root.querySelector('.qcf1441-preview');
  if (!reader) return null;
  const bounds=reader.getBoundingClientRect();
  const words=reader.querySelectorAll(`[data-reading-page="${pageNumber}"] [data-reading-word][data-word-type="word"]`);
  for (const word of words) {
    if (word.closest('.munibin-quran-horizontal-warm-pages, .munibin-quran-font-preview')) continue;
    const pane=word.closest('.munibin-quran-horizontal-page, .munibin-quran-spread-sheet');
    if (pane && !pane.classList.contains('is-active')) continue;
    const box=word.getBoundingClientRect();
    if (box.height>0 && box.bottom>bounds.top+55 && box.top<bounds.bottom-75 && box.right>bounds.left && box.left<bounds.right) return word.dataset.readingWord;
  }
  return null;
}
export function paintRecitation(root, state, wordHidden) {
  if (!root) return;
  const previous=root.querySelectorAll('.qcf1441-glyph-word--mic-verse, .qcf1441-glyph-word--mic-current, .qcf1441-glyph-word--mic-blocked');
  for (const word of previous) {
    const active=state.active && word.dataset.verseKey===state.verseKey;
    word.classList.toggle('qcf1441-glyph-word--mic-verse',active);
    word.classList.toggle('qcf1441-glyph-word--mic-current',state.active && word.dataset.readingWord===state.wordId);
    word.classList.toggle('qcf1441-glyph-word--mic-blocked',state.active && state.waiting && word.dataset.readingWord===state.wordId);
  }
  if (state.active && state.verseKey) {
    for (const word of root.querySelectorAll(`[data-verse-key="${state.verseKey}"][data-reading-word]`)) {
      word.classList.add('qcf1441-glyph-word--mic-verse');
      word.classList.toggle('qcf1441-glyph-word--mic-current',word.dataset.readingWord===state.wordId);
      word.classList.toggle('qcf1441-glyph-word--mic-blocked',state.waiting && word.dataset.readingWord===state.wordId);
    }
  }
  // Native spread pages have their own DOM renderer. Apply the same reveal
  // decisions there without replacing glyphs, font layers, or page geometry.
  for (const word of root.querySelectorAll('.munibin-quran-spread-sheet [data-reading-word]')) {
    const page=Number(word.closest('[data-reading-page]')?.dataset.readingPage);
    const hidden=wordHidden?.(word.dataset.readingWord,page);
    if (hidden==null) continue;
    word.classList.toggle('qcf1441-glyph-word--memorization-hidden',hidden);
    word.setAttribute('aria-label',hidden?'كلمة مخفية في وضع الحفظ':`اضغط مطولاً لخيارات الآية ${word.dataset.verseKey}`);
    if (hidden) { word.setAttribute('aria-hidden','true'); word.tabIndex=-1; }
    else { word.removeAttribute('aria-hidden'); word.removeAttribute('tabindex'); }
  }
  window.__munibinQuranReading?.syncReadingHighlights?.(root);
}

export function createQuranRecitationComponents(React) {
  const h=React.createElement;
  function useRecitation(options) {
    const live=React.useRef(options); live.current=options;
    const [state,setState]=React.useState({active:false,phase:'idle',error:'',waiting:false,revision:0,revealed:new Set(),paintKeys:new Map()});
    const ref=React.useRef(null);
    if (!ref.current) ref.current=new QuranRecitationController({
      loadDocument:()=>live.current.loadDocument(), getContext:()=>live.current,
      onChange:setState, adapter:nativeSpeechAdapter()
    });
    const controller=ref.current;
    const previous=React.useRef({hidden:options.hidden,mode:options.mode,page:options.page});
    React.useEffect(()=>{
      const receive=event=>controller.receive(event.detail);
      const suspend=()=>{if(document.visibilityState==='hidden')controller.stop();};
      const jump=()=>controller.stop({clearReveal:true});
      const pagehide=()=>controller.stop();
      window.addEventListener('munibin-native-speech',receive);
      window.addEventListener('munibin-quran-navigation-target',jump);
      window.addEventListener('pagehide',pagehide);
      document.addEventListener('visibilitychange',suspend);
      return ()=>{
        window.removeEventListener('munibin-native-speech',receive);
        window.removeEventListener('munibin-quran-navigation-target',jump);
        window.removeEventListener('pagehide',pagehide);
        document.removeEventListener('visibilitychange',suspend); controller.dispose();
      };
    },[]);
    React.useEffect(()=>{
      const old=previous.current;
      previous.current={hidden:options.hidden,mode:options.mode,page:options.page};
      if (old.hidden!==options.hidden || old.mode!==options.mode) controller.stop({clearReveal:true});
      else if(old.page!==options.page && options.page!==controller.followPage && !controller.autoPages.has(options.page)) controller.stop({clearReveal:true});
    },[options.hidden,options.mode,options.page]);
    React.useLayoutEffect(()=>{
      const reader=document.querySelector('.qcf1441-preview');
      if (!reader) return;
      let frame=0,disposed=false;
      const paint=()=>{
        frame=0;if(disposed)return;
        paintRecitation(reader,controller.snapshot(),(id,page)=>{
          if (!live.current.hidden) return false;
          if (controller.revealed.has(id)) return false;
          const word=controller.index?.byId.get(id);
          if (!word) return null;
          const count=live.current.counts?.[page] ?? (page<live.current.startPage ? Infinity:0);
          return word.pageWordIndex>=count && !controller.revealed.has(id);
        });
      };
      const schedule=()=>{if(!frame)frame=requestAnimationFrame(paint);};
      paint();
      const observer=new MutationObserver(records=>{
        if(records.some(record=>record.type==='childList' && [...record.addedNodes,...record.removedNodes].some(node=>node.nodeType===1 && !node.classList?.contains('munibin-quran-verse-band'))))schedule();
      });
      observer.observe(reader,{subtree:true,childList:true});
      window.addEventListener('munibin-quran-view-change',schedule);
      window.addEventListener('munibin-quran-memorization-change',schedule);
      window.addEventListener('munibin-global-audio-state',schedule);
      return ()=>{disposed=true;observer.disconnect();cancelAnimationFrame(frame);window.removeEventListener('munibin-quran-view-change',schedule);window.removeEventListener('munibin-quran-memorization-change',schedule);window.removeEventListener('munibin-global-audio-state',schedule);};
    },[state.revision,options.hidden,options.counts,options.page]);
    const toggle=()=>{
      if(controller.active || controller.pendingStart)controller.stop();
      else {live.current.stopPlayback?.();void controller.start();}
    };
    return {...state,toggle,stop:settings=>controller.stop(settings),
      wordHidden:(word,defaultHidden)=>controller.wordHidden(word,defaultHidden),
      controller};
  }
  function Microphone({recitation}) {
    if (!SHOW_QURAN_RECITATION_MIC) return null;
    const busy=['loading','starting','restarting'].includes(recitation.phase);
    const label=recitation.active || busy?'إيقاف التسميع':'بدء التسميع بالميكروفون';
    const message=recitation.error || (recitation.waiting?'لم تتضح الكلمة التالية. أعد المقطع الأخير للمتابعة':busy?'يجري تجهيز الميكروفون…':'');
    return h(React.Fragment,null,
      h('button',{type:'button',className:'qcf1441-recitation-mic'+(recitation.active || busy?' is-listening':''),
        'aria-label':label,title:label,'aria-pressed':recitation.active || busy,
        onClick:event=>{event.stopPropagation();recitation.toggle();},
        onPointerDown:event=>event.stopPropagation(),onPointerUp:event=>event.stopPropagation()},
        h('svg',{viewBox:'0 0 24 24',width:19,height:19,'aria-hidden':'true',fill:'none',stroke:'currentColor',strokeWidth:1.8,strokeLinecap:'round',strokeLinejoin:'round'},
          h('rect',{x:9,y:2,width:6,height:12,rx:3}),h('path',{d:'M5 10v2a7 7 0 0 0 14 0v-2M12 19v3m-4 0h8'}))),
      message?h('div',{className:'qcf1441-recitation-status',role:'status','aria-live':'polite',dir:'rtl'},message):null);
  }
  return {useRecitation,Microphone};
}
