/* Short-lived navigation emphasis, independent of playback and memorization.
   The timer begins when the destination's ink is mounted in the active page. */
export const NAVIGATION_HIGHLIGHT_DURATION = 2000;
export const NAVIGATION_HIGHLIGHT_CLASS = 'qcf1441-glyph-word--navigation';

export function navigationVerseKey(value) {
  const key = typeof value === 'string' ? value : `${value?.surah}:${value?.ayah}`;
  if (!/^\d{1,3}:\d{1,3}$/.test(key)) return null;
  const [surah, ayah] = key.split(':').map(Number);
  return surah >= 1 && surah <= 114 && ayah >= 1 && ayah <= 286 ? `${surah}:${ayah}` : null;
}

function pageNumber(value) {
  const number = Number(value);
  return Number.isInteger(number) && number >= 1 && number <= 604 ? number : null;
}

export function navigationWordIsMounted(node, request, reader) {
  if (node.dataset.verseKey !== request.verseKey) return false;
  if (node.closest('.munibin-quran-horizontal-warm-pages, .munibin-quran-font-preview')) return false;
  const pane = node.closest('.munibin-quran-horizontal-page');
  if (pane && !pane.classList.contains('is-active')) return false;
  const sheet = node.closest('.munibin-quran-spread-sheet');
  if (sheet && !sheet.matches('.is-active, .is-turn-target')) return false;
  const page = Number(node.closest('[data-reading-page]')?.dataset.readingPage);
  if (request.page && page !== request.page && request.startedAt == null) return false;
  if (typeof getComputedStyle === 'function' && getComputedStyle(node).visibility === 'hidden') return false;
  const rect = node.getBoundingClientRect(), bounds = reader.getBoundingClientRect();
  if (!(rect.width > 0 && rect.height > 0 && rect.right > bounds.left && rect.left < bounds.right)) return false;
  // A zoomed target can sit below its page viewport. It is ready for emphasis
  // after scrolling that viewport, without waiting for an already-visible word.
  const scroller = node.closest('.munibin-quran-horizontal-page-scroll, .munibin-quran-vertical-pages, .munibin-quran-leaf-viewport');
  return !!scroller || rect.bottom > bounds.top && rect.top < bounds.bottom;
}

function scrollToNavigationWord(node) {
  const scroller = node.closest('.munibin-quran-horizontal-page-scroll, .munibin-quran-vertical-pages, .munibin-quran-leaf-viewport');
  if (!scroller || !(scroller.scrollHeight > scroller.clientHeight + 1)) return;
  const rect = node.getBoundingClientRect(), bounds = scroller.getBoundingClientRect();
  const margin = Math.min(80, bounds.height * .18);
  if (rect.top >= bounds.top + margin && rect.bottom <= bounds.bottom - margin) return;
  // Move only the Quran's vertical viewport; scrollIntoView can also move the
  // horizontal document and select a neighboring page in WebKit.
  const top = scroller.scrollTop + rect.top - bounds.top - margin;
  const previous = scroller.style.scrollBehavior;
  scroller.style.scrollBehavior = 'auto';
  scroller.scrollTop = Math.max(0, Math.min(scroller.scrollHeight - scroller.clientHeight, top));
  scroller.style.scrollBehavior = previous;
}

export function createNavigationHighlightController(reader, options = {}) {
  const clock = options.now || (() => performance.now());
  const frame = options.requestFrame || (callback => requestAnimationFrame(callback));
  const cancelFrame = options.cancelFrame || (id => cancelAnimationFrame(id));
  const later = options.setTimer || ((callback, delay) => setTimeout(callback, delay));
  const cancelTimer = options.clearTimer || (id => clearTimeout(id));
  const repaint = options.repaint || (() => window.__munibinQuranReading?.syncReadingHighlights?.(reader));
  const mounted = options.mounted || (node => navigationWordIsMounted(node, desired, reader));
  const scroll = options.scroll || scrollToNavigationWord;
  let desired = null, paintFrame = 0, expiryTimer = 0, disposed = false;

  const words = () => Array.from(reader.querySelectorAll('.qcf1441-glyph-word[data-verse-key]'));
  const erase = () => {
    for (const word of reader.querySelectorAll(`.${NAVIGATION_HIGHLIGHT_CLASS}`)) word.classList.remove(NAVIGATION_HIGHLIGHT_CLASS);
    repaint();
  };
  const clear = () => {
    desired = null;
    if (expiryTimer) cancelTimer(expiryTimer);
    expiryTimer = 0;
    if (paintFrame) cancelFrame(paintFrame);
    paintFrame = 0;
    erase();
  };
  const paint = () => {
    paintFrame = 0;
    if (disposed || !desired) return;
    let candidates = words().filter(mounted);
    if (!candidates.length) return;
    if (desired.startedAt === null) {
      scroll(candidates[0]);
      desired.startedAt = clock();
      if (expiryTimer) cancelTimer(expiryTimer);
      expiryTimer = later(clear, NAVIGATION_HIGHLIGHT_DURATION);
      // An ayah can continue onto the second visible book leaf. After the
      // target page is confirmed, emphasize its mounted continuation as well.
      candidates = words().filter(mounted);
    }
    const selected = new Set(candidates);
    for (const word of words()) word.classList.toggle(NAVIGATION_HIGHLIGHT_CLASS, selected.has(word));
    // Hidden words keep their existing opacity, accessibility and tab-index.
    // The shared band renderer omits them, so navigation cannot reveal answers.
    repaint();
  };
  const schedule = () => {
    if (!disposed && desired && !paintFrame) paintFrame = frame(paint);
  };
  const request = (value, page) => {
    const verseKey = navigationVerseKey(value);
    if (!verseKey || disposed) return false;
    clear();
    desired = {verseKey, page: pageNumber(page), startedAt: null};
    // Bound an abandoned/failed jump while allowing asynchronous page/font load.
    expiryTimer = later(clear, 15000);
    schedule();
    return true;
  };
  const Observer = options.MutationObserver || globalThis.MutationObserver;
  const observer = Observer ? new Observer(records => {
    if (records.some(record => {
      const target = record.target?.nodeType === 3 ? record.target.parentElement : record.target;
      if (target?.closest?.('.munibin-quran-verse-band')) return false;
      if (record.type === 'childList') {
        const nodes = [...record.addedNodes, ...record.removedNodes];
        if (nodes.length && nodes.every(node => node.classList?.contains('munibin-quran-verse-band'))) return false;
      }
      return true;
    })) schedule();
  }) : null;
  observer?.observe(reader, {subtree: true, childList: true, attributes: true, attributeFilter: ['class', 'style', 'data-verse-key', 'data-reading-page']});
  reader.addEventListener('scroll', schedule, true);
  const owner = options.owner || globalThis.window;
  owner?.addEventListener('resize', schedule, {passive: true});
  const dispose = () => {
    disposed = true;
    observer?.disconnect();
    reader.removeEventListener('scroll', schedule, true);
    owner?.removeEventListener('resize', schedule);
    clear();
  };
  return {request, clear, dispose, schedule, state: () => desired ? {...desired} : null};
}

let controller = null, pending = null, lastTarget = null;
export function getLastNavigationTarget() {
  return lastTarget ? {...lastTarget} : null;
}
export function requestNavigationHighlight(value, page) {
  const verseKey = navigationVerseKey(value);
  if (!verseKey) return false;
  lastTarget = {verseKey, page: pageNumber(page)};
  if (typeof window !== 'undefined') {
    const EventClass = window.CustomEvent || globalThis.CustomEvent;
    if (typeof EventClass === 'function') window.dispatchEvent(new EventClass('munibin-quran-navigation-target', {detail: getLastNavigationTarget()}));
  }
  if (controller) return controller.request(verseKey, page);
  pending = getLastNavigationTarget();
  return true;
}
export function clearNavigationHighlight() {
  pending = null; lastTarget = null;
  controller?.clear();
}
export function observeNavigationHighlights(reader) {
  controller?.dispose();
  const active = createNavigationHighlightController(reader);
  controller = active;
  if (pending) {
    active.request(pending.verseKey, pending.page);
    pending = null;
  }
  return () => {
    active.dispose();
    if (controller === active) {controller = null; pending = null; lastTarget = null;}
  };
}
if (typeof window !== 'undefined') {
  window.__munibinQuranNavigationHighlight = {request: requestNavigationHighlight, clear: clearNavigationHighlight, target: getLastNavigationTarget};
}
