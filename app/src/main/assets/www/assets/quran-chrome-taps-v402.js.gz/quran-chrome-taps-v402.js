/* Native Quran chrome buttons activate on a completed touch, without waiting
   for the WebView's compatibility click. Page gestures, form fields, modal
   controls, mouse/keyboard clicks and the chrome animation remain unchanged. */
const installations = new WeakMap();
const BUTTONS = '.qcf1441-preview-header button, .qcf1441-background-player button, .qcf1441-memorization-player button';
const MODALS = '[role="dialog"], [aria-modal="true"], dialog, .munibin-choice-overlay';
const FIELDS = 'select, input, textarea, [contenteditable="true"], [role="slider"]';
const MAX_MOVE = 8;
const MAX_TAP_MS = 500;
const GHOST_MS = 700;
const GHOST_RADIUS = 12;

function isNative(target) {
  return target.__munibinNativeApp === true ||
    target.__munibinNativePlatform === 'android' || target.__munibinNativePlatform === 'ios' ||
    !!target.MunibinAndroid;
}

function element(node) {
  return typeof node?.closest === 'function' ? node : node?.parentElement;
}

/** Explicit installation is also available to controlled test harnesses.
 * Returns an idempotent disposer; repeated installations on one document share
 * the same listeners. No timers or asynchronous activation are used. */
export function installQuranChromeTaps(target = window) {
  const document = target.document;
  if (!document?.addEventListener || !document?.removeEventListener) return () => {};
  const existing = installations.get(document);
  if (existing) return existing;
  const now = () => target.performance?.now?.() ?? Date.now();
  let disposed = false;
  let pending = null;
  let ghost = null;
  let dispatchingOwnClick = false;

  function buttonFrom(node) {
    const source = element(node);
    if (document.hidden || !source || source.closest(FIELDS) || source.closest(MODALS)) return null;
    const button = source.closest(BUTTONS);
    if (!button || !button.isConnected || button.disabled || button.matches?.(':disabled') ||
        button.closest('fieldset[disabled], [inert]')) return null;
    if (button.ownerDocument && button.ownerDocument !== document) return null;
    const reader = button.closest('.qcf1441-preview');
    if (!reader || !reader.isConnected || reader.classList.contains('qcf1441-preview--chrome-hidden')) return null;
    for (let node = button; node; node = node.parentElement) {
      if (node.hidden || node.inert || node.getAttribute?.('aria-hidden') === 'true' || node.getAttribute?.('aria-disabled') === 'true') return null;
      const style = target.getComputedStyle?.(node);
      if (style && (style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse' ||
          Number.parseFloat(style.opacity) === 0 || (node === button && style.pointerEvents === 'none'))) return null;
    }
    return button;
  }

  function inside(button, touch) {
    const box = button.getBoundingClientRect?.();
    return !!box && box.width > 0 && box.height > 0 &&
      Number.isFinite(touch.clientX) && Number.isFinite(touch.clientY) &&
      touch.clientX >= box.left && touch.clientX <= box.right &&
      touch.clientY >= box.top && touch.clientY <= box.bottom;
  }

  function changedTouch(event, id) {
    return Array.from(event.changedTouches || []).find(touch => touch.identifier === id);
  }

  function onStart(event) {
    // A genuine new touch never inherits a previous compatibility-click guard.
    ghost = null;
    pending = null;
    if (disposed || event.defaultPrevented || event.touches?.length !== 1) return;
    const touch = event.changedTouches?.[0];
    const button = buttonFrom(event.target);
    if (!touch || !button || !inside(button, touch)) return;
    const scroll = [];
    for (let node = button.parentElement; node; node = node.parentElement) {
      scroll.push({node, top: node.scrollTop || 0, left: node.scrollLeft || 0});
    }
    pending = {button, id: touch.identifier, x: touch.clientX, y: touch.clientY, started: now(), moved: false, scroll};
  }

  function onMove(event) {
    if (!pending) return;
    if (event.touches?.length !== 1) { pending = null; return; }
    const touch = changedTouch(event, pending.id);
    if (touch && Math.hypot(touch.clientX - pending.x, touch.clientY - pending.y) > MAX_MOVE) pending.moved = true;
  }

  function onEnd(event) {
    const tap = pending;
    if (!tap || disposed) return;
    const touch = changedTouch(event, tap.id);
    if (!touch) return;
    pending = null;
    if (event.defaultPrevented || event.touches?.length || tap.moved || now() - tap.started > MAX_TAP_MS ||
        Math.hypot(touch.clientX - tap.x, touch.clientY - tap.y) > MAX_MOVE ||
        tap.scroll.some(s => Math.abs((s.node.scrollTop || 0) - s.top) > 2 || Math.abs((s.node.scrollLeft || 0) - s.left) > 2)) return;
    // Hit-test the current painted pose, not a cached endpoint or the original
    // child target: the header/footer may still be moving underneath the finger.
    if (typeof document.elementFromPoint !== 'function') return;
    const hit = document.elementFromPoint(touch.clientX, touch.clientY);
    if (buttonFrom(hit) !== tap.button || !inside(tap.button, touch)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    ghost = {button: tap.button, x: touch.clientX, y: touch.clientY, until: now() + GHOST_MS};
    dispatchingOwnClick = true;
    try {
      tap.button.click();
    } finally {
      dispatchingOwnClick = false;
    }
  }

  function onCancel() { pending = null; }

  function onMousePointer(event) {
    // Real mouse/pen input is not a delayed touch compatibility click.
    if (event.pointerType === 'mouse' || event.pointerType === 'pen') ghost = null;
  }

  function onClick(event) {
    if (disposed || dispatchingOwnClick || !ghost) return;
    if (now() > ghost.until) { ghost = null; return; }
    if (event.detail === 0 || event.isTrusted === false || event.pointerType === 'mouse' ||
        event.pointerType === 'pen' || event.sourceCapabilities?.firesTouchEvents === false) return;
    const sameButton = event.target === ghost.button || ghost.button.contains?.(event.target);
    const samePoint = Number.isFinite(event.clientX) && Number.isFinite(event.clientY) &&
      Math.hypot(event.clientX - ghost.x, event.clientY - ghost.y) <= GHOST_RADIUS;
    if (!sameButton && !samePoint) return;
    ghost = null;
    event.preventDefault();
    event.stopImmediatePropagation();
  }

  const listeners = [
    ['touchstart', onStart, true], ['touchmove', onMove, true],
    ['touchend', onEnd, false], ['touchcancel', onCancel, true],
    ['pointerdown', onMousePointer, true], ['click', onClick, false]
  ];
  for (const [name, listener, passive] of listeners) document.addEventListener(name, listener, {capture: true, passive});
  const uninstall = () => {
    if (disposed) return;
    disposed = true;
    pending = null;
    ghost = null;
    for (const [name, listener] of listeners) document.removeEventListener(name, listener, true);
    installations.delete(document);
  };
  installations.set(document, uninstall);
  return uninstall;
}

if (typeof window !== 'undefined' && isNative(window)) installQuranChromeTaps(window);
