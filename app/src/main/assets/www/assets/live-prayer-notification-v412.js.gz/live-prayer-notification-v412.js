import { normalizePrayerTimeFormat, readPrayerTimeFormat, formatPrayerHijriDate, prayerDisplayDayForInstant } from './prayer-display-v423.js';
const STATUS_EVENT = 'munibin-live-prayer-status';
const RESUME_EVENT = 'munibin-native-resume';
const settingsComponents = new WeakMap();

export function isAndroidPrayerBridge() {
  return typeof window !== 'undefined' && !!window.MunibinAndroid?.publishPrayerWidgetSnapshot;
}

function bridge() {
  return isAndroidPrayerBridge() ? window.MunibinAndroid : null;
}

export function normalizePrayerLiveStatus(raw) {
  try {
    const value = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    return {
      ...value,
      enabled: value.enabled === true,
      notificationPermission: (value.notificationPermission ?? value.permission) === true,
      channelEnabled: (value.channelEnabled ?? value.permission) === true,
      configured: value.configured === true,
      cacheReady: (value.cacheReady ?? value.available) === true,
      active: (value.active ?? (value.reason === 'running')) === true,
      exactAlarms: (value.exactAlarms ?? value.exactAlarm) === true,
      notchEnabled: value.notchEnabled === true,
      overlayPermission: value.overlayPermission === true,
      notchRunning: value.notchRunning === true,
      notchSupported: value.notchSupported === true,
    };
  } catch { return null; }
}

export function readPrayerLiveStatus() {
  try { return normalizePrayerLiveStatus(bridge()?.getLivePrayerNotificationStatus?.()); }
  catch { return null; }
}

function nativeCall(name, ...args) {
  try {
    const native = bridge();
    if (typeof native?.[name] !== 'function') return false;
    native[name](...args);
    return true;
  } catch { return false; }
}

function makeSettingsComponent(React, jsx) {
  return function PrayerLiveSettings({ configured, light, accent, border, muted, text }) {
    const [status, setStatus] = React.useState(readPrayerLiveStatus);
    const [message, setMessage] = React.useState('');
    React.useEffect(() => {
      let alive = true;
      const read = () => {
        if (!alive) return;
        const next = readPrayerLiveStatus();
        if (next) setStatus(next);
        nativeCall('requestLivePrayerNotificationStatus');
      };
      const onStatus = event => {
        if (!alive) return;
        const next = normalizePrayerLiveStatus(event.detail);
        if (next) { setStatus(next); setMessage(''); }
      };
      const onVisible = () => { if (!document.hidden) read(); };
      window.addEventListener(STATUS_EVENT, onStatus);
      window.addEventListener(RESUME_EVENT, read);
      window.addEventListener('focus', read);
      document.addEventListener('visibilitychange', onVisible);
      read();
      return () => {
        alive = false;
        window.removeEventListener(STATUS_EVENT, onStatus);
        window.removeEventListener(RESUME_EVENT, read);
        window.removeEventListener('focus', read);
        document.removeEventListener('visibilitychange', onVisible);
      };
    }, []);
    React.useEffect(() => {
      const next = readPrayerLiveStatus();
      if (next) setStatus(next);
      nativeCall('requestLivePrayerNotificationStatus');
    }, [configured]);
    const action = (name, ...args) => {
      setMessage('');
      if (!nativeCall(name, ...args)) setMessage('تعذر تغيير الإعداد الآن. أعد فتح صفحة مواقيت الصلاة.');
      const next = readPrayerLiveStatus();
      if (next) setStatus(next);
    };
    const live = status || {};
    const isConfigured = live.configured ?? configured;
    const button = (label, onClick) => jsx.jsx('button', {
      type: 'button', onClick,
      className: 'rounded-xl border px-3 py-2 text-xs font-bold transition-transform active:scale-[0.98]',
      style: { color: accent, borderColor: border, background: 'var(--app-card-bg)' }, children: label,
    });
    const row = (title, enabled, onClick, disabled = false) => jsx.jsxs('div', {
      className: 'flex items-center justify-between gap-3',
      children: [jsx.jsx('span', { className: 'min-w-0 flex-1 text-sm font-bold', style: { color: text }, children: title }), jsx.jsx('button', {
        type: 'button', role: 'switch', 'aria-checked': !!enabled, 'aria-label': title,
        disabled, onClick,
        className: 'relative shrink-0 rounded-full transition-colors duration-200 disabled:opacity-50',
        style: { width: '48px', height: '28px', background: enabled ? accent : light ? 'rgba(161,98,7,0.06)' : 'rgba(255,255,255,0.055)', border: `1px solid ${enabled ? accent : border}` },
        children: jsx.jsx('span', { className: 'absolute rounded-full bg-white shadow-sm transition-transform duration-200', style: { top: '3px', width: '20px', height: '20px', right: enabled ? '3px' : '23px' } }),
      })],
    });
    const actions = [];
    if (live.enabled && (!live.notificationPermission || !live.channelEnabled)) actions.push(button('السماح بالإشعارات', () => action('requestLivePrayerNotificationSettings', 'notifications')));
    if (live.enabled && live.notificationPermission && live.channelEnabled && !live.exactAlarms) actions.push(button('السماح بالتحديث في وقت الصلاة', () => action('requestLivePrayerNotificationSettings', 'alarms')));
    const notchActions = [];
    if (live.notchEnabled && !live.overlayPermission) notchActions.push(button('السماح بالظهور فوق التطبيقات', () => action('requestPrayerNotchPermission')));
    else if (live.notchEnabled && live.notchReason === 'start-required' && isConfigured && live.notificationPermission) notchActions.push(button('تشغيل الشريط العائم', () => action('setPrayerNotchEnabled', true)));
    if (live.notchEnabled && live.notchReason === 'notifications') notchActions.push(button('السماح بالإشعارات', () => action('requestLivePrayerNotificationSettings', 'notifications')));
    return jsx.jsxs('div', {
      className: 'mb-3 rounded-3xl border p-3', dir: 'rtl',
      style: { background: 'var(--app-card-bg)', borderColor: border },
      children: [row('إشعار مواقيت الصلاة الدائم', live.enabled, () => action('setLivePrayerNotificationEnabled', !live.enabled)),
        actions.length ? jsx.jsx('div', { className: 'mt-3 flex flex-wrap gap-2', children: actions }) : null,
        live.notchSupported ? jsx.jsxs('div', { className: 'mt-3 border-t pt-3', style: { borderColor: border }, children: [
          row('الشريط العائم', live.notchEnabled, () => action('setPrayerNotchEnabled', !live.notchEnabled)),
          notchActions.length ? jsx.jsx('div', { className: 'mt-3 flex flex-wrap gap-2', children: notchActions }) : null,
        ] }) : null,
        message ? jsx.jsx('p', { role: 'alert', className: 'mt-3 text-xs leading-6', style: { color: light ? '#991b1b' : '#fca5a5' }, children: message }) : null],
    });
  };
}

export function renderLivePrayerSettings(React, jsx, props) {
  if (!isAndroidPrayerBridge() || typeof bridge()?.getLivePrayerNotificationStatus !== 'function') return null;
  let Component = settingsComponents.get(React);
  if (!Component) { Component = makeSettingsComponent(React, jsx); settingsComponents.set(React, Component); }
  return jsx.jsx(Component, props);
}

const ASCII_DIGITS = value => String(value ?? '').replace(/[٠-٩۰-۹]/g, char => String(char.charCodeAt(0) - (char <= '٩' ? 0x660 : 0x6f0)));
function dateKeyToIso(key) {
  const match = /^(\d{2})-(\d{2})-(\d{4})$/.exec(key);
  if (!match) return null;
  const [, day, month, year] = match;
  const date = new Date(Date.UTC(+year, +month - 1, +day));
  return date.getUTCFullYear() === +year && date.getUTCMonth() === +month - 1 && date.getUTCDate() === +day ? `${year}-${month}-${day}` : null;
}
function localKey(date) {
  return `${String(date.getDate()).padStart(2, '0')}-${String(date.getMonth() + 1).padStart(2, '0')}-${date.getFullYear()}`;
}
// Time-zone validity does not change between rows in an annual calendar.
// Cache both valid and invalid strings without retaining unbounded city input.
const livePrayerTimeZoneCache = new Map();
function validTimeZone(zone) {
  const cacheable = typeof zone === 'string';
  if (cacheable && livePrayerTimeZoneCache.has(zone)) return livePrayerTimeZoneCache.get(zone);
  let valid;
  try { new Intl.DateTimeFormat('en-US', { timeZone: zone }).format(0); valid = zone; }
  catch { valid = null; }
  if (cacheable) {
    livePrayerTimeZoneCache.set(zone, valid);
    if (livePrayerTimeZoneCache.size > 16) livePrayerTimeZoneCache.delete(livePrayerTimeZoneCache.keys().next().value);
  }
  return valid;
}

// Derive every event from its actual calendar date, including tomorrow's Fajr.
// Iqama is an elapsed offset from that prayer's real instant and may cross midnight.
export function buildLivePrayerSchedule(calendar, now, offsets, iqamaOffsets, location, scope, today, adjustTimings, dateEvents, preferredTimeFormat = readPrayerTimeFormat()) {
  if (!location || !(now instanceof Date) || !Number.isFinite(now.getTime())) return null;
  const currentKey = localKey(now);
  const cachedDays = calendar?.days || {};
  const days = { ...cachedDays };
  if (today?.timings && !days[currentKey]) days[currentKey] = today;
  const fallbackZone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  const requestedZone = today?.meta?.timezone || days[currentKey]?.meta?.timezone || Object.values(days).find(day => day?.meta?.timezone)?.meta.timezone || fallbackZone;
  const timeZone = validTimeZone(requestedZone) || validTimeZone(fallbackZone) || 'UTC';
  const zoneDay = dateKeyToIso(prayerDisplayDayForInstant(now, timeZone) || currentKey);
  const yesterday = new Date(`${zoneDay}T12:00:00Z`);
  yesterday.setUTCDate(yesterday.getUTCDate() - 1);
  const yesterdayIso = yesterday.toISOString().slice(0, 10);
  const timeFormat = normalizePrayerTimeFormat(preferredTimeFormat);
  const configurationKey = JSON.stringify({ scope: scope || 'guest', location, offsets: offsets || {}, iqamaOffsets: iqamaOffsets || {}, timeZone, timeFormat });
  const rows = Object.entries(days).map(([key, day]) => ({ key, day, date: dateKeyToIso(key) })).filter(row => row.date && row.date >= yesterdayIso).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 400);
  return { version: 1, timeZone, timeFormat, configurationKey, days: rows.flatMap(({ key, day, date }) => {
    if (!day?.timings || (day.meta?.timezone && (validTimeZone(day.meta.timezone) || timeZone) !== timeZone)) return [];
    const raw = Object.fromEntries(Object.entries(day.timings).map(([prayer, time]) => [prayer, ASCII_DIGITS(time)]));
    const timings = adjustTimings(raw, offsets || {});
    const events = dateEvents(key, timings, timeZone).flatMap(event => {
      const at = typeof event.at === 'number' ? event.at : Date.parse(event.at);
      const time = ASCII_DIGITS(event.time);
      if (!Number.isFinite(at) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) return [];
      const prayerKey = String(event.key).toLowerCase();
      if (!['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'].includes(prayerKey)) return [];
      const minutes = Number(iqamaOffsets?.[event.key] ?? iqamaOffsets?.[prayerKey] ?? 0);
      const iqamaAt = prayerKey === 'sunrise' || !Number.isFinite(minutes) || minutes <= 0 ? 0 : at + Math.floor(minutes) * 60000;
      return [{ key: prayerKey, label: event.label, time, at, iqamaAt }];
    });
    return events.length ? [{ date, hijriDate: formatPrayerHijriDate(day.date), events }] : [];
  }) };
}
