import {observeNavigationHighlights} from './quran-navigation-highlight-v400.js';
import {captureQuranChromeMotion,finishQuranChromeMotion} from './quran-chrome-motion-v389.js';
import {verticalPagePaintKey} from './quran-vertical-ink-v378.js';
import {createVerticalDocumentPages} from './quran-vertical-document-v389.js';
import {createAyahDocumentPages,normalizeReadingDirection,copyQuranVerse} from './quran-ayah-document-v425.js';
export {copyQuranVerse} from './quran-ayah-document-v425.js';
import {loadQuranDocument} from './quran-document-resources-v387.js';
export {loadQuranDocument,prepareQuranDocumentFonts} from './quran-document-resources-v387.js';
import {createQuranPinchScalePainter} from './quran-pinch-scale-v378.js';
/* Quran-specific, offline reading preferences. No app theme/font preference is changed. */
import { fitReadingPageLayout, spaceMushafRows, primeQuranReadingPage } from './quran-page-fit-v367.js';
import { createHorizontalPages } from './quran-horizontal-v388.js';
import { tajweedGuideEntries, TAJWEED_SOURCES } from './quran-tajweed-guide-v358.js';
import { createQuranColorSettings } from './quran-colors-v427.js';
export const READING_KEY = 'munibin:quran-reading:v1';
export const READING_EVENT = 'munibin-quran-reading-change';
export const QURAN_FONTS = [
  { id: 'qcf1441', label: 'مصحف المدينة ١٤٤١', detail: 'QCF 1441', family: null }
];
export const DEFAULT_READING = Object.freeze({ font: 'qcf1441', scale: 1, direction: 'horizontal', tajweed: false, spacing:'automatic', lineSpacing:100 });
// Only these reading preferences can affect geometry. Legacy or unknown
// storage/API fields are omitted from the normalized preferences.
export function sameReadingLayoutPreferences(previous,next) {
 return ['font','scale','direction','tajweed','spacing','lineSpacing'].every(key=>previous[key]===next[key]);
}
export const clampLineSpacing=value=>Math.round(Math.max(100,Math.min(200,Number(value)||100)));
export function lineSpacingFromInput(value,fallback=100) {
 const text=String(value).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[\s%٪]/g,'');
 return /^\d+$/.test(text)?clampLineSpacing(Number(text)):clampLineSpacing(fallback);
}
const clampScale = value => Math.round(Math.max(1, Math.min(2.4, Number(value) || 1)) * 100) / 100;
export function readReadingPreferences(storage = window.localStorage) {
  try {
    const saved = JSON.parse(storage.getItem(READING_KEY) || 'null');
    return {
      font: QURAN_FONTS.some(font => font.id === saved?.font) ? saved.font : DEFAULT_READING.font,
      scale: clampScale(saved?.scale),
      direction: normalizeReadingDirection(saved?.direction),
      tajweed: saved?.tajweed === true,
      spacing:['fixed','automatic','fullscreen'].includes(saved?.spacing)?saved.spacing:'automatic',
      lineSpacing:100
    };
  } catch { return { ...DEFAULT_READING }; }
}

export function zoomScaleFromInput(value, fallback = 1) {
 const normalized=String(value).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/٫/g,'.').replace(/[\s%٪]/g,'');
 return /^\d+(?:\.\d+)?$/.test(normalized)?clampScale(Math.max(1,Number(normalized)/100)):clampScale(fallback);
}
export const spreadCompatible=()=>true;
const isSpread=()=>document.documentElement.classList.contains('munibin-quran-mode-spread');
// Quran has one bundled Mushaf face; app-wide Unicode faces are unchanged.
export function ensureReadingFont(){return Promise.resolve()}
const colorFonts=new Map();
export function ensureTajweedPage(page) {
 const number=Number(page?.page??page);
 if(!Number.isInteger(number)||number<1||number>604)return Promise.resolve();
 if(!colorFonts.has(number)) {
  const face=new FontFace(`QuranTajweed${number}`,`url("/assets/tajweed-v362/fonts/p${number}.woff2") format("woff2")`);
  colorFonts.set(number,face.load().then(loaded=>{document.fonts.add(loaded);return loaded}).catch(error=>{colorFonts.delete(number);throw error}));
 }
 return colorFonts.get(number).then(loaded=>{
  // A resolved load promise alone does not guarantee membership after resume.
  if(!document.fonts.has(loaded))document.fonts.add(loaded);
  return loaded;
 });
}
let tajweedPaintRevision=0;
const paintBounds=new Map();
let paintCanvas;
function glyphPaintPadding(font,text) {
 const key=`${font}|${text}`;
 if(!paintBounds.has(key)) {
  paintCanvas ||= document.createElement('canvas').getContext('2d');
  if(!paintCanvas||!document.fonts?.check(`100px ${font}`,text))return undefined;
  paintCanvas.font=`100px ${font}`;paintCanvas.direction='ltr';
  const ink=paintCanvas.measureText(text);
  const left=Math.max(1,(ink.actualBoundingBoxLeft||0)/100+.08);
  const right=Math.max(1,((ink.actualBoundingBoxRight||0)-ink.width)/100+.08);
  if(paintBounds.size>12000)paintBounds.clear();
  paintBounds.set(key,{'--munibin-tajweed-paint-left':`${left.toFixed(3)}em`,'--munibin-tajweed-paint-right':`${right.toFixed(3)}em`});
 }
 return paintBounds.get(key);
}
export function renderReadingInk(React,word) {
 // The small opacity creates a separate graphics group. COLR palette writes
 // must not become the foreground color for another word or its plain layers.
 return word.colorGlyph?React.createElement('span',{key:tajweedPaintRevision,className:'munibin-tajweed-glyph-ink',style:word.paintPadding},word.text):word.text;
}

// Both native shells dispatch this event when active; visibility/pageshow also
// cover browser suspension and back/forward restoration. Recreate only ink,
// leaving page, word buttons, highlights, scroll position and audio untouched.
export function observeTajweedWake(reader,getPreferences,repaint) {
 let disposed=false,frame=0,settleTimer=0,generation=0;
 let wasHidden=document.visibilityState==='hidden';
 const visible=()=>document.visibilityState!=='hidden';
 const enabled=()=>getPreferences().tajweed===true;
 const cancel=()=>{
  generation++;
  if(frame)cancelAnimationFrame(frame);
  if(settleTimer)clearTimeout(settleTimer);
  frame=0;settleTimer=0;
 };
 const paint=async()=>{
  const token=++generation;
  if(disposed||!visible()||!enabled())return;
  if(getPreferences().font==='qcf1441') {
   const bounds=reader.getBoundingClientRect();
   const pages=Array.from(reader.querySelectorAll('.qcf1441-lines[data-reading-page]')).filter(node=>{
    const r=node.getBoundingClientRect();
    return r.bottom>bounds.top-bounds.height&&r.top<bounds.bottom+bounds.height;
   }).map(node=>Number(node.dataset.readingPage));
   await Promise.allSettled([...new Set(pages)].map(ensureTajweedPage));
  }
  if(disposed||token!==generation||!visible()||!enabled())return;
  repaint(++tajweedPaintRevision);
 };
 const scheduleFrame=()=>{
  if(disposed||frame||!visible()||!enabled())return;
  frame=requestAnimationFrame(()=>{frame=0;void paint()});
 };
 const recover=()=>{
  if(disposed)return;
  if(!visible()){wasHidden=true;return}
  wasHidden=false;
  if(!enabled())return;
  generation++;
  scheduleFrame();
  if(settleTimer)clearTimeout(settleTimer);
  // One bounded second paint after the OS has restored its graphics surface.
  // No recurring timer, font-family switch, temporary empty text or page reset.
  settleTimer=setTimeout(()=>{settleTimer=0;scheduleFrame()},180);
 };
 const hidden=()=>{wasHidden=true;cancel()};
 const visibility=()=>{if(!visible())hidden();else if(wasHidden)recover()};
 const pageShow=event=>{if(event.persisted||wasHidden)recover()};
 const focus=()=>{if(wasHidden&&visible())recover()};
 document.addEventListener('visibilitychange',visibility,true);
 document.addEventListener('resume',recover,true);
 window.addEventListener('munibin-native-resume',recover,true);
 window.addEventListener('pageshow',pageShow,true);
 window.addEventListener('pagehide',hidden,true);
 window.addEventListener('focus',focus,true);
 return ()=>{
  disposed=true;cancel();
  document.removeEventListener('visibilitychange',visibility,true);
  document.removeEventListener('resume',recover,true);
  window.removeEventListener('munibin-native-resume',recover,true);
  window.removeEventListener('pageshow',pageShow,true);
  window.removeEventListener('pagehide',hidden,true);
  window.removeEventListener('focus',focus,true);
 };
}
export function isReadingReflow(prefs) {
  return prefs.scale !== 1 || prefs.direction === 'ayah';
}
// Surah endings come from the bundled Quran navigation metadata, not page boundaries.
const SURAH_AYAH_COUNTS = [7,286,200,176,120,165,206,75,129,109,123,111,43,52,99,128,111,110,98,135,112,78,118,64,77,227,93,88,69,60,34,30,73,54,45,83,182,88,75,85,54,53,89,59,37,35,38,29,18,45,60,49,62,55,78,96,29,22,24,13,14,11,11,18,12,12,30,52,52,44,28,28,20,56,40,31,50,40,46,42,29,19,36,25,22,17,19,26,30,20,15,21,11,8,8,19,5,8,8,11,11,8,3,9,5,4,7,3,6,3,5,4,5,6];
export function readingLineAlignment(line, prefs, page, pageLines = []) {
  if (Number(page) <= 2 || prefs.scale !== 1 || line.words?.some(word => word.type === 'surah_header' || word.type === 'bismillah')) return undefined;
  const words = (line.words || []).filter(word => word.verse_key && (word.type === 'word' || word.type === 'end'));
  if (!words.length) return undefined;
  // The end marker identifies the final physical Mushaf row, even when the
  // final ayah began on an earlier row or shares this row with another ayah.
  if (words.some(word => {
    const [surah, ayah] = word.verse_key.split(':').map(Number);
    return word.type === 'end' && SURAH_AYAH_COUNTS[surah - 1] === ayah;
  })) return 'center';
  const nasEnd = pageLines.findIndex(row => row.words?.some(word => word.type === 'end' && word.verse_key === '114:6'));
  if (nasEnd > 0 && pageLines[nasEnd - 1] === line && words.some(word => word.verse_key.startsWith('114:'))) return 'center';
  return 'justify';
}
export function readingLines(page, prefs) {
  if(page.munibinAyahVerse)return page.lines;
  // Opening pages preserve their short Mushaf rows even when text wraps.
  if (!isReadingReflow(prefs) || page.page <= 2) return page.lines;
  const groups = [];
  for (const line of page.lines) {
    if (!line.words.length) continue;
    const heading = line.words.some(word => word.type === 'surah_header' || word.type === 'bismillah');
    const previous = groups[groups.length - 1];
    if (!heading && previous && !previous.heading) previous.words.push(...line.words);
    else groups.push({ line: line.line, words: [...line.words], heading });
  }
  return groups;
}
export function normalizeTajweedPage(page) {
 const family=`QuranTajweed${page.page}`;page.font=family;let index=0;
 for(const line of page.lines)for(const word of line.words) {
  const textGlyph=word.type==='word'||word.type==='bismillah';
  const text=textGlyph&&word.tajweed?.char?word.tajweed.char:String.fromCodePoint(0xe000+index);
  word.char=text;word.font=family;word.tajweed={char:text,page:page.page};index++;
 }
 return page;
}
export function readingWord(word, pageFont, fontReady, prefs) {
 const selected=QURAN_FONTS.find(font=>font.id===prefs.font);
 if(selected?.family) {
  const ayah=word.verse_key?.split(':')[1];
  const text=word.type==='end'&&ayah?`﴿${ayah}﴾`:word.text?.trim()||word.char;
  return {text,colorGlyph:false,style:{fontFamily:selected.family}};
 }
 const textGlyph=word.type==='word'||word.type==='bismillah';
 const text=word.tajweed?.char||word.char;
 const family=word.font||pageFont;
 const ink=textGlyph&&word.type==='word';
 // ss01 retains all color layers but draws each in the current reading color. Ornaments use
 // the original normal-mode outlines copied into this same page font; tajweed
 // never changes their color, in the reader or tafsir preview.
 return {text,colorGlyph:ink,paintPadding:ink?glyphPaintPadding(family,text):undefined,
  style:{fontFamily:family,fontFeatureSettings:prefs.tajweed&&textGlyph?'"ss01" 0':'"ss01" 1'}};
}

export function memorizationWords(page) {
  return (page?.lines || []).flatMap(line => line.words).filter(word => word.verse_key && (word.type === 'word' || word.type === 'end'));
}
// A rub' marker belongs to its following Quran word, not to the whole page.
// Keep it in the layout while hiding its ink whenever that word is outside
// the selected/revealed part, including a partial verse in memorization mode.
export function quarterMarkerVisible(page, marker, revealedCount=Infinity) {
 let afterMarker=false,index=0;
 for(const word of (page?.lines||[]).flatMap(line=>line.words)) {
  if(word===marker){afterMarker=true;continue}
  if(!word.verse_key||(word.type!=='word'&&word.type!=='end'))continue;
  if(afterMarker&&word.type==='word') {
   return (!marker.verse_key||marker.verse_key===word.verse_key)&&index<revealedCount;
  }
  index++;
 }
 return false;
}
export function syncQuarterMarkerVisibility(root=document) {
 const containers=Array.from(root.querySelectorAll('.qcf1441-lines'));
 if(root.matches?.('.qcf1441-lines'))containers.unshift(root);
 const scopedLeaf=root.matches?.('.munibin-quran-leaf, .qcf1441-lines');
 for(const container of containers) {
  if(container.closest?.('.munibin-quran-horizontal-warm-pages, .munibin-quran-font-preview'))continue;
  if(!scopedLeaf) {
   const pane=container.closest?.('.munibin-quran-horizontal-page');if(pane&&!pane.classList.contains('is-active'))continue;
   const sheet=container.closest?.('.munibin-quran-spread-sheet');if(sheet&&!sheet.matches('.is-active, .is-turn-target'))continue;
  }
  // A spread's warm sheets and rotating back faces are hidden while their ink
  // is prepared. That inherited visibility must not become memorization state:
  // the rub' belongs to its next word and should already be ready when shown.
  const spreadLeaf=container.closest?.('.munibin-quran-leaf');
  const glyphs=Array.from(container.querySelectorAll('.qcf1441-glyph-word, .qcf1441-glyph-quarter'));
  for(let index=0;index<glyphs.length;index++) {
   const marker=glyphs[index];if(!marker.classList.contains('qcf1441-glyph-quarter'))continue;
   const adjacent=glyphs.slice(index+1).find(word=>word.classList.contains('qcf1441-glyph-word')&&word.dataset.wordType!=='end');
   let visible=!!adjacent&&(!marker.dataset.verseKey||marker.dataset.verseKey===adjacent.dataset.verseKey);
   if(visible&&!adjacent.classList.contains('qcf1441-glyph-word--memorization-hidden')) {
    for(let target=adjacent;visible&&target;target=target.parentElement) {
     const style=getComputedStyle(target);
     const visibility=spreadLeaf?target.style?.visibility:style.visibility;
     visible=!target.hidden&&target.getAttribute?.('aria-hidden')!=='true'&&visibility!=='hidden'&&style.display!=='none';
     if(target===container)break;
    }
   } else {
    visible=false;
   }
   marker.classList.toggle('qcf1441-glyph-quarter--memorization-hidden',!visible);
  }
 }
}
export function memorizationRevealed(page, counts, startPage) {
  const total = memorizationWords(page).length;
  const count = counts[page?.page] ?? (page?.page < startPage ? total : 0);
  return Math.max(0, Math.min(total, count));
}
export function stepMemorization(page, counts, startPage, action) {
  const words = memorizationWords(page), count = memorizationRevealed(page, counts, startPage);
  const ends = new Map();
  words.forEach((word, index) => ends.set(word.verse_key, index + 1));
  const boundaries = [...ends.values()];
  if (action === 'revealWord') return Math.min(words.length, count + 1);
  if (action === 'hideWord') return Math.max(0, count - 1);
  if (action === 'revealVerse') return boundaries.find(end => end > count) ?? words.length;
  if (action === 'hideVerse') return boundaries.filter(end => end < count).at(-1) ?? 0;
  return count;
}

// A reflowed paragraph can contain several visual rows. Join only words of the
// same verse on the same row, including the whitespace between those words.
export function readingVerseBands(items,{gap=0,top=-Infinity,bottom=Infinity}={}) {
  const rows=[];
  for(const item of items) {
    const r=item.rect;
    if(!(r.width>0&&r.height>0))continue;
    let row=rows.at(-1);
    const overlap=row?Math.min(row.bottom,r.bottom)-Math.max(row.top,r.top):0;
    if(!row||overlap<Math.min(row.bottom-row.top,r.height)*.5) {
      row={top:r.top,bottom:r.bottom,groups:new Map()};rows.push(row);
    } else {row.top=Math.min(row.top,r.top);row.bottom=Math.max(row.bottom,r.bottom)}
    if(!item.active||!item.verse)continue;
    const ink=item.ink||r;
    let band=row.groups.get(item.verse);
    if(!band) {
      band={verse:item.verse,left:ink.left,right:ink.right,top:ink.top,bottom:ink.bottom};
      row.groups.set(item.verse,band);
    } else {
      band.left=Math.min(band.left,ink.left);band.right=Math.max(band.right,ink.right);
      band.top=Math.min(band.top,ink.top);band.bottom=Math.max(band.bottom,ink.bottom);
    }
  }
  return rows.flatMap((row,index)=>{
    const center=(row.top+row.bottom)/2;
    const previous=rows[index-1],next=rows[index+1];
    const rowTop=previous?Math.max(top,(previous.top+previous.bottom+center*2)/4+gap/2):top;
    const rowBottom=next?Math.min(bottom,(next.top+next.bottom+center*2)/4-gap/2):bottom;
    return Array.from(row.groups.values()).map(band=>({...band,top:Math.max(band.top,rowTop),bottom:Math.min(band.bottom,rowBottom)})).filter(band=>band.bottom>band.top);
  });
}
const readingBandSignatures=new WeakMap();
export function syncReadingHighlights(root=document) {
  syncQuarterMarkerVisibility(root);
  for(const line of root.querySelectorAll('.qcf1441-line-ayah')) {
    if(line.closest('.munibin-quran-horizontal-warm-pages, .munibin-quran-font-preview'))continue;
    const pane=line.closest('.munibin-quran-horizontal-page');if(pane&&!pane.classList.contains('is-active'))continue;
    const sheet=line.closest('.munibin-quran-spread-sheet');
    if(sheet&&!sheet.matches('.is-active, .is-turn-target'))continue;
    const existing=Array.from(line.querySelectorAll(':scope > .munibin-quran-verse-band'));
    const active=line.querySelector('.qcf1441-glyph-word--pressed, .qcf1441-glyph-word--recited, .qcf1441-glyph-word--navigation, .qcf1441-glyph-word--mic-verse');
    if(!active) {
      existing.forEach(node=>node.remove());
      if(line.classList.contains('munibin-quran-joined-highlights'))line.classList.remove('munibin-quran-joined-highlights');
      readingBandSignatures.delete(line);continue;
    }
    const origin=line.getBoundingClientRect();
    const reflow=!!line.closest('.munibin-reader-reflow');
    const style=typeof getComputedStyle==='function'?getComputedStyle(active):null;
    const fontSize=parseFloat(style?.fontSize),lineHeight=parseFloat(style?.lineHeight);
    const leading=fontSize>0&&lineHeight>0?lineHeight/fontSize:1;
    const items=Array.from(line.querySelectorAll('.qcf1441-glyph-word')).filter(word=>!word.classList.contains('qcf1441-glyph-word--memorization-hidden')).map(word=>({
      verse:word.dataset.verseKey,
      active:word.classList.contains('qcf1441-glyph-word--pressed')||word.classList.contains('qcf1441-glyph-word--recited')||word.classList.contains('qcf1441-glyph-word--navigation')||word.classList.contains('qcf1441-glyph-word--mic-verse'),
      rect:word.getBoundingClientRect(),ink:word.querySelector('.qcf1441-glyph-ink')?.getBoundingClientRect()
    }));
    // Inline ink boxes include unused ascent/descent; zoomed word boxes also
    // include leading. A medium 1.44em band works in every mode without turning
    // two highlighted rows into one block. Keep the horizontal ink bounds so
    // justified spaces never break the highlight between a verse's words.
    for(const item of items) {
      const half=item.rect.height/leading*.72,center=item.rect.top+item.rect.height/2,ink=item.ink||item.rect;
      item.ink={left:ink.left,right:ink.right,top:center-half,bottom:center+half};
    }
    // A legacy QCF row uses scaleX(.985). DOMRects include that transform,
    // whereas the absolutely positioned bands use the row's local coordinates.
    const scaleX=origin.width/(line.offsetWidth||line.clientWidth)||1;
    const scaleY=origin.height/line.offsetHeight||1;
    const rounded=value=>Math.round(value*100)/100;
    const gap=Math.max(2,Math.min(4,(fontSize||items[0]?.rect.height/leading||24)*.08))*scaleY;
    let top=-Infinity,bottom=Infinity;
    if(!reflow) {
      // Original Mushaf rows are separate DOM nodes. Limit their bands at the
      // midpoint to neighboring rows, just as wrapped rows are limited below.
      const center=origin.top+origin.height/2;
      const previous=line.previousElementSibling,next=line.nextElementSibling;
      if(previous?.classList.contains('qcf1441-line')) {
        const r=previous.getBoundingClientRect();
        if(r.height>0)top=(r.top+r.height/2+center)/2+gap/2;
      }
      if(next?.classList.contains('qcf1441-line')) {
        const r=next.getBoundingClientRect();
        if(r.height>0)bottom=(r.top+r.height/2+center)/2-gap/2;
      }
    }
    const bands=readingVerseBands(items,{gap,top,bottom}).map(band=>{
      const left=Math.max(0,(band.left-origin.left)/scaleX-2);
      const right=Math.min(line.clientWidth,(band.right-origin.left)/scaleX+2);
      return {verse:band.verse,left:rounded(left),top:rounded((band.top-origin.top)/scaleY),width:rounded(Math.max(0,right-left)),height:rounded((band.bottom-band.top)/scaleY)};
    });
    if(bands.length&&!line.classList.contains('munibin-quran-joined-highlights'))line.classList.add('munibin-quran-joined-highlights');
    if(!bands.length&&line.classList.contains('munibin-quran-joined-highlights'))line.classList.remove('munibin-quran-joined-highlights');
    const signature=JSON.stringify(bands);
    if(readingBandSignatures.get(line)===signature&&existing.length===bands.length)continue;
    existing.forEach(node=>node.remove());
    for(const band of bands) {
      const node=document.createElement('span');
      node.className='munibin-quran-verse-band';node.setAttribute('aria-hidden','true');node.dataset.verseKey=band.verse;
      Object.assign(node.style,{left:`${band.left}px`,top:`${band.top}px`,width:`${band.width}px`,height:`${band.height}px`});
      line.appendChild(node);
    }
    readingBandSignatures.set(line,signature);
  }
}
export function readingHighlightPaintMutation(record) {
  if(record.type!=='attributes'||record.attributeName!=='style'||record.oldValue===null)return false;
  const target=record.target;
  if(!target?.matches?.('.qcf1441-line'))return false;
  const paintOnly=new Set(['transform','transition','transform-origin','will-change']);
  const layout=css=>String(css||'').split(';').map(part=>part.trim()).filter(part=>{
    const colon=part.indexOf(':');
    return colon>=0&&!paintOnly.has(part.slice(0,colon).trim().toLowerCase());
  }).sort().join(';');
  return layout(record.oldValue)===layout(target.getAttribute('style'));
}
export function observeReadingHighlights(reader) {
  const cleanupNavigation=observeNavigationHighlights(reader);
  const changed=records=>records.some(record=>{
    if(readingHighlightPaintMutation(record))return false;
    const target=record.target?.nodeType===3?record.target.parentElement:record.target;
    if(target?.closest?.('.munibin-quran-horizontal-warm-pages, .munibin-quran-font-preview'))return false;
    if(target?.closest?.('.munibin-quran-verse-band'))return false;
    if(record.type==='childList') {
      const nodes=[...record.addedNodes,...record.removedNodes];
      if(nodes.length&&nodes.every(node=>node.nodeType===1&&(node.classList.contains('munibin-quran-verse-band')||node.classList.contains('munibin-quran-font-preview'))))return false;
    }
    return target===reader||!!target?.closest?.('.qcf1441-lines');
  });
  const sync=()=>syncReadingHighlights(reader);
  let frame=0;
  const schedule=()=>{if(!frame)frame=requestAnimationFrame(()=>{frame=0;sync()})};
  const observer=new MutationObserver(records=>{if(changed(records))schedule()});
  observer.observe(reader,{subtree:true,childList:true,characterData:true,attributes:true,attributeOldValue:true,attributeFilter:['class','style','data-verse-key']});
  const resize=new ResizeObserver(schedule);resize.observe(reader);
  window.addEventListener('resize',schedule,{passive:true});
  sync();
  return ()=>{
    cleanupNavigation();observer.disconnect();resize.disconnect();cancelAnimationFrame(frame);window.removeEventListener('resize',schedule);
    reader.querySelectorAll('.munibin-quran-verse-band').forEach(node=>node.remove());
    reader.querySelectorAll('.munibin-quran-joined-highlights').forEach(line=>line.classList.remove('munibin-quran-joined-highlights'));
  };
}

let readerFitFrame=0,readerFitPending=false,adjacentReaderFit=false;
const readerViewportGeometry=new WeakMap();
// All chrome/resize/observer requests share one visible-page layout pass. A
// control tap must not walk every retained neighbor, and audio highlight node
// mutations must not cause a new font/spacing fit at all.
export function scheduleQuranReaderFit() {
 readerFitPending=true;
 if(readerFitFrame)return;
 readerFitFrame=requestAnimationFrame(()=>{
  readerFitFrame=0;
  if(window.__munibinQuranInteracting)return;
  if(!readerFitPending)return;
  readerFitPending=false;fitQuranReaderBeforePaint();
 });
}
export function flushPendingQuranReaderFit() {
 if(readerFitPending&&!window.__munibinQuranInteracting)scheduleQuranReaderFit();
}

export function readerLayoutMutation(record) {
 const target=record.target?.nodeType===3?record.target.parentElement:record.target;
 if(!target?.closest?.('.qcf1441-lines')&&!target?.matches?.('.qcf1441-preview-page'))return false;
 // AyahPages commits its own bounded wrapping, height and highlights.
 if(target?.closest?.('.munibin-quran-ayah-pages'))return false;
 if(target?.closest?.('.munibin-quran-verse-band, .munibin-quran-horizontal-warm-pages, .munibin-quran-font-preview'))return false;
 const pane=target?.closest?.('.munibin-quran-horizontal-page');
 if(pane&&!pane.classList.contains('is-active'))return false;
 const sheet=target?.closest?.('.munibin-quran-spread-sheet');
 if(sheet&&!sheet.classList.contains('is-active'))return false;
 if(record.type==='childList') {
  const nodes=[...record.addedNodes,...record.removedNodes];
  if(nodes.length&&nodes.every(node=>node.nodeType===1&&node.classList.contains('munibin-quran-verse-band')))return false;
 }
 return true;
}

// A retained opening slot uses the same reserves before and after a swipe.
// Ayah mode already owns fixed rows and must keep its document behavior.
export function openingQuranReader(reader) {
 if(!reader||reader.classList.contains('munibin-reader-ayah'))return false;
 const pane=reader.querySelector('.munibin-quran-horizontal-page.is-active');
 if(pane)return Number(pane.dataset.horizontalPage)<=2;
 const sheet=reader.querySelector('.munibin-quran-spread-sheet.is-active');
 if(sheet){const leaf=sheet.querySelector('.munibin-quran-leaf[data-page]');return !!leaf&&Number(leaf.dataset.page)<=2;}
 const scroll=reader.querySelector('.munibin-quran-vertical-pages');
 if(scroll){const bounds=scroll.getBoundingClientRect(),top=bounds.top+(parseFloat(getComputedStyle(scroll).paddingTop)||0)+1;
  const first=Array.from(scroll.querySelectorAll('.qcf1441-lines[data-reading-page]')).find(node=>node.getBoundingClientRect().bottom>top);
  if(first)return Number(first.dataset.readingPage)<=2;
 }
 const lines=reader.querySelector('.qcf1441-lines[data-reading-page]');return !!lines&&Number(lines.dataset.readingPage)<=2;
}
export function commitQuranChromeVisibility(shown) {
  const reader=document.querySelector('.qcf1441-preview');
  if(!reader||reader.classList.contains('qcf1441-preview--chrome-hidden')!==!shown)return;
  if(window.__munibinQuranInteracting){readerFitPending=true;return;}
  const prefs=window.__munibinQuranReading?.getPreferences?.()||DEFAULT_READING;
  const sharedViewport=isSpread()||!!reader.querySelector('.munibin-quran-horizontal-pages');
  const automatic=(sharedViewport||!openingQuranReader(reader))&&prefs.direction!=='ayah'&&(isSpread()||(innerHeight>=innerWidth&&prefs.scale===1))&&prefs.spacing==='automatic';
  if(!automatic){captureQuranChromeMotion(reader);return;}
  cancelAnimationFrame(readerFitFrame);readerFitFrame=0;readerFitPending=false;
  fitQuranReaderBeforePaint(reader);
}
export function measureQuranReader() {
  if(window.__munibinQuranInteracting)return;
  const reader=document.querySelector('.qcf1441-preview');
  if(!reader)return;
  captureQuranChromeMotion(reader);
  const header=reader.querySelector('.qcf1441-preview-header');
  const footer=reader.querySelector('.qcf1441-memorization-player, .qcf1441-background-player');
 const portrait=innerHeight>=innerWidth;
 const spread=isSpread();
 const top=(header?.offsetHeight||48)+(portrait?2:spread?6:0);
 const bottom=(footer?.offsetHeight||56)+(parseFloat(footer?getComputedStyle(footer).bottom:'0')||0)+(portrait?2:6);
  const prefs=window.__munibinQuranReading?.getPreferences?.()||DEFAULT_READING;
  // A zoomed single page already scrolls. Only a 100% portrait page and a
  // two-page book automatically change geometry when controls are toggled.
  // A retained book shares one viewport across every pair. Opening-page
  // reserves belong to its own leaves, never to the active pair or hidden
  // React page: otherwise turning 1–2 ↔ 3–4 changes all cached page sizes.
  const sharedViewport=spread||!!reader.querySelector('.munibin-quran-horizontal-pages');
  const opening=!sharedViewport&&openingQuranReader(reader);reader.dataset.readingOpeningPage=String(opening);
  const automaticFit=!opening&&prefs.direction!=='ayah'&&prefs.spacing==='automatic'&&(isSpread()||(portrait&&prefs.scale===1));
  const bookHidden=automaticFit&&reader.classList.contains('qcf1441-preview--chrome-hidden');
  const fullScreen=!opening&&(prefs.spacing==='fullscreen'||bookHidden);
  const bookTop=fullScreen?6:top;
  const bookBottom=fullScreen?36:bottom;
  // Keep the original font-sizing reserves. A normal 100% book borrows four
  // pixels of header-side air. This is page-independent so retained spreads
  // never need a delayed resize after a quick turn past the opening pages.
  const bookEdgeTop=!opening&&spread&&prefs.font==='qcf1441'&&prefs.scale===1&&prefs.spacing!=='manual'?4:0;
  reader.dataset.readingSpacing=prefs.spacing||'automatic';
  const values={'--munibin-opening-reader-top':top,'--munibin-opening-reader-bottom':bottom,'--munibin-opening-content-height':Math.max(100,reader.clientHeight-top-bottom),'--munibin-book-top':bookTop,'--munibin-book-bottom':bookBottom,'--munibin-book-edge-top':bookEdgeTop,'--munibin-reader-top':bookTop,'--munibin-reader-bottom':bookBottom,'--munibin-reader-content-height':Math.max(100,reader.clientHeight-bookTop-bookBottom),'--munibin-reader-footer-left':footer?.offsetLeft||0};
  for(const [name,value]of Object.entries(values)) {
    const text=`${value}px`;
    if(reader.style.getPropertyValue(name)!==text)reader.style.setProperty(name,text);
  }
}
export function fitQuranReaderBeforePaint(root=document) {
  if(window.__munibinQuranInteracting)return;
  if(!root?.querySelectorAll)root=document;
  const global=root===document||root.matches?.('.qcf1441-preview');
  if(global)window.__munibinQuranPrepareViewport?.();
  const reader=document.querySelector('.qcf1441-preview');
  const documentLayout=global?window.__munibinQuranDocumentLayout:null;
  const documentAnchor=documentLayout?.captureAnchor();
  measureQuranReader();
  if(reader?.classList.contains('munibin-reader-ayah')){window.__munibinQuranAyahLayout?.measure();syncReadingHighlights(reader);finishQuranChromeMotion(reader);return;}
  // Continuous pages own their heights as well as the ink inside them. Let
  // their layout commit both together before fitting or starting row motion.
  if(documentLayout?.measure(documentAnchor))return;
  if(global&&isSpread()) {
    const sheet=reader?.querySelector('.munibin-quran-spread-sheet.is-active');
    if(sheet){window.__munibinFitQuranSpreadTypography?.(sheet);return}
  }
  const native=root.querySelector('.munibin-quran-horizontal-pages');
  if(root.classList?.contains('munibin-quran-horizontal-pages')||native) {
    const pager=native||root;
    const active=pager.querySelector('.munibin-quran-horizontal-page.is-active');
    // An RTL pager's absolute offset belongs to its page width. visualViewport
    // can report the rotated box before the normal resize listener; realign the
    // existing page before measuring/revealing it, without changing navigation.
    const width=pager.children?.[0]?.getBoundingClientRect?.().width||pager.clientWidth||0;
    const geometry=`${innerWidth}x${innerHeight}|${width}|${pager.clientHeight}`;
    if(global&&readerViewportGeometry.get(pager)!==geometry) {
      readerViewportGeometry.set(pager,geometry);
      const page=Number(active?.dataset.horizontalPage);
      if(width>0&&Number.isInteger(page)&&page>=1&&page<=604)pager.scrollLeft=-(page-1)*width;
    }
    root=active||root;
  }
  window.__munibinFitQcf1441Width?.(root);
  fitReadingPageLayout(root);
  window.__munibinFitQcf1441Titles?.(root);
  applyNativeLineSpacing(root);
  syncReadingHighlights(root);
  // A loaded adjacent native page must receive the final chrome budget before
  // controls start moving, never after that page is already swiped on screen.
  if(global&&!isSpread()&&!adjacentReaderFit) {
    adjacentReaderFit=true;
    try{window.__munibinQuranHorizontalPrepareAdjacent?.()}finally{adjacentReaderFit=false}
  }
  if(!adjacentReaderFit&&!isSpread()&&reader&&!root.classList?.contains('munibin-quran-full-document'))finishQuranChromeMotion(reader);
}

export function applyNativeLineSpacing(root=document) {
  if(window.__munibinQuranInteracting)return;
  const prefs=window.__munibinQuranReading?.getPreferences?.()||DEFAULT_READING;
  for(const container of root.querySelectorAll('.qcf1441-lines')) {
    if(container.closest('.munibin-reader-reflow, .munibin-quran-font-preview'))continue;
    if(Number(container.dataset.readingPage)<=2){container.classList.remove('munibin-reading-manual-grid');container.style.removeProperty('--munibin-manual-grid-step');continue;}
    if(window.__munibinApplyQcf1441NativeSpacing) {
      window.__munibinApplyQcf1441NativeSpacing(container,prefs);
      continue;
    }
    if(prefs.spacing!=='manual') {
      container.classList.remove('munibin-reading-manual-grid');
      continue;
    }
    const rows=Array.from(container.querySelectorAll(':scope > .qcf1441-line'));
    const reader=container.closest('.munibin-quran-leaf')||container.closest('.qcf1441-preview');
    if(!reader||!rows.length)continue;
    const style=getComputedStyle(container),readerStyle=getComputedStyle(reader);
    const available=parseFloat(readerStyle.getPropertyValue('--munibin-reader-content-height'))||container.clientHeight;
    const padding=(parseFloat(style.paddingTop)||0)+(parseFloat(style.paddingBottom)||0);
    const opening=Number(container.dataset.readingPage)<=2;
    const openingStep=parseFloat(style.getPropertyValue('--munibin-qcf-opening-row-height'));
    const step=opening&&(openingStep>0)?openingStep:Math.max(1,(available-padding)/rows.length);
    container.style.setProperty('--munibin-manual-grid-step',`${step*clampLineSpacing(prefs.lineSpacing)/100}px`);
    container.classList.add('munibin-reading-manual-grid');
  }
}

// Match the surah selector: live finger tracking, 72px/.65px-ms release,
// 180ms dismissal and a 220ms return. Only the sheet's top is draggable.
export function installQuranSettingsSwipe(sheet,overlay,dismiss) {
 let gesture=null,closing=false,timer=0;
 const transformY=()=>{
  const text=getComputedStyle(sheet).transform;
  const parts=String(text||'').match(/^matrix\(([^)]+)\)$/)?.[1]?.split(',');
  return parts?Number(parts[5])||0:0;
 };
 const down=event=>{
  if(closing||(event.pointerType==='mouse'&&event.button!==0))return;
  if(!event.target.closest('.munibin-quran-settings-heading, .munibin-quran-settings-grip')||event.target.closest('button,input,select,a'))return;
  gesture={id:event.pointerId,y:event.clientY,t:performance.now(),dy:transformY()};
  gesture.initial=gesture.dy;
  sheet.style.transition='none';
  try{sheet.setPointerCapture(event.pointerId)}catch{}
 };
 const move=event=>{
  if(!gesture||event.pointerId!==gesture.id)return;
  gesture.dy=Math.max(0,gesture.initial+event.clientY-gesture.y);
  sheet.style.transform=`translateY(${gesture.dy}px)`;
  overlay.style.opacity=String(Math.max(.35,1-gesture.dy/320));
 };
 const finish=(event,cancelled=false)=>{
  if(!gesture||event.pointerId!==gesture.id)return;
  const g=gesture;gesture=null;
  try{sheet.releasePointerCapture(event.pointerId)}catch{}
  const velocity=Math.max(0,g.dy-g.initial)/Math.max(1,performance.now()-g.t);
  if(!cancelled&&(g.dy>=72||velocity>.65)){
   closing=true;sheet.style.transition='transform .18s ease';sheet.style.transform='translateY(110%)';
   overlay.style.transition='opacity .18s ease';overlay.style.opacity='0';
   timer=setTimeout(dismiss,180);
  }else{
   sheet.style.transition='transform .22s cubic-bezier(.22,.61,.36,1)';sheet.style.transform='translateY(0)';
   overlay.style.transition='opacity .18s ease';overlay.style.opacity='1';
  }
 };
 const up=event=>finish(event),cancel=event=>finish(event,true);
 sheet.addEventListener('pointerdown',down,{passive:true});sheet.addEventListener('pointermove',move,{passive:true});
 sheet.addEventListener('pointerup',up,{passive:true});sheet.addEventListener('pointercancel',cancel,{passive:true});
 const frame=requestAnimationFrame(()=>overlay.classList.add('is-open'));
 return ()=>{cancelAnimationFrame(frame);clearTimeout(timer);gesture=null;
  sheet.removeEventListener('pointerdown',down);sheet.removeEventListener('pointermove',move);
  sheet.removeEventListener('pointerup',up);sheet.removeEventListener('pointercancel',cancel);
 };
}

export function createQuranReadingComponents(React, createPortal, flushSync) {
  const h = React.createElement;
  const ColorSettings=createQuranColorSettings(React,createPortal);
  const VerticalPages=createVerticalDocumentPages(React,{normalize:normalizeTajweedPage,fitBeforePaint:fitQuranReaderBeforePaint,finishMotion:finishQuranChromeMotion,paintKey:verticalPagePaintKey});
  const HorizontalPages=createHorizontalPages(React,fitQuranReaderBeforePaint);
  const AyahPages=createAyahDocumentPages(React,{normalize:normalizeTajweedPage,finishMotion:finishQuranChromeMotion,syncHighlights:syncReadingHighlights});
  function SlidersIcon() {
    return h('svg', { width: 19, height: 19, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.7, strokeLinecap: 'round', 'aria-hidden': true },
      h('path', { d: 'M3 5h5m4 0h9M3 12h11m4 0h3M3 19h3m4 0h11M8 2v6m6 1v6M6 16v6' }));
  }
  function TajweedColorIcon() {
    return h('svg', { className: 'munibin-quran-tajweed-symbol', viewBox: '0 0 24 24', fill: 'none', 'aria-hidden': true },
      h('rect', { x: 2, y: 3, width: 20, height: 18, rx: 4, stroke: 'currentColor', strokeWidth: 1.3 }),
      h('path', { d: 'M6 8h12', stroke: '#e30000', strokeWidth: 2.5, strokeLinecap: 'round' }),
      h('path', { d: 'M6 12h8', stroke: '#26b55d', strokeWidth: 2.5, strokeLinecap: 'round' }),
      h('path', { d: 'M6 16h12', stroke: '#3c84d5', strokeWidth: 2.5, strokeLinecap: 'round' }));
  }
  function scroller() { return document.querySelector('.munibin-quran-horizontal-page.is-active .munibin-quran-horizontal-page-scroll') || document.querySelector('.munibin-quran-vertical-pages') || document.querySelector('.qcf1441-page-stage'); }
  function readAnchor(clientX, clientY) {
    if(isSpread()&&!document.querySelector('.munibin-quran-ayah-pages')) {
      const pointed=Number.isFinite(clientX)&&Number.isFinite(clientY)?document.elementFromPoint(clientX,clientY)?.closest('[data-reading-word]'):null;
      return {spread:Array.from(document.querySelectorAll('.munibin-quran-spread-sheet.is-active .munibin-quran-leaf-viewport')).map(pane=>{
        const bounds=pane.getBoundingClientRect();
        const word=pointed&&pane.contains(pointed)?pointed:Array.from(pane.querySelectorAll('[data-reading-word]')).find(node=>{const r=node.getBoundingClientRect();return r.bottom>bounds.top+12&&r.top<bounds.bottom});
        return word?{word:word.dataset.readingWord,page:word.closest('[data-reading-page]')?.dataset.readingPage,offset:word.getBoundingClientRect().top-bounds.top}:null;
      }).filter(Boolean)};
    }
    const stage = scroller();
    if (!stage) return null;
    const bounds = stage.getBoundingClientRect();
    let word = Number.isFinite(clientX) && Number.isFinite(clientY) ? document.elementFromPoint(clientX, clientY)?.closest('[data-reading-word]') : null;
    if (!word || !stage.contains(word)) {
      // Blank space between words is a valid pinch target. In continuous
      // mode, skip offscreen articles before probing glyph rectangles instead
      // of measuring every word in all previously visited pages.
      const candidates=stage.matches('.munibin-quran-vertical-pages')
        ?Array.from(stage.querySelectorAll('[data-scroll-page]')).filter(article=>{
          const rect=article.getBoundingClientRect();return rect.bottom>bounds.top+12&&rect.top<bounds.bottom;
        }).flatMap(article=>Array.from(article.querySelectorAll('[data-reading-word]')))
        :Array.from(stage.querySelectorAll('[data-reading-word]'));
      word = candidates.find(node => {
        const rect = node.getBoundingClientRect();
        return rect.bottom > bounds.top + 12 && rect.top < bounds.bottom;
      });
    }
    return word ? { word: word.dataset.readingWord, page: word.closest('[data-reading-page]')?.dataset.readingPage, offset: word.getBoundingClientRect().top - bounds.top } : null;
  }
  function restoreAnchor(anchor) {
    if(anchor?.spread&&document.querySelector('.munibin-quran-ayah-pages'))anchor=anchor.spread[0];
    if(anchor?.spread) {
      for(const item of anchor.spread) {
        const pane=document.querySelector(`.munibin-quran-spread-sheet.is-active .munibin-quran-leaf[data-page="${item.page}"] .munibin-quran-leaf-viewport`);
        const word=pane?.querySelector(`[data-reading-word="${item.word}"]`);
        if(word)pane.scrollTop+=word.getBoundingClientRect().top-pane.getBoundingClientRect().top-item.offset;
      }
      return;
    }
    const stage = scroller();
    if (!stage || !anchor) return;
    const page = stage.matches('.munibin-quran-ayah-pages')?stage:anchor.page ? stage.querySelector(`[data-reading-page="${anchor.page}"]`) : stage;
    const word = page?.querySelector(`[data-reading-word="${anchor.word}"]`);
    if (word) stage.scrollTop += word.getBoundingClientRect().top - stage.getBoundingClientRect().top - anchor.offset;
  }
  function useReadingPreferences() {
    const [prefs, setPrefs] = React.useState(readReadingPreferences);
    const [paintRevision,setTajweedPaintRevision]=React.useState(0);
    const current = React.useRef(prefs);
    const anchor = React.useRef(null);
    const frame = React.useRef(0);
    const pinchPainter = React.useRef(null);
    if(!window.__munibinQuranPinching)current.current = prefs;
    const locked=false;
    const [spread,setSpread]=React.useState(isSpread);
    const committedSpread=React.useRef(spread);
    const requestedSpread=React.useRef(spread);
    const [error,setError]=React.useState('');
    const preferenceVersion=React.useRef(0);
    const update=React.useCallback(async patch=>{
      const token=++preferenceVersion.current;
      const next={font:'qcf1441',scale:clampScale(patch.scale??current.current.scale),direction:normalizeReadingDirection(patch.direction??current.current.direction),tajweed:(patch.tajweed??current.current.tajweed)===true,spacing:['fixed','automatic','fullscreen'].includes(patch.spacing??current.current.spacing)?(patch.spacing??current.current.spacing):'automatic',lineSpacing:100};
      // Only Quran text needs the colored QCF face; ornaments stay plain.
      if(next.tajweed&&!current.current.tajweed&&next.font==='qcf1441') {
        const visible=Array.from(document.querySelectorAll('[data-reading-page], .munibin-quran-leaf[data-page]')).filter(node=>{
          if(node.closest('.munibin-quran-font-preview, .munibin-quran-horizontal-warm-pages'))return false;
          const sheet=node.closest('.munibin-quran-spread-sheet');if(sheet&&!sheet.classList.contains('is-active'))return false;
          const r=node.getBoundingClientRect();return r.bottom>0&&r.top<innerHeight&&r.right>0&&r.left<innerWidth;
        });
        try {await Promise.all([...new Set(visible.map(node=>Number(node.dataset.readingPage||node.dataset.page)))].map(ensureTajweedPage));}
        catch {setError('تعذر تحميل خط التجويد. حاول مرة أخرى.');return false;}
      }
      if(token!==preferenceVersion.current)return false;
      if(!sameReadingLayoutPreferences(current.current,next))anchor.current=readAnchor();
      if(next.direction==='ayah'&&current.current.direction!=='ayah')window.__munibinQuranPendingAyahAnchor=anchor.current?.spread?.[0]||anchor.current;
      current.current=next;setPrefs(next);setError('');return true;
    },[]);
    React.useLayoutEffect(()=>{
      const bridge={getPreferences:()=>current.current,update,ensureTajweedPage,ensureReadingFont,loadDocumentPage:number=>loadQuranDocument(normalizeTajweedPage).then(pages=>pages[number-1]),readingWord,readingLines,readingLineAlignment,normalizeTajweedPage,quarterMarkerVisible,syncQuarterMarkerVisibility,fitReadingPageLayout,spaceMushafRows,spreadCompatible,measureQuranReader,syncReadingHighlights,applyNativeLineSpacing,fitQuranReaderBeforePaint,scheduleQuranReaderFit,flushPendingQuranReaderFit,finishQuranChromeMotion,commitChromeVisibility:commitQuranChromeVisibility};
      window.__munibinQuranReading=bridge;
      window.__munibinPrimeQuranReadingPage=primeQuranReadingPage;
      const changed=()=>{
        const next=isSpread();
        const nativeCommit=window.__munibinQuranCommittingViewport&&typeof flushSync==='function';
        if(nativeCommit) {
          if(next===committedSpread.current&&next===requestedSpread.current)return;
        } else if(next===requestedSpread.current)return;
        requestedSpread.current=next;
        const commit=()=>setSpread(next);
        // A native viewport event changes CSS mode immediately. Commit the
        // matching React page tree in that same event, not one paint later.
        // Layout-effect preparation remains ordinary React state so flushSync
        // is never called from inside React's own commit lifecycle.
        if(nativeCommit)flushSync(commit);
        else commit();
      };
      window.addEventListener('munibin-quran-view-change',changed);changed();
      return ()=>{window.removeEventListener('munibin-quran-view-change',changed);if(window.__munibinQuranReading===bridge){delete window.__munibinQuranReading;delete window.__munibinPrimeQuranReadingPage;cancelAnimationFrame(readerFitFrame);readerFitFrame=0;readerFitPending=false;}};
    },[update]);
    React.useLayoutEffect(()=>{
      const reader=document.querySelector('.qcf1441-preview');if(!reader)return;
      document.documentElement.classList.add("munibin-quran-modern-reader");
      let geometry='';
      const fit=()=>{
        const next=`${innerWidth}x${innerHeight}|${reader.clientWidth}x${reader.clientHeight}|${isSpread()}`;
        if(next!==geometry&&!window.__munibinQuranInteracting) {
          geometry=next;fitQuranReaderBeforePaint(reader);
        } else scheduleQuranReaderFit();
      };
      fit();const resize=new ResizeObserver(fit);resize.observe(reader);
      const watched=new WeakSet();
      const watch=()=>reader.querySelectorAll('.qcf1441-preview-header, .qcf1441-memorization-player, .qcf1441-background-player').forEach(node=>{if(!watched.has(node)){resize.observe(node);watched.add(node)}});watch();
      const observer=new MutationObserver(()=>{watch();fit()});observer.observe(reader,{childList:true});
      window.addEventListener('resize',fit,{passive:true});
      window.visualViewport?.addEventListener('resize',fit,{passive:true});
      return ()=>{resize.disconnect();observer.disconnect();window.removeEventListener('resize',fit);window.visualViewport?.removeEventListener('resize',fit)};
    },[]);
    React.useLayoutEffect(() => {
      window.__munibinQuranReadingReflow = isReadingReflow(prefs) || prefs.direction === 'vertical';
      document.documentElement.classList.add('munibin-quran-modern-reader');
      window.dispatchEvent(new Event(READING_EVENT));
      fitQuranReaderBeforePaint();
      // The committed reader/leaf scale must exist before temporary local
      // preview values are removed. An older boundary commit cannot clear a
      // newer finger position that has not reached React yet.
      if(prefs.scale===current.current.scale)pinchPainter.current?.clear({committedScale:prefs.scale,currentScale:current.current.scale});
      restoreAnchor(anchor.current);
      anchor.current = null;
    }, [prefs.font,prefs.scale,prefs.direction,prefs.tajweed,prefs.spacing,prefs.lineSpacing]);
    React.useLayoutEffect(()=>{
      try { localStorage.setItem(READING_KEY, JSON.stringify(prefs)); } catch {}
    },[prefs]);
    React.useLayoutEffect(()=>{
      committedSpread.current=spread;
      // Entering/leaving a book replaces the underlying native page tree even
      // when zoom/preferences did not change. Its retained fonts must not carry
      // the old half-column width through the first portrait/landscape paint.
      fitQuranReaderBeforePaint();
    },[spread]);
    React.useEffect(()=>{
      const reader=document.querySelector('.qcf1441-preview');
      return reader?observeReadingHighlights(reader):undefined;
    },[]);
    React.useEffect(()=>{
      const reader=document.querySelector('.qcf1441-preview');
      return reader?observeTajweedWake(reader,()=>current.current,revision=>{setTajweedPaintRevision(revision);window.dispatchEvent(new Event('munibin-quran-ink-refresh'))}):undefined;
    },[]);
    // Page/font/chrome commits get their final sizing before the browser paints.
    // Persistent page panes fit when their own data or geometry changes. Audio,
    // header labels and settling a finger swipe must not run a global fit.
    React.useEffect(() => {
      const root = document.querySelector('.qcf1441-preview-page');
      if (!root) return;
      const painter=createQuranPinchScalePainter(root);
      pinchPainter.current=painter;
      let gesture = null, releaseTimer = 0, pendingPinch = null;
      const previewScale=()=>{
        cancelAnimationFrame(frame.current);frame.current=0;
        if(!pendingPinch)return;
        const {scale,x,y}=pendingPinch;pendingPinch=null;
        const previous=current.current;
        if(previous.scale===scale)return;
        const next={...previous,scale};
        const position=readAnchor(x,y);current.current=next;
        if(next.direction==='ayah'&&window.__munibinQuranAyahLayout){
          window.__munibinQuranAyahLayout.previewScale(scale,position);
        } else if(isReadingReflow(previous)!==isReadingReflow(next)) {
          anchor.current=position;setPrefs(next);
        } else {
          // Live wrapping belongs to visible pages only. Cached neighboring
          // ink receives the final inherited scale in the release commit.
          painter.preview(scale,{x,y,page:position?.page??position?.spread?.[0]?.page});
          restoreAnchor(position);
        }
      };
      const scheduleFit = () => {
        if(!isReadingReflow(current.current))return;
        scheduleQuranReaderFit();
      };
      const observer = new MutationObserver(records=>{if(records.some(readerLayoutMutation))scheduleFit()});
      observer.observe(root, { childList: true, subtree: true, characterData: true });
      window.addEventListener('resize', scheduleFit, { passive: true });
      const distance = touches => Math.hypot(touches[0].clientX - touches[1].clientX, touches[0].clientY - touches[1].clientY);
      const start = event => {
        if (event.touches.length < 2) return;
        event.preventDefault(); event.stopPropagation();
        clearTimeout(releaseTimer);
        window.__munibinQuranPinching = true;
        window.__munibinQuranAyahLayout?.beginPreview?.();
        window.__munibinQuranNavigationBridge?.cancelGesture?.();
        preferenceVersion.current++;
        gesture = { distance: Math.max(1, distance(event.touches)), scale: current.current.scale };
      };
      const move = event => {
        if (!gesture || event.touches.length < 2) return;
        event.preventDefault(); event.stopPropagation();
        const scale = clampScale(gesture.scale * distance(event.touches) / gesture.distance);
        const x = (event.touches[0].clientX + event.touches[1].clientX) / 2;
        const y = (event.touches[0].clientY + event.touches[1].clientY) / 2;
        pendingPinch={scale,x,y};
        if(!frame.current)frame.current=requestAnimationFrame(previewScale);
      };
      const end = event => {
        if (!gesture || event.touches.length >= 2) return;
        event.stopPropagation();
        previewScale();anchor.current=readAnchor();window.__munibinQuranAyahLayout?.finishPreview?.(anchor.current);setPrefs({...current.current});gesture = null;
        window.__munibinQuranNavigationBridge?.cancelGesture?.();
        // Ignore the remaining finger's pointerup; it must not turn a page or hide chrome.
        releaseTimer = setTimeout(() => { window.__munibinQuranPinching = false;window.dispatchEvent(new Event('munibin-quran-pinch-end'));flushPendingQuranReaderFit(); }, event.touches.length?300:80);
      };
      root.addEventListener('touchstart', start, { passive: false, capture: true });
      root.addEventListener('touchmove', move, { passive: false, capture: true });
      root.addEventListener('touchend', end, { passive: true, capture: true });
      root.addEventListener('touchcancel', end, { passive: true, capture: true });
      return () => {
        root.removeEventListener('touchstart', start, true); root.removeEventListener('touchmove', move, true);
        root.removeEventListener('touchend', end, true); root.removeEventListener('touchcancel', end, true);
        cancelAnimationFrame(frame.current); clearTimeout(releaseTimer);
        painter.dispose();if(pinchPainter.current===painter)pinchPainter.current=null;
        observer.disconnect(); window.removeEventListener('resize', scheduleFit);
        window.__munibinQuranPinching = false;
        window.__munibinQuranReadingReflow = false;
        document.documentElement.classList.remove('munibin-quran-modern-reader');
        window.dispatchEvent(new Event(READING_EVENT));
      };
    }, []);
    return { prefs, update, locked, spread, error, paintRevision };
  }
  function ZoomPercentage({scale,update,disabled}) {
    const [draft,setDraft]=React.useState(String(Math.round(scale*100)));
    React.useEffect(()=>setDraft(String(Math.round(scale*100))),[scale]);
    const cancel=React.useRef(false);
    const commit=()=>{const next=cancel.current?scale:zoomScaleFromInput(draft,scale);cancel.current=false;setDraft(String(Math.round(next*100)));if(next!==scale)update({scale:next})};
    return h('label',{className:'munibin-quran-zoom-entry'},
      h('input',{type:'text',inputMode:'decimal',value:draft,disabled,'aria-label':'نسبة تكبير نص القرآن',onChange:event=>setDraft(event.target.value),onFocus:event=>event.target.select(),onBlur:commit,
        onKeyDown:event=>{if(event.key==='Enter'){event.preventDefault();event.currentTarget.blur()}else if(event.key==='Escape'){event.stopPropagation();cancel.current=true;event.currentTarget.blur()}}}),
      h('span',{'aria-hidden':true},'%'));
  }

  function SpacingSettings({prefs,update,disabled}) {
    return h('fieldset',{disabled},h('legend',null,'المسافة بين الأسطر'),
      h('div',{className:'munibin-quran-spacing-options'},[
        ['automatic','تلقائي · الافتراضي'],
        ['fixed','ثابت بين الشريطين'],
        ['fullscreen','ثابت بملء الشاشة']
      ].map(([value,label])=>h('button',{key:value,type:'button','aria-pressed':(prefs.spacing||'automatic')===value,onClick:()=>update({spacing:value})},h('span',null,label)))));
  }

  function SettingsButton({ prefs, update, onOpen, locked, error }) {
    const [open, setOpen] = React.useState(false),[guide,setGuide]=React.useState(false);
    const trigger = React.useRef(null), sheet = React.useRef(null);
    React.useEffect(()=>{
      if(!open||!sheet.current)return;
      return installQuranSettingsSwipe(sheet.current,sheet.current.parentElement,()=>setOpen(false));
    },[open]);
    React.useEffect(() => {
      if (!open) return;
      const previousOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      sheet.current?.querySelector('button')?.focus();
      const keydown = event => {
        if(document.querySelector('.munibin-quran-color-dialog'))return;
        if (event.key === 'Escape') { event.preventDefault(); if(guide)setGuide(false);else setOpen(false); }
        if (event.key !== 'Tab') return;
        const buttons = Array.from(sheet.current?.querySelectorAll('button:not(:disabled), input:not(:disabled), select:not(:disabled), a[href]') || []);
        if (!buttons.length) return;
        const first = buttons[0], last = buttons[buttons.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      };
      document.addEventListener('keydown', keydown);
      return () => { document.body.style.overflow = previousOverflow; document.removeEventListener('keydown', keydown); trigger.current?.focus({ preventScroll: true }); };
    }, [open,guide]);
    const button = h('button', { ref: trigger, type: 'button', className: 'qcf1441-icon-button munibin-quran-settings-button', 'aria-label': 'إعدادات القرآن', 'aria-haspopup': 'dialog', 'aria-expanded': open, onClick: () => { onOpen?.(); setOpen(true); } }, h(SlidersIcon));
    const modal = open && h('div', { className: 'munibin-quran-settings-backdrop munibin-quran-reader-menu', onPointerDown: event => { if (event.target === event.currentTarget) setOpen(false); } },
      h('section', { ref: sheet, role: 'dialog', 'aria-modal': true, 'aria-labelledby': guide?'quran-tajweed-guide-title':'quran-reading-settings-title', className: 'munibin-quran-settings-sheet', dir: 'rtl' },
       h('div',{className:'munibin-quran-settings-grip','aria-hidden':true},h('span')),
       ...(guide?[
        h('div',{className:'munibin-quran-settings-heading'},h('h2',{id:'quran-tajweed-guide-title'},'دليل ألوان التجويد'),h('button',{type:'button',className:'munibin-quran-guide-back',onClick:()=>setGuide(false),'aria-label':'العودة إلى إعدادات القرآن'},h('svg',{viewBox:'0 0 24 24','aria-hidden':true},h('path',{d:'m15 18-6-6 6-6',fill:'none',stroke:'currentColor',strokeWidth:2.2,strokeLinecap:'round',strokeLinejoin:'round'})))),
        h('div',{className:'munibin-quran-settings-body'},
         h('p',{className:'munibin-quran-guide-intro'},'كل لون يساعدك على تمييز حكم عند التلاوة. هذا المفتاح يطابق الخط المختار: '+(QURAN_FONTS.find(font=>font.id===prefs.font)?.label||'مصحف المدينة')+'.'),
         h('ul',{className:'munibin-quran-guide-list'},tajweedGuideEntries().map(entry=>h('li',{key:entry.title},h('span',{className:'munibin-quran-guide-swatch',style:{background:entry.color},'aria-hidden':true}),h('div',null,h('h3',null,entry.title),h('p',null,entry.text))))),
         h('div',{className:'munibin-quran-guide-sources'},h('strong',null,'المصادر'),TAJWEED_SOURCES.map(source=>h('a',{key:source.url,href:source.url,target:'_blank',rel:'noreferrer'},source.label)),h('p',null,'الشرح متاح دون اتصال. اضبط المقادير بالسماع والتلقي من معلّم متقن؛ فالحركة مقدار زمني وليست ثانية ثابتة.')))
       ]:[
        h('div', { className: 'munibin-quran-settings-heading' }, h('div', null, h('h2', { id: 'quran-reading-settings-title' }, 'إعدادات القرآن')), h('button', { type: 'button', className:'munibin-quran-menu-close', 'aria-label': 'إغلاق إعدادات القرآن', onClick: () => setOpen(false) }, '×')),
        h('div', { className: 'munibin-quran-settings-body' },
          error&&h('p',{role:'alert'},error),
          h('fieldset',null,h('legend',null,'خط المصحف'),h('div',{className:'munibin-quran-current-font'},h('span',null,'مصحف المدينة ١٤٤١'),h('b',{'aria-hidden':true},'✓'))),
          h('fieldset', {disabled:locked}, h('legend', null, 'حجم النص'), h('div', { className: 'munibin-quran-size-control', dir: 'ltr' }, h('button', { type: 'button', 'aria-label': 'تصغير نص القرآن', disabled: prefs.scale <= 1, onClick: () => update({ scale: prefs.scale - .1 }) }, '−'), h(ZoomPercentage,{scale:prefs.scale,update,disabled:locked}), h('button', { type: 'button', 'aria-label': 'تكبير نص القرآن', disabled: prefs.scale >= 2.4, onClick: () => update({ scale: prefs.scale + .1 }) }, '+'))),
          h(ColorSettings),
          h('fieldset', null, h('legend', null, 'ألوان التجويد'), h('div', { className: 'munibin-quran-tajweed-row' }, h('span', {className:'munibin-quran-tajweed-label'}, h(TajweedColorIcon), 'إظهار أحكام التجويد بالألوان'), h('button',{type:'button',className:'munibin-quran-guide-button','aria-label':'شرح ألوان التجويد','aria-haspopup':'dialog',onClick:()=>setGuide(true)},'؟'), h('button', { type: 'button', role: 'switch', 'aria-checked':prefs.tajweed,onClick:()=>update({tajweed:!prefs.tajweed}),'aria-label':'إظهار ألوان التجويد', className: 'munibin-quran-tajweed-switch' }, h('span')))),
          h(SpacingSettings,{prefs,update,disabled:locked}),
          h('fieldset', {disabled:locked}, h('legend', null, 'التنقل بين الصفحات'), h('div', { className: 'munibin-quran-direction-options' }, [['horizontal', 'جانبيًا'], ['vertical', 'من أعلى إلى أسفل'], ['ayah','آية بآية']].map(([direction, label]) => h('button', { key: direction, type: 'button', 'aria-pressed': prefs.direction === direction, onClick: () => update({ direction }) }, h('span', null, label))))),
          h('button', { type: 'button', className:'munibin-quran-settings-reset',disabled:locked,onClick:()=>update(DEFAULT_READING) }, 'استعادة إعدادات القراءة الافتراضية'))])));
    return h(React.Fragment, null, button, modal && createPortal(modal, document.body));
  }

  // Prepare native wraps in the actual viewport, outside the visible/accessibility
  // tree. Incoming mounts reuse their fitted sizes instead of doing a new search
  // on the first drag frame. Keep only two neighbors on each side.
  function HorizontalWarmPages({page,loadPage,renderPage,prefs}) {
    const [pages,setPages]=React.useState([]);
    const load=React.useRef(loadPage);load.current=loadPage;
    React.useEffect(()=>{
      let cancelled=false;
      if(prefs.font==='qcf1441')void ensureTajweedPage(page).catch(()=>{});
      const wanted=[page-1,page+1,page-2,page+2].filter(n=>n>=1&&n<=604);
      setPages(previous=>previous.filter(item=>wanted.includes(item.page)));
      wanted.forEach(number=>{
        load.current(number).then(item=>{
          if(cancelled)return;
          if(prefs.font==='qcf1441')void ensureTajweedPage(number).catch(()=>{});
          setPages(previous=>previous.some(entry=>entry.page===number)?previous:[...previous,item]);
        }).catch(()=>{});
      });
      return ()=>{cancelled=true};
    },[page,prefs.font,prefs.tajweed]);
    React.useLayoutEffect(()=>{fitQuranReaderBeforePaint()},[pages,prefs.font,prefs.scale,prefs.direction,prefs.tajweed,prefs.spacing,prefs.lineSpacing]);
    const prepared=React.useMemo(()=>pages.map(item=>h('div',{key:item.page,className:'qcf1441-page-layer'},renderPage(item))),[pages,prefs.font,prefs.scale,prefs.tajweed]);
    return h('div',{className:'munibin-quran-horizontal-warm-pages','aria-hidden':true,inert:''},prepared);
  }
  return { useReadingPreferences, SettingsButton, VerticalPages, HorizontalWarmPages, HorizontalPages, AyahPages, copyQuranVerse };
}
