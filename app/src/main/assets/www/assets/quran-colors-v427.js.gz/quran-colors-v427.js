/* Independent, offline Quran canvas colors. Geometry and app preferences stay separate. */
export const QURAN_COLOR_KEY='munibin:quran-colors:v1';
export const QURAN_COLOR_EVENT='munibin-quran-colors-change';
export const DEFAULT_QURAN_COLORS=Object.freeze({followApp:true,text:'#2f251b',background:'#fff7e7'});
const installs=new WeakMap();
export function normalizeQuranColor(value,fallback) {
 return typeof value==='string'&&/^#[0-9a-f]{6}$/i.test(value)?value.toLowerCase():fallback;
}
export function normalizeQuranColors(value) {
 return Object.freeze({followApp:value?.followApp!==false,text:normalizeQuranColor(value?.text,DEFAULT_QURAN_COLORS.text),background:normalizeQuranColor(value?.background,DEFAULT_QURAN_COLORS.background)});
}
export function readQuranColors(storage) {
 try{return normalizeQuranColors(JSON.parse(storage?.getItem(QURAN_COLOR_KEY)||'null'))}catch{return DEFAULT_QURAN_COLORS}
}
export function deriveQuranColorSurfaces(background) {
 const paper=normalizeQuranColor(background,DEFAULT_QURAN_COLORS.background),rgb=[1,3,5].map(at=>parseInt(paper.slice(at,at+2),16));
 const shade=(rgb[0]*299+rgb[1]*587+rgb[2]*114)/1000>=128?0:255;
 const mix=ratio=>'#'+rgb.map(channel=>Math.round(channel*(1-ratio)+shade*ratio).toString(16).padStart(2,'0')).join('');
 return Object.freeze({control:mix(.08),hover:mix(.14),border:mix(.22)});
}
let lastPaper='',paperSurfaces;
export function applyQuranColors(value,root) {
 const prefs=normalizeQuranColors(value);
 if(!root)return prefs;
 const mode=prefs.followApp?'app':'custom';
 if(root.dataset.quranColorMode!==mode)root.dataset.quranColorMode=mode;
 if(lastPaper!==prefs.background){lastPaper=prefs.background;paperSurfaces=deriveQuranColorSurfaces(lastPaper)}
 for(const [name,color]of [['--munibin-quran-custom-text',prefs.text],['--munibin-quran-custom-background',prefs.background],['--munibin-quran-custom-control-background',paperSurfaces.control],['--munibin-quran-custom-control-hover',paperSurfaces.hover],['--munibin-quran-custom-border',paperSurfaces.border]]) {
  const previous=root.style.getPropertyValue?.(name);
  if(prefs.followApp){if(previous!=='' )root.style.removeProperty(name)}
  else if(previous!==color)root.style.setProperty(name,color);
 }
 return prefs;
}
export function installQuranColors(target=window) {
 if(installs.has(target))return installs.get(target);
 let storage;try{storage=target.localStorage}catch{}
 const root=target.document?.documentElement;
 let prefs=applyQuranColors(readQuranColors(storage),root),frame=0,saveTimer=0,dirty=false;
 const later=target.setTimeout?.bind(target)||setTimeout,cancelLater=target.clearTimeout?.bind(target)||clearTimeout;
 const publish=()=>{applyQuranColors(prefs,root);target.dispatchEvent(new target.Event(QURAN_COLOR_EVENT))};
 const persist=()=>{if(!dirty||!storage)return;try{storage.setItem(QURAN_COLOR_KEY,JSON.stringify(prefs));dirty=false}catch{}};
 const flush=()=>{if(frame){target.cancelAnimationFrame?.(frame);frame=0;publish()}};
 const commit=()=>{if(saveTimer){cancelLater(saveTimer);saveTimer=0}flush();persist();return prefs};
 const change=(patch,preview)=>{
  const next=normalizeQuranColors({...prefs,...patch});
  if(next.followApp===prefs.followApp&&next.text===prefs.text&&next.background===prefs.background){if(!preview)commit();return prefs}
  prefs=next;dirty=true;
  if(preview) {
   // The slider and its small local preview move immediately. Repaint the Quran
   // once per frame, and persist only after the drag settles or is released.
   if(!frame){if(target.requestAnimationFrame)frame=target.requestAnimationFrame(()=>{frame=0;publish()});else publish()}
   if(saveTimer)cancelLater(saveTimer);saveTimer=later(()=>{saveTimer=0;persist()},180);
  } else {
   if(frame){target.cancelAnimationFrame?.(frame);frame=0}
   if(saveTimer){cancelLater(saveTimer);saveTimer=0}
   publish();persist();
  }
  return prefs;
 };
 const bridge={
  get:()=>prefs,
  update:patch=>change(patch,false),
  preview:patch=>change(patch,true),
  commit,
  reset(field) {return field==='text'||field==='background'?bridge.update({[field]:DEFAULT_QURAN_COLORS[field],followApp:false}):prefs},
  restore() {
   // Keep a current drag or an in-memory choice when storage is unavailable.
   if(dirty){commit();applyQuranColors(prefs,root);return}
   if(!storage){applyQuranColors(prefs,root);return}
   let next;try{next=normalizeQuranColors(JSON.parse(storage.getItem(QURAN_COLOR_KEY)||'null'))}catch{applyQuranColors(prefs,root);return}
   if(next.followApp!==prefs.followApp||next.text!==prefs.text||next.background!==prefs.background){prefs=next;publish()}else applyQuranColors(prefs,root);
  }
 };
 target.addEventListener('storage',event=>{if(event.key===QURAN_COLOR_KEY||event.key===null)bridge.restore()});
 target.addEventListener('pageshow',()=>bridge.restore());
 target.addEventListener('pagehide',commit);
 target.document?.addEventListener?.('visibilitychange',()=>{if(target.document.hidden)commit()});
 target.addEventListener('beforeunload',commit);
 installs.set(target,bridge);return bridge;
}
export const QURAN_COLOR_SPECTRUM=Object.freeze([
 [0,'#ff3b30'],[90,'#ff9500'],[180,'#ffd60a'],[290,'#4ecb71'],[410,'#00c9d8'],[530,'#1674f5'],[650,'#922bd0'],[750,'#ee247b'],[870,'#ffffff'],[1000,'#111111']
]);
export function spectrumColor(value) {
 const position=Math.max(0,Math.min(1000,Number(value)||0));
 let left=QURAN_COLOR_SPECTRUM[0],right=QURAN_COLOR_SPECTRUM.at(-1);
 for(let index=1;index<QURAN_COLOR_SPECTRUM.length;index++)if(position<=QURAN_COLOR_SPECTRUM[index][0]){left=QURAN_COLOR_SPECTRUM[index-1];right=QURAN_COLOR_SPECTRUM[index];break}
 const ratio=(position-left[0])/(right[0]-left[0]);
 return '#'+[1,3,5].map(index=>Math.round(parseInt(left[1].slice(index,index+2),16)*(1-ratio)+parseInt(right[1].slice(index,index+2),16)*ratio).toString(16).padStart(2,'0')).join('');
}
export function closestSpectrumPosition(color) {
 const rgb=[1,3,5].map(index=>parseInt(color.slice(index,index+2),16));
 let best=0,distance=Infinity;
 for(let position=0;position<=1000;position++) {
  const sample=spectrumColor(position);const next=[1,3,5].reduce((sum,index,channel)=>sum+(parseInt(sample.slice(index,index+2),16)-rgb[channel])**2,0);
  if(next<distance){distance=next;best=position}
 }
 return best;
}
const PRESETS=Object.freeze({
 text:[['بني داكن','#2f251b'],['أسود','#111111'],['أبيض','#ffffff'],['أخضر','#236b50'],['أزرق','#1674f5'],['بنفسجي','#922bd0'],['وردي','#ee247b'],['رمادي','#788995']],
 background:[['كريمي','#fff7e7'],['أبيض','#ffffff'],['بيج','#eadbc1'],['أخضر فاتح','#e3ede6'],['أزرق فاتح','#e1eaf2'],['رمادي','#d6dadd'],['زيتوني داكن','#202b1c'],['داكن','#111111']]
});
export function createQuranColorSettings(React,createPortal) {
 const h=React.createElement,bridge=installQuranColors();
 // Same Pencil paths as the existing app icon set.
 const icon=h('svg',{viewBox:'0 0 24 24',fill:'none',stroke:'currentColor',strokeWidth:1.8,strokeLinecap:'round',strokeLinejoin:'round','aria-hidden':true},h('path',{d:'M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z'}),h('path',{d:'m15 5 4 4'}));
 return function QuranColorSettings() {
  const [prefs,setPrefs]=React.useState(bridge.get),[open,setOpen]=React.useState(false),[tab,setTab]=React.useState('text'),[position,setPosition]=React.useState(()=>closestSpectrumPosition(bridge.get().text));
  const trigger=React.useRef(null),sheet=React.useRef(null),spectrumChoice=React.useRef(null);
  React.useEffect(()=>{const change=()=>setPrefs(bridge.get());window.addEventListener(QURAN_COLOR_EVENT,change);return()=>window.removeEventListener(QURAN_COLOR_EVENT,change)},[]);
  React.useEffect(()=>{if(spectrumChoice.current?.tab!==tab||spectrumChoice.current?.color!==prefs[tab])setPosition(closestSpectrumPosition(prefs[tab]))},[tab,prefs[tab]]);
  React.useEffect(()=>()=>bridge.commit(),[]);
  React.useEffect(()=>{
   if(!open)return;
   // The parent Quran settings sheet owns the body scroll lock. The nested
   // dialog must not restore 'hidden' after a parent-first navigation cleanup.
   sheet.current?.querySelector('button')?.focus({preventScroll:true});
   const keydown=event=>{
    if(event.key==='Escape'){event.preventDefault();event.stopPropagation();setOpen(false);return}
    if(event.key!=='Tab')return;
    const choices=Array.from(sheet.current?.querySelectorAll('button:not(:disabled), input:not(:disabled), [tabindex="0"]')||[]);
    const first=choices[0],last=choices.at(-1);if(!first)return;
    if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus()}
    else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus()}
   };
   document.addEventListener('keydown',keydown,true);
   return()=>{bridge.commit();document.removeEventListener('keydown',keydown,true);trigger.current?.focus({preventScroll:true})};
  },[open]);
  const choose=color=>{spectrumChoice.current=null;return bridge.update({[tab]:color,followApp:false})};
  const slide=event=>{const value=Number(event.target.value),color=spectrumColor(value);spectrumChoice.current={tab,color};setPosition(value);setPrefs(bridge.preview({[tab]:color,followApp:false}))};
  const exact=event=>{const color=normalizeQuranColor(event.target.value,bridge.get()[tab]);spectrumChoice.current={tab,color};setPrefs(bridge.preview({[tab]:color,followApp:false}))};
  const finishExact=()=>{bridge.commit();spectrumChoice.current=null;setPosition(closestSpectrumPosition(bridge.get()[tab]))};
  const previewStyle=prefs.followApp?undefined:{backgroundColor:prefs.background,color:prefs.text};
  const colorLabel=tab==='text'?'لون خط الآيات':'لون خلفية القراءة';
  const modal=open&&h('div',{className:'munibin-quran-color-backdrop',onPointerDown:event=>{if(event.target===event.currentTarget)setOpen(false)}},
   h('section',{ref:sheet,role:'dialog','aria-modal':true,'aria-labelledby':'munibin-quran-color-title',className:'munibin-quran-color-dialog',dir:'rtl'},
    h('header',{className:'munibin-quran-color-heading'},h('h2',{id:'munibin-quran-color-title'},'ألوان قراءة القرآن'),h('button',{type:'button',className:'munibin-quran-color-close','aria-label':'إغلاق ألوان القراءة',onClick:()=>setOpen(false)},h('svg',{viewBox:'0 0 24 24',fill:'none',stroke:'currentColor',strokeWidth:2,strokeLinecap:'round','aria-hidden':true},h('path',{d:'m6 6 12 12M18 6 6 18'})))),
    h('div',{className:'munibin-quran-color-tabs',role:'tablist','aria-label':'نوع لون القراءة'},[['text','لون خط الآيات'],['background','لون خلفية القراءة']].map(([value,label])=>h('button',{key:value,id:`munibin-quran-color-tab-${value}`,type:'button',role:'tab','aria-selected':tab===value,'aria-controls':'munibin-quran-color-panel',tabIndex:tab===value?0:-1,onClick:()=>setTab(value),onKeyDown:event=>{if(event.key==='ArrowLeft'||event.key==='ArrowRight'){event.preventDefault();const next=tab==='text'?'background':'text';setTab(next);sheet.current?.querySelector(`#munibin-quran-color-tab-${next}`)?.focus()}},children:label}))),
    h('div',{id:'munibin-quran-color-panel',role:'tabpanel','aria-labelledby':`munibin-quran-color-tab-${tab}`,className:'munibin-quran-color-panel'},
     h('div',{className:'munibin-quran-color-sample',style:previewStyle,'aria-label':'معاينة لون النص والخلفية'},h('span',{'aria-hidden':true},'ض')),
     h('div',{className:'munibin-quran-color-presets','aria-label':colorLabel},PRESETS[tab].map(([label,color])=>h('button',{key:color,type:'button',className:'munibin-quran-color-swatch',style:{backgroundColor:color},'aria-label':label,'aria-pressed':prefs[tab]===color,onClick:()=>choose(color)},h('span',{'aria-hidden':true,style:{color:parseInt(color.slice(1),16)>0x888888?'#111111':'#ffffff'}},'✓')))),
     h('div',{className:'munibin-quran-color-spectrum',dir:'ltr'},h('input',{type:'range',min:0,max:1000,step:1,value:position,'aria-label':`طيف ${colorLabel}`,'aria-valuetext':prefs[tab],onInput:slide,onChange:slide,onPointerUp:()=>bridge.commit(),onPointerCancel:()=>bridge.commit(),onKeyUp:()=>bridge.commit(),onBlur:()=>bridge.commit()})),
     h('label',{className:'munibin-quran-color-exact'},h('span',null,'اختيار لون آخر'),h('input',{type:'color',value:prefs[tab],'aria-label':`اختيار ${colorLabel}`,onInput:exact,onChange:exact,onBlur:finishExact,onKeyUp:finishExact,onPointerUp:()=>bridge.commit()}))),
    h('footer',{className:'munibin-quran-color-footer'},h('button',{type:'button',className:'munibin-quran-color-default',onClick:()=>bridge.reset(tab)},'اللون الافتراضي'),h('div',{className:'munibin-quran-color-app-row'},h('span',{id:'munibin-quran-color-app-label'},'مشابه للتطبيق'),h('button',{type:'button',role:'switch','aria-checked':prefs.followApp,'aria-labelledby':'munibin-quran-color-app-label',className:'munibin-quran-color-app-switch',onClick:()=>bridge.update({followApp:!bridge.get().followApp})},h('span'))))));
  return h(React.Fragment,null,h('div',{className:'munibin-quran-color-setting'},h('span',{className:'munibin-quran-color-label'},'لون نص القرآن وخلفيته'),h('span',{className:'munibin-quran-color-preview','aria-hidden':true,style:previewStyle},'ض'),h('button',{ref:trigger,type:'button',className:'munibin-quran-color-opener','aria-label':'تعديل لون نص القرآن وخلفيته','aria-haspopup':'dialog','aria-expanded':open,onClick:()=>{setPrefs(bridge.get());setOpen(true)}},icon)),modal&&createPortal(modal,document.body));
 };
}
