// Prayer clocks keep their canonical HH:mm data; this module changes display only.
export const PRAYER_TIME_FORMAT_KEY = 'munibin:prayer-time-format:v1';
export const PRAYER_TIME_FORMAT_EVENT = 'munibin-prayer-time-format-change';
export const PRAYER_THEME_EVENT = 'munibin-prayer-theme-change';

export function normalizePrayerTimeFormat(value) {
  return value === '12h' ? '12h' : '24h';
}

export function asciiPrayerDigits(value) {
  return String(value ?? '').replace(/[\u0660-\u0669\u06f0-\u06f9]/g, digit => String(digit.charCodeAt(0) - (digit >= '\u06f0' ? 0x06f0 : 0x0660)));
}

let sessionPrayerTimeFormat = null;
export function readPrayerTimeFormat(storage) {
  if (sessionPrayerTimeFormat) return sessionPrayerTimeFormat;
  try {
    const source = storage === undefined ? globalThis.localStorage : storage;
    const saved = source?.getItem(PRAYER_TIME_FORMAT_KEY);
    if (saved === '12h' || saved === '24h') return saved;
  } catch {}
  try {
    const native = globalThis.window?.MunibinAndroid?.getPrayerTimeFormat;
    if (typeof native === 'function') {
      const saved = native.call(window.MunibinAndroid);
      if (saved === '12h' || saved === '24h') return saved;
    }
  } catch {}
  // The iOS shell exposes its saved native choice even if web storage is blocked.
  const nativeFallback = globalThis.window?.__munibinPrayerTimeFormat;
  return nativeFallback === '12h' || nativeFallback === '24h' ? nativeFallback : '24h';
}

function syncNativePrayerTimeFormat(timeFormat, explicit = false) {
  const native = globalThis.window;
  try {
    if (native?.__munibinPrayerTimeFormat === '12h' || native?.__munibinPrayerTimeFormat === '24h') native.__munibinPrayerTimeFormat = timeFormat;
    if (typeof native?.MunibinAndroid?.setPrayerTimeFormat === 'function') native.MunibinAndroid.setPrayerTimeFormat(timeFormat);
    native?.webkit?.messageHandlers?.['prayer-time-format']?.postMessage({ timeFormat, explicit });
  } catch {}
}

export function savePrayerTimeFormat(value, storage) {
  const clean = normalizePrayerTimeFormat(value);
  let persisted = false;
  try {
    const source = storage === undefined ? globalThis.localStorage : storage;
    source?.setItem(PRAYER_TIME_FORMAT_KEY, clean);
    persisted = source?.getItem(PRAYER_TIME_FORMAT_KEY) === clean;
  } catch {}
  // A denied write must not let an older stored mode undo this session's choice.
  sessionPrayerTimeFormat = persisted ? null : clean;
  syncNativePrayerTimeFormat(clean, true);
  if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent(PRAYER_TIME_FORMAT_EVENT, { detail: { timeFormat: clean } }));
  return clean;
}

export function formatPrayerClock(value, timeFormat = readPrayerTimeFormat()) {
  if (value == null || value === '') return '—:—';
  const text = asciiPrayerDigits(value).trim();
  const match = /^(\d{1,2}):(\d{2})(?::\d{2})?(?:\s.*)?$/.exec(text);
  if (!match) return text;
  const hour = Number(match[1]), minute = Number(match[2]);
  if (hour > 23 || minute > 59) return text;
  if (normalizePrayerTimeFormat(timeFormat) === '24h') return `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
  return `${hour % 12 || 12}:${String(minute).padStart(2, '0')} ${hour < 12 ? 'ص' : 'م'}`;
}

// Iqama list annotations are configured minutes after adhan, independent of clock format.
export function formatPrayerIqamaOffset(minutes) {
  return Number.isSafeInteger(minutes) && minutes > 0 ? `+${minutes}` : '';
}

const prayerInstantClockFormatters = new Map();
export function formatPrayerInstantClock(instant, timeZone, timeFormat = readPrayerTimeFormat()) {
  const date = new Date(instant);
  if (!Number.isFinite(date.getTime())) return null;
  let clock;
  if (timeZone) {
    try {
      let formatter = prayerInstantClockFormatters.get(timeZone);
      if (formatter) prayerInstantClockFormatters.delete(timeZone);
      else formatter = new Intl.DateTimeFormat('en-US-u-nu-latn', {timeZone, hour: '2-digit', minute: '2-digit', hourCycle: 'h23'});
      prayerInstantClockFormatters.set(timeZone, formatter);
      if (prayerInstantClockFormatters.size > 16) prayerInstantClockFormatters.delete(prayerInstantClockFormatters.keys().next().value);
      const parts = Object.fromEntries(formatter.formatToParts(date).filter(part => part.type === 'hour' || part.type === 'minute').map(part => [part.type, part.value]));
      clock = `${parts.hour}:${parts.minute}`;
    } catch { return null; }
  } else clock = `${date.getHours()}:${String(date.getMinutes()).padStart(2, '0')}`;
  return formatPrayerClock(clock, timeFormat);
}

const prayerPaletteIds = new Set(['cream', 'gold', 'olive', 'wood', 'blue', 'monochrome']);
function opaquePrayerColor(value, background, fallback) {
  const text = String(value || '').trim();
  const color = /^#([\da-f]{3}|[\da-f]{4}|[\da-f]{6}|[\da-f]{8})$/i.exec(text);
  let rgb, alpha = 1;
  if (color) {
    let hex = color[1];
    if (hex.length < 5) hex = Array.from(hex, character => character + character).join('');
    alpha = hex.length === 8 ? parseInt(hex.slice(6), 16) / 255 : 1;
    rgb = [0, 2, 4].map(index => parseInt(hex.slice(index, index + 2), 16));
  } else {
    const functional = /^rgba?\(([^()]+)\)$/i.exec(text);
    if (!functional) return fallback;
    const tokens = functional[1].replace(/,/g, ' ').replace(/\//g, ' / ').trim().split(/\s+/);
    const slash = tokens.indexOf('/');
    const channels = slash >= 0 ? tokens.slice(0, slash) : tokens.slice(0, 3);
    const opacity = slash >= 0 ? tokens.slice(slash + 1) : tokens.slice(3);
    if (channels.length !== 3 || opacity.length > 1) return fallback;
    const number = (token, max) => {
      if (!/^(?:\d+(?:\.\d+)?|\.\d+)%?$/.test(token)) return NaN;
      const percentage = token.endsWith('%');
      const value = Number(percentage ? token.slice(0, -1) : token);
      return value >= 0 && value <= (percentage ? 100 : max) ? (percentage ? value * max / 100 : value) : NaN;
    };
    rgb = channels.map(channel => number(channel, 255));
    alpha = opacity.length ? number(opacity[0], 1) : 1;
    if (!rgb.every(Number.isFinite) || !Number.isFinite(alpha)) return fallback;
  }
  const base = [1, 3, 5].map(index => parseInt(background.slice(index, index + 2), 16));
  return '#' + rgb.map((channel, index) => Math.round(channel * alpha + base[index] * (1 - alpha)).toString(16).padStart(2, '0')).join('').toUpperCase();
}
export function readPrayerTheme() {
  const root = globalThis.document?.documentElement;
  const light = root?.classList?.contains('light') === true;
  const theme = light ? 'light' : 'dark';
  const backgroundPalette = prayerPaletteIds.has(root?.dataset?.backgroundPalette) ? root.dataset.backgroundPalette : 'cream';
  const style = root && typeof globalThis.getComputedStyle === 'function' ? getComputedStyle(root) : null;
  const raw = name => style?.getPropertyValue(name)?.trim();
  const backgroundStart = opaquePrayerColor(raw('--app-bg'), '#000000', light ? '#FDF6E3' : '#3D1506');
  const backgroundEnd = opaquePrayerColor(raw('--app-card-bg'), backgroundStart, backgroundStart);
  const accent = opaquePrayerColor(raw('--app-gold'), backgroundEnd, light ? '#B45309' : '#F59E0B');
  const primary = opaquePrayerColor(raw('--app-text-primary'), backgroundEnd, light ? '#3D1506' : '#FFFFFF');
  return { theme, backgroundPalette, themeColors: {
    backgroundStart, backgroundEnd, accent, primary,
    secondary: opaquePrayerColor(raw('--app-text-secondary'), backgroundEnd, light ? '#866453' : '#CDBEB8'),
    border: opaquePrayerColor(raw('--app-card-border'), backgroundEnd, accent),
    iconBackground: opaquePrayerColor(raw('--app-badge-bg'), backgroundEnd, backgroundEnd),
    highlight: light ? '#12642F' : '#85F0AB',
    iqama: light ? '#A32335' : '#FFB4AE'
  } };
}
let lastPrayerNativeTheme = '';
export function syncNativePrayerTheme(value = readPrayerTheme()) {
  const serialized = JSON.stringify(value);
  if (serialized === lastPrayerNativeTheme) return value;
  try {
    globalThis.window?.MunibinAndroid?.setPrayerTheme?.(serialized);
    globalThis.window?.webkit?.messageHandlers?.['prayer-theme']?.postMessage(value);
    lastPrayerNativeTheme = serialized;
  } catch {}
  return value;
}
function installPrayerThemeRefresh() {
  const root = globalThis.document?.documentElement;
  if (!root || typeof MutationObserver === 'undefined') return;
  let previous = '';
  const refresh = () => {
    const value = readPrayerTheme(), serialized = JSON.stringify(value);
    if (serialized === previous) return;
    previous = serialized;
    syncNativePrayerTheme(value);
    window.dispatchEvent(new CustomEvent(PRAYER_THEME_EVENT, { detail: value }));
  };
  new MutationObserver(refresh).observe(root, { attributes: true, attributeFilter: ['class', 'data-background-palette'] });
  queueMicrotask(refresh);
}
installPrayerThemeRefresh();

export function readPrayerLiveActivityEnabled() {
  return globalThis.window?.__munibinPrayerLiveActivityEnabled === true;
}
if (typeof window !== 'undefined') {
  window.addEventListener('munibin-prayer-live-activity-status', event => {
    window.__munibinPrayerLiveActivityEnabled = event.detail?.enabled === true;
  });
}

// A countdown is an elapsed duration, so 12/24-hour clock choices never alter it.
export function formatPrayerDuration(seconds) {
  const numeric = Number(seconds);
  const remaining = Number.isFinite(numeric) ? Math.max(0, Math.floor(numeric)) : 0;
  const hours = Math.floor(remaining / 3600), minutes = Math.floor(remaining % 3600 / 60), rest = remaining % 60;
  return [hours, minutes, rest].map(part => String(part).padStart(2, '0')).join(':');
}

// Display dates follow the countdown's real prayer date, not the device's civil day.
const prayerDisplayDateFormatters = new Map();
export function prayerDisplayDayForInstant(instant, timeZone) {
  const date = new Date(instant);
  if (!Number.isFinite(date.getTime())) return null;
  if (!timeZone) return `${String(date.getDate()).padStart(2, '0')}-${String(date.getMonth() + 1).padStart(2, '0')}-${date.getFullYear()}`;
  try {
    let formatter = prayerDisplayDateFormatters.get(timeZone);
    if (!formatter) {
      formatter = new Intl.DateTimeFormat('en-GB-u-nu-latn', { timeZone, day: '2-digit', month: '2-digit', year: 'numeric' });
      prayerDisplayDateFormatters.set(timeZone, formatter);
      if (prayerDisplayDateFormatters.size > 16) prayerDisplayDateFormatters.delete(prayerDisplayDateFormatters.keys().next().value);
    }
    const parts = Object.fromEntries(formatter.formatToParts(date).filter(part => ['day', 'month', 'year'].includes(part.type)).map(part => [part.type, part.value]));
    return `${parts.day}-${parts.month}-${parts.year}`;
  } catch { return null; }
}

export function formatPrayerHijriDate(date) {
  const raw = asciiPrayerDigits(date?.hijriDate ?? date?.hijri?.date ?? '');
  const match = /^(\d{1,2})-\d{1,2}-(\d{4})$/.exec(raw);
  const day = match ? String(Number(match[1])) : raw.split('-')[0] || '';
  const month = date?.hijriMonth ?? date?.hijri?.month?.ar ?? '';
  const year = asciiPrayerDigits(date?.hijriYear ?? date?.hijri?.year ?? match?.[2] ?? '');
  return [day && `${day}-`, month, year && `- ${year}`].filter(Boolean).join(' ').trim();
}

export function resolvePrayerDisplayTimetable({ day, data, timings, timeZone, target, calendar, adjustTimings = value => value } = {}) {
  const fallback = { day, data, timings, timeZone };
  // An iqama can end after midnight; its rows still belong to the adhan's day.
  const targetDay = target?.day || prayerDisplayDayForInstant(target?.kind === 'iqama' ? target.startsAt : target?.time, timeZone);
  if (!targetDay || targetDay === day) return fallback;
  const selected = calendar?.days?.[targetDay];
  const selectedZone = selected?.meta?.timezone || timeZone;
  const keys = ['Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
  if (!selected?.timings || (timeZone && selectedZone !== timeZone) || !keys.every(key => /^([01]?\d|2[0-3]):[0-5]\d$/.test(String(selected.timings[key] ?? '')))) return fallback;
  return { day: targetDay, data: selected, timings: adjustTimings(selected.timings), timeZone: selectedZone };
}

// The main countdown is display-only; canonical adhan events and schedules remain untouched.
export function resolvePrayerCountdownTarget({ day, timings, iqamaOffsets, now, timeZone, toInstant, nextPrayer, calendar, adjustTimings = value => value } = {}) {
  const fallback = nextPrayer ? { ...nextPrayer, kind: nextPrayer.key === 'Sunrise' ? 'sunrise' : 'prayer', day: prayerDisplayDayForInstant(nextPrayer.time, timeZone) } : null;
  const current = new Date(now).getTime();
  if (!Number.isFinite(current) || typeof toInstant !== 'function' || !timings) return fallback;
  const match = /^(\d{2})-(\d{2})-(\d{4})$/.exec(String(day ?? ''));
  if (!match) return fallback;
  const [dateDay, month, year] = match.slice(1).map(Number);
  const date = new Date(Date.UTC(year, month - 1, dateDay));
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== dateDay) return fallback;
  date.setUTCDate(date.getUTCDate() - 1);
  const previousDay = `${String(date.getUTCDate()).padStart(2, '0')}-${String(date.getUTCMonth() + 1).padStart(2, '0')}-${date.getUTCFullYear()}`;
  const previous = calendar?.days?.[previousDay];
  const days = [{ day, timings, timeZone }];
  if (previous?.timings) days.unshift({ day: previousDay, timings: adjustTimings(previous.timings), timeZone: previous.meta?.timezone || timeZone });
  const prayers = [['Fajr', 'الفجر'], ['Dhuhr', 'الظهر'], ['Asr', 'العصر'], ['Maghrib', 'المغرب'], ['Isha', 'العشاء']];
  let active = null;
  for (const candidate of days) for (const [key, label] of prayers) {
    const minutes = iqamaOffsets?.[key];
    if (!Number.isInteger(minutes) || minutes <= 0 || !/^\d{1,2}:\d{2}$/.test(String(candidate.timings?.[key] ?? ''))) continue;
    const raw = toInstant(candidate.day, candidate.timings[key], candidate.timeZone);
    const startsAt = typeof raw === 'number' ? raw : typeof raw === 'string' ? Date.parse(raw) : raw instanceof Date ? raw.getTime() : NaN;
    const endsAt = startsAt + minutes * 60000;
    if (!Number.isFinite(startsAt) || !Number.isFinite(endsAt) || current < startsAt || current >= endsAt || !Number.isFinite(new Date(endsAt).getTime())) continue;
    if (!active || startsAt < active.startsAt) active = { kind: 'iqama', key, label: `${label} إقامة`, time: new Date(endsAt), startsAt, day: candidate.day };
  }
  if (active) return active;
  // Sunrise participates in the countdown even though the canonical adhan fallback contains only five prayers.
  const sunriseRaw = /^\d{1,2}:\d{2}$/.test(String(timings.Sunrise ?? '')) ? toInstant(day, timings.Sunrise, timeZone) : null;
  const sunriseAt = typeof sunriseRaw === 'number' ? sunriseRaw : typeof sunriseRaw === 'string' ? Date.parse(sunriseRaw) : sunriseRaw instanceof Date ? sunriseRaw.getTime() : NaN;
  const fallbackAt = fallback?.time instanceof Date ? fallback.time.getTime() : typeof fallback?.time === 'number' ? fallback.time : typeof fallback?.time === 'string' ? Date.parse(fallback.time) : NaN;
  if (Number.isFinite(sunriseAt) && sunriseAt > current && (!Number.isFinite(fallbackAt) || sunriseAt < fallbackAt)) {
    return { kind: 'sunrise', key: 'Sunrise', label: 'الشروق', time: new Date(sunriseAt), day };
  }
  return fallback;
}

export function createPrayerDisplayComponents(React) {
  const h = React.createElement;
  function usePrayerTimeFormat() {
    const [timeFormat, setTimeFormat] = React.useState(() => readPrayerTimeFormat());
    React.useEffect(() => {
      const refresh = () => setTimeFormat(readPrayerTimeFormat());
      window.addEventListener(PRAYER_TIME_FORMAT_EVENT, refresh);
      window.addEventListener('storage', refresh);
      syncNativePrayerTimeFormat(readPrayerTimeFormat());
      return () => { window.removeEventListener(PRAYER_TIME_FORMAT_EVENT, refresh); window.removeEventListener('storage', refresh); };
    }, []);
    return [timeFormat, value => setTimeFormat(savePrayerTimeFormat(value))];
  }
  // Keep the clock's LTR digits intact and the Arabic suffix after it in RTL reading order.
  function PrayerClockValue({ value }) {
    const clock = asciiPrayerDigits(value ?? '—:—');
    const match = /^(\d{1,2}:\d{2})(?:\s([صم]))?$/.exec(clock);
    return h('bdi', { className: 'munibin-prayer-clock-value', dir: 'rtl' },
      match ? [h('bdi', { key: 'clock', dir: 'ltr' }, match[1]), match[2] ? ' ' + match[2] : null] : clock);
  }
  function PrayerIqamaOffset({ minutes, active = false, prayerLabel = '' }) {
    const value = formatPrayerIqamaOffset(minutes);
    if (!value) return null;
    return h('bdi', {
      className: 'munibin-prayer-iqama-offset tabular-nums', dir: 'ltr',
      'data-active': active === true,
      'aria-label': `إقامة ${prayerLabel} بعد الأذان بـ ${minutes} دقيقة`
    }, value);
  }
  function PrayerTimeFormatChoice({ value, onChange }) {
    const selected = normalizePrayerTimeFormat(value);
    return h('div', { className: 'munibin-prayer-time-format', dir: 'rtl' },
      h('span', { className: 'munibin-prayer-time-format-label' }, 'صيغة الوقت'),
      h('div', { className: 'munibin-prayer-time-format-options', role: 'group', 'aria-label': 'صيغة مواقيت الصلاة' },
        [['12h', '12 ساعة'], ['24h', '24 ساعة']].map(([format, label]) => h('button', {
          key: format, type: 'button', 'aria-pressed': selected === format, 'data-selected': selected === format,
          className: 'munibin-prayer-time-format-option', onClick: () => onChange(format)
        }, label))));
  }
  function usePrayerLiveActivityEnabled() {
    const [enabled, setEnabled] = React.useState(readPrayerLiveActivityEnabled);
    React.useEffect(() => {
      const handler = window.webkit?.messageHandlers?.['munibin-prayer-live-activity'];
      if (!handler) return;
      const refresh = event => {
        const next = event.detail?.enabled === true;
        window.__munibinPrayerLiveActivityEnabled = next;
        setEnabled(next);
      };
      window.addEventListener('munibin-prayer-live-activity-status', refresh);
      handler.postMessage({ action: 'status' });
      return () => window.removeEventListener('munibin-prayer-live-activity-status', refresh);
    }, []);
    return enabled;
  }
  function PrayerLiveActivityControl({ configured }) {
    const handler = globalThis.window?.webkit?.messageHandlers?.['munibin-prayer-live-activity'];
    const [status, setStatus] = React.useState(() => ({
      supported: window.__munibinPrayerLiveActivitySupported === true,
      enabled: window.__munibinPrayerLiveActivityEnabled === true,
      active: false
    }));
    React.useEffect(() => {
      if (!handler) return;
      const refresh = event => {
        if (event.detail && typeof event.detail === 'object') setStatus(event.detail);
      };
      window.addEventListener('munibin-prayer-live-activity-status', refresh);
      handler.postMessage({ action: 'status' });
      return () => window.removeEventListener('munibin-prayer-live-activity-status', refresh);
    }, []);
    if (!handler || !status.supported) return null;
    const toggle = () => {
      handler.postMessage({ enabled: !status.enabled, explicit: true });
    };
    return h('div', { className: 'munibin-prayer-live-activity', dir: 'rtl' },
      h('div', { className: 'munibin-prayer-live-activity-row' },
        h('span', { className: 'munibin-prayer-live-activity-label' }, 'إشعار مواقيت الصلاة المباشر'),
        h('button', { type: 'button', role: 'switch', 'aria-label': 'إشعار مواقيت الصلاة المباشر', 'aria-checked': status.enabled === true,
          'aria-describedby': status.message ? 'munibin-prayer-live-activity-status' : undefined,
          disabled: !configured && !status.enabled, onClick: toggle, className: 'munibin-prayer-live-activity-switch', 'data-on': status.enabled === true },
          h('span', { className: 'munibin-prayer-live-activity-switch-track', 'aria-hidden': true },
            h('span', { className: 'munibin-prayer-live-activity-switch-thumb' })))),
      status.message ? h('p', { id: 'munibin-prayer-live-activity-status', role: 'status', className: 'munibin-prayer-live-activity-status' }, status.message) : null);
  }
  return { usePrayerTimeFormat, PrayerTimeFormatChoice, PrayerLiveActivityControl, usePrayerLiveActivityEnabled, PrayerClockValue, PrayerIqamaOffset };
}
