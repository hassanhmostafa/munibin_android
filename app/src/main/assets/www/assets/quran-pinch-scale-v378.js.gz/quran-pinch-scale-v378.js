/* Live pinch paint belongs to the visible page, not its retained neighbors.
   React and the existing fitters still own reflow boundaries and final zoom. */
const SCALE='--munibin-reading-scale';
const ARTICLE='[data-scroll-page]';
const SPREAD_LEAF='.munibin-quran-leaf:not(.munibin-quran-turn-placeholder)';
function connected(node) {return !!node&&node.isConnected!==false}
function readingRoot(root) {
 return root?.matches?.('.qcf1441-preview')?root:root?.closest?.('.qcf1441-preview')||root;
}
function nextArticle(node,direction) {
 let sibling=direction<0?node.previousElementSibling:node.nextElementSibling;
 while(sibling&&!sibling.matches?.(ARTICLE))sibling=direction<0?sibling.previousElementSibling:sibling.nextElementSibling;
 return sibling;
}
export function createQuranPinchScalePainter(root) {
 const reader=readingRoot(root),doc=reader?.ownerDocument||root?.ownerDocument;
 const painted=new Map();
 let lastScale=null,lastVerticalAnchor=null,disposed=false;
 const restore=(node,snapshot,committedScale)=>{
  const value=node.style.getPropertyValue(SCALE),priority=node.style.getPropertyPriority(SCALE);
  // A spread leaf owns its committed scale locally. Restoring its pre-pinch
  // value after updateLeafReading would silently undo the committed zoom.
  if(snapshot.spread&&committedScale!==undefined&&value===String(committedScale)) {
   if(priority!==snapshot.priority)node.style.setProperty(SCALE,value,snapshot.priority);
   return;
  }
  // An author write after the preview takes ownership, including its priority.
  if(value!==snapshot.preview||priority!==snapshot.previewPriority)return;
  if(snapshot.value)node.style.setProperty(SCALE,snapshot.value,snapshot.priority);else node.style.removeProperty(SCALE);
 };
 const visibleArticles=(scroller,point)=>{
  const bounds=scroller.getBoundingClientRect();
  const page=Number(point?.page);
  let anchor=Number.isInteger(page)&&page>=1&&page<=604?scroller.querySelector(`[data-scroll-page="${page}"]`):null;
  const pointed=(x,y)=>{
   const article=doc?.elementFromPoint?.(x,y)?.closest?.(ARTICLE);
   return article&&scroller.contains(article)?article:null;
  };
  if(!anchor&&Number.isFinite(point?.x)&&Number.isFinite(point?.y))anchor=pointed(point.x,point.y);
  if(!anchor)anchor=pointed(bounds.left+bounds.width/2,bounds.top+Math.min(Math.max(1,bounds.height*.22),130));
  if(!anchor&&connected(lastVerticalAnchor)&&scroller.contains(lastVerticalAnchor))anchor=lastVerticalAnchor;
  if(!connected(anchor))return [];
  lastVerticalAnchor=anchor;
  const targets=[anchor],rect=anchor.getBoundingClientRect();
  // A supplied word anchor can momentarily leave the viewport during reflow.
  // Paint it for anchor restoration without searching through distant pages.
  if(rect.bottom<=bounds.top||rect.top>=bounds.bottom)return targets;
  for(const direction of [-1,1]) {
   let node=nextArticle(anchor,direction);
   while(node) {
    const box=node.getBoundingClientRect();
    if(box.bottom<=bounds.top||box.top>=bounds.bottom)break;
    targets.push(node);node=nextArticle(node,direction);
   }
  }
  return targets;
 };
 const targetsFor=point=>{
  if(!connected(reader))return [];
  const spread=reader.querySelector('.munibin-quran-spread-sheet.is-active');
  if(spread)return Array.from(spread.querySelectorAll(SPREAD_LEAF)).filter(connected).map(node=>({node,spread:true}));
  const horizontal=reader.querySelector('.munibin-quran-horizontal-page.is-active');
  if(connected(horizontal))return [{node:horizontal,spread:false}];
  const vertical=reader.querySelector('.munibin-quran-vertical-pages');
  if(connected(vertical))return visibleArticles(vertical,point).map(node=>({node,spread:false}));
  const base=reader.querySelector('.qcf1441-page-layer--base');
  return connected(base)?[{node:base,spread:false}]:[];
 };
 const clear=({committedScale,currentScale}={})=>{
  // An older React boundary commit cannot erase a newer live pinch sample.
  // At100% the next structure is committed instead of locally previewed, so
  // the hook supplies its authoritative current scale rather than last paint.
  const latest=currentScale===undefined?lastScale:Number(currentScale);
  if(committedScale!==undefined&&latest!==null&&Number(committedScale)!==latest)return false;
  for(const [node,snapshot]of painted)restore(node,snapshot,committedScale);
  painted.clear();lastScale=null;lastVerticalAnchor=null;return true;
 };
 return {
  preview(scale,point) {
   const value=Number(scale);
   if(disposed||!Number.isFinite(value)||!(value>0))return 0;
   const targets=targetsFor(point),current=new Set(targets.map(({node})=>node));
   for(const [node,snapshot]of painted)if(!current.has(node)){restore(node,snapshot);painted.delete(node)}
   const text=String(value);
   for(const {node,spread}of targets) {
    let snapshot=painted.get(node);
    if(!snapshot) {
     snapshot={value:node.style.getPropertyValue(SCALE),priority:node.style.getPropertyPriority(SCALE),spread,preview:null,previewPriority:null};
     painted.set(node,snapshot);
    }
    const priority=snapshot.priority;
    if(node.style.getPropertyValue(SCALE)!==text||node.style.getPropertyPriority(SCALE)!==priority)node.style.setProperty(SCALE,text,priority);
    snapshot.preview=text;snapshot.previewPriority=priority;
   }
   lastScale=value;return targets.length;
  },
  clear,
  dispose() {if(disposed)return;clear();disposed=true}
 };
}
