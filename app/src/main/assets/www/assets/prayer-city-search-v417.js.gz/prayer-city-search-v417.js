import { createPrayerDisplayComponents, formatPrayerClock } from './prayer-display-v423.js';
const CITY_PRAYER_KEYS = ['Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
const CITY_NEXT_PRAYERS = [
  ['Fajr', 'الفجر'], ['Dhuhr', 'الظهر'], ['Asr', 'العصر'], ['Maghrib', 'المغرب'], ['Isha', 'العشاء']
];

export function isValidPrayerTimeZone(timeZone) {
  if (typeof timeZone !== 'string' || !timeZone.trim()) return false;
  try { new Intl.DateTimeFormat('en-US', { timeZone }).format(0); return true; } catch { return false; }
}

function cityServiceDate(now) {
  const date = new Date(now);
  if (!Number.isFinite(date.getTime())) throw new RangeError('تعذر تحديد تاريخ المواقيت.');
  return date;
}

function cityServiceName(value) {
  if (typeof value !== 'string') return '';
  const name = value.normalize('NFC').replace(/[\u0000-\u001f\u007f]/g, '').replace(/\s+/g, ' ').trim().slice(0, 180);
  return /[\p{L}\p{N}]/u.test(name) ? name : '';
}

function cityServiceCoordinates(city) {
  return !!city && typeof city === 'object' &&
    typeof city.latitude === 'number' && Number.isFinite(city.latitude) && city.latitude >= -90 && city.latitude <= 90 &&
    typeof city.longitude === 'number' && Number.isFinite(city.longitude) && city.longitude >= -180 && city.longitude <= 180;
}

function cityServiceAbort(signal) {
  if (!signal?.aborted) return;
  if (signal.reason?.name === 'AbortError' || signal.reason?.name === 'TimeoutError') throw signal.reason;
  if (typeof DOMException === 'function') throw new DOMException('تم إلغاء الطلب.', 'AbortError');
  const error = new Error('تم إلغاء الطلب.'); error.name = 'AbortError'; throw error;
}

function cityServiceZoneParts(now, timeZone) {
  return Object.fromEntries(new Intl.DateTimeFormat('en-US-u-ca-gregory-nu-latn', {
    timeZone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23'
  }).formatToParts(now).filter(part => ['year', 'month', 'day', 'hour', 'minute', 'second'].includes(part.type)).map(part => [part.type, Number(part.value)]));
}

function cityServiceDay(year, month, day) {
  return `${String(day).padStart(2, '0')}-${String(month).padStart(2, '0')}-${String(year).padStart(4, '0')}`;
}

// Missing/invalid zones retain the existing GPS device-calendar behavior.
// City records themselves are validated strictly before using these fallbacks.
export function prayerDayForZone(now, timeZone) {
  const date = cityServiceDate(now);
  if (!isValidPrayerTimeZone(timeZone)) return cityServiceDay(date.getFullYear(), date.getMonth() + 1, date.getDate());
  const parts = cityServiceZoneParts(date, timeZone);
  return cityServiceDay(parts.year, parts.month, parts.day);
}

// A wall-clock carrier for the existing highlight algorithm, never an event instant.
export function prayerClockForZone(now, timeZone) {
  const date = cityServiceDate(now);
  if (!isValidPrayerTimeZone(timeZone)) return date;
  const parts = cityServiceZoneParts(date, timeZone);
  return new Date(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, parts.second, date.getMilliseconds());
}

function cityServiceGregorianDay(value) {
  if (typeof value !== 'string') return null;
  let year, month, day;
  const text = value.trim();
  const dayFirst = /^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/.exec(text);
  const yearFirst = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
  if (dayFirst) [, day, month, year] = dayFirst.map(Number);
  else if (yearFirst) [, year, month, day] = yearFirst.map(Number);
  else return null;
  const date = new Date(Date.UTC(year, month - 1, day));
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) return null;
  return cityServiceDay(year, month, day);
}

function cityServiceTomorrow(day) {
  const normalized = cityServiceGregorianDay(day);
  if (!normalized) return null;
  const [date, month, year] = normalized.split('-').map(Number);
  const tomorrow = new Date(Date.UTC(year, month - 1, date + 1));
  return cityServiceDay(tomorrow.getUTCFullYear(), tomorrow.getUTCMonth() + 1, tomorrow.getUTCDate());
}

function cityServiceValidTime(value) {
  return typeof value === 'string' && /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value);
}

export function validatePrayerCityToday(today, expectedDay, expectedTimezone) {
  if (!today || typeof today !== 'object' || Array.isArray(today) || !today.timings ||
      !CITY_PRAYER_KEYS.every(key => cityServiceValidTime(today.timings[key])) ||
      !today.date || typeof today.date !== 'object' || Array.isArray(today.date) ||
      !today.meta || typeof today.meta !== 'object' || Array.isArray(today.meta)) return false;
  const suppliedZone = today.meta.timezone;
  if (suppliedZone != null && suppliedZone !== '' && !isValidPrayerTimeZone(suppliedZone)) return false;
  if (!isValidPrayerTimeZone(suppliedZone || expectedTimezone)) return false;
  const expected = expectedDay == null ? null : cityServiceGregorianDay(expectedDay);
  if (expectedDay != null && !expected) return false;
  const reportedDay = today.date.gregorianDate ?? today.date.gregorian?.date;
  if (reportedDay != null && reportedDay !== '') {
    const reported = cityServiceGregorianDay(reportedDay);
    if (!reported || (expected && reported !== expected)) return false;
  }
  return true;
}

export async function searchPrayerCities(query, { signal, fetcher = globalThis.fetch } = {}) {
  const name = typeof query === 'string' ? query.normalize('NFC').replace(/\s+/g, ' ').trim().slice(0, 100) : '';
  if (Array.from(name).length < 2) return [];
  cityServiceAbort(signal);
  if (typeof fetcher !== 'function') throw new Error('البحث عن المدن يحتاج إلى اتصال بالإنترنت.');
  const url = new URL('https://geocoding-api.open-meteo.com/v1/search');
  url.search = new URLSearchParams({ name, count: '8', language: 'ar', format: 'json' }).toString();
  let payload;
  try {
    const response = await fetcher(url.toString(), { signal, headers: { Accept: 'application/json' } });
    cityServiceAbort(signal);
    if (!response?.ok) throw new Error('تعذر البحث عن المدن. تحقق من اتصالك وحاول مرة أخرى.');
    payload = await response.json();
    cityServiceAbort(signal);
  } catch (error) {
    cityServiceAbort(signal);
    if (error?.name === 'AbortError' || error?.name === 'TimeoutError') throw error;
    throw new Error('تعذر البحث عن المدن. تحقق من اتصالك وحاول مرة أخرى.');
  }
  if (!payload || typeof payload !== 'object' || Array.isArray(payload) || payload.error || (payload.results != null && !Array.isArray(payload.results))) throw new Error('تعذر قراءة نتائج البحث عن المدن.');
  const found = [], ids = new Set(), coordinates = new Set();
  for (const city of payload?.results || []) {
    const cityName = cityServiceName(city?.name);
    const timezone = typeof city?.timezone === 'string' ? city.timezone.trim() : '';
    if (!cityServiceCoordinates(city) || !cityName || !isValidPrayerTimeZone(timezone)) continue;
    if (city.feature_code != null && city.feature_code !== '' && !/^P/i.test(String(city.feature_code))) continue;
    const point = `${city.latitude.toFixed(5)}:${city.longitude.toFixed(5)}`;
    const id = typeof city.id === 'number' && Number.isFinite(city.id) || typeof city.id === 'string' && city.id.trim()
      ? String(city.id).trim().slice(0, 100) : `city:${point}`;
    if (ids.has(id) || coordinates.has(point)) continue;
    ids.add(id); coordinates.add(point);
    found.push({ id, name: cityName, country: cityServiceName(city.country), admin1: cityServiceName(city.admin1), timezone, latitude: city.latitude, longitude: city.longitude });
    if (found.length === 8) break;
  }
  return found;
}

export function nextPrayerForZone(timings, now, timeZone, dateForPrayer, tomorrowTimings) {
  if (!timings || !CITY_NEXT_PRAYERS.every(([key]) => cityServiceValidTime(timings[key])) || typeof dateForPrayer !== 'function') return null;
  let date, zone;
  try {
    date = cityServiceDate(now);
    zone = isValidPrayerTimeZone(timeZone) ? timeZone : Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (!isValidPrayerTimeZone(zone)) return null;
  } catch { return null; }
  const day = prayerDayForZone(date, zone);
  for (const [key, label] of CITY_NEXT_PRAYERS) {
    let at;
    try { const instant = dateForPrayer(day, timings[key], zone); if (instant == null) return null; at = new Date(instant); } catch { return null; }
    if (!Number.isFinite(at.getTime())) return null;
    if (at.getTime() > date.getTime()) return { key, label, time: at };
  }
  const fajr = tomorrowTimings == null ? timings.Fajr : tomorrowTimings.Fajr;
  if (!cityServiceValidTime(fajr)) return null;
  try {
    const instant = dateForPrayer(cityServiceTomorrow(day), fajr, zone);
    if (instant == null) return null;
    const at = new Date(instant);
    return Number.isFinite(at.getTime()) && at.getTime() > date.getTime() ? { key: 'Fajr', label: 'الفجر', time: at } : null;
  } catch { return null; }
}

export async function queryPrayerCityToday(city, { signal, now = new Date(), queryToday } = {}) {
  if (!cityServiceCoordinates(city) || !cityServiceName(city.name) || !isValidPrayerTimeZone(city.timezone)) throw new Error('بيانات المدينة غير صالحة. اختر مدينة أخرى.');
  cityServiceAbort(signal);
  const clock = cityServiceDate(now);
  const client = globalThis.window?.__munibinTrpc || globalThis.__munibinTrpc;
  const request = queryToday || (client?.prayerTimes?.today?.query ? (input, options) => client.prayerTimes.today.query(input, options) : null);
  if (typeof request !== 'function') throw new Error('تعذر تحميل مواقيت المدينة. حاول مرة أخرى.');
  let zone = city.timezone;
  let day = prayerDayForZone(clock, zone);
  const readToday = async requestedDay => {
    const result = await request({ latitude: city.latitude, longitude: city.longitude, date: requestedDay }, { signal });
    cityServiceAbort(signal);
    if (!validatePrayerCityToday(result, undefined, zone)) throw new Error('تعذر التحقق من مواقيت هذه المدينة. حاول مرة أخرى.');
    return result;
  };
  let today = await readToday(day);
  const returnedZone = today.meta.timezone || zone;
  const returnedDay = prayerDayForZone(clock, returnedZone);
  if (returnedDay !== day) {
    zone = returnedZone;
    day = returnedDay;
    today = await readToday(day);
  }
  zone = today.meta.timezone || returnedZone;
  if (prayerDayForZone(clock, zone) !== day || !validatePrayerCityToday(today, day, zone)) throw new Error('تغيّر تاريخ مواقيت المدينة. حدّث النتائج ثم حاول مرة أخرى.');
  return {
    location: { latitude: city.latitude, longitude: city.longitude, cityName: cityServiceName(city.name), countryName: cityServiceName(city.country), admin1: cityServiceName(city.admin1), timeZone: zone, cityId: String(city.id ?? ''), source: 'city' },
    day, today
  };
}

// The service exports above this component are bundled into the same module.
export function createPrayerCityPicker(React) {
  const h = React.createElement;
  const { usePrayerTimeFormat } = createPrayerDisplayComponents(React);
  const prayers = [
    ['Fajr', 'الفجر'], ['Sunrise', 'الشروق'], ['Dhuhr', 'الظهر'],
    ['Asr', 'العصر'], ['Maghrib', 'المغرب'], ['Isha', 'العشاء']
  ];
  const aborted = () => Object.assign(new Error('تم إلغاء الطلب.'), { name: 'AbortError' });
  function deadline(task, parentSignal, milliseconds = 15000) {
    const controller = new AbortController();
    let timer;
    let detach = () => {};
    return new Promise((resolve, reject) => {
      let settled = false;
      const finish = (callback, value) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        detach();
        callback(value);
      };
      const cancel = () => { controller.abort(); finish(reject, aborted()); };
      if (parentSignal?.aborted) { cancel(); return; }
      parentSignal?.addEventListener('abort', cancel, { once: true });
      detach = () => parentSignal?.removeEventListener('abort', cancel);
      timer = setTimeout(() => {
        controller.abort();
        finish(reject, new Error('استغرق الطلب وقتاً طويلاً. أعد المحاولة.'));
      }, milliseconds);
      Promise.resolve().then(() => { if (controller.signal.aborted) throw aborted(); return task(controller.signal); }).then(
        value => finish(resolve, value), error => finish(reject, error)
      );
    });
  }
  function Icon({ name, size = 18 }) {
    const shared = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true };
    if (name === 'search') return h('svg', shared, h('circle', { cx: 11, cy: 11, r: 8 }), h('path', { d: 'm21 21-4.3-4.3' }));
    if (name === 'close') return h('svg', shared, h('path', { d: 'M18 6 6 18M6 6l12 12' }));
    return h('svg', shared, h('path', { d: 'm5 12 4 4L19 6' }));
  }
  function CityPicker({ open, onClose, onSelect, onUseLocation, locationBusy = false, adjustTimings, currentLocation, queryToday }) {
    const [timeFormat] = usePrayerTimeFormat();
    const [query, setQuery] = React.useState('');
    const [attempt, setAttempt] = React.useState(0);
    const [status, setStatus] = React.useState('idle');
    const [rows, setRows] = React.useState([]);
    const [message, setMessage] = React.useState('');
    const [choosing, setChoosing] = React.useState(null);
    const dialogRef = React.useRef(null);
    const inputRef = React.useRef(null);
    const epoch = React.useRef(0);
    const request = React.useRef(null);
    const latest = React.useRef({ onClose, onSelect, onUseLocation, queryToday });
    latest.current = { onClose, onSelect, onUseLocation, queryToday };
    React.useEffect(() => {
      if (!open) return;
      setQuery(''); setStatus('idle'); setRows([]); setMessage(''); setChoosing(null);
      const previousFocus = document.activeElement;
      const overflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      inputRef.current?.focus({ preventScroll: true });
      const controls = () => Array.from(dialogRef.current?.querySelectorAll('button:not(:disabled), input:not(:disabled), a[href], [tabindex]:not([tabindex="-1"])') || []).filter(node => !node.hidden && node.getAttribute('aria-hidden') !== 'true');
      const onKey = event => {
        if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); latest.current.onClose(); return; }
        if (event.key !== 'Tab') return;
        const list = controls(), first = list[0], last = list[list.length - 1];
        if (!first) { event.preventDefault(); dialogRef.current?.focus({ preventScroll: true }); return; }
        const outside = !dialogRef.current?.contains(document.activeElement) || document.activeElement === dialogRef.current;
        if (event.shiftKey && (outside || document.activeElement === first)) { event.preventDefault(); last.focus({ preventScroll: true }); }
        else if (!event.shiftKey && (outside || document.activeElement === last)) { event.preventDefault(); first.focus({ preventScroll: true }); }
      };
      document.addEventListener('keydown', onKey);
      return () => {
        epoch.current += 1;
        request.current?.abort(); request.current = null;
        document.removeEventListener('keydown', onKey);
        document.body.style.overflow = overflow;
        if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true });
      };
    }, [open]);
    React.useEffect(() => {
      const generation = ++epoch.current;
      request.current?.abort();
      request.current = null;
      if (!open) return;
      const term = query.trim();
      setRows([]); setMessage(''); setChoosing(null);
      if (term.length < 2) { setStatus('idle'); return; }
      const controller = new AbortController();
      request.current = controller;
      const active = () => generation === epoch.current && !controller.signal.aborted;
      setStatus('searching');
      const timer = setTimeout(async () => {
        try {
          const cities = await deadline(signal => searchPrayerCities(term, { signal }), controller.signal);
          if (!active()) return;
          const initial = cities.map((city, index) => ({ id: `${city.id ?? index}:${city.latitude}:${city.longitude}`, city, status: 'loading', payload: null }));
          setRows(initial); setStatus(cities.length ? 'results' : 'empty');
          let cursor = 0;
          const worker = async () => {
            while (active() && cursor < initial.length) {
              const row = initial[cursor++];
              try {
                const payload = await deadline(signal => queryPrayerCityToday(row.city, { signal, queryToday: latest.current.queryToday }), controller.signal);
                if (!active()) return;
                setRows(previous => previous.map(value => value.id === row.id ? { ...value, status: 'ready', payload } : value));
              } catch (error) {
                if (!active()) return;
                setRows(previous => previous.map(value => value.id === row.id ? { ...value, status: 'error', error: 'تعذر جلب المواقيت. اضغط لإعادة المحاولة.' } : value));
              }
            }
          };
          await Promise.all(Array.from({ length: Math.min(3, initial.length) }, worker));
        } catch (error) {
          if (!active()) return;
          setStatus('error');
          setMessage(typeof navigator !== 'undefined' && navigator.onLine === false ? 'البحث عن المدن يحتاج إلى اتصال بالإنترنت.' : 'تعذر البحث عن المدن الآن. تحقق من الاتصال وأعد المحاولة.');
        }
      }, attempt ? 0 : 400);
      return () => { clearTimeout(timer); controller.abort(); if (request.current === controller) request.current = null; };
    }, [open, query, attempt]);
    const refreshRow = async row => {
      const generation = epoch.current, controller = request.current;
      if (!controller || controller.signal.aborted || choosing) return;
      setRows(previous => previous.map(value => value.id === row.id ? { ...value, status: 'loading', payload: null } : value));
      try {
        const payload = await deadline(signal => queryPrayerCityToday(row.city, { signal, queryToday: latest.current.queryToday }), controller.signal);
        if (generation !== epoch.current || controller.signal.aborted) return;
        setRows(previous => previous.map(value => value.id === row.id ? { ...value, status: 'ready', payload, error: null } : value));
      } catch (error) {
        if (generation !== epoch.current || controller.signal.aborted) return;
        setRows(previous => previous.map(value => value.id === row.id ? { ...value, status: 'error', error: 'تعذر جلب المواقيت. اضغط لإعادة المحاولة.' } : value));
      }
    };
    const choose = async row => {
      if (row.status !== 'ready' || choosing || !row.payload) return;
      const currentDay = prayerDayForZone(new Date(), row.payload.location.timeZone);
      if (currentDay !== row.payload.day) {
        setMessage('بدأ يوم جديد في هذه المدينة. راجع المواقيت المحدّثة ثم اخترها.');
        await refreshRow(row);
        return;
      }
      if (!validatePrayerCityToday(row.payload.today, row.payload.day, row.payload.location.timeZone)) {
        await refreshRow(row);
        return;
      }
      const generation = epoch.current;
      setChoosing(row.id); setMessage('');
      try {
        const accepted = await latest.current.onSelect(row.payload);
        if (accepted === false && generation === epoch.current) {
          setRows(previous => previous.map(value => value.id === row.id ? { ...value, status: 'error', error: 'أعد تحميل المواقيت ثم اختر المدينة.' } : value));
          setMessage('تعذر اختيار المدينة. أعد تحميل مواقيتها ثم حاول مرة أخرى.');
        }
      } catch (error) {
        if (generation === epoch.current) setMessage('تعذر حفظ المدينة الآن. أعد المحاولة.');
      } finally {
        if (generation === epoch.current) setChoosing(null);
      }
    };
    if (!open) return null;
    return h('div', { className: 'munibin-prayer-city-backdrop', onClick: event => { if (event.target === event.currentTarget) latest.current.onClose(); } },
      h('section', { ref: dialogRef, className: 'munibin-prayer-city-dialog', role: 'dialog', 'aria-modal': true, 'aria-labelledby': 'munibin-prayer-city-title', dir: 'rtl', tabIndex: -1 },
        h('div', { className: 'munibin-prayer-city-heading' },
          h('h2', { id: 'munibin-prayer-city-title' }, 'اختر المدينة'),
          h('button', { className: 'munibin-prayer-city-close', type: 'button', 'aria-label': 'إغلاق البحث عن مدينة', onClick: () => latest.current.onClose() }, h(Icon, { name: 'close' }))),
        h('form', { className: 'munibin-prayer-city-search', onSubmit: event => { event.preventDefault(); if (query.trim().length >= 2) setAttempt(value => value + 1); else inputRef.current?.focus({ preventScroll: true }); } },
          h('input', { ref: inputRef, type: 'search', value: query, onChange: event => { epoch.current += 1; request.current?.abort(); setAttempt(0); setQuery(event.target.value); }, placeholder: 'ابحث عن مدينة أو اكتب اسمها مع البلد', 'aria-label': 'اسم المدينة', autoComplete: 'off', autoCapitalize: 'none', maxLength: 120, enterKeyHint: 'search' }),
          h('button', { type: 'submit', 'aria-label': 'البحث عن مدينة', disabled: query.trim().length < 2 }, h(Icon, { name: 'search' }))),
        h('div', { className: 'munibin-prayer-city-results', 'aria-busy': status === 'searching' },
          h('p', { className: 'munibin-prayer-city-status', role: 'status', 'aria-live': 'polite' }, status === 'idle' ? 'اكتب اسم المدينة لمعاينة مواقيت اليوم.' : status === 'searching' ? 'يجري البحث عن المدن…' : status === 'empty' ? 'لا توجد نتائج. جرّب اسم المدينة مع البلد.' : status === 'error' ? message : ''),
          status === 'error' && h('button', { type: 'button', className: 'munibin-prayer-city-retry', onClick: () => setAttempt(value => value + 1) }, 'إعادة المحاولة'),
          rows.map(row => {
            const selected = currentLocation && Math.abs(currentLocation.latitude - row.city.latitude) < .00005 && Math.abs(currentLocation.longitude - row.city.longitude) < .00005;
            const timings = row.payload ? (adjustTimings ? adjustTimings(row.payload.today.timings) : row.payload.today.timings) : null;
            const region = [row.city.admin1, row.city.country].filter((value, index, values) => value && value !== row.city.name && values.indexOf(value) === index).join('، ');
            return h('article', { key: row.id, className: 'munibin-prayer-city-result', 'data-selected': selected ? 'true' : undefined },
              h('button', { type: 'button', className: 'munibin-prayer-city-select', disabled: row.status !== 'ready' || !!choosing, 'aria-label': `اختيار ${row.city.name}${region ? '، ' + region : ''}`, 'aria-pressed': !!selected, onClick: () => choose(row) },
                h('span', { className: 'munibin-prayer-city-name-row' }, h('strong', null, row.city.name), selected && h(Icon, { name: 'check', size: 16 })),
                region && h('span', { className: 'munibin-prayer-city-region' }, region),
                h('span', { className: 'munibin-prayer-city-preview', 'aria-label': 'مواقيت اليوم' }, prayers.map(([key, label]) => h('span', { key, className: 'munibin-prayer-city-time' }, h('span', null, label), h('time', { dir: 'ltr', dateTime: timings?.[key] || undefined }, timings ? formatPrayerClock(timings[key], timeFormat) : '—:—')))),
                row.payload && h('span', { className: 'munibin-prayer-city-day', dir: 'ltr' }, row.payload.day)),
              row.status === 'loading' && h('p', { className: 'munibin-prayer-city-row-status', role: 'status' }, 'يجري تجهيز مواقيت اليوم…'),
              row.status === 'error' && h('button', { type: 'button', className: 'munibin-prayer-city-row-retry', onClick: () => refreshRow(row) }, row.error),
              choosing === row.id && h('p', { className: 'munibin-prayer-city-row-status', role: 'status' }, 'يجري اختيار المدينة…'));
          }),
          message && status !== 'error' && h('p', { className: 'munibin-prayer-city-message', role: 'alert' }, message)),
        h('div', { className: 'munibin-prayer-city-footer' },
          onUseLocation && h('button', { type: 'button', className: 'munibin-prayer-city-gps', disabled: locationBusy || !!choosing, onClick: () => { latest.current.onClose(); latest.current.onUseLocation(); } }, locationBusy ? 'يجري تحديد الموقع…' : 'استخدام موقعي الحالي'),
          h('p', { className: 'munibin-prayer-city-attribution' }, 'بيانات المدن: ', h('a', { href: 'https://www.geonames.org/', target: '_blank', rel: 'noopener noreferrer' }, 'GeoNames'), ' · ', h('a', { href: 'https://open-meteo.com/', target: '_blank', rel: 'noopener noreferrer' }, 'Open-Meteo')))));
  }
  return CityPicker;
}
