/* Munibin Quran landscape reader v358.
 * Phones and tablets have a header switch between a single page and a
 * true two-page Mushaf spread (odd page on the right, even page on the left).
 */
(() => {
  'use strict';
  if (window.__munibinQuranLandscapeV305) return;
  window.__munibinQuranLandscapeV305 = true;

  const MAX_PAGE = 604;
  const MODE_KEY = 'munibin:quran-tablet-landscape-mode:v1';
  const STYLE_ID = 'munibin-quran-landscape-v305-style';
  const ROOT_CLASS = 'munibin-quran-landscape';
  const TABLET_CLASS = 'munibin-quran-tablet-landscape';
  const ANDROID_CLASS = 'munibin-quran-android-landscape';
  const ZOOM_CLASS = 'munibin-quran-mode-zoom';
  const SPREAD_CLASS = 'munibin-quran-mode-spread';
  const pageCache = new Map();
  const fontCache = new Map();
  // Retain six light page-pair shells in each direction. A turn always has a
  // destination, including while its local data/font is still being prepared.
  // Only two pairs prepare resources together; ink is built in idle turns.
  const BOOK_CACHE_RADIUS = 6;
  const BOOK_RESOURCE_PAIRS = 2;
  let bookResourceTasks = 0;
  const pendingSheets = new Map();
  let neighborWork = Promise.resolve();
  const neighborJobs = [];
  let neighborDrainSerial = 0;
  let bookInteraction = false;
  let modernLandscapeSize = '';


  let currentReader = null;
  let currentMode = 'zoom';
  let currentAnchor = null;
  let spreadRoot = null;
  let switchRoot = null;
  let gesture = null;
  let renderSerial = 0;
  let lastObservedPage = 0;
  let lastObservedVerse = '';
  let layoutRaf = 0;
  let lastLayoutSignature = '';
  let neighborGeometryTimer = 0, neighborGeometrySerial = 0;
  let pendingBridgePage = 0;
  let pendingBridgeStarted = 0;
  let bookTurn = null;
  let bookTurnTimer = 0;
  let bookTurnFrame = 0;
  let bridgeSyncTimer = 0;
  let bridgeSyncPage = 0;
  let bookPublishTimer = 0;
  let lastZoomPrefetchPage = 0;
  let lastSpreadSize = '';
  let portraitPrimeNeeded = false;
  let lastPortraitSize = '';
  let iphonePortraitPrimed = false;
  let iphonePortraitSettleTimer = 0;

  const q = (s, r = document) => r.querySelector(s);
  const qa = (s, r = document) => Array.from(r.querySelectorAll(s));
  const clampPage = (n) => Math.max(1, Math.min(MAX_PAGE, Math.trunc(Number(n) || 1)));
  const padPage = (n) => String(clampPage(n)).padStart(3, '0');
  const oddAnchor = (n) => {
    const p = clampPage(n);
    return p % 2 === 0 ? Math.max(1, p - 1) : p;
  };

  function installStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
      html.${ROOT_CLASS} .qcf1441-preview {
        --qcf1441-toolbar-space: 42px !important;
        --qcf1441-footer-space: 78px !important;
        --munibin-quran-footer-bottom: max(4px, env(safe-area-inset-bottom)) !important;
        --munibin-quran-footer-height: 70px !important;
      }
      html.${ROOT_CLASS} .qcf1441-preview-header {
        min-height: 42px !important;
        height: 42px !important;
        padding: max(2px, env(safe-area-inset-top)) 9px 2px !important;
        gap: 6px !important;
      }
      /* Phone landscape only: keep the outer Quran controls away from rounded
         corners/notches. Portrait and tablet horizontal spacing are untouched. */
      html.${ROOT_CLASS}:not(.${TABLET_CLASS}) .qcf1441-preview-header {
        padding-left: max(44px, env(safe-area-inset-left)) !important;
        padding-right: max(44px, env(safe-area-inset-right)) !important;
      }
      html.${ROOT_CLASS}:not(.${TABLET_CLASS}) .qcf1441-background-player,
      html.${ROOT_CLASS}:not(.${TABLET_CLASS}) .qcf1441-memorization-player {
        left: max(30px, env(safe-area-inset-left)) !important;
        right: max(30px, env(safe-area-inset-right)) !important;
        width: auto !important;
      }
      /* Android landscape WebViews can report the status-bar inset even though the
         native content is already below it. Do not apply that inset a second time. */
      html.${ANDROID_CLASS}:not(.${TABLET_CLASS}) .qcf1441-preview-header {
        padding-top: 2px !important;
        padding-bottom: 2px !important;
        align-items: center !important;
      }
      html.${ANDROID_CLASS}:not(.${TABLET_CLASS}) .qcf1441-header-actions,
      html.${ANDROID_CLASS}:not(.${TABLET_CLASS}) .munibin-quran-context-button {
        transform: translateY(-1px) !important;
      }
      /* Phone landscape only: give the header a little more vertical room so
         rounded-screen edges never crop the top of the controls. Tablet and all
         portrait layouts stay exactly as they are. */
      html.${ROOT_CLASS}:not(.${TABLET_CLASS}) .qcf1441-preview {
        --qcf1441-toolbar-space: 46px !important;
      }
      html.${ROOT_CLASS}:not(.${TABLET_CLASS}) .qcf1441-preview-header {
        min-height: 46px !important;
        height: 46px !important;
        padding-top: max(6px, env(safe-area-inset-top)) !important;
        padding-bottom: 3px !important;
      }
      /* v291 Android phone landscape: the native WebView already accounts for the
         top system inset. Keep the header size unchanged, but lift both the left
         action group and the right Quran context control slightly so every button
         sits fully inside the header. This does not affect iOS, tablets, or portrait. */
      html.${ANDROID_CLASS}:not(.${TABLET_CLASS}) .qcf1441-preview-header {
        padding-top: 3px !important;
        padding-bottom: 3px !important;
        align-items: center !important;
      }
      html.${ANDROID_CLASS}:not(.${TABLET_CLASS}) .qcf1441-header-actions,
      html.${ANDROID_CLASS}:not(.${TABLET_CLASS}) .munibin-quran-context-button,
      html.${ANDROID_CLASS}:not(.${TABLET_CLASS}) .qcf1441-page-context {
        transform: translateY(-2px) !important;
      }
      html.${ROOT_CLASS} .qcf1441-page-context strong { font-size: .82rem !important; }
      html.${ROOT_CLASS} .qcf1441-page-context > span { font-size: .52rem !important; }
      html.${ROOT_CLASS} .qcf1441-icon-button,
      html.${ROOT_CLASS} .qcf1441-header-actions > input { width: 31px !important; height: 31px !important; }
      html.${ROOT_CLASS} .qcf1441-background-player,
      html.${ROOT_CLASS} .qcf1441-memorization-player {
        bottom: max(4px, env(safe-area-inset-bottom)) !important;
        min-height: 70px !important;
        height: 70px !important;
        padding: 3px !important;
      }
      html.${ROOT_CLASS} .qcf1441-background-player--idle .qcf1441-audio-footer-launch {
        width: 92px !important;
        min-width: 92px !important;
        height: 42px !important;
        border-radius: 15px !important;
        transform: none !important;
        font-size: .72rem !important;
      }
      html.${ROOT_CLASS} .qcf1441-background-player-actions > button,
      html.${ROOT_CLASS} .qcf1441-memorization-player-actions > button,
      html.${ROOT_CLASS} .qcf1441-footer-mode-switch,
      html.${ROOT_CLASS} .qcf1441-audio-menu-opener {
        min-height: 34px !important;
        height: 34px !important;
      }
      /* Landscape single-page only: lift the draggable audio progress control
         clear of the transport buttons without moving or resizing the buttons. */
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-background-player > input[type="range"] {
        transform: translateY(-6px) !important;
      }
      /* The visible progress track is custom-painted on the player's ::before
         pseudo-element, separate from the native range thumb. Move that track by
         the same amount so the orange/remaining line and thumb stay together. */
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-background-player.munibin-audio-active::before {
        transform: translateY(-6px) !important;
      }

      /* Landscape zoom mode keeps the QCF glyphs at their real aspect ratio.
         The 15 Mushaf lines get a measured row height and the page itself becomes
         vertically scrollable instead of forcing rows/glyph boxes to shrink. */
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-preview-page { touch-action: pan-y !important; }
      /* Landscape single-page only: hiding the Quran chrome should reveal the
         already-laid-out Mushaf underneath the reserved header/footer bands.

         The viewport itself expands to the screen edges, but the Mushaf layer is
         counter-offset by the exact header reserve. That keeps every existing line
         at the same screen Y coordinate when the chrome disappears. The footer
         reserve is added only to the layer's blank scroll extent, which preserves
         the exact scrollTop/max-scroll geometry without changing glyph size, row
         height, line spacing, or typography fitting. Once hidden, Quran content
         that was already behind either chrome band can simply be seen there. */
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-preview.qcf1441-preview--chrome-hidden .qcf1441-preview-page {
        top: 0 !important;
        bottom: 0 !important;
      }
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-preview.qcf1441-preview--chrome-hidden .qcf1441-page-layer {
        top: var(--qcf1441-toolbar-space) !important;
        bottom: auto !important;
        min-height: calc(var(--munibin-quran-zoom-content-height) + var(--qcf1441-footer-space)) !important;
        height: calc(var(--munibin-quran-zoom-content-height) + var(--qcf1441-footer-space)) !important;
      }
      /* Landscape single-page only: when the header/footer chrome is hidden, the
         newly exposed bands must be visually identical to the Mushaf body. The
         gap above the fixed page layer belongs to the scroll stage, whose normal
         background is the slightly darker "subtle" color; override only this
         hidden-chrome zoom state to the page background so no seam is visible. */
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-preview.qcf1441-preview--chrome-hidden .qcf1441-page-stage {
        background: var(--qcf1441-bg) !important;
      }
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-page-stage {
        overflow-x: hidden !important;
        overflow-y: auto !important;
        -webkit-overflow-scrolling: touch;
        overscroll-behavior-y: contain;
        overflow-anchor: none !important;
        touch-action: pan-y !important;
        align-items: flex-start !important;
      }
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-page-layer {
        --munibin-quran-zoom-row-height: 56px;
        --munibin-quran-zoom-content-height: 890px;
        min-height: var(--munibin-quran-zoom-content-height) !important;
        height: var(--munibin-quran-zoom-content-height) !important;
        /* Keep the very tall zoom page on a clipped compositor layer. Safari was
           repainting overflow while the layer moved, which made landscape swipes
           feel heavier than the normal portrait reader. */
        overflow: hidden !important;
        contain: layout paint !important;
        will-change: transform !important;
        backface-visibility: hidden !important;
        -webkit-backface-visibility: hidden !important;
        align-items: stretch !important;
        flex-direction: column !important;
      }
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-page-layer--outgoing,
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-page-layer--incoming {
        box-shadow: none !important;
      }
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-lines {
        width: 100% !important;
        height: auto !important;
        min-height: 0 !important;
        max-height: none !important;
        flex: 0 0 auto !important;
        align-self: stretch !important;
        grid-template-rows: repeat(15, var(--munibin-quran-zoom-row-height)) !important;
        padding-top: 10px !important;
        padding-bottom: 10px !important;
        overflow: visible !important;
      }
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-line {
        white-space: nowrap !important;
        overflow: visible !important;
        min-width: 0 !important;
      }
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-glyph,
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-glyph-word {
        flex: 0 0 auto !important;
        max-width: none !important;
      }
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-preview-page > .qcf1441-page-number {
        display: none !important;
      }
      /* Landscape single-page mode: use the generous empty vertical space around
         Surah dividers to make the Mushaf artwork more prominent, while still
         keeping clear breathing room from the Quran text above and below. Portrait
         mode is untouched. */
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-surah-title-panel {
        width: calc(100% - 18px) !important;
        max-width: calc(100% - 18px) !important;
        height: 46px !important;
        min-height: 46px !important;
        --qcf1441-title-window: clamp(190px, 46vw, 310px) !important;
        margin-top: 4px !important;
        margin-bottom: 4px !important;
      }
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-surah-title-window {
        height: calc(100% - 4px) !important;
      }
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-glyph-surah_header {
        font-size: clamp(18px, 2.35vw, 27px) !important;
        line-height: .86 !important;
      }
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-surah-title-ornament {
        background-size: 14px 14px !important;
      }
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-surah-title-ornament:before,
      html.${ROOT_CLASS}.${ZOOM_CLASS} .qcf1441-surah-title-ornament:after {
        width: 10px !important;
        height: 10px !important;
      }
      .munibin-quran-zoom-page-number {
        position: static;
        z-index: 5;
        flex: 0 0 28px;
        width: 100%;
        height: 28px;
        display: grid;
        place-items: start center;
        padding-top: 4px;
        box-sizing: border-box;
        color: var(--qcf1441-text);
        opacity: .68;
        font-variant-numeric: tabular-nums;
        font-family: Amiri, serif;
        font-size: 1.08rem;
        font-weight: 600;
        line-height: 1;
        pointer-events: none;
      }
      html.${TABLET_CLASS}.${ZOOM_CLASS} .qcf1441-glyph {
        font-size: clamp(1rem, 4.2vw, 3.15rem);
      }

      /* Tablet-only view switch. It floats in the unused centre of the landscape header
         so the existing header's left/right controls are not rearranged. */
      .munibin-quran-landscape-switch {
        position: absolute;
        z-index: 3;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        height: 31px;
        padding: 2px;
        border: 1px solid var(--qcf1441-border);
        border-radius: 10px;
        background: var(--qcf1441-subtle);
        display: inline-grid;
        grid-template-columns: 1fr 1fr;
        direction: rtl;
        gap: 2px;
        font-family: var(--app-font);
        box-shadow: 0 1px 5px rgba(0,0,0,.08);
      }
      .munibin-quran-landscape-switch button {
        height: 25px;
        min-width: 72px;
        padding: 0 9px;
        border: 0;
        border-radius: 7px;
        background: transparent;
        color: var(--qcf1441-secondary);
        font: inherit;
        font-size: 11px;
        font-weight: 800;
        white-space: nowrap;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
      }
      .munibin-quran-view-symbol {
        width: 16px;
        height: 12px;
        display: inline-flex;
        align-items: stretch;
        justify-content: center;
        gap: 2px;
        direction: ltr;
        flex: 0 0 auto;
      }
      .munibin-quran-view-symbol i {
        display: block;
        height: 100%;
        box-sizing: border-box;
        border: 1.35px solid currentColor;
        border-radius: 2px;
        background: transparent;
      }
      .munibin-quran-view-symbol--spread i { width: 6px; }
      .munibin-quran-view-symbol--zoom i { width: 10px; }
      .munibin-quran-landscape-switch button[aria-pressed="true"] {
        background: var(--qcf1441-gold);
        color: var(--qcf1441-header);
      }

      /* Tablet two-page Mushaf. Odd pages are on the right and even pages on
         the left. Adjacent spreads stay pre-rendered but hidden so turning a page
         never flashes the previous spread while React catches up. */
      html.${ROOT_CLASS}.${SPREAD_CLASS} .qcf1441-page-stage > .qcf1441-page-layer,
      html.${ROOT_CLASS}.${SPREAD_CLASS} .qcf1441-preview-page > .qcf1441-page-number {
        visibility: hidden !important;
        pointer-events: none !important;
      }
      html.${ROOT_CLASS}.${SPREAD_CLASS} .qcf1441-page-stage {
        /* Let the custom spread extend into the footer zone just like the native
           portrait page number does. The footer itself stays above it (z-index 45). */
        overflow: visible !important;
        contain: layout !important;
        touch-action: pan-y !important;
      }
      .munibin-quran-spread {
        position: absolute;
        z-index: 8;
        top: 0;
        right: 0;
        left: 0;
        bottom: calc(-1 * var(--qcf1441-footer-space));
        overflow: hidden;
        background: var(--qcf1441-subtle);
        touch-action: pan-y;
        direction: rtl;
        perspective: 1800px;
        perspective-origin: 50% 50%;
      }
      .munibin-quran-spread-sheet {
        position: absolute;
        inset: 0;
        display: grid;
        grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
        direction: rtl;
        visibility: hidden;
        pointer-events: none;
        z-index: 0;
        transform: translateZ(0);
        backface-visibility: hidden;
        -webkit-backface-visibility: hidden;
      }
      .munibin-quran-spread-sheet.is-active {
        visibility: visible;
        pointer-events: auto;
        z-index: 2;
      }
      .munibin-quran-spread-sheet.is-turn-target {
        visibility: visible;
        z-index: 1;
      }
      .munibin-quran-leaf {
        --munibin-spread-glyph-size: 22px;
        position: relative;
        min-width: 0;
        min-height: 0;
        height: 100%;
        overflow: hidden;
        background: var(--qcf1441-bg);
        color: var(--qcf1441-text);
        display: flex;
        flex-direction: column;
        contain: layout paint;
      }
      .munibin-quran-leaf:first-child { border-left: 1px solid var(--qcf1441-border); }
      .munibin-quran-leaf:last-child { border-right: 1px solid color-mix(in srgb, var(--qcf1441-border) 35%, transparent); }
      .munibin-quran-leaf .qcf1441-lines {
        width: 100% !important;
        /* The spread itself extends behind the footer. The 15 Mushaf rows consume
           the full visible reading area above that footer, with no page-number row
           stealing vertical space. The number lives in the hidden footer zone. */
        height: calc(100% - var(--qcf1441-footer-space)) !important;
        min-height: 0 !important;
        max-height: calc(100% - var(--qcf1441-footer-space)) !important;
        flex: 0 0 calc(100% - var(--qcf1441-footer-space)) !important;
        grid-template-rows: repeat(15, minmax(0, 1fr)) !important;
        padding: 6px 9px 2px !important;
        align-self: flex-start !important;
        overflow: visible !important;
      }
      .munibin-quran-leaf .qcf1441-line {
        white-space: nowrap !important;
        overflow: visible !important;
        min-width: 0 !important;
      }
      .munibin-quran-leaf .qcf1441-glyph {
        font-size: var(--munibin-spread-glyph-size) !important;
        flex: 0 0 auto !important;
        min-width: 0;
        max-width: none !important;
      }
      .munibin-quran-leaf .qcf1441-glyph-word {
        flex: 0 0 auto !important;
      }
      .munibin-quran-leaf .qcf1441-surah-title-panel {
        width: 92% !important;
        max-width: 92% !important;
        height: min(1.85rem, calc(var(--munibin-spread-glyph-size) * 1.18)) !important;
        --qcf1441-title-window: min(40%, 184px) !important;
      }
      .munibin-quran-leaf .qcf1441-glyph-surah_header {
        /* Each title is additionally measured in JS; this conservative cap prevents
           a long Surah-name glyph from spilling into the ornament while it settles. */
        font-size: min(16px, calc(var(--munibin-spread-glyph-size) * .68)) !important;
        max-width: 100% !important;
      }
      .munibin-quran-leaf-number {
        position: absolute;
        z-index: 5;
        right: 0;
        left: 0;
        bottom: max(7px, env(safe-area-inset-bottom));
        display: grid;
        place-items: center;
        box-sizing: border-box;
        font-family: Amiri, serif;
        font-size: 15px;
        font-weight: 600;
        line-height: 1;
        color: var(--qcf1441-text);
        opacity: .68;
        pointer-events: none;
      }
      .munibin-quran-leaf-loading,
      .munibin-quran-leaf-error {
        height: 100%;
        display: grid;
        place-items: center;
        color: var(--qcf1441-secondary);
        font-family: var(--app-font);
        font-size: 12px;
      }
      .munibin-quran-spread .qcf1441-glyph-word--pressed { transform: none; }

      /* A real RTL book turn: advancing turns the left leaf toward the right;
         going back turns the right leaf toward the left. */
      .munibin-quran-turn-page {
        position: absolute;
        top: 0;
        bottom: 0;
        width: 50%;
        z-index: 6;
        transform-style: preserve-3d;
        -webkit-transform-style: preserve-3d;
        will-change: transform;
        pointer-events: none;
      }
      .munibin-quran-turn-page--next {
        left: 0;
        transform-origin: 100% 50%;
      }
      .munibin-quran-turn-page--previous {
        right: 0;
        transform-origin: 0 50%;
      }
      .munibin-quran-turn-face {
        position: absolute;
        inset: 0;
        overflow: hidden;
        background: var(--qcf1441-bg);
        backface-visibility: hidden;
        -webkit-backface-visibility: hidden;
      }
      .munibin-quran-turn-face--back {
        transform: rotateY(180deg);
      }
      .munibin-quran-turn-page--next .munibin-quran-turn-face--front {
        box-shadow: 10px 0 18px rgba(0,0,0,.12);
      }
      .munibin-quran-turn-page--previous .munibin-quran-turn-face--front {
        box-shadow: -10px 0 18px rgba(0,0,0,.12);
      }
      .munibin-quran-turn-page.is-settling {
        transition: transform 185ms cubic-bezier(.22,.61,.36,1);
      }
      .munibin-quran-turn-face > .munibin-quran-leaf {
        width: 100%;
        height: 100%;
        /* Retain the leaf's own border/box geometry while it turns. */
      }

      @media (max-height: 520px) and (orientation: landscape) {
        html.${ROOT_CLASS} .qcf1441-preview {
          --qcf1441-toolbar-space: 38px !important;
          --qcf1441-footer-space: 78px !important;
          --munibin-quran-footer-height: 70px !important;
        }
        html.${ROOT_CLASS} .qcf1441-preview-header { height: 38px !important; min-height: 38px !important; }
        html.${ROOT_CLASS} .qcf1441-background-player,
        html.${ROOT_CLASS} .qcf1441-memorization-player { height: 70px !important; min-height: 70px !important; }
        html.${ROOT_CLASS} .qcf1441-background-player--idle .qcf1441-audio-footer-launch { height: 38px !important; }
      }
    `;
    document.head.appendChild(style);
  }

  function isLandscape() {
    // Native rotation publishes the media-query and layout-viewport updates in
    // separate steps. Requiring both used to clear a landscape reader while its
    // box was still wide, then build it again on the next resize. The geometry
    // used by the fitter is the same source that must select its reading mode.
    return window.innerWidth > window.innerHeight;
  }

  function isTouchTablet() {
    const ua = navigator.userAgent || '';
    const ipad = /iPad/i.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    if (ipad) return true;
    const touch = (navigator.maxTouchPoints || 0) > 0 || 'ontouchstart' in window;
    if (!touch) return false;
    const shortScreen = Math.min(Number(screen.width) || innerWidth, Number(screen.height) || innerHeight);
    if (/Android/i.test(ua)) return !/Mobile/i.test(ua) || shortScreen >= 600;
    return shortScreen >= 600;
  }

  function isAndroidNative() {
    return window.__munibinNativePlatform === 'android' || /Android/i.test(navigator.userAgent || '');
  }


  function isIOSPhone() {
    const ua = navigator.userAgent || '';
    return !isTouchTablet() && (window.__munibinNativePlatform === 'ios' || /iPhone|iPod/i.test(ua));
  }

  function orientationWantsPortrait() {
    if (typeof window.orientation === 'number') return Math.abs(Number(window.orientation)) % 180 === 0;
    try { return !!window.matchMedia?.('(orientation: portrait)')?.matches; } catch (_) { return false; }
  }

  function visibleLineInkWidth(line) {
    let left = Infinity, right = -Infinity;
    for (const child of Array.from(line.children || [])) {
      if (!(child instanceof HTMLElement) || getComputedStyle(child).display === 'none') continue;
      const rect = child.getBoundingClientRect();
      if (!Number.isFinite(rect.left) || !Number.isFinite(rect.right)) continue;
      left = Math.min(left, rect.left);
      right = Math.max(right, rect.right);
    }
    return Number.isFinite(left) && Number.isFinite(right) ? Math.max(0, right - left) : 0;
  }

  // iPhone WKWebView publishes several intermediate viewport widths while rotating
  // back to portrait. Pre-compute the final portrait QCF width from the current
  // page before those resize steps begin, then hold that exact font size until the
  // viewport settles. This prevents the visible wide/narrow snap after rotation.
  function primeIPhonePortraitFont() {
    if (modernReader() || window.__munibinQuranReadingReflow) return false;
    if (!isIOSPhone() || !orientationWantsPortrait()) return false;
    const reader = currentReader?.isConnected ? currentReader : readerOnPage();
    if (!reader?.isConnected) return false;
    const screenW = Math.min(Number(screen.width) || innerWidth, Number(screen.height) || innerHeight);
    if (!(screenW > 0)) return false;
    const readerW = Math.max(1, reader.getBoundingClientRect().width || innerWidth || screenW);
    const rem = Number.parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
    const basePortraitFont = Math.min(2.15 * rem, Math.max(.84 * rem, screenW * .061));

    qa('.qcf1441-lines', reader).forEach(lines => {
      const ayahLines = qa(':scope > .qcf1441-line-ayah', lines);
      const glyph = q('.qcf1441-line-ayah .qcf1441-glyph', lines) || q('.qcf1441-glyph', lines);
      if (!ayahLines.length || !glyph) return;
      const currentFont = Number.parseFloat(getComputedStyle(glyph).fontSize);
      const maxInk = Math.max(0, ...ayahLines.map(visibleLineInkWidth));
      if (!(currentFont > 0) || !(maxInk > 0)) return;
      const widthPerFontPx = maxInk / currentFont;
      const cs = getComputedStyle(lines);
      const horizontalPadding = (Number.parseFloat(cs.paddingLeft) || 0) + (Number.parseFloat(cs.paddingRight) || 0);
      const targetContainerWidth = Math.max(1, screenW * (lines.clientWidth / readerW));
      const available = Math.max(1, targetContainerWidth - horizontalPadding - 4);
      const widthLimited = available / Math.max(.01, widthPerFontPx);
      let predicted = basePortraitFont;
      const scale = widthLimited / basePortraitFont;
      if (scale < 1) predicted = widthLimited;
      else if (scale >= 1.005) predicted = Math.min(widthLimited, basePortraitFont * 1.18);
      if (!Number.isFinite(predicted) || predicted <= 0) return;
      lines.style.setProperty('--munibin-qcf1441-fit-font-size', `${predicted.toFixed(3)}px`);
      lines.classList.add('munibin-qcf1441-width-fit');
    });
    iphonePortraitPrimed = true;
    try { window.__munibinQuranPortraitFitLocked = true; } catch (_) {}
    return true;
  }

  function settleIPhonePortraitFit() {
    if (!iphonePortraitPrimed) return;
    if (iphonePortraitSettleTimer) clearTimeout(iphonePortraitSettleTimer);
    iphonePortraitSettleTimer = window.setTimeout(() => {
      iphonePortraitSettleTimer = 0;
      if (isLandscape()) return;
      try { window.__munibinQuranPortraitFitLocked = false; } catch (_) {}
      try { window.__munibinFitQcf1441Width?.(); } catch (_) {}
      const reader = readerOnPage();
      try { if (reader) void reader.offsetWidth; } catch (_) {}
      iphonePortraitPrimed = false;
    }, 120);
  }

  function readerOnPage() {
    if (!location.pathname.startsWith('/quran')) return null;
    return q('.qcf1441-preview');
  }

  function currentPage() {
    try {
      const s = window.__munibinQuranNavigationBridge?.debugState?.();
      const p = Number(s?.refPage ?? s?.reactPage ?? s?.dataPage);
      if (Number.isInteger(p) && p >= 1 && p <= MAX_PAGE) return p;
    } catch (_) {}
    const text = q('.qcf1441-page-number--base,.qcf1441-page-number')?.textContent || '';
    const ascii = text.replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
    const m = ascii.match(/\d{1,3}/);
    return m ? clampPage(Number(m[0])) : 1;
  }

  const modernReader=()=>!!window.__munibinQuranReading;
  function readingPreferences() {
    if(modernReader())return window.__munibinQuranReading.getPreferences();
    try{return {font:'qcf1441',scale:1,direction:'horizontal',...JSON.parse(localStorage.getItem('munibin:quran-reading:v1')||'{}')}}
    catch{return {font:'qcf1441',scale:1,direction:'horizontal'}}
  }
  const spreadCompatible=()=>readingPreferences().direction!=='ayah';
  function notifyView(){window.dispatchEvent(new Event('munibin-quran-view-change'))}
  function storedMode() {
    try { const saved=localStorage.getItem(MODE_KEY);return saved==='spread'||saved==='zoom'?saved:isTouchTablet()?'spread':'zoom'; }
    catch (_) { return isTouchTablet()?'spread':'zoom'; }
  }

  function persistMode(mode) {
    try { localStorage.setItem(MODE_KEY, mode); } catch (_) {}
  }

  function ensureSwitch(reader) {
    if(readingPreferences().direction==='ayah'){removeSwitch();return;}
    const header = q('.qcf1441-preview-header', reader);
    if (!header) return;
    if (switchRoot && switchRoot.isConnected && switchRoot.parentElement === header) {
      updateSwitch();
      return;
    }
    switchRoot?.remove();
    const el = document.createElement('div');
    el.className = 'munibin-quran-landscape-switch';
    el.setAttribute('role', 'group');
    el.setAttribute('aria-label', 'طريقة عرض المصحف في الوضع الأفقي');
    el.innerHTML = '<button type="button" data-mode="spread"><span class="munibin-quran-view-symbol munibin-quran-view-symbol--spread" aria-hidden="true"><i></i><i></i></span><span>صفحتان</span></button><button type="button" data-mode="zoom"><span class="munibin-quran-view-symbol munibin-quran-view-symbol--zoom" aria-hidden="true"><i></i></span><span>صفحة</span></button>';
    el.addEventListener('pointerdown', e => e.stopPropagation());
    el.addEventListener('pointerup', e => e.stopPropagation());
    el.addEventListener('click', e => {
      const b = e.target.closest('button[data-mode]');
      if (!b) return;
      e.stopPropagation();
      setMode(b.dataset.mode === 'spread' ? 'spread' : 'zoom', true);
    });
    header.appendChild(el);
    switchRoot = el;
    updateSwitch();
  }

  function updateSwitch() {
    if (!switchRoot) return;
    qa('button[data-mode]',switchRoot).forEach(b=>{b.setAttribute('aria-pressed',String(b.dataset.mode===currentMode));const unavailable=b.dataset.mode==='spread'&&!spreadCompatible();b.dataset.unavailable=String(unavailable);b.title=unavailable?'عرض الصفحتين متاح فقط بخط المصحف':''});
  }

  function removeSwitch() {
    switchRoot?.remove();
    switchRoot = null;
  }

  function clearZoomPageNumbers() {
    qa('.munibin-quran-zoom-page-number').forEach(el => el.remove());
  }

  function syncZoomPageNumbers() {
    if (currentMode !== 'zoom' || !currentReader || !isLandscape()) {
      clearZoomPageNumbers();
      return;
    }
    const base = currentPage();
    qa('.qcf1441-page-layer', currentReader).forEach(layer => {
      let page = base;
      if (layer.classList.contains('qcf1441-page-layer--incoming')) {
        if (layer.classList.contains('qcf1441-page-layer--next')) page = clampPage(base + 1);
        else if (layer.classList.contains('qcf1441-page-layer--previous')) page = clampPage(base - 1);
      }
      let number = q('.munibin-quran-zoom-page-number', layer);
      if (!number) {
        number = document.createElement('span');
        number.className = 'munibin-quran-zoom-page-number';
        number.setAttribute('aria-hidden', 'true');
        layer.appendChild(number);
      }
      number.textContent = Number(page).toLocaleString('ar-EG');
    });
  }

  function fitZoomTypography(root = currentReader) {
    if (currentMode !== 'zoom' || !root?.isConnected || !isLandscape()) return;
    qa('.qcf1441-page-layer', root).forEach(layer => {
      const lines = q('.qcf1441-lines', layer);
      if (!lines) return;
      const glyph = q('.qcf1441-line-ayah .qcf1441-glyph', lines) || q('.qcf1441-glyph', lines);
      if (!glyph) return;
      const fontPx = Number.parseFloat(getComputedStyle(glyph).fontSize);
      if (!Number.isFinite(fontPx) || fontPx <= 0) return;
      // Preserve the portrait Mushaf's breathing room between diacritics. Landscape
      // gets taller and scrolls instead of reducing this vertical rhythm.
      // Give landscape zoom a little more of the portrait Mushaf's vertical breathing room.
      // The layer is scrollable, so this never compresses or clips the 15 original lines.
      const rowHeight = Math.max(38, Math.ceil(fontPx * 1.80));
      const cs = getComputedStyle(lines);
      const padding = (Number.parseFloat(cs.paddingTop) || 0) + (Number.parseFloat(cs.paddingBottom) || 0);
      const linesHeight = Math.ceil(rowHeight * 15 + padding);
      const contentHeight = linesHeight + 30;
      layer.style.setProperty('--munibin-quran-zoom-row-height', `${rowHeight}px`);
      layer.style.setProperty('--munibin-quran-zoom-content-height', `${contentHeight}px`);
    });
  }

  function refitZoomSoon() {
    requestAnimationFrame(() => {
      window.__munibinFitQcf1441Width?.();
      requestAnimationFrame(() => {
        fitZoomTypography();
        syncZoomPageNumbers();
      });
    });
  }

  function prefetchZoomNeighbors(page = currentPage()) {
    // Horizontal single-page shells own bounded idle preparation. Starting
    // separate eager font loads here would compete with their gesture frames.
    if(modernReader()&&readingPreferences().direction==='horizontal')return;
    if (currentMode !== 'zoom' || !isLandscape()) return;
    const preload = window.__munibinQuranNavigationBridge?.preloadPage;
    if (typeof preload !== 'function') return;
    const p = clampPage(page);
    if (p === lastZoomPrefetchPage) return;
    lastZoomPrefetchPage = p;
    [p - 2, p - 1, p + 1, p + 2]
      .filter(n => n >= 1 && n <= MAX_PAGE)
      .forEach(n => { try { preload(n); } catch (_) {} });
  }

  function primeModernLandscape() {
    if (!modernReader() || !currentReader?.isConnected || !isLandscape()) return;
    const prefs=readingPreferences();
    const size = `${innerWidth}x${innerHeight}|${currentReader.clientWidth}x${currentReader.clientHeight}|${currentMode}|${prefs.font}|${prefs.scale}|${prefs.tajweed}|${prefs.spacing}|${prefs.lineSpacing}`;
    if (window.__munibinQuranInteracting || window.__munibinQuranPinching) return;
    if(size===modernLandscapeSize) {
      // A pending React view commit can replace the stage at unchanged geometry.
      // Recover its detached imperative book without refitting a connected pair.
      if(currentMode==='spread'&&!spreadRoot?.isConnected) {
        ensureSwitch(currentReader);ensureSpread();
      }
      return;
    }
    modernLandscapeSize = size;
    // The modern reader bypasses fitZoomTypography. Resolve its own complete
    // metrics inside the entry/resize event for a single page or the active pair,
    // before a portrait-sized/old-half-column frame can paint in landscape.
    window.__munibinQuranReading.fitQuranReaderBeforePaint?.(currentReader);
    if(currentMode==='spread') {
      ensureSwitch(currentReader);
      ensureSpread();
    }
  }

  function setBookInteraction(active) {
    bookInteraction = !!active;
    window.__munibinQuranBookInteracting = bookInteraction;
    window.__munibinQuranInteracting = bookInteraction || !!window.__munibinQuranPinching;
    if(!window.__munibinQuranInteracting)window.__munibinQuranReading?.flushPendingQuranReaderFit?.();
  }

  function iosBookChromeBusy() {
    return currentMode==='spread'&&window.__munibinQuranChromeMotionActive===true&&(
      window.__munibinNativePlatform==='ios'||/iPhone|iPad|iPod/i.test(navigator.userAgent||'')||
      (navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1));
  }

  function waitForBookIdle(serial, yieldWork = false, background = false) {
    return new Promise(resolve => {
      const run = () => {
        if (serial !== renderSerial || currentMode !== 'spread') { resolve(false); return; }
        if (bookInteraction || gesture || window.__munibinQuranPinching || (background&&iosBookChromeBusy())) {
          setTimeout(run, 40); return;
        }
        resolve(true);
      };
      if (yieldWork) setTimeout(run, 24); else run();
    });
  }

  function setMode(mode, persist) {
    const tablet = isTouchTablet();
    const previousSpread=document.documentElement.classList.contains(SPREAD_CLASS);
    const allowed=isLandscape()&&mode==='spread'&&spreadCompatible();
    currentMode = allowed ? 'spread' : 'zoom';
    const html = document.documentElement;
    html.classList.toggle(SPREAD_CLASS, currentMode === 'spread');
    html.classList.toggle(ZOOM_CLASS,currentMode==='zoom'&&!modernReader());
    if(previousSpread!==(currentMode==='spread'))notifyView();
    if (persist) persistMode(currentMode);
    updateSwitch();
    if (currentMode === 'spread') {
      clearZoomPageNumbers();
      const stage = q('.qcf1441-page-stage', currentReader || document);
      if (stage) stage.scrollTop = 0;
      ensureSpread();
    } else {
      destroySpread();
      if(modernReader()){clearZoomPageNumbers();primeModernLandscape();prefetchZoomNeighbors();return}
      // Apply the final landscape zoom metrics in the same event turn. This avoids
      // painting the compact portrait-like row spacing for one frame and then
      // expanding it on the following animation frame. The delayed pass remains
      // only as a correction for late font/width changes.
      try { window.__munibinFitQcf1441Width?.(); } catch (_) {}
      fitZoomTypography(currentReader);
      syncZoomPageNumbers();
      prefetchZoomNeighbors();
      refitZoomSoon();
    }
  }

  function ensureSpread() {
    if (currentMode !== 'spread' || !currentReader) return;
    if (pendingBridgePage && performance.now() - pendingBridgeStarted < 2500) return;
    const anchor = oddAnchor(currentPage());
    if (!spreadRoot?.isConnected || currentAnchor !== anchor) renderSpread(anchor);
  }

  function primePortraitState(reader = readerOnPage(), force = false, fitModern = true) {
    if (!modernReader() && window.__munibinQuranReadingReflow) return;
    if (!reader?.isConnected) return false;
    // orientationchange can fire before WKWebView publishes the new viewport size.
    // Only measure the portrait reader once the geometry itself is actually portrait.
    if (window.innerHeight < window.innerWidth) return false;

    const prefs=readingPreferences();
    const size = `${window.innerWidth}x${window.innerHeight}|${reader.clientWidth}x${reader.clientHeight}|${prefs.font}|${prefs.scale}|${prefs.tajweed}|${prefs.spacing}|${prefs.lineSpacing}`;
    if (!force && !portraitPrimeNeeded && lastPortraitSize === size) return true;
    if(modernReader()&&!fitModern)return true;

    // Remove landscape-only inline metrics before the first portrait paint. They are
    // harmless once the landscape classes are gone, but clearing them makes the
    // transition deterministic and prevents stale values from being reused by a
    // layer that React keeps mounted across rotation.
    qa('.qcf1441-page-layer', reader).forEach(layer => {
      layer.style.removeProperty('--munibin-quran-zoom-row-height');
      layer.style.removeProperty('--munibin-quran-zoom-content-height');
    });

    // qcf-width-fit normally refits on requestAnimationFrame after resize. That
    // one-frame delay is exactly what made portrait briefly render with the old
    // landscape glyph size before snapping to its normal form. Run the fitter
    // synchronously while the resize/orientation event is still being handled, so
    // the browser's first portrait paint already has the final portrait metrics.
    if(modernReader()) {
      // Mark this geometry before entering the reader's full fit, whose viewport
      // hook calls back into this helper. Unlike the old width-only shortcut,
      // this also replaces retained zoom bases, word caps and chrome reserves.
      portraitPrimeNeeded=false;lastPortraitSize=size;
      window.__munibinQuranReading.fitQuranReaderBeforePaint?.(reader);
    } else if (iphonePortraitPrimed && isIOSPhone()) {
      // Keep the precomputed portrait size fixed while WKWebView emits its
      // intermediate rotation widths. One final measured fit runs after resize
      // has been quiet for a moment.
      settleIPhonePortraitFit();
    } else {
      try { window.__munibinFitQcf1441Width?.(); } catch (_) {}
    }

    // Force style/layout resolution now, still before the next paint. This keeps
    // Safari/WKWebView from deferring the newly fitted portrait metrics.
    try { void reader.offsetWidth; } catch (_) {}

    portraitPrimeNeeded = false;
    lastPortraitSize = size;
    return true;
  }

  function clearLayout(fitModern = true) {
    const reader = currentReader?.isConnected ? currentReader : readerOnPage();
    const wasSpread=document.documentElement.classList.contains(SPREAD_CLASS);
    document.documentElement.classList.remove(ROOT_CLASS,TABLET_CLASS,ANDROID_CLASS,ZOOM_CLASS,SPREAD_CLASS);
    if(wasSpread||(fitModern&&window.__munibinQuranCommittingViewport))notifyView();
    destroySpread();
    clearZoomPageNumbers();
    removeSwitch();
    currentReader = null;
    currentAnchor = null;
    lastObservedPage = 0;
    lastZoomPrefetchPage = 0;
    pendingBridgePage = 0;
    pendingBridgeStarted = 0;
    lastSpreadSize = '';
    modernLandscapeSize = '';
    lastLayoutSignature = '';
    neighborGeometrySerial++;clearTimeout(neighborGeometryTimer);neighborGeometryTimer=0;
    portraitPrimeNeeded = true;
    lastPortraitSize = '';
    // If the new viewport dimensions are already available, prime immediately.
    // Otherwise the following resize/visualViewport event will do it.
    primePortraitState(reader, true, fitModern);
    if (iphonePortraitPrimed) settleIPhonePortraitFit();
  }

  function primeLandscapeState(fitModern = true) {
    installStyle();
    const reader = readerOnPage();
    if (!reader || !isLandscape()) {
      if (document.documentElement.classList.contains(ROOT_CLASS)) clearLayout(fitModern);
      else if(fitModern&&window.__munibinQuranCommittingViewport)notifyView();
      // clearLayout may have run on orientationchange while the old landscape
      // dimensions were still exposed. Always try again here so the first resize
      // carrying real portrait geometry performs the synchronous final fit.
      primePortraitState(reader,false,fitModern);
      return false;
    }

    currentReader = reader;
    if (iphonePortraitPrimed) {
      iphonePortraitPrimed = false;
      try { window.__munibinQuranPortraitFitLocked = false; } catch (_) {}
      if (iphonePortraitSettleTimer) { clearTimeout(iphonePortraitSettleTimer); iphonePortraitSettleTimer = 0; }
    }
    portraitPrimeNeeded = true;
    lastPortraitSize = '';
    const tablet = isTouchTablet();
    const html = document.documentElement;
    html.classList.add(ROOT_CLASS);
    html.classList.toggle(TABLET_CLASS, tablet);
    html.classList.toggle(ANDROID_CLASS, isAndroidNative());

    const previousSpread=html.classList.contains(SPREAD_CLASS);
    const mode=storedMode()==='spread'&&spreadCompatible()?'spread':'zoom';
    currentMode = mode;
    html.classList.toggle(SPREAD_CLASS, mode === 'spread');
    html.classList.toggle(ZOOM_CLASS,mode==='zoom'&&!modernReader());
    if(previousSpread!==(mode==='spread')||(fitModern&&window.__munibinQuranCommittingViewport))notifyView();

    if(modernReader()&&fitModern)primeModernLandscape();
    if(mode==='zoom'&&!modernReader()){
      // qcf-width-fit is loaded before this helper. Run it now so the zoom row
      // height is computed from the final glyph size before the browser paints.
      try { window.__munibinFitQcf1441Width?.(); } catch (_) {}
      fitZoomTypography(reader);
      syncZoomPageNumbers();
      prefetchZoomNeighbors();
    }
    return true;
  }

  function applyLayout() {
    layoutRaf = 0;
    if(window.__munibinQuranInteracting)return;
    installStyle();
    const reader = readerOnPage();
    if (!reader || !isLandscape()) {
      if (document.documentElement.classList.contains(ROOT_CLASS)) clearLayout();
      primePortraitState(reader);
      return;
    }
    const prefs=readingPreferences();
    const signature=`${reader.clientWidth}|${reader.clientHeight}|${innerWidth}|${innerHeight}|${currentPage()}|${storedMode()}|${prefs.font}|${prefs.scale}|${prefs.tajweed}|${prefs.spacing}|${prefs.lineSpacing}|${reader.classList.contains('qcf1441-preview--chrome-hidden')}`;
    if(currentReader===reader&&lastLayoutSignature===signature)return;
    lastLayoutSignature=signature;
    currentReader = reader;
    const tablet = isTouchTablet();
    const html = document.documentElement;
    html.classList.add(ROOT_CLASS);
    html.classList.toggle(TABLET_CLASS, tablet);
    html.classList.toggle(ANDROID_CLASS, isAndroidNative());
    ensureSwitch(reader);
    setMode(storedMode(), false);

    const p = currentPage();
    if (currentMode === 'spread') {
      const now = performance.now();
      if (pendingBridgePage) {
        if (p === pendingBridgePage) {
          lastObservedPage = p;
          pendingBridgePage = 0;
          pendingBridgeStarted = 0;
        } else if (now - pendingBridgeStarted < 2500) {
          // Keep the already-promoted spread on screen while the underlying React
          // reader finishes its page jump. This removes the old-spread flash.
          const size = spreadRoot?.isConnected ? `${spreadRoot.clientWidth}x${spreadRoot.clientHeight}` : '';
          if (size && size !== lastSpreadSize) {
            lastSpreadSize = size;
            fitVisibleSpreadAndQueueNeighbors();
          }
          return;
        } else {
          pendingBridgePage = 0;
          pendingBridgeStarted = 0;
        }
      }
      const anchor = oddAnchor(p);
      if (!spreadRoot?.isConnected || (!bookTurn && currentAnchor !== anchor)) renderSpread(anchor);
      lastObservedPage = p;
      const size = spreadRoot?.isConnected ? `${spreadRoot.clientWidth}x${spreadRoot.clientHeight}` : '';
      if (size && size !== lastSpreadSize) {
        lastSpreadSize = size;
        fitVisibleSpreadAndQueueNeighbors();
      }
    } else {
      if(modernReader()){clearZoomPageNumbers();lastObservedPage=p;prefetchZoomNeighbors(p);return}
      syncZoomPageNumbers();
      fitZoomTypography();
      if (p !== lastObservedPage) {
        lastObservedPage = p;
        const stage = q('.qcf1441-page-stage', reader);
        if (stage) stage.scrollTop = 0;
        prefetchZoomNeighbors(p);
        refitZoomSoon();
      }
    }
  }

  function scheduleLayout() {
    if (layoutRaf) return;
    layoutRaf = requestAnimationFrame(applyLayout);
  }

  function fontUrl(font) {
    const page=Number(/^QuranTajweed(\d+)$/.exec(font)?.[1]);
    return `/assets/tajweed-v362/fonts/p${page}.woff2`;
  }

  function loadFont(font) {
    if (!font || !/^QuranTajweed\d+$/.test(font)) return Promise.resolve();
    if (fontCache.has(font)) return fontCache.get(font);
    const p = (async () => {
      const ensure=window.__munibinQuranReading?.ensureTajweedPage;
      if(ensure){await ensure(Number(/^QuranTajweed(\d+)$/.exec(font)[1]));return}
      try {
        if(Array.from(document.fonts||[]).some(face=>face.family.replace(/["']/g,'')===font&&face.status==='loaded'))return;
        const face = new FontFace(font, `url("${fontUrl(font)}") format("woff2")`);
        const loaded = await face.load();
        document.fonts.add(loaded);
      } catch (_) {}
    })();
    fontCache.set(font, p);
    p.catch(()=>fontCache.delete(font));
    return p;
  }

  function fetchPage(page) {
    const p = clampPage(page);
    if (pageCache.has(p)) return pageCache.get(p);
    const shared=window.__munibinQuranReading?.loadDocumentPage;
    const pageData=shared?shared(p):fetch(`/api/quran/qcf4/page/${padPage(p)}.json?reader=362`, { cache: 'force-cache' })
      .then(r => { if (!r.ok) throw new Error(`page ${p}`); return r.json(); });
    const promise = Promise.resolve(pageData)
      .then(async data => {
        if(!shared) {
         const normalize=window.__munibinQuranReading?.normalizeTajweedPage;
         if(normalize)normalize(data);
         else {
          const family=`QuranTajweed${data.page}`;data.font=family;let index=0;
          for(const line of data.lines||[])for(const word of line.words||[]){
            const text=(word.type==='word'||word.type==='bismillah')&&word.tajweed?.char?word.tajweed.char:String.fromCodePoint(0xe000+index);
            word.char=text;word.font=family;word.tajweed={char:text,page:data.page};index++;
          }
         }
        }
        await loadFont(data.font);
        return data;
      });
    pageCache.set(p, promise);
    promise.catch(() => pageCache.delete(p));
    return promise;
  }

  function glyphText(word) {
    if (typeof word?.char === 'string' && word.char) return word.char;
    return String(word?.text || '');
  }

  function makeSurahTitle(word, font, rendered) {
    const panel = document.createElement('div');
    panel.className = 'qcf1441-surah-title-panel';
    panel.setAttribute('aria-label', 'عنوان السورة');
    const ornament = side => {
      const span = document.createElement('span');
      span.className = `qcf1441-surah-title-ornament qcf1441-surah-title-ornament--${side}`;
      span.setAttribute('aria-hidden', 'true');
      span.append(document.createElement('i'), document.createElement('i'), document.createElement('i'));
      return span;
    };
    const win = document.createElement('span');
    win.className = 'qcf1441-surah-title-window';
    const glyph = document.createElement('span');
    glyph.className = 'qcf1441-glyph qcf1441-glyph-surah_header';
    Object.assign(glyph.style,{fontFamily:font},rendered?.style||{});
    paintSpreadInk(glyph,rendered,glyphText(word));
    win.appendChild(glyph);
    panel.append(ornament('right'), win, ornament('left'));
    return panel;
  }

  function makePageLines(data) {
    const lines = document.createElement('div');
    lines.className = 'qcf1441-lines munibin-quran-spread-lines';
    lines.dataset.readingPage=String(data.page);
    const prefs=readingPreferences();
    lines.dataset.readingFont=prefs.font;
    lines.dataset.readingTajweed=String(prefs.tajweed);
    for (const lineData of window.__munibinQuranReading?.readingLines(data,prefs)||data.lines||[]) {
      const special = lineData.words?.find(w => w.type === 'surah_header' || w.type === 'bismillah')?.type;
      const line = document.createElement('div');
      line.className = `qcf1441-line qcf1441-line-${special || 'ayah'}`;
      const alignment=window.__munibinQuranReading?.readingLineAlignment(lineData,prefs,data.page,data.lines);
      if(alignment)line.dataset.readingAlignment=alignment;
      for (const word of lineData.words || []) {
        const rendered=window.__munibinQuranReading?.readingWord(word,data.font,true,prefs);
        const font=rendered?.style.fontFamily||word.font||data.font||"'Amiri Quran', 'Amiri', serif";
        const isWord = !!word.verse_key && (word.type === 'word' || word.type === 'end');
        if (!isWord && word.type === 'surah_header') {
          line.appendChild(makeSurahTitle(word, font, rendered));
          continue;
        }
        if (!isWord) {
          const span = document.createElement('span');
          span.className = `qcf1441-glyph qcf1441-glyph-${word.type || 'word'}`;
          if(word.type==='quarter'&&word.verse_key)span.dataset.verseKey=word.verse_key;
          Object.assign(span.style,{fontFamily:font},rendered?.style||{});
          paintSpreadInk(span,rendered,glyphText(word));
          line.appendChild(span);
          continue;
        }
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'qcf1441-glyph qcf1441-glyph-word';
        Object.assign(button.style,{fontFamily:font},rendered?.style||{});
        button.dataset.verseKey = word.verse_key;
        button.dataset.wordType = word.type || 'word';
        button.setAttribute('aria-label', `اضغط مطولاً لخيارات الآية ${word.verse_key}`);
        const ink = document.createElement('span');
        ink.className = 'qcf1441-glyph-ink';
        paintSpreadInk(ink,rendered,glyphText(word));
        button.dataset.readingWord=`${word.verse_key}:${word.position}`;
        button.appendChild(ink);
        line.appendChild(button);
      }
      lines.appendChild(line);
    }
    return lines;
  }
  function paintSpreadInk(node,rendered,fallback) {
    node.replaceChildren();
    if(rendered?.runs)for(const [text,rule]of rendered.runs) {
      const span=document.createElement('span');span.textContent=text;
      if(rule)span.className=`munibin-tajweed-${rule}`;node.appendChild(span);
    } else if(rendered?.colorGlyph) {
      const span=document.createElement('span');span.className='munibin-tajweed-glyph-ink';span.textContent=rendered.text;
      for(const [name,value]of Object.entries(rendered.paintPadding||{}))span.style.setProperty(name,value);
      node.appendChild(span);
    } else node.textContent=rendered?.text??fallback;
  }
  function updateLeafReading(leaf,data) {
    const prefs=readingPreferences(),reflow=prefs.font!=='qcf1441'||prefs.scale!==1;
    leaf.classList.toggle('munibin-reader-reflow',reflow);
    leaf.classList.toggle('munibin-reader-text-font',prefs.font!=='qcf1441');
    leaf.style.setProperty('--munibin-reading-scale',String(prefs.scale));
    let pane=q(':scope > .munibin-quran-leaf-viewport',leaf);
    if(!pane){pane=document.createElement('div');pane.className='munibin-quran-leaf-viewport';pane.setAttribute('aria-label',`صفحة ${data.page}`);leaf.replaceChildren(pane)}
    const signature=`${prefs.font}|${prefs.tajweed}|${reflow}|${prefs.scale===1}`;
    if(leaf.dataset.inkSignature!==signature) {
      const num=document.createElement('span');num.className='munibin-quran-leaf-number';num.textContent=Number(data.page).toLocaleString('ar-EG');
      pane.replaceChildren(makePageLines(data),num);leaf.dataset.inkSignature=signature;
    }
    leaf.__munibinSpreadPage=data;
  }
  let readingRefreshSerial=0;
  function refreshSpreadReading() {
    if(!spreadRoot)return;
    cleanupBookTurn(false,true);
    const prefs=readingPreferences();spreadRoot.dataset.direction=prefs.direction;spreadRoot.dataset.zoom=String(prefs.scale>1);
    const serial=++readingRefreshSerial;
    const active=q('.munibin-quran-spread-sheet.is-active',spreadRoot);
    qa('.munibin-quran-leaf',active||spreadRoot).forEach(leaf=>{if(leaf.__munibinSpreadPage)updateLeafReading(leaf,leaf.__munibinSpreadPage)});
    fitSpreadTypography(active||spreadRoot);syncCustomHighlights();
    const neighbors=qa('.munibin-quran-spread-sheet:not(.is-active)',spreadRoot);
    const prepare=()=>{
      if(serial!==readingRefreshSerial||!spreadRoot?.isConnected)return;
      if(iosBookChromeBusy()){requestAnimationFrame(prepare);return}
      const sheet=neighbors.shift();if(!sheet)return;
      qa('.munibin-quran-leaf',sheet).forEach(leaf=>{if(leaf.__munibinSpreadPage)updateLeafReading(leaf,leaf.__munibinSpreadPage)});
      fitSpreadTypography(sheet);if(neighbors.length)requestAnimationFrame(prepare);
    };
    requestAnimationFrame(prepare);
  }

  function makeLeaf(page) {
    const leaf = document.createElement('section');
    leaf.className = 'munibin-quran-leaf';
    leaf.dataset.page = String(page);
    // The blank viewport has the final half-page geometry and native pan owner.
    // No loading label or fallback-font glyphs are painted before ink is ready.
    const pane=document.createElement('div');
    pane.className='munibin-quran-leaf-viewport';
    pane.setAttribute('aria-label',`صفحة ${page}`);
    leaf.appendChild(pane);
    return leaf;
  }

  function makeSheet(anchor, offset, serial) {
    const sheet = document.createElement('div');
    sheet.className = 'munibin-quran-spread-sheet';
    sheet.dataset.anchor = String(anchor);
    sheet.dataset.offset = String(offset);
    sheet.dataset.contentState='queued';
    sheet.append(makeLeaf(clampPage(anchor)),makeLeaf(clampPage(anchor+1)));
    queueSheetContent(sheet,serial);
    return sheet;
  }

  function queueSheetContent(sheet,serial=renderSerial) {
    if(!sheet||serial!==renderSerial)return;
    const anchor=Number(sheet.dataset.anchor),key=`${serial}|${anchor}`;
    if(pendingSheets.has(key))return;
    const leaves=qa(':scope > .munibin-quran-leaf',sheet);
    const data=leaves.map(leaf=>leaf.__munibinSpreadPage);
    const ready=data.length===2&&data.every(Boolean);
    const job={anchor,serial,key,sheet,started:ready,ready,data:ready?data:null,readingFont:ready?readingPreferences().font:null};
    pendingSheets.set(key,job);neighborJobs.push(job);
    // Starting the async drain yields before any resources, DOM ink, or fitting.
    setTimeout(()=>{if(serial===renderSerial)drainNeighborSheets(serial).catch(()=>{})},0);
  }

  function publishVisibleSpread(sheet,serial=renderSerial) {
    const anchor=Number(sheet?.dataset.anchor);
    if(bookPublishTimer){clearTimeout(bookPublishTimer);bookPublishTimer=0}
    const publishWhenIdle=()=>{
      bookPublishTimer=0;
      if(serial!==renderSerial||currentMode!=='spread'||!sheet?.isConnected||!sheet.classList.contains('is-active')||currentAnchor!==anchor)return;
      if(bookInteraction||gesture||window.__munibinQuranPinching||iosBookChromeBusy()) {
        bookPublishTimer=setTimeout(publishWhenIdle,40);return;
      }
      const publish=window.__munibinQuranNavigationBridge?.publishPage;
      if(typeof publish!=='function')return;
      for(const leaf of qa(':scope > .munibin-quran-leaf',sheet)) {
        const data=leaf.__munibinSpreadPage;
        if(data)try{publish(data.page,data)}catch(_){}
      }
    };
    bookPublishTimer=setTimeout(publishWhenIdle,24);
  }

  function fitSpreadSurahTitles(leaf) {
    window.__munibinFitQcf1441Titles?.(leaf);
  }

  function spreadTextColumn(width,height,scale=1) {
    const safe=Math.max(14,Math.min(28,width*.045));
    // The reading column follows a Mushaf page's proportions. Extra screen
    // width becomes equal outer/inner margins, never stretched word spaces.
    const textWidth=Math.max(1,Math.min(width-safe*2,Math.min(width-safe*2,height*.72)*scale));
    return {width:textWidth,padding:Math.max(safe,(width-textWidth)/2)};
  }

  function spreadTitleHeight(slot,count,base) {
    // An ornament must be smaller than its actual Mushaf row. The old row+3
    // cap let the bar paint over the preceding verse on short phone screens.
    const row=Math.max(1,(slot-6)/Math.max(1,count));
    return Math.max(1,Math.min(28,row*.68,base*1.65));
  }

  function fitLeafTypography(leaf) {
    if (!leaf?.isConnected) return;
    const lines = q('.qcf1441-lines', leaf);
    if (!lines || !lines.clientWidth) return;
    const opening=Number(leaf.dataset.page)<=2,stored=readingPreferences(),prefs=opening&&stored.spacing==='manual'?{...stored,spacing:'fixed',lineSpacing:100}:stored;
    // A book's first eight-row artwork expands with the same chrome slot as
    // every other spread. Only its natural row arrangement remains special.
    const hidden=prefs.spacing==='fullscreen'||prefs.spacing==='automatic'&&currentReader.classList.contains('qcf1441-preview--chrome-hidden');
    const readerStyle=getComputedStyle(currentReader);
    const footer=hidden?36:(parseFloat(readerStyle.getPropertyValue('--munibin-reader-bottom'))||70);
    const fullHeight=prefs.font==='qcf1441'&&prefs.scale===1&&!opening&&prefs.spacing!=='manual';
    const extraTop=parseFloat(readerStyle.getPropertyValue('--munibin-book-edge-top'))||0;
    const fontSlot=Math.max(60,leaf.clientHeight-footer-extraTop);
    // A smaller number leaves six more pixels below a hidden-chrome page,
    // and two when chrome is shown. Keep ink above the actual footer, then
    // spend part on letters and the rest on row gaps.
    const rowFooter=fullHeight?Math.max(0,footer-(hidden?16:6)):footer;
    const slot=fullHeight?Math.max(60,leaf.clientHeight-rowFooter):fontSlot;
    const signature=`${prefs.font}|${prefs.scale}|${prefs.tajweed}|${leaf.clientWidth}|${slot}|${fontSlot}|${hidden}|${prefs.spacing}|${prefs.lineSpacing}|${leaf.dataset.inkSignature}`;
    if(leaf.__munibinTypographySignature===signature)return false;
    // A 100% QCF baseline uses this leaf's half-screen width and height, even
    // when its actual DOM rows have reflowed at the chosen zoom level.
    const original=leaf.__munibinSpreadPage;
    const metrics=window.__munibinQcf1441PageMetrics?.(leaf.dataset.page);
    const count=original?.lines.length||15;
    const gaps=Math.max(0,...(original?.lines||[]).filter(line=>!line.words.some(word=>word.type==='surah_header'||word.type==='bismillah')).map(line=>line.words.length-1));
    const cap=Number(leaf.dataset.page)<=2?Math.min(35.4,Math.max(.5,(fontSlot-6)/count-13)/(metrics?.[1]||1.9)):Math.min(35.4,Math.max(.5,(fontSlot-24)/count)*.675,Math.max(.5,(fontSlot-6)/count-2)/(metrics?.[1]||1.9));
    const natural=window.__munibinQcf1441NaturalWidth?.(leaf.dataset.page)||((metrics?.[0]||16)+gaps*.16);
    const nativeBaseline=prefs.font==='qcf1441'&&Number(leaf.dataset.page)>2;
    const previousColumn=spreadTextColumn(leaf.clientWidth,fontSlot);
    const maximumColumn=spreadTextColumn(leaf.clientWidth,fontSlot,nativeBaseline?1.04:1);
    const width=Math.max(1,maximumColumn.width-6);
    const previousBase=nativeBaseline?window.__munibinQcf1441Spread100Size?.(leaf.dataset.page,width,fontSlot,Math.max(1,previousColumn.width-6))||Math.max(.5,Math.min(cap,width/natural)):Math.max(.5,Math.min(cap,width/natural));
    // Preserve the v371 column before sizing compact titles. Any extra text
    // must fit this same width so it closes word gaps instead of widening them.
    const textNatural=window.__munibinQcf1441NaturalWidth?.(leaf.dataset.page,.02)||natural;
    const required=nativeBaseline?previousBase*textNatural+6:previousColumn.width;
    let columnWidth=Math.max(previousColumn.width,Math.min(maximumColumn.width,required));
    const maximumSize=Math.max(.5,(columnWidth-6)/textNatural);
    // Use the same joint title/text baseline at 100% and zoom. Only a native
    // 100% page packs rows into this slot; zoomed pages reflow and scroll.
    const titleSlot=fontSlot+(prefs.spacing==='manual'?0:hidden?14:8);
    const titleFit=nativeBaseline?window.__munibinQcf1441Spread100TitleFit?.(leaf.dataset.page,previousBase,titleSlot,prefs.spacing==='manual'?4:1,prefs.spacing==='manual'?prefs.lineSpacing:0,maximumSize):null;
    const originalBase=titleFit?.size||previousBase;
    const titleHeight=titleFit?.titleHeight||spreadTitleHeight(fontSlot,count,originalBase);
    // Zoom uses this same native book budget before CSS scales and wraps the
    // text. Its scroll viewport must not introduce a smaller baseline.
    const densitySlot=prefs.spacing==='manual'?fontSlot:Math.max(60,leaf.clientHeight-Math.max(0,footer-(hidden?10:4)));
    const density=nativeBaseline?window.__munibinQcf1441Spread100DensityFit?.(leaf.dataset.page,originalBase,densitySlot,titleHeight,prefs.spacing==='manual'?4:1,prefs.spacing==='manual'?prefs.lineSpacing:0,maximumSize):null;
    let base=density?.size||originalBase;
    if(nativeBaseline) {
      const gain=hidden?6:2;
      // The largest native outline leading bounds every text row, including
      // standalone basmalas. Keep at least 55% of reclaimed height for gaps.
      const inkBudget=count*(metrics?.[1]||2.4);
      const limit=Math.min(base*1.03,base+gain*.45/Math.max(.01,inkBudget));
      const expandedColumn=spreadTextColumn(leaf.clientWidth,fontSlot,1.07);
      const capacity=Math.max(.5,(Math.max(columnWidth,expandedColumn.width)-6)/textNatural);
      const grown=window.__munibinQcf1441Spread100DensityFit?.(leaf.dataset.page,base,densitySlot+gain,titleHeight,1,0,capacity);
      base=Math.max(base,Math.min(limit,grown?.size||base));
      columnWidth=Math.max(columnWidth,Math.min(expandedColumn.width,base*textNatural+6));
    }
    leaf.style.setProperty('--munibin-spread-inline-padding',`${Math.max(0,(leaf.clientWidth-columnWidth)/2).toFixed(3)}px`);
    leaf.style.setProperty('--munibin-reader-content-height',`${slot}px`);
    leaf.style.setProperty('--munibin-spread-edge-padding',fullHeight?'1px':'4px');
    if(leaf.dataset.readingFullHeight!==String(fullHeight))leaf.dataset.readingFullHeight=String(fullHeight);
    lines.style.setProperty('--munibin-qcf-native-gap',nativeBaseline&&prefs.scale===1?'.02em':'.16em');
    leaf.style.setProperty('--munibin-spread-base-size',`${base.toFixed(3)}px`);
    leaf.style.setProperty('--munibin-spread-title-height',`${titleHeight.toFixed(3)}px`);
    leaf.style.setProperty('--munibin-spread-basmala-scale',String(density?.basmalaScale||1));
    if(prefs.font!=='qcf1441'||prefs.scale!==1) {
      window.__munibinQuranReading?.fitReadingPageLayout(leaf);
      fitSpreadSurahTitles(leaf);
      leaf.__munibinTypographySignature=signature;
      return true;
    }
    // The same measured baseline serves phones and tablets. Every original
    // row (and its ink) fits in the leaf's slot at 100%, without scrolling.
    leaf.style.setProperty('--munibin-spread-glyph-size',`${base.toFixed(3)}px`);
    lines.style.setProperty('--munibin-qcf-line-count',String(count));
    // Manual row geometry must be final before static ink alignment and reveal.
    // Reapplying it after alignment caused a cold page to snap into its row step.
    window.__munibinApplyQcf1441NativeSpacing?.(lines,prefs,base);
    window.__munibinAlignQcf1441Lines?.(lines,base);
    window.__munibinQuranReading?.spaceMushafRows(lines);
    fitSpreadSurahTitles(leaf);
    leaf.__munibinTypographySignature=signature;
    return true;
  }

  function bookGeometryKey() {
    const prefs = readingPreferences();
    const hidden = prefs.spacing === 'fullscreen' || prefs.spacing === 'automatic' && currentReader?.classList.contains('qcf1441-preview--chrome-hidden');
    return `${currentReader?.clientWidth}|${currentReader?.clientHeight}|${prefs.font}|${prefs.tajweed}|${prefs.scale}|${prefs.spacing}|${prefs.lineSpacing}|${hidden}`;
  }

  function sheetInkMatchesReading(sheet) {
    if(sheet?.dataset.contentState!=='ready')return false;
    const prefs=readingPreferences(),reflow=prefs.font!=='qcf1441'||prefs.scale!==1;
    const signature=`${prefs.font}|${prefs.tajweed}|${reflow}|${prefs.scale===1}`;
    const leaves=qa(':scope > .munibin-quran-leaf',sheet);
    return leaves.length===2&&leaves.every(leaf=>leaf.__munibinSpreadPage&&leaf.dataset.inkSignature===signature);
  }

  function fitSpreadTypography(root = spreadRoot) {
    if (!root?.isConnected) return;

    window.__munibinQuranReading?.measureQuranReader?.();
    const scopes=[root],geometry=bookGeometryKey();
    // Fit only loaded immediate destinations before chrome animation starts.
    // Farther pairs keep their idle preparation; no data/font/ink work is added.
    if(root.classList?.contains('munibin-quran-spread-sheet')&&root.classList.contains('is-active')&&spreadRoot?.isConnected) {
      const anchor=Number(root.dataset.anchor);
      for(const sheet of qa('.munibin-quran-spread-sheet',spreadRoot)) {
        if(sheet!==root&&Math.abs(Number(sheet.dataset.anchor)-anchor)===2&&sheet.__munibinBookGeometry!==geometry&&sheetInkMatchesReading(sheet))scopes.push(sheet);
      }
    }
    for(const scope of scopes) {
      let changed=false;
      qa('.munibin-quran-leaf:not(.munibin-quran-turn-placeholder)',scope).forEach(leaf=>{changed=fitLeafTypography(leaf)||changed});
      const sheets=scope.classList?.contains('munibin-quran-spread-sheet')?[scope]:qa('.munibin-quran-spread-sheet',scope);
      sheets.forEach(sheet=>{sheet.__munibinBookGeometry=geometry});
      if(changed) {
        window.__munibinQuranReading?.applyNativeLineSpacing?.(scope);
        window.__munibinQuranReading?.syncReadingHighlights?.(scope);
      }
    }
    // A retained leaf can already match its new fitting signature. Pending
    // chrome motion still needs its endpoint even when no ink changed here.
    if(currentReader)window.__munibinQuranReading?.finishQuranChromeMotion?.(currentReader);
  }

  function fitVisibleSpreadAndQueueNeighbors() {
    if(!spreadRoot?.isConnected)return;
    const active=q('.munibin-quran-spread-sheet.is-active',spreadRoot);
    if(active)fitSpreadTypography(active);
    const serial=++neighborGeometrySerial;
    clearTimeout(neighborGeometryTimer);
    const neighbors=qa('.munibin-quran-spread-sheet:not(.is-active)',spreadRoot);
    const next=()=>{
      neighborGeometryTimer=0;
      if(serial!==neighborGeometrySerial||!spreadRoot?.isConnected||currentMode!=='spread')return;
      if(window.__munibinQuranInteracting||iosBookChromeBusy()){neighborGeometryTimer=setTimeout(next,60);return}
      const sheet=neighbors.shift();if(!sheet)return;
      fitSpreadTypography(sheet);
      if(neighbors.length)neighborGeometryTimer=setTimeout(next,24);
    };
    if(neighbors.length)neighborGeometryTimer=setTimeout(next,24);
  }

  function sheetByOffset(offset) {
    if (!spreadRoot) return null;
    return q(`.munibin-quran-spread-sheet[data-offset="${offset}"]`, spreadRoot);
  }

  function markActiveSheet(sheet) {
    if (!spreadRoot || !sheet) return;
    qa('.munibin-quran-spread-sheet', spreadRoot).forEach(el => {
      el.classList.toggle('is-active', el === sheet);
      if (el !== sheet) el.classList.remove('is-turn-target');
    });
    sheet.dataset.offset = '0';
  }

  function drainNeighborSheets(serial) {
    if(neighborDrainSerial===serial)return neighborWork;
    neighborDrainSerial=serial;
    const valid=job=>job.serial===serial&&job.sheet.isConnected&&Math.abs((job.anchor-currentAnchor)/2)<=BOOK_CACHE_RADIUS;
    const nearest=jobs=>jobs.sort((a,b)=>Math.abs(a.anchor-currentAnchor)-Math.abs(b.anchor-currentAnchor))[0];
    neighborWork=(async()=>{
      while(serial===renderSerial&&spreadRoot?.isConnected&&currentMode==='spread') {
        for(const job of neighborJobs.filter(job=>job.serial===serial&&!valid(job))) {
          neighborJobs.splice(neighborJobs.indexOf(job),1);
          if(pendingSheets.get(job.key)===job)pendingSheets.delete(job.key);
        }
        const eligible=neighborJobs.filter(valid);
        if(!eligible.some(job=>job.ready||(!job.started&&bookResourceTasks<BOOK_RESOURCE_PAIRS)))break;
        if(!await waitForBookIdle(serial,true,true))break;
        // Re-evaluate priority after the finger stops. Unresolved font/data tasks
        // never hold this drain, and never block a newer visible pair.
        const live=neighborJobs.filter(valid);
        const ready=nearest(live.filter(job=>job.ready));
        if(ready) {
          if(ready.readingFont!==readingPreferences().font) {
            ready.started=false;ready.ready=false;ready.data=null;continue;
          }
          const leaves=qa(':scope > .munibin-quran-leaf',ready.sheet);
          for(let index=0;index<leaves.length;index++) {
            const leaf=leaves[index],result=ready.data[index];
            if(result?.error) {
              const error=document.createElement('div');error.className='munibin-quran-leaf-error';error.textContent='تعذر تحميل الصفحة';
              q('.munibin-quran-leaf-viewport',leaf)?.replaceChildren(error);
            } else if(result)updateLeafReading(leaf,result);
          }
          fitSpreadTypography(ready.sheet);
          for(const leaf of leaves)q('.munibin-quran-leaf-viewport',leaf)?.style.removeProperty('visibility');
          ready.sheet.dataset.contentState=ready.data.some(data=>data?.error)?'error':'ready';
          neighborJobs.splice(neighborJobs.indexOf(ready),1);
          if(pendingSheets.get(ready.key)===ready)pendingSheets.delete(ready.key);
          if(ready.sheet.classList.contains('is-active')) {
            syncCustomHighlights();publishVisibleSpread(ready.sheet,serial);
            window.dispatchEvent(new Event('munibin-quran-font-layouts-ready'));
          }
          continue;
        }
        const job=bookResourceTasks<BOOK_RESOURCE_PAIRS?nearest(live.filter(job=>!job.started)):null;
        if(!job)break;
        job.started=true;job.readingFont=readingPreferences().font;bookResourceTasks++;
        const resources=[job.anchor,job.anchor+1].map(async page=>{
          try {
            const data=await fetchPage(page);
            await window.__munibinQuranReading?.ensureReadingFont(job.readingFont);
            if(job.readingFont==='qcf1441')await window.__munibinQuranReading?.ensureTajweedPage(data);
            return data;
          } catch(_){return {error:true,page}}
        });
        Promise.all(resources).then(data=>{
          if(!valid(job)||serial!==renderSerial||pendingSheets.get(job.key)!==job)return;
          job.data=data;job.ready=true;drainNeighborSheets(serial).catch(()=>{});
        }).finally(()=>{
          bookResourceTasks--;
          if(spreadRoot?.isConnected&&currentMode==='spread')drainNeighborSheets(renderSerial).catch(()=>{});
        });
      }
    })().finally(()=>{
      if(neighborDrainSerial!==serial)return;
      neighborDrainSerial=0;
      // A resource can finish while the drain's final microtask is pending.
      const live=neighborJobs.filter(valid);
      if(live.some(job=>job.ready||(!job.started&&bookResourceTasks<BOOK_RESOURCE_PAIRS)))setTimeout(()=>{
        if(serial===renderSerial)drainNeighborSheets(serial).catch(()=>{});
      },0);
    });
    return neighborWork;
  }

  function ensureSheetShell(anchor,serial=renderSerial) {
    if(!spreadRoot?.isConnected||serial!==renderSerial||anchor<1||anchor>603)return null;
    let sheet=q(`.munibin-quran-spread-sheet[data-anchor="${anchor}"]`,spreadRoot);
    if(!sheet) {
      sheet=makeSheet(anchor,Math.round((anchor-currentAnchor)/2),serial);
      spreadRoot.appendChild(sheet);
    }
    return sheet;
  }

  function prepareNeighborSheets(anchor,serial=renderSerial) {
    if(!spreadRoot?.isConnected||serial!==renderSerial||currentMode!=='spread')return Promise.resolve();
    // Shell creation is a few fixed nodes, independent of Quran glyph count.
    // Resource requests and final ink/fitting remain deferred to the idle drain.
    for(let distance=1;distance<=BOOK_CACHE_RADIUS;distance++)for(const offset of [distance,-distance]) {
      const target=anchor+offset*2;
      if(target>=1&&target<=603)ensureSheetShell(target,serial);
    }
    return drainNeighborSheets(serial).catch(()=>{});
  }

  function renderSpread(anchor) {
    if(currentMode!=='spread'||!currentReader)return;
    const stage=q('.qcf1441-preview-page',currentReader);
    if(!stage)return;
    anchor=Math.min(603,oddAnchor(anchor));currentAnchor=anchor;
    const serial=++renderSerial;
    pendingSheets.clear();neighborJobs.length=0;neighborDrainSerial=0;neighborWork=Promise.resolve();
    cleanupBookTurn(false,true);
    if(!spreadRoot||!spreadRoot.isConnected||spreadRoot.parentElement!==stage) {
      spreadRoot?.remove();spreadRoot=document.createElement('div');spreadRoot.className='munibin-quran-spread';
      spreadRoot.setAttribute('aria-label','عرض المصحف على صفحتين');stage.appendChild(spreadRoot);bindSpreadGestures(spreadRoot);
    }
    spreadRoot.dataset.anchor=String(anchor);spreadRoot.dataset.direction=readingPreferences().direction;
    spreadRoot.dataset.zoom=String(readingPreferences().scale>1);spreadRoot.replaceChildren();
    const active=makeSheet(anchor,0,serial);
    active.classList.add('is-active');spreadRoot.appendChild(active);
    const gutter=document.createElement('div');gutter.className='munibin-quran-spread-gutter';gutter.setAttribute('aria-hidden','true');spreadRoot.appendChild(gutter);
    lastSpreadSize=`${spreadRoot.clientWidth}x${spreadRoot.clientHeight}`;
    prepareNeighborSheets(anchor,serial).catch(()=>{});
  }

  function flushBridgePageSync() {
    if (bridgeSyncTimer) {
      clearTimeout(bridgeSyncTimer);
      bridgeSyncTimer = 0;
    }
    const page = bridgeSyncPage;
    bridgeSyncPage = 0;
    if (!page) return;
    try { window.__munibinQuranNavigationBridge?.goPage?.(page); } catch (_) {}
  }

  function scheduleBridgePageSync(page) {
    const select=window.__munibinQuranNavigationBridge?.selectPageShell;
    if(typeof select==='function') {
      if(bridgeSyncTimer){clearTimeout(bridgeSyncTimer);bridgeSyncTimer=0}
      bridgeSyncPage=0;
      try{select(clampPage(page));return}catch(_){}
    }
    bridgeSyncPage = clampPage(page);
    if (bridgeSyncTimer) clearTimeout(bridgeSyncTimer);
    // A quick sequence of page turns should stay entirely inside the pre-rendered
    // spread until the finger pauses. Updating React after every intermediate turn
    // was the main source of the stutter when users spam-swiped.
    bridgeSyncTimer = window.setTimeout(() => {
      bridgeSyncTimer = 0;
      flushBridgePageSync();
    }, 140);
  }

  function prepareBookTurn(direction) {
    if (!spreadRoot || !currentAnchor) return null;
    if (bookTurn?.settling) {
      const commit = !!bookTurn.settleCommit;
      cleanupBookTurn(commit, true);
    } else if (bookTurn?.direction === direction) {
      return bookTurn;
    } else if (bookTurn) {
      cleanupBookTurn(false, true);
    }

    const offset = direction === 'next' ? 1 : -1;
    const currentSheet = sheetByOffset(0) || q('.munibin-quran-spread-sheet.is-active', spreadRoot);
    const targetSheet = sheetByOffset(offset)||ensureSheetShell(currentAnchor+offset*2);
    if (!currentSheet || !targetSheet) return null;

    const currentLeaves = qa(':scope > .munibin-quran-leaf', currentSheet);
    const targetLeaves = qa(':scope > .munibin-quran-leaf', targetSheet);
    if (currentLeaves.length < 2 || targetLeaves.length < 2) return null;
    // A ready retained target must already use this chrome budget when its
    // first turning frame paints. Only a genuinely cold/mismatched ink tree
    // needs resource preparation; never blank a ready page until after a turn.
    if (targetSheet.__munibinBookGeometry && targetSheet.__munibinBookGeometry !== bookGeometryKey()) {
      if(sheetInkMatchesReading(targetSheet)) {
        targetLeaves.forEach(fitLeafTypography);
        targetSheet.__munibinBookGeometry=bookGeometryKey();
        for(const leaf of targetLeaves)q('.munibin-quran-leaf-viewport',leaf)?.style.removeProperty('visibility');
      } else {
        for(const leaf of targetLeaves)q('.munibin-quran-leaf-viewport',leaf)?.style.setProperty('visibility','hidden');
        queueSheetContent(targetSheet);
      }
    }
    qa('.munibin-quran-leaf-viewport',targetSheet).forEach(pane=>{pane.scrollTop=0});
    if(readingPreferences().direction==='vertical') {
      targetSheet.classList.add('is-turn-target');
      bookTurn={direction,vertical:true,wrapper:document.createElement('div'),currentSheet,targetSheet,turningLeaf:null,targetAnchor:Number(targetSheet.dataset.anchor),progress:0,settling:false,settleCommit:false};
      setBookInteraction(true);syncCustomHighlights();
      updateBookTurnTransform(0,false);return bookTurn;
    }

    // DOM order is right page, then left page.
    const turningLeaf = direction === 'next' ? currentLeaves[1] : currentLeaves[0];
    const backLeaf = direction === 'next' ? targetLeaves[0] : targetLeaves[1];
    const wrapper = document.createElement('div');
    wrapper.className = `munibin-quran-turn-page munibin-quran-turn-page--${direction}`;

    const front = document.createElement('div');
    front.className = 'munibin-quran-turn-face munibin-quran-turn-face--front';
    front.style.visibility='visible';
    const frontPlaceholder = turningLeaf.cloneNode(false);
    const backPlaceholder = backLeaf.cloneNode(false);
    for (const placeholder of [frontPlaceholder, backPlaceholder]) {
      placeholder.classList.add('munibin-quran-turn-placeholder');
      placeholder.setAttribute('aria-hidden', 'true');
      placeholder.style.visibility = 'hidden';
      placeholder.inert = true;
    }
    turningLeaf.before(frontPlaceholder);
    backLeaf.before(backPlaceholder);
    front.appendChild(turningLeaf);
    const back = document.createElement('div');
    back.className = 'munibin-quran-turn-face munibin-quran-turn-face--back';
    back.style.visibility='hidden';
    back.appendChild(backLeaf);
    wrapper.append(front, back);

    // Move the real, already fitted leaves instead of deep-cloning thousands of
    // colored glyph nodes on the first drag frame. Shallow placeholders preserve
    // the stationary half's grid column. Their viewport scroll/highlights remain
    // on the same native elements for the entire gesture.
    targetSheet.classList.add('is-turn-target');
    spreadRoot.appendChild(wrapper);
    bookTurn = {
      direction,
      wrapper,
      currentSheet,
      targetSheet,
      turningLeaf,
      backLeaf,
      frontFace:front,backFace:back,
      frontPlaceholder,
      backPlaceholder,
      targetAnchor: Number(targetSheet.dataset.anchor),
      progress: 0,
      settling: false,
      settleCommit: false
    };
    setBookInteraction(true);
    syncCustomHighlights();
    updateBookTurnTransform(0, false);
    return bookTurn;
  }

  function updateBookTurnTransform(progress, settling) {
    const turn = bookTurn;
    if (!turn) return;
    const p = Math.max(0, Math.min(1, Number(progress) || 0));
    turn.progress = p;
    if(turn.vertical) {
      const sign=turn.direction==='next'?-1:1,height=spreadRoot.clientHeight||1;
      for(const sheet of [turn.currentSheet,turn.targetSheet])sheet.style.transition=settling?'transform 200ms ease-out':'none';
      turn.currentSheet.style.transform=`translateY(${sign*p*height}px)`;
      turn.targetSheet.style.transform=`translateY(${-sign*(1-p)*height}px)`;
      return;
    }
    // WebKit can paint a composited leaf through CSS backface-visibility.
    // Only the physically facing leaf is allowed to paint at this frame's angle.
    if(turn.frontFace)turn.frontFace.style.visibility=p<.5?'visible':'hidden';
    if(turn.backFace)turn.backFace.style.visibility=p>=.5?'visible':'hidden';
    turn.wrapper.classList.remove('is-settling');
    const angle = (turn.direction === 'next' ? 180 : -180) * p;
    turn.wrapper.style.transform = `rotateY(${angle}deg)`;
  }

  function cleanupBookTurn(promote = false, immediate = false) {
    const turn = bookTurn;
    if (!turn) return;
    cancelAnimationFrame(bookTurnFrame);bookTurnFrame=0;
    if (bookTurnTimer) {
      clearTimeout(bookTurnTimer);
      bookTurnTimer = 0;
    }
    if(turn.frontPlaceholder?.isConnected)turn.frontPlaceholder.replaceWith(turn.turningLeaf);
    if(turn.backPlaceholder?.isConnected)turn.backPlaceholder.replaceWith(turn.backLeaf);
    if(turn.turningLeaf)turn.turningLeaf.style.visibility = '';
    if(turn.vertical)for(const sheet of [turn.currentSheet,turn.targetSheet]){sheet.style.removeProperty('transform');sheet.style.removeProperty('transition')}
    turn.targetSheet.classList.remove('is-turn-target');
    turn.wrapper.classList.remove('is-settling');
    turn.wrapper.remove();
    bookTurn = null;
    setBookInteraction(false);

    if (!promote || !spreadRoot?.isConnected) return;
    const target = turn.targetSheet;
    const targetAnchor = oddAnchor(turn.targetAnchor);
    // Rebase and keep the nearby already-rendered spreads. This lets the very next
    // gesture start immediately instead of deleting and rebuilding its target.
    qa('.munibin-quran-spread-sheet', spreadRoot).forEach(sheet => {
      const a = oddAnchor(Number(sheet.dataset.anchor));
      const offset = Math.round((a - targetAnchor) / 2);
      const keep = Math.abs(offset) <= BOOK_CACHE_RADIUS;
      if (!keep) { sheet.remove(); return; }
      sheet.dataset.offset = String(offset);
      sheet.classList.toggle('is-active', sheet === target);
      sheet.classList.remove('is-turn-target');
    });
    target.classList.add('is-active');
    target.dataset.offset = '0';
    currentAnchor = targetAnchor;
    spreadRoot.dataset.anchor = String(targetAnchor);
    lastObservedPage = targetAnchor;
    pendingBridgePage = targetAnchor;
    pendingBridgeStarted = performance.now();
    const serial = renderSerial;
    // Promotion changes visibility only. Re-fitting every retained page here
    // caused the long frame and blocked a second gesture during fast swipes.
    syncCustomHighlights();
    window.__munibinQuranReading?.syncReadingHighlights?.(target);
    if(target.dataset.contentState==='error')queueSheetContent(target,serial);
    prepareNeighborSheets(targetAnchor, serial).catch(() => {});
    scheduleBridgePageSync(targetAnchor);
    publishVisibleSpread(target,serial);
  }

  function settleBookTurn(commit, done) {
    const turn = bookTurn;
    if (!turn) { done?.(false); return; }
    turn.settling = true;
    turn.settleCommit = !!commit;
    if(turn.vertical) {
      updateBookTurnTransform(commit?1:0,true);
      if(bookTurnTimer)clearTimeout(bookTurnTimer);
      bookTurnTimer=setTimeout(()=>{bookTurnTimer=0;if(bookTurn!==turn)return;cleanupBookTurn(commit);done?.(commit)},200);
      return;
    }
    cancelAnimationFrame(bookTurnFrame);
    const from=turn.progress,to=commit?1:0,start=performance.now();
    const duration=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches?0:185;
    const step=now=>{
      if(bookTurn!==turn)return;
      const progress=duration?Math.min(1,(now-start)/duration):1;
      updateBookTurnTransform(from+(to-from)*(1-Math.pow(1-progress,3)),false);
      if(progress<1)bookTurnFrame=requestAnimationFrame(step);
      else {bookTurnFrame=0;cleanupBookTurn(commit);done?.(commit)}
    };
    bookTurnFrame=requestAnimationFrame(step);
  }

  function destroySpread() {
    if (bookTurn?.settling && bookTurn.settleCommit) cleanupBookTurn(true, true);
    flushBridgePageSync();
    if(bookPublishTimer){clearTimeout(bookPublishTimer);bookPublishTimer=0}
    renderSerial += 1;
    pendingSheets.clear();
    neighborJobs.length = 0;
    neighborDrainSerial = 0;
    neighborWork = Promise.resolve();
    gesture = null;
    setBookInteraction(false);
    cleanupBookTurn(false, true);
    spreadRoot?.remove();
    spreadRoot = null;
    currentAnchor = null;
    lastSpreadSize = '';
  }

  function cancelParentGesture(pointerId, x, y, pointerType) {
    // Taking over a book turn must cancel the outer reader, not release its
    // swipe. Its pointercancel handler can otherwise finish a partial drag and
    // advance once before the spread advances again.
    const cancel = window.__munibinQuranNavigationBridge?.cancelGesture;
    if (typeof cancel === 'function') {
      try { cancel(); return; } catch (_) {}
    }
    const section = q('.qcf1441-preview-page', currentReader || document);
    if (!section || typeof PointerEvent !== 'function') return;
    try {
      section.dispatchEvent(new PointerEvent('pointercancel', {
        bubbles: true,
        cancelable: true,
        pointerId,
        clientX: x,
        clientY: y,
        pointerType: pointerType || 'touch'
      }));
    } catch (_) {}
  }

  function clearPressed() {
    if (!spreadRoot) return;
    qa('.qcf1441-glyph-word--pressed', spreadRoot).forEach(el => el.classList.remove('qcf1441-glyph-word--pressed'));
  }

  function bindSpreadGestures(root) {
    root.addEventListener('pointerdown', e => {
      if(window.__munibinQuranPinching||e.isPrimary===false){if(gesture?.longTimer)clearTimeout(gesture.longTimer);gesture=null;cleanupBookTurn(false,true);clearPressed();return}
      if (e.button != null && e.pointerType === 'mouse' && e.button !== 0) return;
      if (bookTurn?.settling) {
        const commit = !!bookTurn.settleCommit;
        cleanupBookTurn(commit, true);
      }
      const word = e.target.closest?.('.qcf1441-glyph-word[data-verse-key]');
      const now = performance.now();
      gesture = {
        id: e.pointerId,
        x: e.clientX,
        y: e.clientY,
        lastX: e.clientX,
        lastY: e.clientY,
        lastTime: now,
        velocity: 0,
        axis: null,
        dragging: false,
        long: false,
        pointerType: e.pointerType || 'touch',
        verseKey: word?.dataset.verseKey || '',
        viewport:e.target.closest?.('.munibin-quran-leaf-viewport'),
        vertical:readingPreferences().direction==='vertical',
        longTimer: null
      };
      // Ready neighbours are retained across turns; no page-building work starts
      // in this pointer-down handler.
      if (word) {
        qa(`.qcf1441-glyph-word[data-verse-key="${CSS.escape(word.dataset.verseKey)}"]`, root).forEach(el => el.classList.add('qcf1441-glyph-word--pressed'));
        gesture.longTimer = window.setTimeout(() => {
          if (!gesture || gesture.id !== e.pointerId || gesture.dragging) return;
          gesture.long = true;
          cancelParentGesture(gesture.id, gesture.x, gesture.y, gesture.pointerType);
          clearPressed();
          const fn = window.__munibinOpenQuranVerseMenu;
          if (typeof fn === 'function') fn(gesture.verseKey, gesture.x, gesture.y);
        }, 520);
      }
    }, { passive: true });

    root.addEventListener('pointermove', e => {
      if(window.__munibinQuranPinching){if(gesture?.longTimer)clearTimeout(gesture.longTimer);gesture=null;cleanupBookTurn(false,true);clearPressed();return}
      const g = gesture;
      if (!g || g.id !== e.pointerId || g.long) return;
      const dx = e.clientX - g.x;
      const dy = e.clientY - g.y;
      const ax = Math.abs(dx), ay = Math.abs(dy);
      if (Math.hypot(dx, dy) > 12 && g.longTimer) {
        clearTimeout(g.longTimer);
        g.longTimer = null;
        clearPressed();
      }
      if (!g.axis && Math.max(ax,ay)>6) g.axis = ax > ay * 1.08 ? 'x' : (ay > ax * 1.08 ? 'y' : null);
      if (g.axis !== (g.vertical?'y':'x')) return;
      // Enlarged text pans natively inside its own half. The central book
      // gutter remains available for vertical turns between page pairs.
      if(g.vertical&&g.viewport&&readingPreferences().scale>1)return;
      if (!g.dragging) {
        g.dragging = true;
        cancelParentGesture(g.id, e.clientX, e.clientY, g.pointerType);
      }
      e.preventDefault();
      e.stopPropagation();

      const now = performance.now();
      const dt = Math.max(1, now - g.lastTime);
      const v = (g.vertical?e.clientY-g.lastY:e.clientX-g.lastX) / dt;
      g.velocity = g.lastTime === 0 ? v : g.velocity * .62 + v * .38;
      g.lastX = e.clientX;
      g.lastY = e.clientY;
      g.lastTime = now;

      const movement=g.vertical?-dy:dx;
      if (Math.abs(movement) < 2) {
        if (bookTurn) updateBookTurnTransform(0, false);
        return;
      }
      const direction = movement > 0 ? 'next' : 'previous';
      const atEdge = direction === 'next' ? currentAnchor >= 603 : currentAnchor <= 1;
      if (atEdge) {
        cleanupBookTurn(false, true);
        return;
      }
      const turn = prepareBookTurn(direction);
      if (!turn) return;
      const extent = g.vertical?root.clientHeight:root.clientWidth;
      const progress = Math.min(1, Math.abs(movement) / Math.max(1, extent * .48));
      updateBookTurnTransform(progress, false);
    }, { passive: false });

    const finish = (e, cancelled) => {
      if(window.__munibinQuranPinching){if(gesture?.longTimer)clearTimeout(gesture.longTimer);gesture=null;cleanupBookTurn(false,true);clearPressed();return}
      const g = gesture;
      if (!g || g.id !== e.pointerId) return;
      if (g.longTimer) clearTimeout(g.longTimer);
      clearPressed();
      gesture = null;
      if (g.long) {
        e.preventDefault?.();
        e.stopPropagation?.();
        return;
      }
      if (!g.dragging) return;

      e.preventDefault?.();
      e.stopPropagation?.();
      if (cancelled || !bookTurn) {
        if (bookTurn) settleBookTurn(false);
        return;
      }

      const width = (g.vertical?root.clientHeight:root.clientWidth)||1;
      const endX = Number.isFinite(e.clientX) ? e.clientX : g.lastX;
      const dx = g.vertical?-((Number.isFinite(e.clientY)?e.clientY:g.lastY)-g.y):endX-g.x;
      const direction = bookTurn.direction;
      const directionMatches = direction === 'next' ? dx > 0 : dx < 0;
      const speed=g.vertical?-g.velocity:g.velocity;
      const velocityMatches = direction === 'next' ? speed > 0 : speed < 0;
      const validTarget = Number.isInteger(bookTurn.targetAnchor) && bookTurn.targetAnchor >= 1 && bookTurn.targetAnchor <= 603;
      const commit = validTarget && directionMatches && (
        Math.abs(dx) >= width * .12 || (velocityMatches && Math.abs(g.velocity) >= .42)
      );
      settleBookTurn(commit);
    };
    root.addEventListener('pointerup', e => finish(e, false), { passive: false });
    root.addEventListener('pointercancel', e => finish(e, true), { passive: false });
  }

  function syncMemorization(scope = spreadRoot) {
    if(!spreadRoot)return;if(!scope?.querySelectorAll)scope=spreadRoot;const state=window.__munibinQuranNavigationBridge?.memorizationState?.();
    qa('.munibin-quran-leaf:not(.munibin-quran-turn-placeholder)',scope).forEach(leaf=>{
      const page=Number(leaf.dataset.page),words=qa('.qcf1441-glyph-word',leaf);
      const shown=state?.counts?.[page]??(page<state?.startPage?words.length:0);
      words.forEach((word,index)=>{const hidden=!!state?.enabled&&index>=shown&&!state?.revealedWords?.has(word.dataset.readingWord);word.classList.toggle('qcf1441-glyph-word--memorization-hidden',hidden);if(hidden){word.setAttribute('aria-hidden','true');word.tabIndex=-1}else{word.removeAttribute('aria-hidden');word.removeAttribute('tabindex')}});
      window.__munibinQuranReading?.syncQuarterMarkerVisibility?.(leaf);
    });
  }
  function spreadRecitedVerse(audioState) {
    let state=audioState;
    if(state===undefined)try{state=window.__munibinQuranPlaylistBridge?.getState?.()}catch(_){}
    // The page's normal player publishes activeParaId, not the playlist global.
    // A live bridge is authoritative: stopping or leaving Quran clears old ink.
    const key=state?(state.active===true?(state.activeParaId||state.track?.paraId||window.__munibinPlaylistVerseKey||''):''):(window.__munibinPlaylistVerseKey||'');
    return /^\d+:\d+$/.test(String(key))?String(key):'';
  }
  function syncCustomHighlights(event) {
    if(!spreadRoot)return;
    const scopes = [q('.munibin-quran-spread-sheet.is-active', spreadRoot), q('.munibin-quran-spread-sheet.is-turn-target', spreadRoot), bookTurn?.wrapper].filter(Boolean);
    const verse = spreadRecitedVerse(event?.type==='munibin-quran-audio-state'?event.detail:undefined);
    lastObservedVerse = verse;
    for (const scope of scopes) {
      syncMemorization(scope);
      let changed=false;
      qa('.qcf1441-glyph-word[data-verse-key]', scope).forEach(el => {
        const active = !!verse && el.dataset.verseKey === verse;
        const end=active&&el.dataset.wordType==='end';
        if(el.classList.contains('qcf1441-glyph-word--recited')!==active||el.classList.contains('qcf1441-glyph-word--recited-end')!==end)changed=true;
        el.classList.toggle('qcf1441-glyph-word--recited', active);
        el.classList.toggle('qcf1441-glyph-word--recited-end', end);
      });
      // Paint joined verse bands immediately, without refitting fonts/pages.
      // Unchanged progress events perform no band measurement or DOM rebuild.
      if(changed)window.__munibinQuranReading?.syncReadingHighlights?.(scope);
    }
  }

  // A reader fit owns its measurements. Its preparation hook only synchronises
  // mode/classes; resize/orientation entry points request the complete fit once.
  window.__munibinQuranPrepareViewport=()=>primeLandscapeState(false);
  window.__munibinFitQuranSpreadTypography=fitSpreadTypography;
  installStyle();
  primeLandscapeState();
  function updateViewportBeforePaint() {
    const previous=window.__munibinQuranCommittingViewport;
    window.__munibinQuranCommittingViewport=true;
    try {
      if (isIOSPhone() && orientationWantsPortrait() && document.documentElement.classList.contains(ROOT_CLASS) && !iphonePortraitPrimed) {
        primeIPhonePortraitFont();
      }
      primeLandscapeState();
      if (iphonePortraitPrimed) settleIPhonePortraitFit();
    } finally {
      if(previous===undefined)delete window.__munibinQuranCommittingViewport;
      else window.__munibinQuranCommittingViewport=previous;
    }
    scheduleLayout();
  }
  window.addEventListener('resize',updateViewportBeforePaint,{passive:true});
  try {
    // WKWebView may publish its layout box here before the window resize. Both
    // notifications perform the same atomic mode/tree/metrics handoff.
    window.visualViewport?.addEventListener('resize',updateViewportBeforePaint,{passive:true});
  } catch (_) {}
  window.addEventListener('orientationchange', () => {
    // The first notification may still expose the old viewport. Keep its
    // geometry coherent; the first new layout box commits immediately, without
    // a modern-reader timer predicting or reapplying a different font later.
    updateViewportBeforePaint();
    if(modernReader())return;
    setTimeout(() => {
      primeLandscapeState();
      if (iphonePortraitPrimed) settleIPhonePortraitFit();
      scheduleLayout();
    }, 40);
  }, { passive: true });
  window.addEventListener('munibin-quran-memorization-change',syncMemorization);
  window.addEventListener('munibin-quran-reading-change',()=>{refreshSpreadReading();scheduleLayout()});
  window.addEventListener('munibin-quran-ink-refresh',()=>{
    if(!spreadRoot)return;
    qa('.munibin-tajweed-glyph-ink, .qcf1441-glyph-ink > [class^="munibin-tajweed-"]',spreadRoot).forEach(ink=>ink.replaceWith(ink.cloneNode(true)));
  });
  window.addEventListener('popstate', scheduleLayout);
  window.addEventListener('munibin-global-audio-state', syncCustomHighlights);
  window.addEventListener('munibin-quran-audio-state', syncCustomHighlights);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) scheduleLayout(); });
  new MutationObserver(records=>{
    for(const record of records) {
      if(!record.target.matches?.('.qcf1441-preview'))continue;
      const before=String(record.oldValue||'').split(/\s+/).includes('qcf1441-preview--chrome-hidden');
      const after=record.target.classList.contains('qcf1441-preview--chrome-hidden');
      if(before!==after&&readingPreferences().spacing==='automatic'&&(currentMode==='spread'||(!isLandscape()&&readingPreferences().scale===1))) {
        window.__munibinQuranReading?.scheduleQuranReaderFit?.();
        // Book geometry updates its visible pair only. Retained pairs are
        // prepared later, without blocking the header/footer's first paint.
        scheduleLayout();
      }
    }
  }).observe(document.documentElement,{subtree:true,attributes:true,attributeFilter:['class'],attributeOldValue:true});
  new MutationObserver(records=>{
    if(records.some(record=>{
      const target=record.target?.nodeType===3?record.target.parentElement:record.target;
      if(target?.closest?.('.munibin-quran-spread, .munibin-quran-verse-band'))return false;
      if(target?.closest?.('.qcf1441-preview'))return true;
      return [...record.addedNodes,...record.removedNodes].some(node=>node.nodeType===1&&(node.matches?.('.qcf1441-preview')||node.querySelector?.('.qcf1441-preview')));
    }))scheduleLayout();
  }).observe(document.documentElement, { childList: true, subtree: true });
  setInterval(() => {
    // Older recitation engines only publish the verse global. Retain a tiny
    // compatibility check, but never poll reader geometry or unchanged words.
    if(currentMode==='spread'&&spreadRecitedVerse()!==lastObservedVerse)syncCustomHighlights();
  }, 450);
  scheduleLayout();
})();
