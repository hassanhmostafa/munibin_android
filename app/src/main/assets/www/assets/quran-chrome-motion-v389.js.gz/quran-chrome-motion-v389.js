/* Reflow once, then animate paint coordinates. iOS paints each composed row
   explicitly, without relying on a same-turn CSS transition being committed.
   All geometry is measured before paint writes; a frame only writes transforms. */
const readers=new WeakMap();
const activeAnimations=new Set();
function trackAnimation(state,animation) {
 state.animations.add(animation);activeAnimations.add(animation);
 window.__munibinQuranChromeMotionActive=true;
}
function releaseAnimation(state,animation) {
 state.animations.delete(animation);activeAnimations.delete(animation);
 window.__munibinQuranChromeMotionActive=activeAnimations.size>0;
}
const reduceMotion=()=>typeof matchMedia==='function'&&matchMedia('(prefers-reduced-motion: reduce)').matches;
function visibleLine(line) {
 // Ayah rows own fixed geometry while controls fade; chrome never rescales ink.
 if(line.closest('.munibin-quran-ayah-pages'))return false;
 const opening=line.closest('.qcf1441-lines[data-reading-page]');
 if(opening&&Number(opening.dataset.readingPage)<=2&&!document.documentElement.classList.contains('munibin-quran-mode-spread'))return false;
 const sheet=line.closest('.munibin-quran-spread-sheet');
 if(sheet&&!sheet.classList.contains('is-active'))return false;
 const pane=line.closest('.munibin-quran-horizontal-page');
 return !pane||pane.classList.contains('is-active');
}
export function chromeMotionDelta(previous,next,origin,fontScale) {
 const scale=Math.max(.4,Math.min(2.5,Number.isFinite(fontScale)?fontScale:previous.height/Math.max(.01,next.height)));
 return {scale,x:previous.left-(origin.x+(next.left-origin.x)*scale),y:previous.top-(origin.y+(next.top-origin.y)*scale)};
}
function isIOS() {
 return window.__munibinNativePlatform==='ios'||/iPhone|iPad|iPod/i.test(navigator.userAgent||'')||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
}
function translatedOrigin(box,transform) {
 const matrix=String(transform||'').match(/^matrix\(([^)]+)\)$/);
 const matrix3d=String(transform||'').match(/^matrix3d\(([^)]+)\)$/);
 const values=(matrix?.[1]||matrix3d?.[1]||'').split(',').map(Number);
 const x=matrix?values[4]:matrix3d?values[12]:0;
 const y=matrix?values[5]:matrix3d?values[13]:0;
 return {x:box.left+box.width/2-(Number.isFinite(x)?x:0),y:box.top+box.height/2-(Number.isFinite(y)?y:0)};
}
function paintedFontScale(style) {
 const matrix=String(style.transform||'').match(/^matrix\(([^)]+)\)$/);
 const matrix3d=String(style.transform||'').match(/^matrix3d\(([^)]+)\)$/);
 const values=(matrix?.[1]||matrix3d?.[1]||'').split(',').map(Number);
 const transformed=matrix?Math.hypot(values[2],values[3]):matrix3d?Math.hypot(values[4],values[5],values[6]):1;
 const individual=String(style.scale||'none').trim().split(/\s+/).map(Number);
 const scale=Number.isFinite(individual[0])?(Number.isFinite(individual[1])?individual[1]:individual[0]):1;
 return Math.max(.01,(Number.isFinite(transformed)?transformed:1)*Math.abs(scale));
}
function transformMatrix(value) {
 const match=String(value||'').match(/^matrix(3d)?\(([^)]+)\)$/);
 const values=match?.[2].split(',').map(Number);
 if(values&&(values.length===6||values.length===16)&&values.every(Number.isFinite))return values;
 return [1,0,0,1,0,0];
}
function matrix3d(values) {
 return values.length===16?values:[values[0],values[1],0,0,values[2],values[3],0,0,0,0,1,0,values[4],values[5],0,1];
}
function captureChromeFrames(reader) {
 return Array.from(reader.querySelectorAll('.qcf1441-preview-header, .qcf1441-background-player, .qcf1441-memorization-player')).filter(node=>node.isConnected).map(node=>{
  const style=getComputedStyle(node),opacity=parseFloat(style.opacity);
  return {node,matrix:transformMatrix(style.transform),opacity:Number.isFinite(opacity)?opacity:1};
 });
}
function prepareChromeFrames(frames) {
 if(!frames.length)return null;
 const names=['transform','opacity','transition','will-change'];
 const targets=frames.map(frame=>({...frame,saved:names.map(name=>[name,frame.node.style.getPropertyValue(name),frame.node.style.getPropertyPriority(name)])}));
 // Compute each actual class endpoint once with transitions disabled. This
 // includes native landscape footer translations and safe-area CSS; no pixel
 // distance or light/dark pose is guessed by the animation.
 for(const {node}of targets)node.style.setProperty('transition','none','important');
 for(const target of targets) {
  const style=getComputedStyle(target.node),opacity=parseFloat(style.opacity);
  target.endMatrix=transformMatrix(style.transform);target.endOpacity=Number.isFinite(opacity)?opacity:1;
  if(target.matrix.length!==target.endMatrix.length){target.matrix=matrix3d(target.matrix);target.endMatrix=matrix3d(target.endMatrix)}
 }
 const control={targets,restored:false,restore(){
  if(this.restored)return;this.restored=true;
  for(const {node,saved}of targets)for(const [name,value,priority]of saved) {
   if(value)node.style.setProperty(name,value,priority);else node.style.removeProperty(name);
  }
 }};
 for(const {node}of targets)node.style.setProperty('will-change','transform, opacity','important');
 paintChromeFrames(control,0);
 return control;
}
function paintChromeFrames(control,progress) {
 if(!control||control.restored)return;
 for(const {node,matrix,endMatrix,opacity,endOpacity}of control.targets) {
  if(!node.isConnected)continue;
  const values=matrix.map((value,index)=>value+(endMatrix[index]-value)*progress);
  node.style.setProperty('transform',`${values.length===16?'matrix3d':'matrix'}(${values.join(',')})`,'important');
  node.style.setProperty('opacity',String(opacity+(endOpacity-opacity)*progress),'important');
 }
}
function motionProgress(value) {
 if(value<=0)return 0;if(value>=1)return 1;
 // Match Android and the chrome's cubic-bezier(.2,.8,.2,1) once per frame.
 const coordinate=(t,a,b)=>3*(1-t)*(1-t)*t*a+3*(1-t)*t*t*b+t*t*t;
 let low=0,high=1;
 for(let index=0;index<18;index++) {
  const t=(low+high)/2;
  if(coordinate(t,.2,.2)<value)low=t;else high=t;
 }
 return coordinate((low+high)/2,.8,1);
}
function animateComposedRows(motions,reader,state) {
 const chrome=state.chrome;
 if(!motions.length&&!chrome)return;
 const duration=240,names=['transform','transition','transform-origin','will-change'];
 const prepared=motions.map(({line,delta,transform})=>({line,delta,base:transform&&transform!=='none'?` ${transform}`:'',saved:names.map(name=>[name,line.style.getPropertyValue(name),line.style.getPropertyPriority(name)])}));
 let frame=0,finished=false;
 let startedAt=null;
 const restore=()=>{
  if(finished)return;finished=true;
  cancelAnimationFrame(frame);frame=0;
  for(const {line,saved}of prepared) {
   for(const [name,value,priority]of saved) {
    if(value)line.style.setProperty(name,value,priority);else line.style.removeProperty(name);
   }
  }
  chrome?.restore();
  if(state.chrome===chrome)state.chrome=null;
  releaseAnimation(state,animation);
 };
 const animation={cancel:restore};trackAnimation(state,animation);
 const paint=remaining=>{
  for(const {line,delta,base}of prepared) {
   if(!line.isConnected)continue;
   const scale=1+(delta.scale-1)*remaining;
   line.style.setProperty('transform',`translate3d(${delta.x*remaining}px,${delta.y*remaining}px,0) scale(${scale})${base}`,'important');
  }
  paintChromeFrames(chrome,1-remaining);
 };
 for(const {line}of prepared) {
  line.style.setProperty('transition','none','important');
  line.style.setProperty('transform-origin','50% 50%','important');
  line.style.setProperty('will-change','transform','important');
 }
 // The initial inverse remains through the first paint. Subsequent frames
 // interpolate cached coordinates only; no font fitting or geometry reads can
 // hold up WebKit's transition or restart it after an observer notification.
 paint(1);
 const tick=timestamp=>{
  frame=0;if(finished)return;
  const now=Number.isFinite(timestamp)?timestamp:performance.now();
  // WebKit may deliver this first frame after unrelated main-thread work.
  // Start from the first presented inverse pose, so that work cannot spend the
  // animation's duration before any intermediate text frame is visible.
  if(startedAt===null)startedAt=now;
  const elapsed=Math.max(0,now-startedAt);
  if(elapsed>=duration){restore();return}
  if(!prepared.some(({line})=>line.isConnected)&&!chrome?.targets.some(({node})=>node.isConnected)){restore();return}
  const remaining=1-motionProgress(elapsed/duration);
  paint(remaining);frame=requestAnimationFrame(tick);
 };
 frame=requestAnimationFrame(tick);
}
function verticalAnchor(reader) {
 const scroller=reader.querySelector?.('.munibin-quran-vertical-pages');
 if(!scroller)return null;
 const viewport=scroller.getBoundingClientRect(),top=viewport.top;
 const bottom=viewport.bottom??top+reader.clientHeight;
 const padding=parseFloat(getComputedStyle(scroller).paddingTop)||0;
 const pages=Array.from(scroller.querySelectorAll('[data-scroll-page]')).map(node=>({node,rect:node.getBoundingClientRect()}));
 const entry=pages.find(({rect})=>rect.bottom>top+padding+1);
 const visible=pages.filter(({rect})=>rect.bottom>top&&rect.top<bottom).map(({node})=>node);
 return entry?{scroller,section:entry.node,offset:entry.rect.top-top-padding,visible}:null;
}
function restoreVerticalAnchor(anchor) {
 if(!anchor?.scroller.isConnected||!anchor.section.isConnected)return;
 const {scroller,section,offset}=anchor;
 const padding=parseFloat(getComputedStyle(scroller).paddingTop)||0;
 const delta=section.getBoundingClientRect().top-scroller.getBoundingClientRect().top-padding-offset;
 // Changing the heights of preceding pages is a layout operation, not a page
 // turn. Correct it once before paint; never write scroll positions per frame.
 if(Number.isFinite(delta)&&Math.abs(delta)>.5)scroller.scrollTop+=delta;
}
export function captureQuranChromeMotion(reader) {
 const hidden=reader.classList.contains('qcf1441-preview--chrome-hidden');
 const prefs=window.__munibinQuranReading?.getPreferences?.()||{};
 const spread=document.documentElement.classList.contains('munibin-quran-mode-spread');
 const automaticFit=spread||(innerHeight>=innerWidth&&prefs.scale===1);
 const mode=automaticFit?(prefs.spacing||'automatic'):'fixed';
 const ink=`${prefs.font}|${prefs.scale}|${prefs.tajweed}|${prefs.lineSpacing}`;
 const size=`${reader.clientWidth}|${reader.clientHeight}|${innerWidth}|${innerHeight}|${spread}`;
 const previous=readers.get(reader);
 const state={hidden,mode,size,ink,pending:previous?.pending||null,anchor:previous?.anchor||null,chrome:previous?.chrome&&!previous.chrome.restored?previous.chrome:null,animations:previous?.animations||new Set()};
 readers.set(reader,state);
 if(mode!=='automatic'||previous?.size!==size||previous?.ink!==ink||window.__munibinQuranInteracting){
  for(const animation of state.animations)animation.cancel();state.animations.clear();state.chrome?.restore();state.chrome=null;state.pending=null;state.anchor=null;return;
 }
 if(!previous||previous.hidden===hidden||previous.mode!=='automatic')return;
 // Read the current animated rectangles before cancelling, so reversal starts
 // from the visible position even when the prior motion is only halfway done.
 const frames=[];const anchor=verticalAnchor(reader);
 const roots=anchor?anchor.visible:[reader];
 const lines=reduceMotion()?[]:roots.flatMap(root=>Array.from(root.querySelectorAll('.qcf1441-lines > .qcf1441-line')));
 // Page numbers belong to the same moving page as its rows. Leaving a number
 // at the new slot edge while rows still paint at their old coordinates can
 // place it over the next page during a between-page chrome transition.
 if(anchor&&!reduceMotion())for(const root of roots){
  const number=root.querySelector('.munibin-quran-scroll-page-number');
  if(number)lines.push(number);
 }
 for(const line of lines) {
  if(!visibleLine(line))continue;
  const reference=line.classList?.contains('munibin-quran-scroll-page-number')?line:line.querySelector('.qcf1441-glyph-word, .qcf1441-glyph-bismillah, .qcf1441-surah-title-panel');
  if(!reference)continue;
  const rect=reference.getBoundingClientRect(),paintBox=line.getBoundingClientRect();
  if(!(rect.height>0&&rect.width>0)||paintBox.bottom<0||paintBox.top>innerHeight)continue;
  const fontSize=(parseFloat(getComputedStyle(reference).fontSize)||0)*paintedFontScale(getComputedStyle(line));
  frames.push({line,reference,rect,fontSize});
 }
 const chromeFrames=isIOS()&&!reduceMotion()?captureChromeFrames(reader):[];
 for(const animation of state.animations)animation.cancel();
 state.chrome?.restore();
 state.chrome=prepareChromeFrames(chromeFrames);
 state.animations.clear();state.pending=frames;state.anchor=anchor;
}
export function finishQuranChromeMotion(reader) {
 const state=readers.get(reader),frames=state?.pending;
 if(!frames)return;
 state.pending=null;restoreVerticalAnchor(state.anchor);state.anchor=null;
 if(reduceMotion()){state.chrome?.restore();state.chrome=null;return}
 const motions=[];
 // Batch final measurements before any animation writes. The same helper is
 // used by native portrait fitting and the imperative two-page book fitter.
 for(const {line,reference,rect,fontSize}of frames) {
  if(!line.isConnected||!reference.isConnected||!visibleLine(line))continue;
  const next=reference.getBoundingClientRect(),box=line.getBoundingClientRect();
  if(!(next.height>0&&box.width>0&&box.height>0))continue;
  const lineStyle=getComputedStyle(line),transform=lineStyle.transform||'none';
  const origin=translatedOrigin(box,transform);
  const nextFontSize=(parseFloat(getComputedStyle(reference).fontSize)||0)*paintedFontScale(lineStyle);
  const panel=reference.classList?.contains('qcf1441-surah-title-panel');
  const fontScale=!panel&&fontSize>0&&nextFontSize>0?fontSize/nextFontSize:undefined;
  const delta=chromeMotionDelta(rect,next,origin,fontScale);
  if(![delta.x,delta.y,delta.scale].every(Number.isFinite))continue;
  if(Math.abs(delta.x)+Math.abs(delta.y)<.3&&Math.abs(delta.scale-1)<.002)continue;
  motions.push({line,delta,transform});
 }
 const independent=typeof CSS!=='undefined'&&CSS.supports('translate','1px')&&CSS.supports('scale','1');
 if(isIOS()||!independent) {
  animateComposedRows(motions,reader,state);return;
 }
 for(const {line,delta}of motions) {
  if(typeof line.animate!=='function')continue;
  const keyframes=[
   {translate:`${delta.x}px ${delta.y}px`,scale:String(delta.scale)},
   {translate:'0px 0px',scale:'1'}
  ];
  const animation=line.animate(keyframes,{duration:240,easing:'cubic-bezier(.2,.8,.2,1)',fill:'none'});
  trackAnimation(state,animation);
  const clear=()=>releaseAnimation(state,animation);
  animation.addEventListener('finish',clear,{once:true});
  animation.addEventListener('cancel',clear,{once:true});
 }
}
