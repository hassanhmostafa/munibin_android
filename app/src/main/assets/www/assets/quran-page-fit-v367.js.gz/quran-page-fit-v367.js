/* Measure the selected offline face. Keep native word/verse buttons intact,
   with bounded gaps, a fitted 100% page and larger scrollable zoomed text. */
import {QCF_READING_METRICS} from './quran-reading-metrics-v361.js';
const fittedPages=new WeakMap();
const preparedSizes=new Map();
const preparedLayouts=new Map();
const inkMetrics=new Map();
// Neighbor fonts loading in the background must not invalidate a visible page.
// Measurements are recorded only for loaded faces, and keyed by face + text.
const context=()=>document.createElement('canvas').getContext('2d');
let canvas;
const write=(node,name,value)=>{
 if(node.style.getPropertyValue(name)!==value)node.style.setProperty(name,value);
};
const containerProperties=['--munibin-reading-base-size','--munibin-reading-leading','--munibin-reading-row-space'];
const wordProperties=['--munibin-reading-ink-shift','--munibin-row-gap-extra','--munibin-reading-word-cap','--munibin-reading-glyph-leading'];
const saveProperties=(node,names)=>names.map(name=>node.style.getPropertyValue(name));
function restoreProperties(node,names,values) {
 for(let index=0;index<names.length;index++) {
  if(values[index])write(node,names[index],values[index]);
  else if(node.style.getPropertyValue(names[index]))node.style.removeProperty(names[index]);
 }
}
function saveLayout(container,lines) {
 return {container:saveProperties(container,containerProperties),classes:['munibin-reading-fitted-page','munibin-reading-opening-page','munibin-reading-manual-page'].map(name=>container.classList.contains(name)),
  lines:lines.map(line=>line.style.getPropertyValue('margin-top')),
  words:Array.from(container.querySelectorAll('.qcf1441-glyph'),word=>saveProperties(word,wordProperties))};
}
function restoreLayout(container,lines,layout) {
 const words=Array.from(container.querySelectorAll('.qcf1441-glyph'));
 if(words.length!==layout.words.length||lines.length!==layout.lines.length)return false;
 restoreProperties(container,containerProperties,layout.container);
 ['munibin-reading-fitted-page','munibin-reading-opening-page','munibin-reading-manual-page'].forEach((name,index)=>container.classList.toggle(name,layout.classes[index]));
 lines.forEach((line,index)=>restoreProperties(line,['margin-top'],[layout.lines[index]]));
 words.forEach((word,index)=>restoreProperties(word,wordProperties,layout.words[index]));
 return true;
}

export function manualReadingRowGap(gap,size,scale,leading,percent) {
 const factor=Math.max(1,Math.min(2,(Number(percent)||100)/100));
 return gap*factor+size*scale*leading*(factor-1);
}
export function boundedReadingGap(available,width,count,size) {
 return count>1?Math.max(0,Math.min(size*.20,(available-width-.75)/(count-1))):0;
}
export function readingRowGroups(items) {
 const rows=[];
 for(const item of items) {
  const row=rows.at(-1);
  const center=item.top+(item.height||0)/2;
  if(!row||Math.abs(row.center-center)>1)rows.push({top:item.top,center,items:[item]});
  else row.items.push(item);
 }
 return rows;
}
export function largestFittingReadingSize(measure,available,minimum=4,maximum=56) {
 // A monotone native wrap measurement includes headings, all ayat and marks.
 // The small reserve absorbs fractional pixels on both mobile WebViews.
 let low=minimum,high=maximum;
 if(measure(low)>available)return low;
 for(let n=0;n<12;n++) {
  const mid=(low+high)/2;
  if(measure(mid)<=available-.75)low=mid;else high=mid;
 }
 return Math.floor(low*100)/100;
}
function wordsOf(line) {
 return Array.from(line.children).filter(node=>node.matches('.qcf1441-glyph')&&getComputedStyle(node).display!=='none');
}
function naturalHeight(container,lines) {
 const style=getComputedStyle(container);
 return (parseFloat(style.paddingTop)||0)+(parseFloat(style.paddingBottom)||0)+lines.reduce((height,line)=>{
  const s=getComputedStyle(line);
  return height+line.getBoundingClientRect().height+(parseFloat(s.marginTop)||0)+(parseFloat(s.marginBottom)||0);
 },0);
}
function baselineFallback(style) {
 // Older WebViews omit fontBoundingBoxAscent/Descent. A zero-height inline
 // marker measures the native CSS baseline in a fixed 100px line box.
 const probe=document.createElement('span'),marker=document.createElement('span');
 Object.assign(probe.style,{position:'fixed',left:'0px',top:'-10000px',visibility:'hidden',display:'inline-block',whiteSpace:'nowrap',fontFamily:style.fontFamily,fontWeight:style.fontWeight,fontSize:'100px',lineHeight:'100px',padding:'0',margin:'0',border:'0'});
 Object.assign(marker.style,{display:'inline-block',width:'0',height:'0',padding:'0',margin:'0',verticalAlign:'baseline'});
 probe.append(document.createTextNode('بِسْمِ اللَّهِ'),marker);document.body.append(probe);
 const ascent=marker.getBoundingClientRect().top-probe.getBoundingClientRect().top;
 probe.remove();return {ascent,descent:100-ascent};
}
function fontProfiles(container,unicode) {
 canvas ||= context();
 const profiles=new Map();
 if(!canvas)return {leading:1.9,profiles};
 for(const word of container.querySelectorAll('.qcf1441-glyph')) {
  const style=getComputedStyle(word),text=word.textContent;
  if(!text)continue;
  const family=`${style.fontWeight} ${style.fontFamily}`,key=`${family}|${text}`;
  let ink=inkMetrics.get(key);
  if(!ink) {
   canvas.font=`${style.fontWeight} 100px ${style.fontFamily}`;canvas.direction='rtl';
   ink=canvas.measureText(text);if(inkMetrics.size>5000)inkMetrics.clear();inkMetrics.set(key,ink);
  }
  let profile=profiles.get(family);
  if(!profile) {
   const fallback=Number.isFinite(ink.fontBoundingBoxAscent)&&Number.isFinite(ink.fontBoundingBoxDescent)?null:baselineFallback(style);
   profile={ascent:0,descent:0,fontAscent:fallback?.ascent??ink.fontBoundingBoxAscent,fontDescent:fallback?.descent??ink.fontBoundingBoxDescent,factor:0};
  }
  profile.ascent=Math.max(profile.ascent,ink.actualBoundingBoxAscent||0);
  profile.descent=Math.max(profile.descent,ink.actualBoundingBoxDescent||0);
  const factor=word.dataset.wordType==='end'&&unicode?0:1;
  if(word.closest('.qcf1441-line-ayah')||word.classList.contains('qcf1441-glyph-bismillah'))profile.factor=Math.max(profile.factor,factor);
  profiles.set(family,profile);
 }
 // The CSS marker box reserves the same advance in both QCF variants. Keep
 // its line height stable too, so a Unicode color toggle cannot change wraps.
 let leading=unicode?1.95:1.4;
 for(const profile of profiles.values())if(profile.factor)leading=Math.max(leading,(profile.ascent+profile.descent)/100*profile.factor+.18);
 for(const word of container.querySelectorAll('.qcf1441-glyph-surah_header, .qcf1441-glyph-bismillah')) {
  const style=getComputedStyle(word),profile=profiles.get(`${style.fontWeight} ${style.fontFamily}`);
  if(profile)write(word,'--munibin-reading-glyph-leading',String((profile.ascent+profile.descent)/100+.18));
 }
 return {leading,profiles};
}
function centerReadingInk(container,profiles) {
 for(const word of container.querySelectorAll('.qcf1441-glyph')) {
  const style=getComputedStyle(word),profile=profiles.get(`${style.fontWeight} ${style.fontFamily}`);
  if(!profile||!Number.isFinite(profile.fontAscent)||!Number.isFinite(profile.fontDescent))continue;
  // One common shift per face preserves Arabic baselines. It centers real ink,
  // instead of letting a face's unused ascender space push it below the footer.
  const shift=(profile.ascent-profile.descent-profile.fontAscent+profile.fontDescent)/200*parseFloat(style.fontSize);
  write(word,'--munibin-reading-ink-shift',`${shift.toFixed(3)}px`);
 }
}
function pageInkEdges(container,profiles) {
 let top=Infinity,bottom=-Infinity;
 for(const word of container.querySelectorAll('.qcf1441-glyph')) {
  const title=word.closest('.qcf1441-surah-title-panel');
  if(title){const r=title.getBoundingClientRect();top=Math.min(top,r.top);bottom=Math.max(bottom,r.bottom);continue}
  const style=getComputedStyle(word),profile=profiles.get(`${style.fontWeight} ${style.fontFamily}`);
  if(!profile)continue;
  const rect=word.getBoundingClientRect(),inkHeight=(profile.ascent+profile.descent)/100*parseFloat(style.fontSize);
  const center=rect.top+rect.height/2;
  top=Math.min(top,center-inkHeight/2);bottom=Math.max(bottom,center+inkHeight/2);
 }
 return {top,bottom};
}
function capWideWords(container) {
 canvas ||= context();
 if(!canvas)return;
 for(const line of container.querySelectorAll(':scope > .qcf1441-line')) {
  const words=line.classList.contains('qcf1441-line-surah_header')?[]:wordsOf(line);
  for(const word of words) {
   const available=(word.closest('.qcf1441-surah-title-window')?.clientWidth||line.clientWidth)-6;
   if(!(available>0))continue;
   const style=getComputedStyle(word),key=`${style.fontWeight} ${style.fontFamily}|${word.textContent}`;
   let ink=inkMetrics.get(key);
   if(!ink) {
    canvas.font=`${style.fontWeight} 100px ${style.fontFamily}`;canvas.direction='rtl';
    ink=canvas.measureText(word.textContent);inkMetrics.set(key,ink);
   }
   // Fixed caps depend on the face's natural advance, not a DOM readback after
   // every candidate size. Batch these once before searching the native wraps.
   const cap=available/Math.max(.01,ink.width/100);
   write(word,'--munibin-reading-word-cap',`${cap.toFixed(3)}px`);
  }
 }
}
export function spaceMushafRows(container) {
 let rowCount=0;
 for(const line of container.querySelectorAll(':scope > .qcf1441-line-ayah')) {
  const words=wordsOf(line);
  // Center every naturally wrapped row, including a short surah ending. CSS
  // supplies the same .16em gap at every zoom; no surplus becomes word space.
  words.forEach(word=>word.style.removeProperty('--munibin-row-gap-extra'));
  const rows=readingRowGroups(words.map(word=>{const r=word.getBoundingClientRect();return {word,top:r.top,height:r.height,width:r.width}}));
  rowCount+=rows.length;
 }
 return rowCount;
}

// QCF is the only Quran face. Its immutable font-table geometry can be used
// before a new page paints, even while a native fling is still in progress.
// No canvas/font decode, per-word computed-style reads or row DOMRects occur
// here. Idle fits use the identical path; they cannot correct a revealed page
// to another font size or spacing later.
function fitQcfReadingLayout(container,reader,readerStyle,scale,available,prefs,colored) {
 // Retained 100% pages can carry an imperative width-fit class through a
 // React reflow update. Remove it before any cache shortcut or page reveal.
 if(container.classList.contains('munibin-qcf1441-width-fit'))container.classList.remove('munibin-qcf1441-width-fit');
 if(container.style.getPropertyValue('--munibin-qcf1441-fit-font-size'))container.style.removeProperty('--munibin-qcf1441-fit-font-size');
 if(container.style.getPropertyValue('--munibin-qcf-row-height'))container.style.removeProperty('--munibin-qcf-row-height');
 if(container.style.getPropertyValue('--munibin-qcf-native-gap'))container.style.removeProperty('--munibin-qcf-native-gap');
 const page=Number(container.dataset.readingPage),entry=QCF_READING_METRICS[page]?.[colored?1:0];
 if(page<=2){prefs={...prefs,spacing:'fixed',lineSpacing:100};for(const row of container.querySelectorAll(':scope > .qcf1441-line'))row.style.removeProperty('--munibin-qcf-line-shift');}
 if(!entry)return false;
 const words=Array.from(container.querySelectorAll('.qcf1441-glyph'));
 if(words.length!==entry[2].length)return false;
 const base=(page<=2?window.__munibinQcf1441OpeningBaseSize?.(container):undefined)||parseFloat(readerStyle.getPropertyValue('--munibin-spread-base-size'))||(innerWidth>innerHeight?34:Math.min(35.5,Math.max(22.5,innerWidth*.063)));
 const signature=`${page}|${container.clientWidth}|${available}|${base}|${colored}|${prefs.spacing||'automatic'}|${prefs.lineSpacing||100}`;
 if(fittedPages.get(container)?.layoutSignature===signature)return true;
 const [leading,profiles,widths]=entry;
 write(container,'--munibin-reading-base-size',`${base}px`);
 write(container,'--munibin-reading-leading',String(leading));
 const manual=prefs.spacing==='manual';
 const spacingFactor=Math.max(1,Math.min(2,(Number(prefs.lineSpacing)||100)/100));
 write(container,'--munibin-reading-row-space',manual?`calc(var(--munibin-reading-font-size) * ${leading*(spacingFactor-1)})`:'0px');
 container.classList.toggle('munibin-reading-fitted-page',false);
 container.classList.toggle('munibin-reading-opening-page',page<=2);
 container.classList.toggle('munibin-reading-manual-page',manual);
 const lineWidths=new Map();
 for(let index=0;index<words.length;index++) {
  const word=words[index],line=word.closest('.qcf1441-line');
  if(!line)return false;
  if(word.style.getPropertyValue('--munibin-row-gap-extra'))word.style.removeProperty('--munibin-row-gap-extra');
  if(line.classList.contains('qcf1441-line-surah_header'))continue;
  if(!lineWidths.has(line))lineWidths.set(line,Math.max(1,line.clientWidth-6));
  const cap=lineWidths.get(line)/Math.max(.01,widths[index]);
  write(word,'--munibin-reading-word-cap',`${cap.toFixed(3)}px`);
  const family=(word.style.fontFamily||'').replace(/["']/g,'').trim();
  const profile=profiles[family];
  if(!profile)continue;
  const bismillah=word.classList.contains('qcf1441-glyph-bismillah');
  const [ascent,descent,fontAscent,fontDescent]=profile;
  const shift=(ascent-descent-fontAscent+fontDescent)/2;
  // Caps and font metrics are immutable during a pinch. CSS scales each word's
  // ink baseline with its actual capped size, without new per-word DOM writes.
  write(word,'--munibin-reading-ink-shift',`calc(min(var(--munibin-reading-font-size), var(--munibin-reading-word-cap, 1000px)${bismillah?', 38px':''}) * ${shift.toFixed(6)})`);
  if(word.classList.contains('qcf1441-glyph-bismillah'))write(word,'--munibin-reading-glyph-leading',String(ascent+descent+.18));
 }
 const first=container.querySelector(':scope > .qcf1441-line');
 if(first?.style.getPropertyValue('margin-top'))first.style.removeProperty('margin-top');
 fittedPages.set(container,{layoutSignature:signature,size:base,colored});
 return true;
}

export function primeQuranReadingPage(root) {
 if(!root?.querySelectorAll)return false;
 const containers=Array.from(root.querySelectorAll('.munibin-reader-reflow .qcf1441-lines'));
 if(root.matches?.('.qcf1441-lines')&&root.closest('.munibin-reader-reflow'))containers.unshift(root);
 if(!containers.length)return false;
 const prefs=window.__munibinQuranReading?.getPreferences?.()||{};
 for(const container of containers) {
  const reader=container.closest('.munibin-quran-leaf')||container.closest('.qcf1441-preview');
  if(!reader||!(container.clientWidth>0))return false;
  const style=getComputedStyle(reader),scale=parseFloat(style.getPropertyValue('--munibin-reading-scale'))||1;
  const budget=container.closest('.munibin-quran-opening-slot');
  const available=parseFloat((budget?getComputedStyle(budget):style).getPropertyValue('--munibin-reader-content-height'))||reader.clientHeight;
  const colored=container.dataset.readingTajweed==null?prefs.tajweed===true:container.dataset.readingTajweed==='true';
  if(!fitQcfReadingLayout(container,reader,style,scale,available,prefs,colored))return false;
 }
 return window.__munibinFitQcf1441Titles?.(root)!==false;
}

export function fitReadingPageLayout(root=document) {
 if(window.__munibinQuranPortraitFitLocked===true||window.__munibinQuranInteracting)return;
 for(const container of root.querySelectorAll('.munibin-reader-reflow .qcf1441-lines')) {
  if(root===document) {
   if(container.closest('.munibin-quran-font-preview'))continue;
   const pane=container.closest('.munibin-quran-horizontal-page');if(pane&&!pane.classList.contains('is-active'))continue;
  }
  const reader=container.closest('.munibin-quran-font-preview')||container.closest('.munibin-quran-leaf')||container.closest('.qcf1441-preview');
  if(!reader)continue;
  const unicode=reader.classList.contains('munibin-reader-text-font');
  const page=Number(container.dataset.readingPage),opening=page<=2;
  const readerStyle=getComputedStyle(reader);
  const scale=parseFloat(readerStyle.getPropertyValue('--munibin-reading-scale'))||1;
  const budget=container.closest('.munibin-quran-opening-slot');
  const available=parseFloat((budget?getComputedStyle(budget):readerStyle).getPropertyValue('--munibin-reader-content-height'))||reader.clientHeight;
  const lines=Array.from(container.querySelectorAll(':scope > .qcf1441-line'));
  if(!lines.length||!(available>0)||!(container.clientWidth>0))continue;
  const stored=window.__munibinQuranReading?.getPreferences?.()||{},prefs=opening?{...stored,spacing:'fixed',lineSpacing:100}:stored;
  const colored=container.dataset.readingTajweed==null?prefs.tajweed===true:container.dataset.readingTajweed==='true';
  const fontId=container.dataset.readingFont||prefs.font||'qcf1441';
  if(!unicode&&fontId==='qcf1441'&&fitQcfReadingLayout(container,reader,readerStyle,scale,available,prefs,colored))continue;
  const signature=`${page}|${container.clientWidth}|${available}|${fontId}|${readerStyle.getPropertyValue('--munibin-spread-base-size')}`;
  let cached=fittedPages.get(container);
  const layoutSignature=`${signature}|${scale}|${colored}|${prefs.spacing||"automatic"}|${prefs.lineSpacing||100}`;
  if(cached?.layoutSignature===layoutSignature)continue;
  const prepared=preparedLayouts.get(layoutSignature);
  if(prepared&&restoreLayout(container,lines,prepared)) {
   fittedPages.set(container,{signature,layoutSignature,size:parseFloat(prepared.container[0])||4,colored});
   continue;
  }
  container.classList.remove('munibin-reading-manual-page');
  // Before measuring, remove last layout's added margins and vertical spacing.
  container.querySelectorAll('.qcf1441-glyph').forEach(word=>word.style.removeProperty('--munibin-row-gap-extra'));
  write(container,'--munibin-reading-row-space','0px');
  lines[0].style.removeProperty('margin-top');
  if(!cached||cached.signature!==signature||!cached.profiles||cached.colored!==colored) {
   const inherited=container.style.getPropertyValue('--munibin-reading-scale');
   write(container,'--munibin-reading-scale','1');
   const font=fontProfiles(container,unicode);
   write(container,'--munibin-reading-leading',String(font.leading));
   capWideWords(container);
   let size=preparedSizes.get(signature);
   if(unicode) {
    if(!size)size=largestFittingReadingSize(value=>{
     write(container,'--munibin-reading-base-size',`${value}px`);
     return naturalHeight(container,lines);
    },available,reader.classList.contains('munibin-quran-leaf')?1:4,opening?34:56);
   } else {
    // Retain the existing zoom baseline; the standard 1441 page is independent.
    size=parseFloat(readerStyle.getPropertyValue('--munibin-spread-base-size'))||(innerWidth>innerHeight?34:Math.min(35.5,Math.max(22.5,innerWidth*.063)));
   }
   write(container,'--munibin-reading-base-size',`${size}px`);
   if(inherited)write(container,'--munibin-reading-scale',inherited);
   else container.style.removeProperty('--munibin-reading-scale');
   if(preparedSizes.size>240)preparedSizes.delete(preparedSizes.keys().next().value);
   preparedSizes.set(signature,size);
   cached={signature,size,profiles:font.profiles,colored};fittedPages.set(container,cached);
  }
  write(container,'--munibin-reading-base-size',`${cached.size}px`);
  const fitted=unicode&&scale===1;
  container.classList.toggle('munibin-reading-fitted-page',fitted);
  container.classList.toggle('munibin-reading-opening-page',opening);
  capWideWords(container);
  centerReadingInk(container,cached.profiles);
  const rows=spaceMushafRows(container);
  if(fitted&&!opening&&rows>1) {
   // Distribute only the remaining height after the font/line count fit. This
   // brings the last row to the footer's upper edge without covering its ink.
   let natural=naturalHeight(container,lines),edgeReserve=0;
   if(innerHeight>=innerWidth||reader.classList.contains('munibin-quran-leaf')) {
    const ink=pageInkEdges(container,cached.profiles),origin=container.getBoundingClientRect();
    if(Number.isFinite(ink.top)&&Number.isFinite(ink.bottom)) {
     const topSpace=Math.max(0,ink.top-origin.top-2);
     edgeReserve=Math.max(0,natural-(ink.bottom-origin.top));
     const margin=parseFloat(getComputedStyle(lines[0]).marginTop)||0;
     write(lines[0],'margin-top',`${(margin-topSpace).toFixed(3)}px`);
     natural-=topSpace;
    }
   }
   const surplus=Math.max(0,available-natural+edgeReserve-2);
   const gaps=Math.max(1,rows-lines.filter(line=>line.classList.contains('qcf1441-line-ayah')).length+lines.length-1);
   write(container,'--munibin-reading-row-space',`${(surplus/gaps).toFixed(3)}px`);
  }
  if(prefs.spacing==='manual') {
   const leading=parseFloat(container.style.getPropertyValue('--munibin-reading-leading'))||1.9;
   const gap=parseFloat(container.style.getPropertyValue('--munibin-reading-row-space'))||0;
   write(container,'--munibin-reading-row-space',`${manualReadingRowGap(gap,cached.size,scale,leading,prefs.lineSpacing)}px`);
   container.classList.add('munibin-reading-manual-page');
   container.classList.remove('munibin-reading-fitted-page');
  }
  cached.layoutSignature=layoutSignature;
  if(preparedLayouts.size>240)preparedLayouts.delete(preparedLayouts.keys().next().value);
  preparedLayouts.set(layoutSignature,saveLayout(container,lines));
 }
}
