/* Full-document scroll geometry for the one bundled Quran face. This does not
 * load fonts or measure DOM. The vertical reader gives every page a permanent
 * slot while only nearby pages own interactive glyph trees.
 *
 * At 100% use the native grid's exact font/row dimensions. Zoomed pages keep
 * the existing reflow calculations below.
 * Contract with the zoomed vertical CSS: the lines container is a flex column;
 * its headings are centered flex rows (no inline-font strut); surah heading
 * padding is 4.5px on each edge. Existing line margins are preserved, including
 * the stronger rule which replaces every non-first line's top margin with the
 * manual row gap. Horizontal and two-page typography is not affected.
 *
 * Normalized advances are rounded in the existing metrics table. A half-pixel
 * wrap reserve and final upward rounding protect the fixed slots at fractional
 * widths. Live page measurements may improve this estimate, but must not change
 * preceding slot heights during native pan/inertia.
 */
import { QCF_READING_METRICS } from './quran-reading-metrics-v361.js';
import {nativeDocumentPageLayout} from './quran-document-native-v387.js';

const finite = (value, fallback) => Number.isFinite(Number(value)) ? Number(value) : fallback;
const clamp = (value, minimum, maximum) => Math.max(minimum, Math.min(maximum, value));
const WRAP_RESERVE = .5;
const CONTENT_PADDING = 14; // Reflow lines: 6px above + 8px below.
const PAGE_NUMBER_HEIGHT = 36; // 28px border-box + 8px top margin.
const PAGE_BORDER = 1;
const PAGE_GAP = 18;

// Exact title ascent + descent + .08em clearance from qcf-width-fit-v381's
// TITLE_METRICS. Keys are page:number-of-original-glyph, before zoom grouping.
// Landscape title fitting grows the actual frame to fit each name, rather than
// always leaving it at the 46px fallback in CSS. Reuse the same factors without
// activating all 604 fonts or depending on an imperative fit having run first.
export const QCF_DOCUMENT_TITLE_INK_HEIGHTS = Object.freeze({
  '1:0':1.164,'2:0':1.1952,'50:0':1.408,'77:0':1.2672,'106:51':1.1756,'128:0':1.3512,'151:0':1.3056,'177:0':1.3652,'187:0':1.2156,'208:0':1.1816,'221:60':1.2464,'235:76':1.1756,'249:0':1.25,'255:16':1.2812,'262:0':1.2168,'267:54':1.34,'282:0':1.316,'293:100':1.2484,'305:0':1.236,'312:36':1.2228,'322:0':1.3972,'332:0':1.246,'342:0':1.2264,'350:0':1.2468,'359:91':1.1952,'367:0':1.2288,'377:0':1.2328,'385:72':1.2548,'396:73':1.178,'404:84':1.2712,'411:0':1.3476,'415:0':1.1876,'418:0':1.4084,'428:0':1.2672,'434:74':1.2304,'440:26':1.1756,'446:0':1.1924,'453:0':1.2248,'458:35':1.2124,'467:18':1.1884,'477:0':1.2588,'483:0':1.1988,'489:44':1.2416,'496:0':1.238,'499:0':1.1944,'502:62':1.2684,'507:0':1.2548,'511:0':1.3876,'515:55':1.234,'518:0':1.1756,'520:110':1.302,'523:76':1.2088,'526:0':1.2072,'528:90':1.1756,'531:38':1.1912,'534:50':1.2088,'537:105':1.216,'542:0':1.2924,'545:52':1.1892,'549:0':1.2116,'551:59':1.1992,'553:0':1.1756,'554:60':1.2824,'556:0':1.2864,'558:0':1.26,'560:0':1.2304,'562:0':1.322,'564:55':1.3388,'566:91':1.1972,'568:91':1.2048,'570:38':1.2064,'572:0':1.3212,'574:0':1.3316,'575:80':1.1756,'577:55':1.2264,'578:105':1.3,'580:60':1.2872,'582:0':1.332,'583:78':1.202,'585:0':1.1756,'586:8':1.3432,'587:0':1.258,'587:101':1.2004,'589:18':1.1804,'590:10':1.2392,'591:0':1.2084,'591:80':1.3308,'592:44':1.1836,'593:19':1.1916,'594:43':1.2904,'595:11':1.1968,'595:82':1.4564,'596:56':1.2396,'596:109':1.1868,'597:26':1.2516,'597:70':1.3212,'598:35':1.2216,'598:72':1.3176,'599:49':1.3756,'599:95':1.1892,'600:35':1.2148,'600:84':1.1756,'601:0':1.178,'601:19':1.1952,'601:63':1.1804,'602:0':1.2072,'602:23':1.2372,'602:57':1.2436,'603:0':1.2832,'603:34':1.2292,'603:58':1.2068,'604:0':1.3856,'604:21':1.3668,'604:51':1.1756,
});

// Keep this grouping identical to readingLines: zoomed normal ayah rows merge,
// but standalone headings and the original first two page rows remain intact.
function groupsOf(page, scale, widths) {
  const groups = [];
  let index = 0;
  for (const line of page.lines || []) {
    const words = (line.words || []).map(word => ({ word, index, advance: widths[index++] }));
    if (!words.length) continue;
    const title = words.some(entry => entry.word.type === 'surah_header');
    const basmala = !title && words.some(entry => entry.word.type === 'bismillah');
    const heading = title || basmala;
    const previous = groups.at(-1);
    if (scale !== 1 && Number(page.page) > 2 && !heading && previous && !previous.heading) {
      previous.words.push(...words);
    } else {
      groups.push({ words, heading, title, basmala });
    }
  }
  return groups;
}

function profileFor(word, profiles, number) {
  return profiles[word.font] || profiles[`QuranTajweed${number}`] || Object.values(profiles)[0];
}

function advanceOf(entry) {
  // All 604 shipped pages have a normalized advance for every glyph, including
  // end-of-ayah and rub' markers. An unexpected absent entry gets its own row
  // instead of an underestimated width. Font additions need new metrics.
  return Math.max(.01, finite(entry.advance, 1000));
}

function wordSize(entry, bodySize, available) {
  const cap = Math.max(1, available - 6) / advanceOf(entry);
  return Math.min(bodySize, cap, entry.word.type === 'bismillah' ? 38 : Infinity);
}

function ayahRows(words, bodySize, leading, available, rowGap) {
  const columnGap = bodySize * .16;
  const rows = [];
  let width = 0, height = 0, count = 0;
  const finish = () => {
    if (count) rows.push({ height, width, count });
    width = 0; height = 0; count = 0;
  };
  for (const entry of words) {
    const size = wordSize(entry, bodySize, available);
    const advance = advanceOf(entry) * size;
    if (count && width + columnGap + advance > available - WRAP_RESERVE) finish();
    width += (count ? columnGap : 0) + advance;
    height = Math.max(height, size * leading);
    count++;
  }
  finish();
  return {
    rows,
    height: rows.reduce((sum, row) => sum + row.height, 0) + rowGap * Math.max(0, rows.length - 1),
  };
}

/** Return the fixed article and document-slot geometry for a real page object.
 * viewport.width is the vertical reader's CSS width, not physical screen pixels.
 * No DOM, font loading, network access, timers, or caller-data writes occur here.
 */
export function documentPageLayout(page, prefs = {}, viewport = {}) {
  const number = Number(page?.page);
  if (!page || !Array.isArray(page.lines) || !Number.isInteger(number) || number < 1 || number > 604) {
    throw new TypeError('A Quran page from 1 through 604 is required.');
  }
  const entry = QCF_READING_METRICS[number]?.[prefs.tajweed === true ? 1 : 0];
  if (!entry) throw new TypeError(`Quran page ${number} has no bundled geometry.`);
  const [leading, profiles, widths] = entry;
  if(number<=2){prefs={...prefs,spacing:'fixed',lineSpacing:100};viewport={...viewport,contentHeight:Number(viewport.openingContentHeight)||viewport.contentHeight};}
  const width = Math.max(1, finite(viewport.width, 390));
  const height = Math.max(1, finite(viewport.height, 844));
  const portrait = typeof viewport.landscape === 'boolean' ? !viewport.landscape : height >= width;
  const rootFontSize = Math.max(1, finite(viewport.rootFontSize, 16));
  const padding = Math.max(0, finite(viewport.inlinePadding, 9));
  const available = Math.max(1, width - padding * 2);
  const scale = clamp(finite(prefs.scale, 1), 1, 2.4);
  if(scale===1)return nativeDocumentPageLayout(page,prefs,viewport);
  const defaultBase = portrait ? Math.min(35.5, Math.max(22.5, width * .063)) : 34;
  const baseSize = number<=2?nativeDocumentPageLayout(page,prefs,viewport).baseSize:Math.max(1, finite(viewport.fontBase, defaultBase));
  const bodySize = baseSize * scale;
  const manual = prefs.spacing === 'manual';
  const spacingFactor = manual ? clamp(finite(prefs.lineSpacing, 100) / 100, 1, 2) : 1;
  const rowGap = bodySize * leading * (spacingFactor - 1);
  let titleFrameHeight = (portrait
    ? clamp(width * .073, rootFontSize * 1.74, rootFontSize * 2.3) * 1.08
    : 46) * scale;
  const groups = groupsOf(page, scale, widths);
  const lines = [];
  let naturalContentHeight = CONTENT_PADDING;
  for (let index = 0; index < groups.length; index++) {
    const group = groups[index];
    const marginTop = index ? rowGap : group.heading ? bodySize * .12 : 0;
    const marginBottom = group.title ? bodySize * .22 : group.basmala ? bodySize * .18 : 0;
    let groupHeight, rows, frameHeight;
    if (group.title) {
      frameHeight = portrait ? titleFrameHeight : Math.max(46 * scale, ...group.words
        .filter(entry => entry.word.type === 'surah_header')
        .map(entry => {
          const profile = profileFor(entry.word, profiles, number);
          const factor = QCF_DOCUMENT_TITLE_INK_HEIGHTS[`${number}:${entry.index}`]
            ?? (profile ? profile[0] + profile[1] + .08 : leading);
          // fitTitles writes the 3-decimal CSS variable before live zoom.
          return Number(Math.max(46, baseSize * factor + 10).toFixed(3)) * scale;
        }));
      titleFrameHeight = Math.max(titleFrameHeight, frameHeight);
      groupHeight = frameHeight + 9;
      rows = [{ height: groupHeight, count: group.words.length }];
    } else if (group.basmala) {
      groupHeight = Math.max(0, ...group.words.map(word => {
        const profile = profileFor(word.word, profiles, number);
        const glyphLeading = profile ? profile[0] + profile[1] + .18 : leading;
        return wordSize(word, bodySize, available) * glyphLeading;
      }));
      rows = [{ height: groupHeight, count: group.words.length }];
    } else {
      const flow = ayahRows(group.words, bodySize, leading, available, rowGap);
      groupHeight = flow.height; rows = flow.rows;
    }
    naturalContentHeight += marginTop + groupHeight + marginBottom;
    lines.push({ type: group.title ? 'surah_header' : group.basmala ? 'bismillah' : 'ayah',
      height: groupHeight, frameHeight, marginTop, marginBottom, rows });
  }
  // Opening pages retain the existing centered min-height, at every zoom.
  const minimum = number <= 2 ? Math.max(0, finite(viewport.contentHeight, height)) : 0;
  const contentHeight = Math.max(naturalContentHeight, minimum);
  const articleHeight = Math.ceil((contentHeight + PAGE_NUMBER_HEIGHT + PAGE_BORDER + WRAP_RESERVE) * 2) / 2;
  const gap = number === 604 ? 0 : PAGE_GAP;
  return { page: number, height: articleHeight + gap, articleHeight, gap,
    contentHeight, naturalContentHeight, baseSize, bodySize, leading, rowGap,
    titleFrameHeight, availableWidth: available, lines,
    layoutMode:'reflow',rows: lines.reduce((total, line) => total + line.rows.length, 0) };
}

/** Full slot extent, including its inter-page gap (except after page 604). */
export function pageHeight(page, prefs = {}, viewport = {}) {
  return documentPageLayout(page, prefs, viewport).height;
}
