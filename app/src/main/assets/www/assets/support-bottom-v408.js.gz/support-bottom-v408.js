// Keep a newly opened support conversation at its end as attachments gain size.
// Upward user navigation pauses following until the reader returns to the end.
export function createSupportBottomAnchor(element) {
  const view = element.ownerDocument?.defaultView || globalThis;
  const requestFrame = view.requestAnimationFrame
    ? callback => view.requestAnimationFrame(callback)
    : callback => view.setTimeout(callback, 16);
  const cancelFrame = view.cancelAnimationFrame
    ? id => view.cancelAnimationFrame(id)
    : id => view.clearTimeout(id);
  const previousAnchor = element.style.overflowAnchor;
  const previousBehavior = element.style.scrollBehavior;
  element.style.overflowAnchor = "none";
  element.style.scrollBehavior = "auto";
  let disposed = false;
  let following = true;
  let frame = null;
  let lastTop = element.scrollTop;
  let touchY = null;
  const observed = new Set();
  const maximum = () => Math.max(0, element.scrollHeight - element.clientHeight);
  const atEnd = () => maximum() - element.scrollTop <= 2;

  const bottom = () => {
    if (disposed || !following) return;
    element.scrollTop = maximum();
    lastTop = element.scrollTop;
  };
  const schedule = () => {
    if (disposed || !following || frame !== null) return;
    frame = requestFrame(() => {
      frame = null;
      bottom();
    });
  };
  const pause = () => {
    following = false;
    if (frame !== null) cancelFrame(frame);
    frame = null;
  };
  const onScroll = () => {
    const top = element.scrollTop;
    // A shrinking viewport/content may clamp scrollTop; that is not user input.
    if (following && top < lastTop - 2 && lastTop <= maximum() + 2) pause();
    else if (!following && atEnd()) {
      following = true;
      schedule();
    }
    lastTop = top;
  };
  const onWheel = event => {
    if (event.deltaY < 0 && element.scrollTop > 0) pause();
  };
  const onTouchStart = event => { touchY = event.touches?.[0]?.clientY ?? null; };
  const onTouchMove = event => {
    const y = event.touches?.[0]?.clientY;
    if (touchY !== null && typeof y === "number" && y > touchY + 3 && element.scrollTop > 0) pause();
  };
  const onTouchEnd = () => { touchY = null; };
  const onKey = event => {
    const target = event.target;
    if (target?.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(target?.tagName || "")) return;
    if (["ArrowUp", "PageUp", "Home"].includes(event.key) || (event.key === " " && event.shiftKey)) {
      if (element.scrollTop > 0) pause();
    }
  };
  const resize = typeof view.ResizeObserver === "function"
    ? new view.ResizeObserver(schedule) : null;
  const syncChildren = () => {
    if (!resize) return;
    const children = new Set(element.children);
    for (const child of observed) {
      if (!children.has(child)) { resize.unobserve(child); observed.delete(child); }
    }
    for (const child of children) {
      if (!observed.has(child)) { observed.add(child); resize.observe(child); }
    }
  };
  const refresh = () => { if (!disposed) { syncChildren(); schedule(); } };
  const mutations = typeof view.MutationObserver === "function"
    ? new view.MutationObserver(refresh) : null;
  resize?.observe(element);
  syncChildren();
  mutations?.observe(element, {
    childList: true, subtree: true, characterData: true, attributes: true,
    attributeFilter: ["src", "class", "style", "hidden", "width", "height"]
  });
  element.addEventListener("scroll", onScroll, {passive: true});
  element.addEventListener("wheel", onWheel, {passive: true});
  element.addEventListener("touchstart", onTouchStart, {passive: true});
  element.addEventListener("touchmove", onTouchMove, {passive: true});
  element.addEventListener("touchend", onTouchEnd, {passive: true});
  element.addEventListener("touchcancel", onTouchEnd, {passive: true});
  element.addEventListener("keydown", onKey);
  // Capture load/error because image load does not bubble. Child ResizeObserver
  // also catches cached images, file metadata and font layout changes.
  element.addEventListener("load", schedule, true);
  element.addEventListener("error", schedule, true);
  view.addEventListener?.("resize", schedule);
  view.visualViewport?.addEventListener("resize", schedule);
  const fonts = element.ownerDocument?.fonts;
  fonts?.addEventListener?.("loadingdone", schedule);
  bottom();
  schedule();

  return {
    element,
    refresh,
    dispose() {
      if (disposed) return;
      disposed = true;
      if (frame !== null) cancelFrame(frame);
      frame = null;
      resize?.disconnect();
      mutations?.disconnect();
      observed.clear();
      element.removeEventListener("scroll", onScroll);
      element.removeEventListener("wheel", onWheel);
      element.removeEventListener("touchstart", onTouchStart);
      element.removeEventListener("touchmove", onTouchMove);
      element.removeEventListener("touchend", onTouchEnd);
      element.removeEventListener("touchcancel", onTouchEnd);
      element.removeEventListener("keydown", onKey);
      element.removeEventListener("load", schedule, true);
      element.removeEventListener("error", schedule, true);
      view.removeEventListener?.("resize", schedule);
      view.visualViewport?.removeEventListener("resize", schedule);
      fonts?.removeEventListener?.("loadingdone", schedule);
      element.style.overflowAnchor = previousAnchor;
      element.style.scrollBehavior = previousBehavior;
    }
  };
}

export function useSupportBottomV408(React, scrollRef, channel) {
  const controller = React.useRef(null);
  // Run after every committed render to also handle a replaced message pane.
  React.useLayoutEffect(() => {
    const element = scrollRef.current;
    if (controller.current?.element !== element || controller.current?.channel !== channel) {
      controller.current?.dispose();
      controller.current = element && channel
        ? {...createSupportBottomAnchor(element), channel} : null;
    }
    controller.current?.refresh();
  });
  React.useLayoutEffect(() => () => {
    controller.current?.dispose();
    controller.current = null;
  }, []);
}
